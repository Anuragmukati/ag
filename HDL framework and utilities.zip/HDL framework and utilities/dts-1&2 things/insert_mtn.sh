#/bin/bash
gcloud config set project vz-it-pr-gk1v-edwpr-0
bq query --use_legacy_sql=false \
	'Delete from  `vz-it-pr-gk1v-edwdo-0.udm_prd_tbls.mtn_xref_dly_hist` where 1=1;'

bq query --use_legacy_sql=false \
	'INSERT INTO `vz-it-pr-gk1v-edwdo-0`.udm_prd_tbls.mtn_xref_dly_hist(mtn,eff_dt,exp_dt,curr_prev_ind	,sor_id,cust_id,cust_line_seq_id,mtn_act_dt,line_term_dt,mtn_status_ind,mkt_cd,acct_num,area_cd,insert_dt,last_upd_dt,ln_id_type,ln_of_svc_id_no_p1,ln_of_svc_id_no_p2) select cast(int64_field_0 as string),date_field_1,date_field_2,trim(string_field_3), trim(string_field_4), cast(int64_field_5 as string), cast(int64_field_6 as string), date_field_7, date_field_8, trim(string_field_9), trim(string_field_10), cast(int64_field_11 as string), trim(string_field_12), date_field_13,date_field_14,trim(string_field_15), cast(int64_field_16 as string), cast(int64_field_17 as string) from `vz-it-pr-gk1v-edwpr-0`.udm_prdstg_tbls.mtn_xref_dly_hist_30 where date_field_2 <= "2021-12-31"'


bq query --use_legacy_sql=false \
        'INSERT INTO `vz-it-pr-gk1v-edwdo-0`.udm_prd_tbls.mtn_xref_dly_hist(mtn,eff_dt,exp_dt,curr_prev_ind     ,sor_id,cust_id,cust_line_seq_id,mtn_act_dt,line_term_dt,mtn_status_ind,mkt_cd,acct_num,area_cd,insert_dt,last_upd_dt,ln_id_type,ln_of_svc_id_no_p1,ln_of_svc_id_no_p2) select cast(int64_field_0 as string),date_field_1,date_field_2,trim(string_field_3), trim(string_field_4), cast(int64_field_5 as string), cast(int64_field_6 as string), date_field_7, date_field_8, trim(string_field_9), trim(string_field_10), cast(int64_field_11 as string), trim(string_field_12), date_field_13,date_field_14,trim(string_field_15), cast(int64_field_16 as string), cast(int64_field_17 as string) from `vz-it-pr-gk1v-edwpr-0`.udm_prdstg_tbls.mtn_xref_dly_hist_30 where date_field_2 > "2021-12-31"'

bq query --use_legacy_sql=false \ 
	'drop table `vz-it-pr-gk1v-edwpr-0`.udm_prdstg_tbls.mtn_xref_dly_hist_30;'

gsutil rm -r gs://gk1v-prod-edwpr-0-usre-inbound/td2bq/mtn_xref_dly_hist/*
