import sqlalchemy
from datetime import datetime
from functools import reduce
import logging
import traceback
import sys
import json
import teradatasql
import oracledb
import base64
import pandas as pd
from airflow.models import TaskInstance
from airflow.models import XCom
from airflow.utils.task_group import TaskGroup
from airflow.utils.state import State
from airflow.decorators import task
from airflow.providers.google.cloud.operators.bigquery import BigQueryInsertJobOperator
from airflow.operators.python import BranchPythonOperator
from airflow.exceptions import AirflowSkipException, AirflowFailException
from airflow.operators.empty import EmptyOperator
from airflow.operators.python_operator import PythonOperator
from airflow.providers.google.cloud.hooks.gcs import GCSHook
from airflow.providers.google.cloud.operators.dataproc import DataprocCreateBatchOperator, DataprocSubmitJobOperator
from airflow.providers.google.cloud.hooks.dataproc import DataprocHook
from airflow.models import DagRun
from airflow.models import XCom
from airflow.utils.session import create_session
from google.cloud import secretmanager
import pendulum
from google.cloud import storage
from datetime import date
from google.cloud import bigquery
from functools import reduce

from datetime import datetime
from airflow.models import Variable
from airflow.exceptions import AirflowSkipException
from airflow.models import TaskInstance
from airflow.providers.google.cloud.hooks.bigquery import BigQueryHook
from airflow.providers.google.cloud.hooks.dataproc import DataprocHook
from airflow.providers.google.cloud.hooks.gcs import GCSHook
from airflow.exceptions import AirflowSkipException, AirflowFailException
from google.cloud import storage
from datetime import date
from google.cloud import bigquery
from functools import reduce
import logging
import traceback
import sys
import json
import teradatasql
import oracledb
import base64
import pandas as pd
from datetime import date, timedelta, timezone, tzinfo
import pendulum
from airflow.models import XCom
from airflow.utils.session import create_session
from google.cloud import secretmanager
import re


class CustomTaskGroupBQToJDBCLoader(TaskGroup):

    def __init__(self, group_id, metadataParams, variables, serverless,varMap, dagId, projectDetails, tz,
                 opsgenie_priority,jdbc_check_load_status,alertTeamName=None, sub_lob_alert =None, **kwargs):
        super().__init__(group_id=group_id, **kwargs)
        self.groupId = group_id
        self.metadataParams = metadataParams
        self.variables = variables
        self.varMap = varMap
        self.dagId = dagId
        self.projectDetails = projectDetails
        self.tz = tz
        self.opsgenie_priority = opsgenie_priority
        self.serverless = serverless
        self.alertTeamName = alertTeamName
        self.jdbc_check_load_status = jdbc_check_load_status
        self.sub_lob_alert = sub_lob_alert
        self.custom_labels = kwargs['custom_labels'] if 'custom_labels' in kwargs else None


    def preLoadBqToJDBC(self, **context):
        import bq_to_jdbc_loader
        from bq_to_jdbc_loader import bq_to_jdbc_load
        project_id = self.variables["projectId"]
        PYSPARK_JOB,region = bq_to_jdbc_loader.bq_to_jdbc_load(context, self.metadataParams, self.variables, self.varMap, self.dagId, self.projectDetails, self.tz, self.opsgenie_priority,self.custom_labels)
        print("1234",PYSPARK_JOB)
        print(type(PYSPARK_JOB))
        context['ti'].xcom_push(key='pyspark_job_config_xcom', value=PYSPARK_JOB)
        context['ti'].xcom_push(key='region_xcom', value=region)
        context['ti'].xcom_push(key='project_id_xcom', value=project_id)
    
    def obsgenieAndLogs(self, **context):
        import bq_to_jdbc_loader
        from bq_to_jdbc_loader import getObsParams,sendObsLogs,get_secret_from_sm,auditTableEntry
        from ops_genie import send_alert_to_opsgenie
        logicalDate = context['logical_date']
        task_instance_state = (TaskInstance(context['dag'].get_task(f"{self.groupId}.dataproc_task"), logicalDate)).current_state()

        dict_obs = context['ti'].xcom_pull(key="dict_obs",task_ids="startTask")
        if dict_obs is None:
            dict_obs = {}
        project_id = reduce(lambda key, value: key.replace(*value), self.varMap.items(), self.metadataParams["hook"]["projectId"])
        dict_obs = bq_to_jdbc_loader.getObsParams(context, self.metadataParams, self.varMap, dict_obs, self.dagId, project_id, self.tz)
        if str(task_instance_state).lower()== "success":
            error_msg = "NA"
            end_time = str(datetime.now(self.tz).strftime("%Y-%m-%dT%H:%M:%S"))
            run_status = "SUCCESS"
        else:
            error_msg = "Bigquery to JDBC load job Failed"
            logging.error(traceback.format_exc())
            end_time = str(datetime.now(self.tz).strftime("%Y-%m-%dT%H:%M:%S"))
            run_status = "FAILURE"
        target_dbname = reduce(lambda key, value: key.replace(*value), self.varMap.items(), self.metadataParams["hook"]["parameters"]["target_dbname"])
        target_table = self.metadataParams["hook"]["parameters"]["target_table"]
        project_tag = self.projectDetails[0]
        business_line = self.projectDetails[1]
        project_space = self.projectDetails[2]
        db_config = self.variables[project_tag + '_db_config_bq_jdbc'][business_line] if business_line is not None else self.variables[
        project_tag + '_db_config_bq_jdbc']
        target_dbtype = (self.metadataParams["hook"]["parameters"]["target_dbtype"].lower())
        target_dbtype = (self.metadataParams["hook"]["parameters"]["target_dbtype"].lower()).replace("teradata_v20", "teradata")
        db_instance = self.metadataParams["hook"]["parameters"]["dbinstance"].lower() if "dbinstance" in self.metadataParams["hook"]["parameters"] else "default"
    
        db_config = db_config[target_dbtype][db_instance]
        host_name = db_config['host_name']
        secret_name = db_config["secret_name"]
        dpHook = DataprocHook(gcp_conn_id=self.variables[self.metadataParams["hook"]["gcp_conn_id"]])
        payload=bq_to_jdbc_loader.get_secret_from_sm(project_id,secret_name,dpHook)
        username,password = payload.strip().split(':')
        username = username.strip()
        password = password.strip()
        logs=bq_to_jdbc_loader.sendObsLogs(self.metadataParams, self.variables,dict_obs, run_status, end_time, target_dbname, error_msg, target_table, host_name, username, password, project_space, self.tz)
        if 'query' in self.metadataParams["hook"]["parameters"]:
            query = self.metadataParams["hook"]["parameters"]["query"] 
            query = reduce(lambda key, value: key.replace(*value), self.varMap.items(), query)
            print("load query is: ", query)
            source_table = ""
        elif 'source_table' in self.metadataParams["hook"]["parameters"]:
            source_table = self.metadataParams["hook"]["projectId"]+"."+self.metadataParams["hook"]["parameters"]["source_table"] 
            source_table = reduce(lambda key, value: key.replace(*value), self.varMap.items(), source_table)
            query = ""
        if run_status == "FAILURE":
            task_instance =context['task_instance']
            opsgenie_message = "Beamx|"+self.variables["environment"]+"|Failure|"+task_instance.task_id+"|"+ dict_obs['running_instance_id']
            opsgenie_description = "Failure |BQ to JDBC load failed|" + dict_obs['running_instance_id']
            #opsgenie_message = variables["environment"]+" Alert | BQ to JDBC load failed"
            #opsgenie_description = "BQ to JDBC load failed"
            if 'query' in self.metadataParams["hook"]["parameters"]:
                opsgenie_details = {"DAG ID": self.dagId, "Error Step": "Batch Load from BQ to JDBC", "Query": query, "Target Table": f"{target_dbname}.{target_table}", "Error Message": error_msg}
            else:
                opsgenie_details = {"DAG ID": self.dagId, "Error Step": "Batch Load from BQ to JDBC", "Source Table": source_table, "Target Table": f"{target_dbname}.{target_table}", "Error Message": error_msg}
            send_alert_to_opsgenie(opsgenie_message, opsgenie_description, opsgenie_details, self.opsgenie_priority, projectDetails=self.projectDetails,sub_lob_alert=self.sub_lob_alert)

        # audit_flag = "yes"
        # if "audit_flag" in self.metadataParams["hook"]["parameters"]:
        #     audit_flag = self.metadataParams["hook"]["parameters"]["audit_flag"].lower()

        # if self.metadataParams["hook"]["parameters"]["target_dbtype"].lower() == "teradata" and audit_flag == "yes":
        #     bq_to_jdbc_loader.auditTableEntry(self.metadataParams, self.variables, self.varMap, logs, host_name, username, password, target_table, self.dagId)

    def bqtojdbc_beamx_audit(self, **context):
        import bq_to_jdbc_loader
        from bq_to_jdbc_loader import getObsParams,sendObsLogs,get_secret_from_sm,auditTableEntry
        logicalDate = context['logical_date']
        task_instance_state = (TaskInstance(context['dag'].get_task(f"{self.groupId}.dataproc_task"), logicalDate)).current_state()
        target_dbname = reduce(lambda key, value: key.replace(*value), self.varMap.items(), self.metadataParams["hook"]["parameters"]["target_dbname"])
        target_table = self.metadataParams["hook"]["parameters"]["target_table"]
        project_tag = self.projectDetails[0]
        business_line = self.projectDetails[1]
        project_space = self.projectDetails[2]
        db_config = self.variables[project_tag + '_db_config_bq_jdbc'][business_line] if business_line is not None else self.variables[project_tag + '_db_config_bq_jdbc']
        target_dbtype = (self.metadataParams["hook"]["parameters"]["target_dbtype"].lower())
        target_dbtype = (self.metadataParams["hook"]["parameters"]["target_dbtype"].lower()).replace("teradata_v20", "teradata")
        db_instance = self.metadataParams["hook"]["parameters"]["dbinstance"].lower() if "dbinstance" in self.metadataParams["hook"]["parameters"] else "default"
        db_config = db_config[target_dbtype][db_instance]
        host_name = db_config['host_name']
        secret_name = db_config["secret_name"]
        secret_name = db_config["secret_name"]
        dict_obs = context['ti'].xcom_pull(key="dict_obs",task_ids="startTask")
        if dict_obs is None:
            dict_obs = {}
        if str(task_instance_state).lower()== "success":
            error_msg = "NA"
            end_time = str(datetime.now(self.tz).strftime("%Y-%m-%dT%H:%M:%S"))
            run_status = "SUCCESS"
        else:
            error_msg = "Bigquery to JDBC load job Failed"
            logging.error(traceback.format_exc())
            end_time = str(datetime.now(self.tz).strftime("%Y-%m-%dT%H:%M:%S"))
            run_status = "FAILURE"
        project_id = reduce(lambda key, value: key.replace(*value), self.varMap.items(), self.metadataParams["hook"]["projectId"])
        dpHook = DataprocHook(gcp_conn_id=self.variables[self.metadataParams["hook"]["gcp_conn_id"]])
        payload=bq_to_jdbc_loader.get_secret_from_sm(project_id,secret_name,dpHook)
        username,password = payload.strip().split(':')
        username = username.strip()
        password = password.strip()
        logs=bq_to_jdbc_loader.sendObsLogs(self.metadataParams, self.variables,dict_obs, run_status, end_time, target_dbname, error_msg, target_table, host_name, username, password, project_space, self.tz)
        audit_flag = "yes"
        if "audit_flag" in self.metadataParams["hook"]["parameters"]:
            audit_flag = self.metadataParams["hook"]["parameters"]["audit_flag"].lower()

        if self.metadataParams["hook"]["parameters"]["target_dbtype"].lower() == "teradata" and audit_flag == "yes":
            bq_to_jdbc_loader.auditTableEntry(self.metadataParams, self.variables, self.varMap, logs, host_name, username, password, target_table, self.dagId)

    def preLoadBqToJDBC_serverless(self, **context):
        import bq_to_jdbc_loader
        from bq_to_jdbc_loader import bq_to_jdbc_load_serverless
        project_id = self.variables["projectId"]
        batch_id, batch, region= bq_to_jdbc_loader.bq_to_jdbc_load_serverless(context, self.metadataParams, self.variables, self.varMap, self.dagId, self.projectDetails, self.tz, self.opsgenie_priority,self.custom_labels)
        print("batch_id",batch_id)
        print("region",region)
        print("batch",batch)
        context['ti'].xcom_push(key='batch_id_xcom', value=batch_id)
        context['ti'].xcom_push(key='batch_xcom', value=batch)
        context['ti'].xcom_push(key='project_id_xcom', value=project_id)
        context['ti'].xcom_push(key='region_xcom', value=region)

    def FailureAlert(self,context):
        projectDetails = self.projectDetails
        projectSpace = projectDetails[2]

        BASE_DIR = "/home/airflow/gcs/dags/" + projectSpace+ "/beamx"
        sys.path.append(f"{BASE_DIR}/utils")

        from common_utility_functions import pushFailureStatus,pushLoadStatusResult
        pushFailureStatus(context)
        pushLoadStatusResult(context, self.group_id, "failure")

    def createTaskGroupStatus(self, **context):
        
        dataprocTaskId = f'{self.group_id}.dataproc_task'
        dataprocTaskRunState = (
            TaskInstance(context['dag'].get_task(dataprocTaskId), context['logical_date'])).current_state()
        
        if str(dataprocTaskRunState).lower() == 'skipped' :
            raise AirflowSkipException("***Dataproc Job Skipped***")
        elif str(dataprocTaskRunState).lower() != 'success' :
            raise AirflowFailException("***Dataproc Job Failed***")

    def createTaskGroup(self):
        projectDetails = self.projectDetails
        projectSpace = projectDetails[2]
        BASE_DIR = "/home/airflow/gcs/dags/{{ projectSpace }}"
        sys.path.append(f"{BASE_DIR}/utils")
        from common_utility_functions import pushFailureStatus

        with self:
            if not self.serverless:

             
                create_dataproc_task = PythonOperator(
                    task_id='create_dataproc_config',
                    python_callable=self.preLoadBqToJDBC,
                    provide_context=True,
                    on_failure_callback=self.FailureAlert
                )

                dataproc_task = DataprocSubmitJobOperator(
                    task_id='dataproc_task',
                    job=f"{{{{ti.xcom_pull(task_ids='{self.groupId}.create_dataproc_config',key='pyspark_job_config_xcom')}}}}",
                    region=f"{{{{ti.xcom_pull(task_ids='{self.groupId}.create_dataproc_config',key='region_xcom')}}}}",
                    project_id=f"{{{{ti.xcom_pull(task_ids='{self.groupId}.create_dataproc_config',key='project_id_xcom')}}}}",
                    gcp_conn_id=self.variables[self.metadataParams["hook"]["gcp_conn_id"]],
                    deferrable=True,
                    request_id=None,
                    retry=None,
                    timeout=None,
                    asynchronous=False,
                    polling_interval_seconds=10,
                    cancel_on_kill=True,
                    wait_timeout=None,
                    on_failure_callback=pushFailureStatus
                )

                observability_prep_python_operator = PythonOperator(
                    task_id='observability_prep_python_operator',
                    python_callable=self.obsgenieAndLogs,
                    provide_context=True,
                    trigger_rule="all_done"
                )

                bqtojdbc_beamx_audit = PythonOperator(
                task_id='bqtojdbc_beamx_audit',
                python_callable=self.bqtojdbc_beamx_audit,
                provide_context=True,
                trigger_rule="all_done"
                )

                task_group_status = PythonOperator(
                    task_id="task_group_status",
                    python_callable=self.createTaskGroupStatus,
                    trigger_rule='all_done',
                    on_failure_callback=pushFailureStatus
                )

                create_dataproc_task >> dataproc_task >> observability_prep_python_operator >> bqtojdbc_beamx_audit >> task_group_status
            else:
                
                create_dataproc_config = PythonOperator(
                    task_id='create_dataproc_config',
                    python_callable=self.preLoadBqToJDBC_serverless,
                    provide_context=True,
                    on_failure_callback=self.FailureAlert
                )

                dataproc_task = DataprocCreateBatchOperator(
                    task_id='dataproc_task',
                    project_id=f"{{{{ti.xcom_pull(task_ids='{self.groupId}.create_dataproc_config',key='project_id_xcom')}}}}",
                    region=f"{{{{ti.xcom_pull(task_ids='{self.groupId}.create_dataproc_config',key='region_xcom')}}}}",
                    batch_id=f"{{{{ti.xcom_pull(task_ids='{self.groupId}.create_dataproc_config',key='batch_id_xcom')}}}}",
                    batch=f"{{{{ti.xcom_pull(task_ids='{self.groupId}.create_dataproc_config',key='batch_xcom')}}}}",
                    request_id=None,
                    retry=None,
                    timeout=None,
                    gcp_conn_id=self.variables[self.metadataParams["hook"]["gcp_conn_id"]],
                    asynchronous=False,
                    deferrable=True,
                    polling_interval_seconds=5,
                    on_failure_callback=pushFailureStatus
                )

                observability_prep_python_operator = PythonOperator(
                    task_id='observability_prep_python_operator',
                    python_callable=self.obsgenieAndLogs,
                    provide_context=True,
                    trigger_rule="all_done"
                )

                bqtojdbc_beamx_audit = PythonOperator(
                task_id='bqtojdbc_beamx_audit',
                python_callable=self.bqtojdbc_beamx_audit,
                provide_context=True,
                trigger_rule="all_done"
                )

                task_group_status = PythonOperator(
                    task_id="task_group_status",
                    python_callable=self.createTaskGroupStatus,
                    trigger_rule='all_done',
                    on_failure_callback=pushFailureStatus
                )

                create_dataproc_config >> dataproc_task >> observability_prep_python_operator >> bqtojdbc_beamx_audit >> task_group_status

            return self