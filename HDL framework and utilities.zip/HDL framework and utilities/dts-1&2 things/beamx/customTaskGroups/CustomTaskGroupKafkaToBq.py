from datetime import datetime
from functools import reduce
import logging
import traceback
import sys
import re
from airflow.models import TaskInstance
from airflow.models import XCom
from airflow.utils.task_group import TaskGroup
from airflow.decorators import task
from airflow.providers.google.cloud.operators.bigquery import BigQueryInsertJobOperator
from airflow.operators.python import BranchPythonOperator
from airflow.exceptions import AirflowSkipException, AirflowFailException
from airflow.operators.empty import EmptyOperator
from airflow.operators.python_operator import PythonOperator
from airflow.providers.google.cloud.hooks.gcs import GCSHook
from google.cloud.dataproc_v1.types import ListJobsRequest
from airflow.providers.google.cloud.operators.dataproc import DataprocSubmitJobOperator
import os
import base64
from datetime import date, timedelta, timezone, tzinfo
from google.cloud import secretmanager


class CustomTaskGroupKafkaToBq(TaskGroup):

    def __init__(self, group_id, metadataParams, variables, varMap, dagId, projectDetails, tz,
                 opsgenie_priority,alertTeamName = None,sub_lob_alert = None, **kwargs):
        super().__init__(group_id=group_id, **kwargs)
        self.groupId = group_id
        self.metadataParams = metadataParams
        self.variables = variables
        self.varMap = varMap
        self.dagId = dagId
        self.projectDetails = projectDetails
        self.tz = tz
        self.opsgenie_priority = opsgenie_priority
        self.alertTeamName=alertTeamName
        self.sub_lob_alert=sub_lob_alert
        self.custom_labels = kwargs['custom_labels'] if 'custom_labels' in kwargs else None
        if "gcp_conn_id" in self.metadataParams["hook"]:
            self.gcp_conn_id=self.variables[self.metadataParams["hook"]["gcp_conn_id"]]
        else:
            self.gcp_conn_id=self.variables["gcp_conn_id"]
   
    
    def preLoadKafkaToBq(self, **context):
        BASE_DIR = "/home/airflow/gcs/dags/" + project_space+ "/beamx"
        sys.path.append(f"{BASE_DIR}/utils")
        import kafka_to_bq_loader
        from kafka_to_bq_loader import kafka_to_bq_load
        project_id = self.variables["projectId"]
        PYSPARK_JOB,region = kafka_to_bq_loader.kafka_to_bq_load(context, self.metadataParams, self.dagId, self.variables, self.varMap, self.tz)
        context['ti'].xcom_push(key='pyspark_job_config_xcom', value=PYSPARK_JOB)
        context['ti'].xcom_push(key='region_xcom', value=region)
        context['ti'].xcom_push(key='project_id_xcom', value=project_id)
        # context['ti'].xcom_push(key='gcp_conn_id_xcom', value=gcp_conn_id)
        # return PYSPARK_JOB
    
    def obsgenieAndLogs(self, **context):
        BASE_DIR = "/home/airflow/gcs/dags/" + project_space+ "/beamx"
        sys.path.append(f"{BASE_DIR}/utils")
        from kafka_to_bq_loader import sendObsLogs
        #task_instance = TaskInstance(task=context['dag'].get_task("dataproc_task"))
        logicalDate = context['logical_date']
        task_instance_state = (TaskInstance(context['dag'].get_task(f"{self.groupId}.dataproc_task"), logicalDate)).current_state()
        if str(task_instance_state).lower().lower() == "failed":
            error_message = ""
            error_msg = "Kafka to Bigquery load job Failed"
            logging.error(traceback.format_exc())
            end_time = str(datetime.now(self.tz).strftime("%Y-%m-%dT%H:%M:%S"))
            run_status = "FAILURE"
        elif str(task_instance_state).lower().lower() == "success":
            error_msg = "NA"
            end_time = str(datetime.now(self.tz).strftime("%Y-%m-%dT%H:%M:%S"))
            run_status = "SUCCESS"

        table_name = self.params["hook"]["table_name"]
        dataset_name = self.params["hook"]["dataset_name"]
        dict_obs = context['ti'].xcom_pull(key=self.dagId,task_ids="startTask")
        dict_obs = dict(dict_obs)
        project_id = self.variables["projectId"]
        logger_name = self.params["obs"]["logger_name"]
        dict_obs["logger_name"] = logger_name   
        sendObsLogs(dict_obs, run_status, end_time, error_msg, table_name,dataset_name,self.variables, project_id)

        if run_status == 'FAILURE':
            from kafka_to_bq_loader import failure_task_alert
            task_instance =context['task_instance']
            alertTeamName = context['alertTeamName'] if 'alertTeamName' in context else None
            dict_obs = context['ti'].xcom_pull(key=self.dagId,task_ids="startTask")
            failure_task_alert(error_msg, self.variables,self.metadataParams,self.opsgenie_priority, self.projectDetails, self.dagId,task_instance,self.alertTeamName,self.sub_lob_alert,dict_obs)
            return {"run_status": "failure", "error_message": "Kafka to BQ load failed...exiting"}

        return {"run_status": "success", "error_message": "none"}

    def FailureAlert(self,context):
        projectDetails = self.projectDetails
        projectSpace = projectDetails[2]

        BASE_DIR = "/home/airflow/gcs/dags/" + projectSpace+ "/beamx"
        sys.path.append(f"{BASE_DIR}/utils")

        from common_utility_functions import pushFailureStatus,pushLoadStatusResult
        pushFailureStatus(context)
        pushLoadStatusResult(context, self.group_id, "failure")

    def createTaskGroupStatus(self, **context):
        
        dataprocTaskId = f'{self.group_id}.dataproc_task'
        dataprocTaskRunState = (
            TaskInstance(context['dag'].get_task(dataprocTaskId), context['logical_date'])).current_state()
        
        if str(dataprocTaskRunState).lower() == 'skipped' :
            raise AirflowSkipException("***Dataproc Job Skipped***")
        elif str(dataprocTaskRunState).lower() != 'success' :
            raise AirflowFailException("***Dataproc Job Failed***")

    def createTaskGroup(self):
        projectDetails = self.projectDetails
        projectSpace = projectDetails[2]
        BASE_DIR = "/home/airflow/gcs/dags/" + projectSpace + "/beamx"
        sys.path.append(f"{BASE_DIR}/utils")
        from common_utility_functions import pushFailureStatus

        with self:

            create_dataproc_config = PythonOperator(
                    task_id='create_dataproc_config',
                    python_callable=self.preLoadKafkaToBq,
                    provide_context=True,
                    on_failure_callback=self.FailureAlert
            )

            dataproc_task = DataprocSubmitJobOperator(
                task_id='dataproc_task',
                job=f"{{{{ti.xcom_pull(task_ids='{self.groupId}.create_dataproc_config',key='pyspark_job_config_xcom')}}}}",
                region=f"{{{{ti.xcom_pull(task_ids='{self.groupId}.create_dataproc_config',key='region_xcom')}}}}",
                project_id=f"{{{{ti.xcom_pull(task_ids='{self.groupId}.create_dataproc_config',key='project_id_xcom')}}}}",
                gcp_conn_id=self.gcp_conn_id,
                deferrable=True,
                on_failure_callback=pushFailureStatus
            )

            observability_prep_python_operator = PythonOperator(
                task_id='observability_prep_python_operator',
                python_callable=self.obsgenieAndLogs,
                provide_context=True,
                trigger_rule="all_done"
            )

            task_group_status = PythonOperator(
                    task_id="task_group_status",
                    python_callable=self.createTaskGroupStatus,
                    trigger_rule='all_done',
                    on_failure_callback=pushFailureStatus
                )
    

            create_dataproc_config >> dataproc_task >> observability_prep_python_operator  >> task_group_status

            return self
