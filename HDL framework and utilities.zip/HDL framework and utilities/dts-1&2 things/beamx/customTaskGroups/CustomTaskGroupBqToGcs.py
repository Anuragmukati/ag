"""
File Name: CustomTaskGroupBqToGcs.py
Desciption: This is a python utility to load data from bigquery table to GCS
"""

from datetime import datetime
from functools import reduce
import logging
import traceback
import sys
import re
from airflow.models import TaskInstance
from airflow.models import XCom
from airflow.utils.task_group import TaskGroup
from airflow.decorators import task
from airflow.providers.google.cloud.operators.bigquery import BigQueryInsertJobOperator
from airflow.operators.python import BranchPythonOperator
from airflow.exceptions import AirflowSkipException, AirflowFailException
from airflow.operators.empty import EmptyOperator
from airflow.operators.python_operator import PythonOperator
from airflow.providers.google.cloud.hooks.gcs import GCSHook

class CustomTaskGroupBqToGcs(TaskGroup):


    def __init__(self, group_id, metadataParams, bucketNameVars,varMap, variables, dagId, projectDetails, tz, opsgenie_priority, ingestionPattern, taskType, last_task=None, superGroupId="", custom_labels=None, alertTeamName=None, sub_lob_alert=None,**kwargs):
        super().__init__(group_id=group_id, **kwargs)
        self.metadataParams = metadataParams
        self.bucketNameVars = bucketNameVars
        self.varMap = varMap
        self.variables = variables
        self.dagId = dagId
        self.projectDetails = projectDetails
        self.tz = tz
        self.opsgenie_priority = opsgenie_priority
        self.ingestionPattern = ingestionPattern
        self.taskType = taskType
        self.alertTeamName = alertTeamName if alertTeamName != "None" else None
        self.sub_lob_alert = sub_lob_alert if sub_lob_alert != "None" else None
        self.custom_labels = custom_labels if custom_labels != "None" else None
        self.last_task = last_task
        self.superGroupId = superGroupId

    def FailureAlertForAudit(self,context):
        projectDetails = self.projectDetails
        projectSpace = projectDetails[2]
        BASE_DIR = "/home/airflow/gcs/dags/" + projectSpace+ "/beamx"
        sys.path.append(f"{BASE_DIR}/utils")
        from common_utility_functions import pushFailureStatus
        from ops_genie import send_alert_to_opsgenie
        #pushFailureStatus(context)
        exception = context.get('exception')
        error_msg = str(exception)
        audit_run_status = "FAILURE"
        opsgenie_message = self.variables.get("environment") + " Alert | BQ to GCS audit insert job failed"
        opsgenie_description = error_msg
        opsgenie_priority = self.metadataParams['hook']['OpsgeniePriority']
        alertTeamName = None
        if self.metadataParams['hook']['alertTeamName'] != None:
            alertTeamName = self.metadataParams['hook']['alertTeamName']
        else:
            alertTeamName = None
        opsgenie_details = {"DAG ID": self.dagId, "Error Step": "BQ to GCS audit insert job failed",
                            "Error message": error_msg}

        send_alert_to_opsgenie(opsgenie_message, opsgenie_description, opsgenie_details, opsgenie_priority,
                                   projectDetails=projectDetails, alertTeamName=self.alertTeamName,sub_lob_alert=self.sub_lob_alert)

    def preLoadBqToGcs(self, **context):
        variables = self.variables
        params = self.metadataParams
        bucketNameVars = self.bucketNameVars
        dagId = self.dagId
        projectDetails = self.projectDetails
        tz = self.tz
        opsgenie_priority = self.opsgenie_priority
        ingestionPattern = self.ingestionPattern
        taskType = self.taskType
        last_task = self.last_task
        superGroupId = self.superGroupId
        custom_labels = self.custom_labels
        alertTeamName = self.alertTeamName
        sub_lob_alert =self.sub_lob_alert
        # get the project details
        project_tag = projectDetails[0]
        business_line = projectDetails[1]
        project_space = projectDetails[2]

        # import the necessary modules
        BASE_DIR = "/home/airflow/gcs/dags/" + project_space+ "/beamx"
        sys.path.append(f"{BASE_DIR}/utils")
        from dynamic_params import checkDynamicParams
        from common_utility_functions import pushFailureStatus
        import tpt_bq_to_td_loader

        # checking and parsing dynamic params
        params = checkDynamicParams(context, params, taskType)
        tableId = params["hook"]["tableId"]

        result = tpt_bq_to_td_loader.preChecksAndJobConfiguration(params, dagId, projectDetails, tz, context, bucketNameVars, variables,
                                         last_task, ingestionPattern, opsgenie_priority, self.group_id,
                                         custom_labels, alertTeamName,sub_lob_alert, taskType)


        xcoms = {'params': params, 'result': result}
        context['ti'].xcom_push(key='preloadresult', value=xcoms)
        print("xcoms : ", xcoms)
        if result['run_status'].lower() == 'failure':
            raise AirflowFailException

    def postLoadGcsToBq(self, **context):
        variables = self.variables
        params = self.metadataParams
        dagId = self.dagId
        projectDetails = self.projectDetails
        tz = self.tz
        taskType = self.taskType
        opsgenie_priority = self.opsgenie_priority
        ingestionPattern = self.ingestionPattern
        superGroupId = self.superGroupId
        projectSpace = projectDetails[2]
        alertTeamName = self.alertTeamName
        sub_lob_alert =self.sub_lob_alert
        # import the necessary modules
        BASE_DIR = "/home/airflow/gcs/dags/" + projectSpace + "/beamx"
        sys.path.append(f"{BASE_DIR}/utils")
        from dynamic_params import checkDynamicParams
        from common_utility_functions import pushFailureStatus
        from tpt_bq_to_td_loader import postLoad

        # checking and parsing dynamic params
        params = checkDynamicParams(context, params, taskType)


        #preLoadResult = context['ti'].xcom_pull(task_ids=f"{self.group_id}.create_config_python_operator",
        #                            key='preloadresult')
        result = postLoad(context, variables, params, projectDetails, dagId, tz, opsgenie_priority,
                 ingestionPattern, self.group_id,alertTeamName,sub_lob_alert)

        xcoms = {'params': params, 'result': result}

    def BqToGcsLoad(self, **context):
        variables = self.variables
        params = self.metadataParams
        bucketNameVars = self.bucketNameVars
        dagId = self.dagId
        projectDetails = self.projectDetails
        tz = self.tz
        opsgenie_priority = self.opsgenie_priority
        alertTeamName = self.alertTeamName
        sub_lob_alert= self.sub_lob_alert
        ingestionPattern = self.ingestionPattern
        taskType = self.taskType
        last_task = self.last_task
        custom_labels = self.custom_labels
        dict_obs = context['ti'].xcom_pull(key='dict_obs')

        #print("variables : ", variables)

        # get the project details
        project_space = projectDetails[2]

        # import the necessary modules
        BASE_DIR = "/home/airflow/gcs/dags/"+ project_space+ "/beamx"
        sys.path.append(f"{BASE_DIR}/utils")
        from dynamic_params import checkDynamicParams
        import egress

        #checking and parsing dynamic params
        params = checkDynamicParams(context, params, taskType)
        result = egress.run_query(context, params, dagId, projectDetails, tz, opsgenie_priority, bucketNameVars, variables, dict_obs, self.group_id)

        xcoms = {'params': params, 'result' : result}
        print("xcoms : ", xcoms)
        print("bq_to_gcs_xcom : ", xcoms)
        context['ti'].xcom_push(key='bq_to_gcs_xcom',value=xcoms)
        job_id = context['ti'].task_id+"_"+context['dag_run'].run_id [:63]
        context['ti'].xcom_push(key='bq_to_gcs_job_id', value=job_id)

        if result['run_status'].lower() == 'failure':
            raise AirflowFailException(result['error_message'])
        if result['run_status'].lower() == 'skipped':
            raise AirflowSkipException


    def branchFunction(self,**context):

        params = self.metadataParams
        result = context['ti'].xcom_pull(task_ids=f"{self.group_id}.bq_to_gcs_load_python_operator",key='bq_to_gcs_xcom')['result']
        if result['run_status'] != 'success' and ("compose" not in params["hook"] or params["hook"]["compose"].lower() == 'false' ):
            return f"{self.group_id}.skip_gcs_compose"
        else:
            return f"{self.group_id}.gcs_compose_python_operator"

    def branchFunctionTPT(self, **context):
        result = context['ti'].xcom_pull(task_ids=f"{self.group_id}.create_config_python_operator",
                                key='preloadresult')['result']
        if result['run_status'] != 'SUCCESS':
            return f"{self.group_id}.skip_bq_load"
        else:
            return f"{self.group_id}.bq_to_gcs_load_bigquery_operator"


    def GcsCompose(self,**context):

        variables = self.variables
        params = self.metadataParams
        bucketNameVars = self.bucketNameVars
        dagId = self.dagId
        projectDetails = self.projectDetails
        tz = self.tz
        opsgenie_priority = self.opsgenie_priority
        alertTeamName = self.alertTeamName
        sub_lob_alert= self.sub_lob_alert
        ingestionPattern = self.ingestionPattern
        taskType = self.taskType
        last_task = self.last_task
        custom_labels = self.custom_labels
        dict_obs = context['ti'].xcom_pull(key='dict_obs')

        # get the project details
        project_space = projectDetails[2]

        # import the necessary modules
        BASE_DIR = "/home/airflow/gcs/dags/" + project_space + "/beamx"
        sys.path.append(f"{BASE_DIR}/utils")
        from dynamic_params import checkDynamicParams
        import egress

        # checking and parsing dynamic params
        params = checkDynamicParams(context, params, taskType)

        try:
           BqToGcsLoadResult = context['ti'].xcom_pull(task_ids=f"{self.group_id}.bq_to_gcs_load_python_operator",key='bq_to_gcs_xcom') ['result']

        except TypeError as e:
            raise AirflowSkipException
        result = egress.compose_files(params, dagId, projectDetails, tz, context, opsgenie_priority, bucketNameVars, variables, dict_obs, self.group_id)
        xcoms = {'params': params, 'result': result}
        print("gcs_compose_xcom : ", xcoms)
        context['ti'].xcom_push(key='gcs_compose_xcom',value=xcoms)


        if result['run_status'].lower() == 'failure':
            raise AirflowFailException(result['error_message'])
        if result['run_status'].lower() == 'skipped':
            raise AirflowSkipException

    def FailureAlert(self,context):
        projectDetails = self.projectDetails
        projectSpace = projectDetails[2]

        BASE_DIR = "/home/airflow/gcs/dags/" + projectSpace+ "/beamx"
        sys.path.append(f"{BASE_DIR}/utils")

        from common_utility_functions import pushFailureStatus,pushLoadStatusResult

        exception = context.get('exceptionbqtogcs_beamx_audit')
        if exception:
            error_msg = str(exception)
            errorDetails = {'error_msg': error_msg, 'run_status': "failure"}
            context['ti'].xcom_push(key=f'{self.group_id}_errorDetails',value = errorDetails )
            pushFailureStatus(context)
            pushLoadStatusResult(context, self.group_id, "failure")

    def FailureAlertTPT(self,context):
        projectDetails = self.projectDetails
        projectSpace = projectDetails[2]

        BASE_DIR = "/home/airflow/gcs/dags/" + projectSpace+ "/beamx"
        sys.path.append(f"{BASE_DIR}/utils")

        from common_utility_functions import pushFailureStatus,pushLoadStatusResult

        exception = context.get('exception')
        if exception:
            error_msg = str(exception)
            run_status = "FAILURE"
            bqtogcsrunstatus = {'error_msg': error_msg, 'run_status': run_status}
            context['ti'].xcom_push(key='bqtogcsrunstatus',value = bqtogcsrunstatus )
            pushFailureStatus(context)
            pushLoadStatusResult(context, self.group_id,'failure')

    def postLoadBqToGcs(self, **context):

        variables = self.variables
        params = self.metadataParams
        dagId = self.dagId
        projectDetails = self.projectDetails
        tz = self.tz
        taskType = self.taskType
        opsgenie_priority = self.opsgenie_priority
        ingestionPattern = self.ingestionPattern
        last_task = self.last_task
        alertTeamName = self.alertTeamName
        sub_lob_alert= self.sub_lob_alert

        project_space = projectDetails[2]
        # import the necessary modules
        BASE_DIR = "/home/airflow/gcs/dags/" + project_space + "/beamx"
        sys.path.append(f"{BASE_DIR}/utils")
        from dynamic_params import checkDynamicParams
        import egress
        from common_utility_functions import pushFailureStatus

        # checking and parsing dynamic params
        params = checkDynamicParams(context, params, taskType)

        try:
            BqToGcsLoadResult = context['ti'].xcom_pull(task_ids=f"{self.group_id}.bq_to_gcs_load_python_operator",key='bq_to_gcs_xcom') ['result']
        except TypeError as e:
            raise AirflowSkipException

        result = egress.postgcs_to_bq_load(context, variables, params, projectDetails, dagId, tz, opsgenie_priority, last_task, ingestionPattern, alertTeamName, sub_lob_alert, BqToGcsLoadResult, self.group_id)

        xcoms = {'params': params, 'result': result}
        print("beamx_audit: ", xcoms)
        context['ti'].xcom_push(key='beamx_audit', value=xcoms)

        if result['run_status'].lower() == 'failure':
            raise AirflowFailException
        if result['run_status'].lower() == 'skipped':
            raise AirflowSkipException

        if result["audit_configuration"] is not None:
           return f"{self.group_id}.bqtogcs_beamx_audit"

    def postLoadGcsCompose(self, **context):

        variables = self.variables
        params = self.metadataParams
        dagId = self.dagId
        projectDetails = self.projectDetails
        tz = self.tz
        taskType = self.taskType
        opsgenie_priority = self.opsgenie_priority
        ingestionPattern = self.ingestionPattern
        last_task = self.last_task
        alertTeamName = self.alertTeamName
        sub_lob_alert= self.sub_lob_alert

        project_space = projectDetails[2]
        # import the necessary modules
        BASE_DIR = "/home/airflow/gcs/dags/" + project_space + "/beamx"
        sys.path.append(f"{BASE_DIR}/utils")
        from dynamic_params import checkDynamicParams
        import egress
        from common_utility_functions import pushFailureStatus

        # checking and parsing dynamic params
        params = checkDynamicParams(context, params, taskType)

        try:
            if "compose" in params["hook"] and params["hook"]["compose"].lower() == "true":
                GcsComposeResult = context['ti'].xcom_pull(task_ids=f"{self.group_id}.gcs_compose_python_operator",key='gcs_compose_xcom') ['result']
            else:
                GcsComposeResult = None
        except TypeError as e:
            raise AirflowSkipException

        result = egress.postgcs_compose(context, variables, params, projectDetails, dagId, tz, opsgenie_priority, last_task, ingestionPattern, alertTeamName, sub_lob_alert, GcsComposeResult, self.group_id)

        xcoms = {'params': params, 'result': result}
        print("beamx_audit: ", xcoms)
        context['ti'].xcom_push(key='beamx_audit', value=xcoms)

        if result['run_status'].lower() == 'failure':
            raise AirflowFailException
        if result['run_status'].lower() == 'skipped':
            raise AirflowSkipException

        if result["audit_configuration"] is not None:
           return f"{self.group_id}.gcs_compose_beamx_audit"

    def taskGroupStatus(self, **context):
        upstreamtaskId = f'{self.group_id}.observability_prep_python_operator'
        upstreamtaskIdRunStatus = (
        TaskInstance(context['dag'].get_task(upstreamtaskId), context['logical_date'])).current_state()
        if str(upstreamtaskIdRunStatus).lower() != 'success':
            raise AirflowSkipException("Upstream job failed")
    
        bqToGCSTaskId = f'{self.group_id}.bq_to_gcs_load_bigquery_operator'
        bqToGCSTaskIdRunState = (
            TaskInstance(context['dag'].get_task(bqToGCSTaskId), context['logical_date'])).current_state()
        if bqToGCSTaskIdRunState.lower() == 'skipped':
            raise AirflowSkipException("skipping as the upstream skipped")
        elif bqToGCSTaskIdRunState.lower() != 'success':
            raise AirflowFailException("BQ to GCS job failed")
        
    def createTaskGroupStatus(self, **context):        
        
        
        bqToGCSTaskId = f'{self.group_id}.bq_to_gcs_load_python_operator'
        composeGCSTaskId = f'{self.group_id}.gcs_compose_python_operator'
        skipComposeTaskId = f'{self.group_id}.skip_gcs_compose'

        bqToGCSTaskIdRunState = (TaskInstance(context['dag'].get_task(bqToGCSTaskId), context['logical_date'])).current_state()
        composeGCSTaskIdRunState = (TaskInstance(context['dag'].get_task(composeGCSTaskId), context['logical_date'])).current_state()
        skipComposeTaskRunStatus = (TaskInstance(context['dag'].get_task(skipComposeTaskId), context['logical_date'])).current_state()

        
        if bqToGCSTaskIdRunState.lower() == 'skipped' :
            raise AirflowSkipException("job skipped as BQ to GCS skipped")
        elif composeGCSTaskIdRunState.lower() == 'skipped' and skipComposeTaskRunStatus.lower() == 'skipped':
            raise AirflowSkipException("job skipped as upstream skipped")
        elif bqToGCSTaskIdRunState.lower()  == 'failed':
            raise AirflowFailException(" BQ to GCS failed")
        elif composeGCSTaskIdRunState.lower() == 'failed':
            raise AirflowFailException(" compose GCS failed")
        elif bqToGCSTaskIdRunState.lower()  == 'upstream_failed' or composeGCSTaskIdRunState.lower()  == 'upstream_failed':
            raise AirflowFailException("Upstream failed")

         
    
                    
    
    def createTaskGroup(self):
        projectDetails = self.projectDetails
        projectSpace = projectDetails[2]
        BASE_DIR = "/home/airflow/gcs/dags/" + projectSpace + "/beamx"
        sys.path.append(f"{BASE_DIR}/utils")
        from common_utility_functions import pushFailureStatus

        with self:
            if "target_gcs_path" in self.metadataParams["hook"] and "target_gcs_bucket" in self.metadataParams["hook"]:
                create_config_python_operator = PythonOperator(
                    task_id='create_config_python_operator',
                    python_callable=self.preLoadBqToGcs,
                    on_failure_callback=pushFailureStatus
                )

                branch_task = BranchPythonOperator(
                    task_id='branch_task',
                    python_callable=self.branchFunctionTPT
                )

                bq_to_gcs_load_bigquery_operator = BigQueryInsertJobOperator(
                    task_id="bq_to_gcs_load_bigquery_operator",
                    deferrable=True,
                    gcp_conn_id=self.variables[self.metadataParams["hook"]["gcp_conn_id"]],
                    on_failure_callback=self.FailureAlertTPT,
                    configuration = f"{{{{ti.xcom_pull(task_ids='{self.group_id}.create_config_python_operator',key='preloadresult')['result']['InsertJobConfig']}}}}"

                )

                skip_bq_load = EmptyOperator(
                    task_id='skip_bq_load'
                )

                observability_prep_python_operator = PythonOperator(
                    task_id='observability_prep_python_operator',
                    python_callable=self.postLoadGcsToBq,
                    trigger_rule='all_done'
                )

                task_group_status = PythonOperator(
                    task_id="task_group_status",
                    python_callable=self.taskGroupStatus,
                    trigger_rule='all_done',
                    on_failure_callback=pushFailureStatus
                )                
                create_config_python_operator >> branch_task >> [bq_to_gcs_load_bigquery_operator,
                                                                 skip_bq_load] >> observability_prep_python_operator >> task_group_status
            else:

                bq_to_gcs_load_python_operator = PythonOperator(
                task_id = 'bq_to_gcs_load_python_operator',
                python_callable = self.BqToGcsLoad,
                on_failure_callback=pushFailureStatus,
                trigger_rule = 'all_success'
                )
                bq_to_gcs_load_python_operator.doc_md=""" Bq to GCS Load"""

                observability_prep_bq_gcs = PythonOperator(
                    task_id = 'observability_prep_bq_gcs',
                    python_callable = self.postLoadBqToGcs,
                    trigger_rule = 'all_success'
                )

                bqtogcs_beamx_audit = BigQueryInsertJobOperator(
                    task_id="bqtogcs_beamx_audit",
                    deferrable=True,
                    gcp_conn_id=self.variables[self.metadataParams["hook"]["gcp_conn_id"]],
                    on_failure_callback=self.FailureAlertForAudit,
                    configuration=f"{{{{ti.xcom_pull(task_ids='{self.group_id}.observability_prep_bq_gcs',key='beamx_audit')['result']['audit_configuration']}}}}"
                )

                branch_task = BranchPythonOperator(
                    task_id='branch_task',
                    python_callable=self.branchFunction
                )

                gcs_compose_python_operator = PythonOperator(
                    task_id = 'gcs_compose_python_operator',
                    python_callable = self.GcsCompose,
                    on_failure_callback=pushFailureStatus,
                )

                skip_gcs_compose = EmptyOperator(
                    task_id='skip_gcs_compose'
                )

                observability_prep_gcs_compose = PythonOperator(
                    task_id = 'observability_prep_gcs_compose',
                    python_callable = self.postLoadGcsCompose,
                    trigger_rule = 'none_skipped'
                )

                gcs_compose_beamx_audit = BigQueryInsertJobOperator(
                    task_id="gcs_compose_beamx_audit",
                    deferrable=True,
                    gcp_conn_id=self.variables[self.metadataParams["hook"]["gcp_conn_id"]],
                    on_failure_callback=self.FailureAlertForAudit,
                    configuration=f"{{{{ti.xcom_pull(task_ids='{self.group_id}.observability_prep_gcs_compose',key='beamx_audit')['result']['audit_configuration']}}}}"

                )
                
                task_group_status = PythonOperator(
                    task_id="task_group_status",
                    python_callable=self.createTaskGroupStatus,
                    trigger_rule='all_done',
                    on_failure_callback=pushFailureStatus
                )

                bq_to_gcs_load_python_operator >> observability_prep_bq_gcs >> bqtogcs_beamx_audit >> branch_task >> [gcs_compose_python_operator, skip_gcs_compose] >> task_group_status

                gcs_compose_python_operator >> observability_prep_gcs_compose >> gcs_compose_beamx_audit >> task_group_status

            return self