"""
File Name: CustomTaskGroupBqTransform.py
Desciption: This is a python utility to load data from jdbc table to bigquery
"""

from datetime import datetime
from functools import reduce
import logging
import traceback
import sys
import re
import json
from airflow.models import TaskInstance
from airflow.models import XCom
from airflow.utils.task_group import TaskGroup
from airflow.decorators import task
from airflow.providers.google.cloud.operators.bigquery import BigQueryInsertJobOperator
from airflow.operators.python import BranchPythonOperator
from airflow.exceptions import AirflowSkipException, AirflowFailException
from airflow.operators.empty import EmptyOperator
from airflow.operators.python_operator import PythonOperator
from airflow.providers.google.cloud.hooks.gcs import GCSHook


class CustomTaskGroupBqTransform(TaskGroup):

    def __init__(self, group_id, metadataParams, bucketNameVars, variables, dagId, projectDetails, tz,
                 opsgenie_priority, ingestionPattern, taskType,alertTeamName=None,sub_lob_alert=None,custom_labels=None, last_task=None, last_task_num=None, superGroupId="",
                 jdbc_check_load_status=None, **kwargs):
        super().__init__(group_id=group_id, **kwargs)
        self.metadataParams = metadataParams
        self.bucketNameVars = bucketNameVars
        self.variables = variables
        # self.group_id = group_id
        self.dagId = dagId
        self.projectDetails = projectDetails
        self.tz = tz
        self.opsgenie_priority = opsgenie_priority
        self.ingestionPattern = ingestionPattern
        self.taskType = taskType
        self.custom_labels = custom_labels if custom_labels != "None" else None
        self.alertTeamName = alertTeamName if alertTeamName != "None" else None
        self.sub_lob_alert = sub_lob_alert if sub_lob_alert != "None" else None
        self.last_task = last_task
        self.last_task_num = last_task_num
        self.superGroupId = superGroupId
        self.jdbc_check_load_status = jdbc_check_load_status

    def FailureAlertForAudit(self,context):
        projectDetails = self.projectDetails
        projectSpace = projectDetails[2]
        BASE_DIR = "/home/airflow/gcs/dags/" + projectSpace+ "/beamx"
        sys.path.append(f"{BASE_DIR}/utils")
        from common_utility_functions import pushFailureStatus
        from ops_genie import send_alert_to_opsgenie
        #pushFailureStatus(context)
        exception = context.get('exception')
        error_msg = str(exception)
        audit_run_status = "FAILURE"
        opsgenie_message = self.variables.get("environment") + " Alert | BQ to BQ audit insert job failed"
        opsgenie_description = error_msg
        opsgenie_priority = self.opsgenie_priority

        opsgenie_details = {"DAG ID": self.dagId, "Error Step": "BQ to BQ audit insert job failed",
                            "Error message": error_msg}

        send_alert_to_opsgenie(opsgenie_message, opsgenie_description, opsgenie_details, opsgenie_priority,
                                   projectDetails=projectDetails, alertTeamName=self.alertTeamName,sub_lob_alert=self.sub_lob_alert)



    def preLoadBqTransform(self, **context):
        variables = self.variables
        params = self.metadataParams
        bucketNameVars = self.bucketNameVars
        dagId = self.dagId
        projectDetails = self.projectDetails
        tz = self.tz
        opsgenie_priority = self.opsgenie_priority
        ingestionPattern = self.ingestionPattern
        taskType = self.taskType
        last_task = self.last_task
        last_task_num = self.last_task_num
        superGroupId = self.superGroupId
        custom_labels = self.custom_labels
        alertTeamName = self.alertTeamName
        sub_lob_alert= self.sub_lob_alert
        dict_obs = context['ti'].xcom_pull(key='dict_obs')

        # get the variable map based on the project
        project_space = projectDetails[2]

        # import the necessary modules
        BASE_DIR = "/home/airflow/gcs/dags/" + project_space+ "/beamx"
        sys.path.append(f"{BASE_DIR}/utils")
        from dynamic_params import checkDynamicParams
        from bq_transformer import preChecksAndJobConfiguration
        from common_utility_functions import pushFailureStatus,getPreviousTaskLoadStatus

        # checking and parsing dynamic params
        params = checkDynamicParams(context, params, taskType)

        # get the load status of the previous tasks
        #load_status = getPreviousTaskLoadStatus(context)
        #if load_status is not None and "failure" in load_status:
        #    raise AirflowSkipException("previous task didn't run and hence skipping the task")

        result = preChecksAndJobConfiguration(params, dagId, projectDetails, tz, context, bucketNameVars, variables,
                                              dict_obs, last_task, ingestionPattern, opsgenie_priority, last_task_num,
                                              superGroupId, custom_labels, alertTeamName,sub_lob_alert, taskType)

        xcoms = {'params': params, 'result': result}
        print("xcoms : ", xcoms)
        print("bq_to_bq_xcom : ", xcoms)
        context['ti'].xcom_push(key='bq_to_bq_xcom', value=xcoms)
        job_id = context['ti'].task_id + "_" + context['dag_run'].run_id[:63]
        context['ti'].xcom_push(key='bq_to_bq_job_id', value=job_id)

        if 'run_status' in result and result['run_status'].lower() == 'failure':
            raise AirflowFailException(result['error_message'])
        if 'run_status' in result and result['run_status'].lower() == 'skipped':
            raise AirflowSkipException



    def postLoadBqTransform(self, **context):

        variables = self.variables
        params = self.metadataParams
        dagId = self.dagId
        projectDetails = self.projectDetails
        tz = self.tz
        taskType = self.taskType
        opsgenie_priority = self.opsgenie_priority
        ingestionPattern = self.ingestionPattern
        last_task = self.last_task
        alertTeamName = self.alertTeamName
        sub_lob_alert= self.sub_lob_alert
        jdbc_check_load_status = self.jdbc_check_load_status

        project_space = projectDetails[2]
        # import the necessary modules
        BASE_DIR = "/home/airflow/gcs/dags/" + project_space + "/beamx"
        sys.path.append(f"{BASE_DIR}/utils")
        from dynamic_params import checkDynamicParams
        from bq_transformer import postLoad
        from common_utility_functions import pushFailureStatus

        # checking and parsing dynamic params
        params = checkDynamicParams(context, params, taskType)

        try:
            preLoadResult = \
            context['ti'].xcom_pull(task_ids=f"{self.group_id}.create_config_python_operator",
                                    key='bq_to_bq_xcom')['result']
        except TypeError as e:
            raise AirflowSkipException
    
        result = postLoad(context, variables, params, projectDetails, dagId, tz, opsgenie_priority, last_task, ingestionPattern,
                 alertTeamName, sub_lob_alert, jdbc_check_load_status, preLoadResult, self.group_id)

        xcoms = {'params': params, 'result': result}
        context['ti'].xcom_push(key='beamx_audit', value=xcoms)

        if result['run_status'].lower() == 'failure':
            raise AirflowFailException
        if result['run_status'].lower() == 'skipped':
            raise AirflowSkipException

        if result["audit_configuration"] is not None:
           return f"{self.group_id}.bqtobq_beamx_audit"

    def branchFunction(self, **context):

        params = self.metadataParams

        if "save_result" in params["hook"] and 'xcom' == params["hook"]["save_result"].lower():
            return f"{self.group_id}.save_bq_result"
        else:
            return f"{self.group_id}.bq_to_bq_load_bigquery_operator"

    def saveBqResult(self, **context):

        project_space = self.projectDetails[2]
        # import the necessary modules
        BASE_DIR = "/home/airflow/gcs/dags/" + project_space + "/beamx"
        sys.path.append(f"{BASE_DIR}/utils")
        from bq_transformer import save_bq_result_xcom
        from common_utility_functions import pushFailureStatus
        variables = self.variables
        params = self.metadataParams

        try:
            preLoadResult = \
            context['ti'].xcom_pull(task_ids=f"{self.group_id}.create_config_python_operator",
                                    key='bq_to_bq_xcom')['result']
        except TypeError as e:
            raise AirflowSkipException

        save_bq_result_xcom(preLoadResult, variables, params, context)

    def FailureAlert(self,context):
        projectDetails = self.projectDetails
        projectSpace = projectDetails[2]

        BASE_DIR = "/home/airflow/gcs/dags/" + projectSpace+ "/beamx"
        sys.path.append(f"{BASE_DIR}/utils")

        from common_utility_functions import pushFailureStatus,pushLoadStatusResult
        from ops_genie import send_alert_to_opsgenie
        exception = context.get('exception')
        error_msg = str(exception)
        if exception:
            bqtobqrunstatus = {'error_msg': error_msg, 'run_status': "failure"}
            context['ti'].xcom_push(key=f'{self.group_id}_run_status',value = bqtobqrunstatus )
            pushFailureStatus(context)
            pushLoadStatusResult(context, self.group_id, "failure")
        run_status = "FAILURE"
        opsgenie_message = self.variables.get("environment") + " Alert | BQ to BQ insert job failed"
        opsgenie_description = error_msg
        opsgenie_priority = self.opsgenie_priority

        opsgenie_details = {"DAG ID": self.dagId, "Error Step": "BQ to BQ insert job failed", "Error message": error_msg}

        send_alert_to_opsgenie(opsgenie_message, opsgenie_description, opsgenie_details, opsgenie_priority, projectDetails=projectDetails, alertTeamName=self.alertTeamName, sub_lob_alert=self.sub_lob_alert)

    def taskGroupStatus(self, **context):

        upstreamtaskId = f'{self.group_id}.bqtobq_beamx_audit'
        upstreamtaskIdRunStatus = (
            TaskInstance(context['dag'].get_task(upstreamtaskId), context['logical_date'])).current_state()
        if str(upstreamtaskIdRunStatus).lower() != 'success':
            raise AirflowSkipException("Upstream job failed")

        bqToBqTaskId = f'{self.group_id}.bq_to_bq_load_bigquery_operator'
        bqToBqTaskIdRunState = (
            TaskInstance(context['dag'].get_task(bqToBqTaskId), context['logical_date'])).current_state()
        saveBqTaskId = f'{self.group_id}.save_bq_result'
        saveBqTaskRunState =(TaskInstance(context['dag'].get_task(saveBqTaskId), context['logical_date'])).current_state()
        if bqToBqTaskIdRunState.lower() == 'skipped' and saveBqTaskRunState.lower() == 'skipped':
            raise AirflowSkipException("skipping as the upstream skipped")
        elif bqToBqTaskIdRunState.lower() != 'success' and bqToBqTaskIdRunState.lower() != 'skipped':
            raise AirflowFailException(" gcs to bq job failed")
        elif saveBqTaskRunState.lower() != 'success' and saveBqTaskRunState.lower() != 'skipped':
            raise AirflowFailException("Save BQ  not successful")

    def createTaskGroup(self):
        projectDetails = self.projectDetails
        projectSpace = projectDetails[2]
        BASE_DIR = "/home/airflow/gcs/dags/" + projectSpace + "/beamx"
        sys.path.append(f"{BASE_DIR}/utils")
        from common_utility_functions import pushFailureStatus

        with self:
            create_config_python_operator = PythonOperator(
                task_id='create_config_python_operator',
                python_callable=self.preLoadBqTransform,
                on_failure_callback = pushFailureStatus
            )
            create_config_python_operator.doc_md=""" Staging to Target BQ Transform and Load"""

            branch_task = BranchPythonOperator(
                task_id='branch_task',
                python_callable=self.branchFunction
            )

            bq_to_bq_load_bigquery_operator = BigQueryInsertJobOperator(
                task_id="bq_to_bq_load_bigquery_operator",
                deferrable=True,
                gcp_conn_id=self.variables[self.metadataParams["hook"]["gcp_conn_id"]],
                on_failure_callback=self.FailureAlert,
                configuration=f"{{{{ ti.xcom_pull(task_ids='{self.group_id}.create_config_python_operator',key='bq_to_bq_xcom')['result']['bqInsertJobConfig'] }}}}"
                #job_id=f"{{{{ ti.xcom_pull(task_ids='{self.group_id}.create_config_python_operator',key='bq_to_bq_job_id') }}}}"
            )

            save_bq_result = PythonOperator(
                task_id='save_bq_result',
                python_callable=self.saveBqResult
            )

            observability_prep_python_operator = BranchPythonOperator(
                task_id='observability_prep_python_operator',
                python_callable=self.postLoadBqTransform,
                trigger_rule='all_done'
            )


            gcstobq_beamx_audit = BigQueryInsertJobOperator(
                task_id="bqtobq_beamx_audit",
                deferrable=True,
                gcp_conn_id=self.variables[self.metadataParams["hook"]["gcp_conn_id"]],
                on_failure_callback=self.FailureAlertForAudit,
                configuration=f"{{{{ti.xcom_pull(task_ids='{self.group_id}.observability_prep_python_operator',key='beamx_audit')['result']['audit_configuration']}}}}"

            )

            task_group_status = PythonOperator(
                task_id="task_group_status",
                python_callable=self.taskGroupStatus,
                trigger_rule='all_done',
                on_failure_callback=pushFailureStatus
            )

            create_config_python_operator >> branch_task >> [bq_to_bq_load_bigquery_operator,
                                                             save_bq_result] >> observability_prep_python_operator >> gcstobq_beamx_audit >> task_group_status
            return self
