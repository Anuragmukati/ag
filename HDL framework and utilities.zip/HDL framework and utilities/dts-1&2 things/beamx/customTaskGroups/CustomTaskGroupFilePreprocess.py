"""
File Name: CustomTaskGroupFilePreprocess.py
Desciption: This is a python utility for creating custom task group job for preprocessing
"""

from datetime import datetime
from functools import reduce
import logging
import traceback
import sys
import re
import json
from airflow.models import TaskInstance
from airflow.models import XCom
from airflow.utils.task_group import TaskGroup
from airflow.decorators import task
from airflow.providers.google.cloud.operators.bigquery import BigQueryInsertJobOperator
from airflow.operators.python import BranchPythonOperator
from airflow.exceptions import AirflowSkipException, AirflowFailException
from airflow.operators.empty import EmptyOperator
from airflow.operators.python_operator import PythonOperator
from airflow.providers.google.cloud.hooks.gcs import GCSHook
import pendulum
import os
import json
import logging
import traceback
import sys
import requests
import pickle
from datetime import datetime
from datetime import date, timedelta, timezone, tzinfo
import google.oauth2.id_token
import google.auth.transport.requests
from airflow.providers.google.cloud.hooks.gcs import GCSHook
from airflow.providers.google.cloud.hooks.dataproc import DataprocHook
from airflow.providers.google.cloud.hooks.functions import CloudFunctionsHook
import base64
import pendulum
from google.cloud import storage
from google.auth import impersonated_credentials
from datetime import datetime
from functools import reduce
import logging
import traceback
import sys
import re
import json
import uuid
import fnmatch
from airflow.models import TaskInstance
from airflow.models import XCom
from airflow.utils.task_group import TaskGroup
from airflow.decorators import task
from airflow.operators.python import BranchPythonOperator
from airflow.exceptions import AirflowSkipException, AirflowFailException
from airflow.operators.empty import EmptyOperator
from airflow.operators.python_operator import PythonOperator
from airflow.providers.google.cloud.hooks.gcs import GCSHook
from airflow.providers.google.cloud.operators.dataproc import DataprocSubmitJobOperator, DataprocCreateBatchOperator


class CustomTaskGroupFilePreprocess(TaskGroup):

    def __init__(self, group_id, metadataParams, bucketNameVars, variables, dagId, projectDetails, tz,
                 opsgenie_priority, ingestionPattern, taskType, sourceFileObject, alertTeamName=None,
                 sub_lob_alert=None, superGroupId="", parallelLoad="false", **kwargs):

        super().__init__(group_id=group_id, **kwargs)
        self.variables = variables
        self.sourceFileObject = sourceFileObject
        self.metadataParams = metadataParams
        self.dagId = dagId
        self.bucketNameVars = bucketNameVars
        self.projectDetails = projectDetails
        self.opsgenie_priority = opsgenie_priority
        self.taskType = taskType
        self.alertTeamName = alertTeamName
        self.sub_lob_alert = sub_lob_alert
        self.tz = tz
        self.superGroupId = superGroupId
        self.ingestionPattern = ingestionPattern
        self.opsgenie_priority = opsgenie_priority
        self.preprocessTriggerRule = "all_done" if "*" in metadataParams['hook']['sourceUris'] and ("bulk load" not in taskType.lower() and 'single_file_pattern' not in metadataParams["hook"]) else "all_success"
        self.parallelLoad = parallelLoad

    def getLabelsDictServerless(self, labelsList, dagId, run_id, task_id, composer_name):
        labels_dict = {
            "job_id": dagId.lower()[-63:],
            "task_type": "preproc_serverless",
            "run_id": re.sub(r'[^A-Za-z0-9 _-]+', '', run_id).lower()[-63:],
            "task_id": task_id.lower().replace('.', "")[-63:],
            "instance_name": composer_name.lower()
        }
        return labels_dict

    def branch_function(self, **context):

        variables = self.variables
        metadataParams = self.metadataParams
        dagId = self.dagId
        sourceFileObject = self.sourceFileObject
        projectDetails = self.projectDetails
        bucketNameVars = self.bucketNameVars
        taskType = self.taskType
        alertTeamName = self.alertTeamName
        sub_lob_alert = self.sub_lob_alert
        tz = self.tz
        superGroupId = self.superGroupId
        ingestionPattern = self.ingestionPattern
        opsgenie_priority = self.opsgenie_priority

        # get the project details
        project_space = projectDetails[2]

        # import the necessary modules
        BASE_DIR = "/home/airflow/gcs/dags/" + project_space + "/beamx"
        sys.path.append(f"{BASE_DIR}/utils")
        import bq_loader
        import file_preprocessing
        from file_preprocessing import preprocessing_control_file
        from dynamic_params import checkDynamicParams
        from common_utility_functions import pushFailureStatus
        from file_preprocessing import preProcessingOnDataproc, untar, checkfilesize, checkFileCompression, fileUnzip, \
            preprocessing_control_file

        # checking and parsing dynamic params
        metadataParams = checkDynamicParams(context, metadataParams, taskType)

        sourceBucket = bucketNameVars["SOURCE_URI_BUCKET"].split("/")[-1]
        processBucket = bucketNameVars["PROCESS_BUCKET"].split("/")[-1]
        pp_status = 'none'
        alertTeamName = alertTeamName
        sub_lob_alert = sub_lob_alert
        # get the variable map based on the project
        projectTag = projectDetails[0]
        projectSpace = projectDetails[2]
        varMap = variables[projectTag + "_vars"]
        fileCompressionType = "no match"

        dict_obs = context['ti'].xcom_pull(key='dict_obs')
        sourceFileObject = bq_loader.replaceParametersWithRunDate(sourceFileObject, context, metadataParams, tz)
        gcp_conn_id = variables[metadataParams["hook"]["gcp_conn_id"]]
        gcs_hook = GCSHook(gcp_conn_id=gcp_conn_id)
        project = gcs_hook._get_field("project")
        storage_client = storage.Client(credentials=gcs_hook.get_credentials())
        bucket = storage_client.bucket(sourceBucket)
        print("Source file object  is : ", sourceFileObject)
        if 'single_file_pattern' in metadataParams["hook"]:
            singleLoadFileList = gcs_hook.list(bucket_name=sourceBucket,
                                               match_glob=sourceFileObject)
            if singleLoadFileList is not None or len(singleLoadFileList) != 0:
                for blob_obj in singleLoadFileList:
                    sourceFileObject = blob_obj
                    blob = bucket.get_blob(blob_name=sourceFileObject)
                    break

        context['ti'].xcom_push(key=self.group_id.replace("preprocess_","")+'_sourceFileObject', value=sourceFileObject)
        if "*" in metadataParams['hook']['sourceUris'] and ("bulk load" not in self.taskType.lower() and 'single_file_pattern' not in metadataParams["hook"]):
            # If the file is a placeholder file, skip the tasks
            dummyFileCheck = bq_loader.checkFilePresence(context, bucketNameVars, variables, sourceFileObject, metadataParams, projectDetails, dagId, tz, dict_obs, opsgenie_priority, taskType, self.parallelLoad)
            if dummyFileCheck['run_status'] == 'skipped':
                xcoms = {'params': metadataParams, 'run_status': 'skipped'}
                context['ti'].xcom_push(key='gcs_to_bq_xcom', value=xcoms)
                raise AirflowSkipException

        # create a gcs hook to connect to gcs and get credentials
        gcp_conn_id = variables[metadataParams["hook"]["gcp_conn_id"]]
        gcs_hook = GCSHook(gcp_conn_id=gcp_conn_id)
        project = gcs_hook._get_field("project")

        matches = list(re.finditer('_', str(dagId)))
        start_index = matches[2].end()
        prefixdag_id = str(dagId)[start_index:]
        prefix_job_id = (prefixdag_id.lower() + str(self.group_id))[-40:]
        job_id = prefix_job_id + str(
            ''.join(re.findall(r'\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}', context['ti'].run_id.split('__', 1)[1]))) \
            .replace(".", "-").replace(":", "-").replace("__", "-").lower()
        print("job id is", job_id)

        if "cntrl_file" in metadataParams["hook"]:
            controlFile = metadataParams["hook"]["cntrl_file"]
            controlFileObject = bq_loader.replaceParametersWithRunDate(controlFile, context, metadataParams, tz)
            context['ti'].xcom_push(key='controlFileObject', value=controlFileObject)
            preprocessing_control_file(context, bucketNameVars, variables, controlFileObject, metadataParams, dagId,
                                       projectDetails, opsgenie_priority, self.group_id, tz=tz, taskType=taskType,
                                       sub_lob_alert=sub_lob_alert)

        if "*" in metadataParams['hook']['sourceUris'] and "bulk load" not in self.taskType.lower() and 'single_file_pattern' not in metadataParams["hook"]:
            # update the processed file list with the current source file name
            if self.parallelLoad == 'false':
                processedFileList = context['ti'].xcom_pull(key='processed_file_list')
                processedFileList.append(sourceFileObject)
                processedFileList = context['ti'].xcom_push(key='processed_file_list', value=processedFileList)
            else:
                processedFileList=[]
                processedFileList.append(sourceFileObject)
                processedFileList = context['ti'].xcom_push(key=self.group_id.replace("preprocess_", "")+'_processed_file_list', value=processedFileList)

        storage_client = storage.Client(credentials=gcs_hook.get_credentials())
        bucket = storage_client.bucket(sourceBucket)
        blob = None
        fileSizeCombined = 0
        if "bulk load" in self.taskType.lower():
            prefix = sourceFileObject.rsplit('/', 1)[0] if "/" in sourceFileObject else ""
            bulkLoadFileList = gcs_hook.list(bucket_name=sourceBucket, prefix=prefix, match_glob=sourceFileObject)
            print("bulkLoadFileList : ", bulkLoadFileList)
            exclude_file =[]
            if 'hook' in metadataParams:
                print("exclude file check")
                if 'exclude_file' in metadataParams['hook']:
                    exclude_file = metadataParams['hook']['exclude_file']
                    print("exclude_file pattern is:",exclude_file)
                    bulkLoadFileList = [file for file in bulkLoadFileList if not any(fnmatch.fnmatch(file, f"*{excluded}*") for excluded in exclude_file)]
                    print("bulkLoadFileList after excluding files : ", bulkLoadFileList)
            bulkLoadfilelistFinal = []
            for bulk_file in bulkLoadFileList:
                blob = bucket.get_blob(blob_name=bulk_file)
                if blob.size > 4:
                    bulkLoadfilelistFinal.append(bulk_file)
                    fileSizeCombined += blob.size
            print("bulkLoadfilelistFinal which is greater than 4 bytes: ", bulkLoadfilelistFinal)
            print("fileSizeCombined: ", fileSizeCombined)
            context['ti'].xcom_push(key=self.group_id.replace("preprocess_", "") + '_bulk_load_file_list',
                                    value=bulkLoadFileList)
            context['ti'].xcom_push(key=self.group_id.replace("preprocess_", "") + '_bulk_load_file_list_final',
                                    value=bulkLoadfilelistFinal)
            if bulkLoadfilelistFinal is None or len(bulkLoadfilelistFinal) == 0:
                print("No matching file found for bulk load with url - ", sourceFileObject)
                raise AirflowSkipException
            if bulkLoadfilelistFinal is not None or len(bulkLoadfilelistFinal) != 0:
                for blob_obj in bulkLoadfilelistFinal:
                    sourceFileObject = blob_obj
                    blob = bucket.get_blob(blob_name=sourceFileObject)
                    break
        else:
            if 'single_file_pattern' in metadataParams["hook"]:
                singleLoadFileList = gcs_hook.list(bucket_name=sourceBucket,
                                                   match_glob=sourceFileObject)
                if singleLoadFileList is None or len(singleLoadFileList) == 0:
                    print("No matching file found for bulk load with url - ", sourceFileObject)
                    raise AirflowSkipException

                if singleLoadFileList is not None or len(singleLoadFileList) != 0:
                    for blob_obj in singleLoadFileList:
                        sourceFileObject = blob_obj
                        blob = bucket.get_blob(blob_name=sourceFileObject)
                        break
            # checking the source file size in bytes
            blob = bucket.get_blob(blob_name=sourceFileObject)
        if 'abandon_flag' in metadataParams["hook"] and metadataParams["hook"][
            "abandon_flag"].lower() == 'true' and blob is None:
            raise AirflowSkipException
        if blob is not None:
            fileSize = blob.size
            print("file size is", fileSize)
            context['ti'].xcom_push(key=self.group_id.replace("preprocess_","")+'_fileSize', value=fileSize)
        else:
            raise AirflowFailException("File not found. Please check the inbound bucket for matchng sourceUri.")

        if "bulk load" not in self.taskType.lower() and fileSize <= 4:
            raise AirflowSkipException("file size is too small..skipping the process")

        # checking the file compression
        result = checkFileCompression(sourceBucket, variables, sourceFileObject, metadataParams, dagId,
                                      projectSpace,
                                      project)
        fileCompressionType = result['fileCompressionType']
        print("File compression type :", fileCompressionType)
        context['ti'].xcom_push(key=self.group_id.replace("preprocess_", "")+'file_compression_type', value=fileCompressionType)

        print("group_id : ", self.group_id)

        if "bulk load" not in self.taskType.lower() and (
                "skipLeadingRows" in metadataParams["hook"] or "skip_header" in metadataParams[
            "hook"] or "skip_footer" in metadataParams["hook"]) and fileSize <= 1048576:
            if metadataParams["hook"].get("skipLeadingRows", "0") != "0" or metadataParams["hook"].get("skip_header",
                                                                                                       "false").lower() == "true" or \
                    metadataParams["hook"].get("skip_footer", "false").lower() == "true":
                print("checking if the file has only header..")
                result = checkfilesize(sourceBucket, blob, variables, sourceFileObject, metadataParams, dagId,
                                       projectSpace, project, fileCompressionType, self.group_id, context)

        # checking if the source file is a large file
        if (fileSizeCombined < 5368709120 ) and ("bulk load" in str(taskType).lower() and (((sourceFileObject.lower().endswith('.tar.gz') or (sourceFileObject.lower()).endswith('.tar') or (fileCompressionType != "no match") or ("multidelimiter" in metadataParams["hook"] or "colSpecification" in metadataParams["hook"])) and fileSizeCombined < 5368709120) or ((5368709120 < fileSizeCombined < 21474836480) and fileCompressionType == "no match"))) and ((fileCompressionType == "zip" and "multidelimiter" not in metadataParams["hook"] ) or (fileCompressionType != "zip") ):
            print("Preprocessing will be done in CF as the task type is bulk load and meets the CF requirements")
            return f"{self.group_id}.trigger_preprocessing_cloud_function"
        
        elif ((((sourceFileObject.lower().endswith('.tar.gz')
                                                            or (sourceFileObject.lower()).endswith('.tar') or (
                                                                    fileCompressionType != "no match")) and fileSize > 5368709120) or (
                                                                  fileSize > 32212254720) or (("multidelimiter" in
                                                                                               metadataParams[
                                                                                                   "hook"] or "colSpecification" in
                                                                                               metadataParams[
                                                                                                   "hook"]) and fileSize > 209715200 and (
                                                                                                      sourceFileObject.lower().endswith(
                                                                                                          '.tar.gz') or (
                                                                                                      sourceFileObject.lower()).endswith(
                                                                                                  '.tar') or (
                                                                                                              fileCompressionType != "no match"))) or (
                                                                  ("multidelimiter" in metadataParams[
                                                                      "hook"] or "colSpecification" in metadataParams[
                                                                       "hook"]) and fileSize > 1000000000))) or ("multidelimiter" in metadataParams["hook"] and fileCompressionType == "zip"):
            print("large file detected ....pre processing for " + sourceFileObject + " will be done on dataproc...")
            context['ti'].xcom_push(key=f'{self.group_id}_large_file', value=sourceFileObject)
            from bq_loader import getSourceUris
            bucketName = (bucketNameVars["PROCESS_BUCKET"]).split("/")[-1]
            sourceBucket = bucketNameVars["SOURCE_URI_BUCKET"].split("/")[-1]
            processBucket = bucketNameVars["PROCESS_BUCKET"].split("/")[-1]
            bulkLoadFileListDataproc = "None"

            sourceFileObject = context['ti'].xcom_pull(key=self.group_id.replace("preprocess_","")+'_sourceFileObject')
            dict_obs = context['ti'].xcom_pull(key='dict_obs')
            if sourceFileObject.endswith('.tar.gz') or sourceFileObject.endswith('.tar'):
                if "filesToLoad" in metadataParams["hook"]:
                    filesToLoad = metadataParams["hook"]["filesToLoad"]
                    for index in range(len(filesToLoad)):
                        filesToLoad[index] = "gs://" + bucketName + "/" + sourceFileObject + "/" + filesToLoad[index]
                    print("File objects to be loaded after untar:", filesToLoad)
                else:
                    filesToLoad = None
            else:
                filesToLoad = None

            gcs_hook = GCSHook(gcp_conn_id=variables[metadataParams["hook"]["gcp_conn_id"]])
            prefix = sourceFileObject.rsplit('/', 1)[0] if "/" in sourceFileObject else ""
            bulkLoadFileList = gcs_hook.list(bucket_name=sourceBucket, prefix=prefix,
                                             match_glob=sourceFileObject)

            sourceUris = getSourceUris(metadataParams, bucketName, sourceFileObject, filesToLoad, fileCompressionType,
                                       bulkLoadFileList, taskType)
            
            if "bulk load" in str(self.taskType).lower():
                bulkLoadFileListDataproc = "true"
                sourceUris = "gs://process_bucket/file"
                
            # spark application name -- change
            """if "+" in context["dag_run"].run_id:
               job_id = str(dagId).lower()[:26] + str(context["dag_run"].run_id)[0: str(context["dag_run"].run_id).index("+")] \
                .replace(".", "-").replace(":", "-").replace("__", "-").lower()
            else:
                job_id = str(dagId).lower()[:26] + str(context["dag_run"].run_id).rsplit('-', 1)[0] \
                .replace(".", "-").replace(":", "-").replace("__", "-").lower()"""
            job_id = dagId.replace(".", "-").replace(":", "-").replace(" ", "").replace("__", "-").replace("_", "-")[
                     :31].lower().lstrip('-')
            job_id = job_id + str(uuid.uuid4().hex)
            print("job id is", job_id)
            spark_app_name = "preprocessingapp_ " + self.dagId.lower()
            # job_id = dagId.lower() + '_' + str(datetime.now(tz).strftime("%Y%m%d%H%M%S"))
            job_id = job_id.replace("_", "-")[:63]
            job_id = job_id.lower()
            job_id = job_id.lstrip('-')
            cloudFnParams = {"sourceBucket": sourceBucket, "processBucket": processBucket,
                             "variables": variables, "sourceFileObject": sourceFileObject, "params": metadataParams,
                             "dagId": dagId, "opsgenie_priority": opsgenie_priority,
                             "projectSpace": projectSpace, "fileCompressionType": fileCompressionType,
                             "project": project, "sourceUris": sourceUris, "job_id": job_id,
                             "bulkLoadFileListDataproc": bulkLoadFileListDataproc}
            print("cloud fn param ", cloudFnParams)
            cluster_label = variables['dataproc_config_file_preprocessing']['cluster_label']
            dataprocConfigDict = self.variables["dataproc_config_file_preprocessing"]
            temp_bucket = dataprocConfigDict["temp_bucket"]
            # pyspark job properties
            properties = {
                "spark.app.name": spark_app_name,
                "spark.sql.legacy.parquet.int96RebaseModeInRead": "CORRECTED",
                "spark.sql.legacy.parquet.int96RebaseModeInWrite": "CORRECTED",
                "spark.sql.legacy.parquet.datetimeRebaseModeInRead": "CORRECTED",
                "spark.sql.legacy.parquet.datetimeRebaseModeInWrite": "CORRECTED",
                "spark.dynamicAllocation.enabled": "true",
                "spark.dynamicAllocation.initialExecutors": "2",  # // Assuming 4 cores per executor
                "spark.dynamicAllocation.minExecutors": "2",
                # "spark.dynamicAllocation.maxExecutors": "400",
                # "spark.dynamicAllocation.executorAllocationRatio": "1.0",
                # "spark.dynamicAllocation.executorIdleTimeout": "5m",
                # "spark.dynamicAllocation.cachedExecutorIdleTimeout": "5m",
                "spark.redaction.regex": "(?i)secret|password|token|access[.]key",
                "spark.redaction.string.regex":"(?i)secret|password|dbpass|token",
                "spark.hadoop.fs.gs.system.bucket": temp_bucket
            }
            
            if "spark_conf" in metadataParams["hook"]:
                spark_conf = metadataParams["hook"]["spark_conf"]
                if "overwrite_default_properties" in metadataParams["hook"] and metadataParams["hook"][
                    "overwrite_default_properties"] == 'yes':
                    properties = {"spark.app.name": spark_app_name,
                                  "spark.redaction.regex": "(?i)secret|password|token|access[.]key",
                                  "spark.redaction.string.regex":"(?i)secret|password|dbpass|token"}
                    properties.update(spark_conf)
                else:
                    properties.update(spark_conf)
            
            print("Updated properties for spark job:", properties)


            cluster_label = dataprocConfigDict["cluster_label"]
            staging_bucket = dataprocConfigDict["staging_bucket"]
            jar_file_uri = dataprocConfigDict["jar_file_uris"]
            bq_temp_bucket = dataprocConfigDict["temp_bucket"]
            service_account = dataprocConfigDict["service_account"]
            subnetwork_uri = dataprocConfigDict["subnetwork_uri"]
            phs_cluster_path = dataprocConfigDict["phs_cluster_path"]
            serverless_version = str(dataprocConfigDict["serverless_version"])
            kms_key = dataprocConfigDict["kms_key"]
            # kms_key = "projects/vz-it-np-d0sv-vsadkms-0/locations/us-east4/keyRings/vz-it-np-kr-aid/cryptoKeys/vz-it-np-kms-httv"
            region = dataprocConfigDict["region"]

            composer_name = os.getenv('COMPOSER_ENVIRONMENT')

            labels_dict = self.getLabelsDictServerless(None, self.dagId, "run-check", "task-check", composer_name)

            pyspark_job_config = {
                "pyspark_batch": {
                    "main_python_file_uri": variables['dataproc_config_file_preprocessing']['scriptPath'],
                    "args": [str(cloudFnParams)],
                    "jar_file_uris": jar_file_uri
                },
                "labels": labels_dict,
                "runtime_config": {
                    "version": serverless_version,
                    "properties": properties
                },
                "environment_config": {
                    "execution_config": {
                        "service_account": service_account,
                        "subnetwork_uri": subnetwork_uri,
                        "kms_key": kms_key,
                        "staging_bucket": staging_bucket
                        # "kms_key": 'projects/vz-it-np-d0sv-vsadkms-0/locations/us-east4/keyRings/vz-it-np-kr-aid/cryptoKeys/vz-it-np-kms-gk1v'
                    },

                },
            }
            context['ti'].xcom_push(key='pyspark_job_config_xcom', value=pyspark_job_config)
            context['ti'].xcom_push(key='batch_id_xcom', value=job_id)
            context['ti'].xcom_push(key='project_id_xcom', value=project)
            context['ti'].xcom_push(key='region_xcom', value=variables['dataproc_config_file_preprocessing']["region"])

            return f"{self.group_id}.trigger_dataproc_job"

        else:
            print("preprocessing will be done using a cloud function")
            return f"{self.group_id}.trigger_preprocessing_cloud_function"

    def preprocessingCloudFunction(self, **context):
        variables = self.variables
        metadataParams = self.metadataParams
        dagId = self.dagId
        sourceFileObject = self.sourceFileObject
        projectDetails = self.projectDetails
        bucketNameVars = self.bucketNameVars
        taskType = self.taskType
        alertTeamName = self.alertTeamName
        sub_lob_alert = self.sub_lob_alert
        opsgenie_priority = self.opsgenie_priority
        tz = self.tz
        group_id = self.group_id

        # get the project details
        project_space = projectDetails[2]

        # import the necessary modules
        BASE_DIR = "/home/airflow/gcs/dags/" + project_space + "/beamx"
        sys.path.append(f"{BASE_DIR}/utils")
        from dynamic_params import checkDynamicParams
        from file_preprocessing import preprocessing
        from bq_loader import getSourceUris
        from common_utility_functions import pushFailureStatus

        # checking and parsing dynamic params
        metadataParams = checkDynamicParams(context, metadataParams, taskType)

        bucketName = (bucketNameVars["PROCESS_BUCKET"]).split("/")[-1]
        sourceBucket = bucketNameVars["SOURCE_URI_BUCKET"].split("/")[-1]
        processBucket = bucketNameVars["PROCESS_BUCKET"].split("/")[-1]

        sourceFileObject = context['ti'].xcom_pull(key=self.group_id.replace("preprocess_","")+'_sourceFileObject')
        dict_obs = context['ti'].xcom_pull(key='dict_obs')

        if sourceFileObject.endswith('.tar.gz') or sourceFileObject.endswith('.tar'):
            if "filesToLoad" in metadataParams["hook"]:
                filesToLoad = metadataParams["hook"]["filesToLoad"]
                for index in range(len(filesToLoad)):
                    filesToLoad[index] = "gs://" + bucketName + "/" + sourceFileObject + "/" + filesToLoad[index]
                print("File objects to be loaded after untar:", filesToLoad)
            else:
                filesToLoad = None
        else:
            filesToLoad = None

        fileCompressionType = context['ti'].xcom_pull(key=self.group_id.replace("preprocess_", "")+'file_compression_type')
        gcs_hook = GCSHook(gcp_conn_id=variables[metadataParams["hook"]["gcp_conn_id"]])
        prefix = sourceFileObject.rsplit('/', 1)[0] if "/" in sourceFileObject else ""
        if "bulk load" in self.taskType.lower():
            bulkLoadFileList = context['ti'].xcom_pull(
                key=(self.group_id).replace("preprocess_", "") + '_bulk_load_file_list_final')
            print("bulkLoadFileList: ", bulkLoadFileList)
            bulkLoadFileListFinal = bulkLoadFileList.copy()
        else:
            bulkLoadFileList = gcs_hook.list(bucket_name=sourceBucket, prefix=prefix, match_glob=sourceFileObject)
            bulkLoadFileListFinal = bulkLoadFileList.copy()

        if bulkLoadFileList is None or bulkLoadFileList == []:
            raise AirflowSkipException(
                "There is no file to process. Please check that the file is present or size of file is greater than 4 Bytes.")

        sourceUris = getSourceUris(metadataParams, bucketName, sourceFileObject, filesToLoad, fileCompressionType,
                                   bulkLoadFileList, taskType)
        print("bulkLoadFileListFinal:", bulkLoadFileListFinal)

        if "bulk load" in self.taskType.lower():
            result = preprocessing(context, bucketNameVars, variables, sourceFileObject, metadataParams, dagId,
                                   projectDetails, fileCompressionType,
                                   opsgenie_priority, taskType=taskType, alertTeamName=alertTeamName,
                                   sub_lob_alert=sub_lob_alert, tz=tz, sourceUris=sourceUris,
                                   bulkLoadFileListFinal=bulkLoadFileListFinal)
        else:
            result = preprocessing(context, bucketNameVars, variables, sourceFileObject, metadataParams, dagId,
                                   projectDetails, fileCompressionType,
                                   opsgenie_priority, taskType=taskType, alertTeamName=alertTeamName,
                                   sub_lob_alert=sub_lob_alert, tz=tz, sourceUris=sourceUris)

        xcoms = {'params': metadataParams, 'result': result}
        print("xcoms : ", xcoms)
        print("preprocessing_cloud_function : ", xcoms)
        context['ti'].xcom_push(key='preprocessing_cloud_function', value=xcoms)

        if ("udf" in metadataParams["hook"]):
            cloudFnName = metadataParams["hook"]["udf"]

            if ("customUdfArgs" in metadataParams["hook"]):
                customUdfArgs = metadataParams["hook"]["customUdfArgs"]
                invoke_udf(context, bucketNameVars, variables, sourceFileObject, metadataParams, dagId, projectDetails,
                           opsgenie_priority, cloudFnName, dict_obs, customArgs=customUdfArgs,
                           alertTeamName=alertTeamName, sub_lob_alert=sub_lob_alert)
            else:
                invoke_udf(context, bucketNameVars, variables, sourceFileObject, metadataParams, dagId, projectDetails,
                           opsgenie_priority, cloudFnName, dict_obs, alertTeamName=alertTeamName,
                           sub_lob_alert=sub_lob_alert)

        context['ti'].xcom_push(key='preprocessing_run_status', value="success")

    def check_pp_status(self, **context):
        sourceFileObject = context['ti'].xcom_pull(key=self.group_id.replace("preprocess_","")+'_sourceFileObject')
        print("Preprocessing done!")
        context['ti'].xcom_push(key=self.group_id.replace("preprocess_","")+'_sourceFileObject', value=sourceFileObject)

        dataprocTaskId = f'{self.group_id}.trigger_dataproc_job'
        dataprocTaskRunState = (
            TaskInstance(context['dag'].get_task(dataprocTaskId), context['logical_date'])).current_state()

        cloudFnTaskId = f'{self.group_id}.trigger_preprocessing_cloud_function'
        cloudFnTaskRunState = (
            TaskInstance(context['dag'].get_task(cloudFnTaskId), context['logical_date'])).current_state()

        large_file = "yes" if context['ti'].xcom_pull(key=f'{self.group_id}_large_file') is not None else "no"

        if large_file == "yes":
            client_gcs = GCSHook(gcp_conn_id=self.variables[self.metadataParams["hook"]["gcp_conn_id"]]).get_conn()
            processBucket = self.bucketNameVars["PROCESS_BUCKET"].split("/")[-1]
            process_buck = client_gcs.get_bucket(processBucket)
            file_name = str(context['ti'].xcom_pull(key='batch_id_xcom')) + ".json"
            obj_blob = process_buck.blob(file_name)
            if obj_blob.exists():
                file_content = obj_blob.download_as_text()
                data_content = json.loads(file_content)
                data_content = json.loads(data_content)
                print("json data from audit file ", data_content)
                print("json data from audit file type ", type(data_content))

                audit_logs = {}
                if "header_record" in data_content:
                    audit_logs["header_record"] = data_content["header_record"]
                else:
                    audit_logs["header_record"] = None

                if "footer_record_count" in data_content:
                    audit_logs["footer_record_count"] = data_content["footer_record_count"]
                else:
                    audit_logs["footer_record_count"] = None

                if "file_record_count" in data_content:
                    audit_logs["file_record_count"] = data_content["file_record_count"]
                else:
                    audit_logs["file_record_count"] = None

                if "footer_record" in data_content:
                    audit_logs["footer_record"] = data_content["footer_record"]
                else:
                    audit_logs["footer_record"] = None

                context['ti'].xcom_push(key=f'audit_logs', value=audit_logs)

                try:
                    obj_blob.delete()
                except Exception as e:
                    print("file is not deleted")
            else:
                print("file does not exist")

            if dataprocTaskRunState.lower() == 'skipped':
                raise AirflowSkipException("skipping as the upstream skipped")
            elif dataprocTaskRunState.lower() != 'success':
                raise AirflowFailException(" preprocessing failed")
        else:
            if cloudFnTaskRunState.lower() == 'skipped':
                raise AirflowSkipException("skipping as the upstream skipped")
            elif cloudFnTaskRunState.lower() != 'success':
                raise AirflowFailException(" preprocessing failed")

    def preprocessing_udf(self, **context):

        variables = self.variables
        metadataParams = self.metadataParams
        dagId = self.dagId
        sourceFileObject = self.sourceFileObject
        projectDetails = self.projectDetails
        bucketNameVars = self.bucketNameVars
        taskType = self.taskType
        alertTeamName = self.alertTeamName
        sub_lob_alert = self.sub_lob_alert
        opsgenie_priority = self.opsgenie_priority
        tz = self.tz

        # get the project details
        project_space = projectDetails[2]

        # import the necessary modules
        BASE_DIR = "/home/airflow/gcs/dags/" + project_space + "/beamx"
        sys.path.append(f"{BASE_DIR}/utils")
        from dynamic_params import checkDynamicParams
        from udf_invoker import invoke_udf

        sourceFileObject = context['ti'].xcom_pull(key=self.group_id.replace("preprocess_","")+'_sourceFileObject')

        # checking and parsing dynamic params
        metadataParams = checkDynamicParams(context, metadataParams, taskType)

        cloudFnName = metadataParams["hook"]["preProcessUdf"]

        if ("customUdfArgs" in metadataParams["hook"]):
            customUdfArgs = metadataParams["hook"]["customUdfArgs"]
            invoke_udf(context, bucketNameVars, variables, sourceFileObject, metadataParams, dagId, projectDetails,
                       opsgenie_priority, cloudFnName, customArgs=customUdfArgs, alertTeamName=alertTeamName,
                       sub_lob_alert=sub_lob_alert)

        context['ti'].xcom_push(key='preprocessing_run_status', value="success")

    def diagnostics_preprocessing(self):

        variables = self.variables
        metadataParams = self.metadataParams
        dagId = self.dagId
        sourceFileObject = self.sourceFileObject
        projectDetails = self.projectDetails
        bucketNameVars = self.bucketNameVars
        taskType = self.taskType
        alertTeamName = self.alertTeamName
        sub_lob_alert = self.sub_lob_alert
        opsgenie_priority = self.opsgenie_priority
        tz = self.tz
        sourceBucket = bucketNameVars["SOURCE_URI_BUCKET"].split("/")[-1]
        processBucket = bucketNameVars["PROCESS_BUCKET"].split("/")[-1]

        # get the project details
        project_space = projectDetails[2]

        # import the necessary modules
        BASE_DIR = "/home/airflow/gcs/dags/" + project_space + "/beamx"
        sys.path.append(f"{BASE_DIR}/utils")
        from dynamic_params import checkDynamicParams
        from udf_invoker import invoke_udf

        sourceFileObject = context['ti'].xcom_pull(key=self.group_id.replace("preprocess_","")+'_sourceFileObject')

        # checking and parsing dynamic params
        metadataParams = checkDynamicParams(context, metadataParams, taskType)

        result = diagnostics(sourceBucket, processBucket, variables, sourceFileObject, metadataParams, dagId,
                             projectDetails, opsgenie_priority, tz, alertTeamName=alertTeamName,
                             sub_lob_alert=sub_lob_alert)

        xcoms = {'params': metadataParams, 'result': result}
        print("xcoms : ", xcoms)
        print("diagnostics_xcom : ", xcoms)
        context['ti'].xcom_push(key='submit_dataproc_diagnostics', value=xcoms)

        return f"{self.group_id}.trigger_dataproc_job_diagnostics"

    def createTaskGroup(self):
        projectDetails = self.projectDetails
        projectSpace = projectDetails[2]
        BASE_DIR = "/home/airflow/gcs/dags/" + projectSpace + "/beamx"
        sys.path.append(f"{BASE_DIR}/utils")
        from common_utility_functions import pushFailureStatus

        with self:
            if ("preProcessUdf" in self.metadataParams['hook']):
                check_file_size = BranchPythonOperator(
                    task_id='check_file_size',
                    python_callable=self.branch_function,
                    on_failure_callback=pushFailureStatus,
                    trigger_rule=self.preprocessTriggerRule
                )
                preprocessing_udf = PythonOperator(
                    task_id='preprocessing_udf',
                    python_callable=self.preprocessing_udf,
                    on_failure_callback=pushFailureStatus
                )

                trigger_preprocessing_cloud_function = PythonOperator(
                    task_id='trigger_preprocessing_cloud_function',
                    python_callable=self.preprocessingCloudFunction,
                    on_failure_callback=pushFailureStatus
                )

                trigger_dataproc_job = DataprocCreateBatchOperator(
                    task_id='trigger_dataproc_job',

                    region=f"{{{{ti.xcom_pull(task_ids='{self.group_id}.check_file_size', key='region_xcom')}}}}",

                    batch=f"{{{{ti.xcom_pull(task_ids='{self.group_id}.check_file_size',key='pyspark_job_config_xcom')}}}}",
                    batch_id=f"{{{{ti.xcom_pull(task_ids='{self.group_id}.check_file_size',key='batch_id_xcom')}}}}",
                    project_id=f"{{{{ti.xcom_pull(task_ids='{self.group_id}.check_file_size',key='project_id_xcom')}}}}",
                    request_id=None,
                    retry=None,
                    timeout=None,
                    gcp_conn_id=self.variables[self.metadataParams["hook"]["gcp_conn_id"]],
                    asynchronous=False,
                    deferrable=True,
                    polling_interval_seconds=5)

                preprocessing_status = PythonOperator(
                    task_id='preprocessing_status',
                    python_callable=self.check_pp_status,
                    trigger_rule='all_done',
                    on_failure_callback=pushFailureStatus
                )

                preprocessing_udf >> check_file_size >> [trigger_preprocessing_cloud_function,
                                                         trigger_dataproc_job] >> preprocessing_status

            if ("udf" in self.metadataParams['hook']):
                check_file_size = BranchPythonOperator(
                    task_id='check_file_size',
                    python_callable=self.branch_function,
                    on_failure_callback=pushFailureStatus,
                    trigger_rule=self.preprocessTriggerRule
                )
                preprocessing_udf = PythonOperator(
                    task_id='preprocessing_udf',
                    python_callable=self.preprocessing_udf,
                    on_failure_callback=pushFailureStatus
                )

                trigger_preprocessing_cloud_function = PythonOperator(
                    task_id='trigger_preprocessing_cloud_function',
                    python_callable=self.preprocessingCloudFunction,
                    on_failure_callback=pushFailureStatus
                )

                trigger_dataproc_job = DataprocCreateBatchOperator(
                    task_id='trigger_dataproc_job',

                    region=f"{{{{ti.xcom_pull(task_ids='{self.group_id}.check_file_size', key='region_xcom')}}}}",

                    batch=f"{{{{ti.xcom_pull(task_ids='{self.group_id}.check_file_size',key='pyspark_job_config_xcom')}}}}",
                    batch_id=f"{{{{ti.xcom_pull(task_ids='{self.group_id}.check_file_size',key='batch_id_xcom')}}}}",
                    project_id=f"{{{{ti.xcom_pull(task_ids='{self.group_id}.check_file_size',key='project_id_xcom')}}}}",
                    request_id=None,
                    retry=None,
                    timeout=None,
                    gcp_conn_id=self.variables[self.metadataParams["hook"]["gcp_conn_id"]],
                    asynchronous=False,
                    deferrable=True,
                    polling_interval_seconds=5)

                preprocessing_status = PythonOperator(
                    task_id='preprocessing_status',
                    python_callable=self.check_pp_status,
                    trigger_rule='all_done',
                    on_failure_callback=pushFailureStatus
                )

                check_file_size >> [trigger_preprocessing_cloud_function,
                                    trigger_dataproc_job] >> preprocessing_udf >> preprocessing_status

            if ("diagnostics" in self.metadataParams["hook"]["sourceUris"].split("/")):
                check_file_size = BranchPythonOperator(
                    task_id='check_file_size',
                    python_callable=self.branch_function,
                    on_failure_callback=pushFailureStatus,
                    trigger_rule=self.preprocessTriggerRule
                )

                trigger_preprocessing_cloud_function = PythonOperator(
                    task_id='trigger_preprocessing_cloud_function',
                    python_callable=self.preprocessingCloudFunction,
                    on_failure_callback=pushFailureStatus
                )

                trigger_dataproc_job = DataprocCreateBatchOperator(
                    task_id='trigger_dataproc_job',

                    region=f"{{{{ti.xcom_pull(task_ids='{self.group_id}.check_file_size', key='region_xcom')}}}}",

                    batch=f"{{{{ti.xcom_pull(task_ids='{self.group_id}.check_file_size',key='pyspark_job_config_xcom')}}}}",
                    batch_id=f"{{{{ti.xcom_pull(task_ids='{self.group_id}.check_file_size',key='batch_id_xcom')}}}}",
                    project_id=f"{{{{ti.xcom_pull(task_ids='{self.group_id}.check_file_size',key='project_id_xcom')}}}}",
                    request_id=None,
                    retry=None,
                    timeout=None,
                    gcp_conn_id=self.variables[self.metadataParams["hook"]["gcp_conn_id"]],
                    asynchronous=False,
                    deferrable=True,
                    polling_interval_seconds=5)

                preprocessing_diagnostics = PythonOperator(
                    task_id='preprocessing_diagnostics',
                    python_callable=self.diagnostics_preprocessing,
                    on_failure_callback=pushFailureStatus
                )

                trigger_dataproc_job_diagnostics = DataprocSubmitJobOperator(
                    task_id='trigger_dataproc_job_diagnostics',
                    job=f"{{ti.xcom_pull(task_ids='{self.group_id}.preprocessing_diagnostics', key='submit_dataproc_diagnostics')['result']['pysparkJobConfig']}}",
                    region=f"{{ti.xcom_pull(task_ids='{self.group_id}.preprocessing_diagnostics', key='submit_dataproc_diagnostics')['result']['region']}}",
                    gcp_conn_id=self.variables[self.metadataParams["hook"]["gcp_conn_id"]],
                    on_failure_callback=pushFailureStatus
                )

                preprocessing_status = PythonOperator(
                    task_id='preprocessing_status',
                    python_callable=self.check_pp_status,
                    trigger_rule='all_done',
                    on_failure_callback=pushFailureStatus
                )

                check_file_size >> [trigger_preprocessing_cloud_function,
                                    trigger_dataproc_job] >> preprocessing_diagnostics >> trigger_dataproc_job_diagnostics >> preprocessing_status

            else:
                check_file_size = BranchPythonOperator(
                    task_id='check_file_size',
                    python_callable=self.branch_function,
                    on_failure_callback=pushFailureStatus,
                    trigger_rule=self.preprocessTriggerRule
                )

                trigger_preprocessing_cloud_function = PythonOperator(
                    task_id='trigger_preprocessing_cloud_function',
                    python_callable=self.preprocessingCloudFunction,
                    on_failure_callback=pushFailureStatus
                )

                trigger_dataproc_job = DataprocCreateBatchOperator(
                    task_id='trigger_dataproc_job',

                    region=f"{{{{ti.xcom_pull(task_ids='{self.group_id}.check_file_size', key='region_xcom')}}}}",

                    batch=f"{{{{ti.xcom_pull(task_ids='{self.group_id}.check_file_size',key='pyspark_job_config_xcom')}}}}",
                    batch_id=f"{{{{ti.xcom_pull(task_ids='{self.group_id}.check_file_size',key='batch_id_xcom')}}}}",
                    project_id=f"{{{{ti.xcom_pull(task_ids='{self.group_id}.check_file_size',key='project_id_xcom')}}}}",
                    request_id=None,
                    retry=None,
                    timeout=None,
                    gcp_conn_id=self.variables[self.metadataParams["hook"]["gcp_conn_id"]],
                    asynchronous=False,
                    deferrable=True,
                    polling_interval_seconds=5)

                preprocessing_status = PythonOperator(
                    task_id='preprocessing_status',
                    python_callable=self.check_pp_status,
                    trigger_rule='all_done',
                    on_failure_callback=pushFailureStatus
                )

                check_file_size >> [trigger_preprocessing_cloud_function, trigger_dataproc_job] >> preprocessing_status

            return self
