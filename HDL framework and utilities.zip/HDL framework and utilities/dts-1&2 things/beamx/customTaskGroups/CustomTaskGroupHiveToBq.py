from datetime import datetime
from functools import reduce
import logging
import traceback
import sys
import re
from airflow.models import TaskInstance
from airflow.models import XCom
from airflow.utils.task_group import TaskGroup
from airflow.decorators import task
from airflow.providers.google.cloud.operators.bigquery import BigQueryInsertJobOperator
from airflow.operators.python import BranchPythonOperator
from airflow.exceptions import AirflowSkipException, AirflowFailException
from airflow.operators.empty import EmptyOperator
from airflow.operators.python_operator import PythonOperator
from airflow.providers.google.cloud.hooks.gcs import GCSHook

class CustomTaskGroupHiveToBq(TaskGroup):
    def __init__(self, group_id, metadataParams, bucketNameVars, variables, dagId, projectDetails, tz, opsgenie_priority, ingestionPattern, taskType,last_task=None, superGroupId="", custom_labels=None,fileSensorDetails=None, alertTeamName=None, sub_lob_alert=None, last_task_num=None,**kwargs):
        super().__init__(group_id=group_id, **kwargs)
        self.metadataParams = metadataParams
        self.bucketNameVars = bucketNameVars
        # self.group_id = group_id
        self.variables = variables
        self.dagId = dagId
        self.projectDetails = projectDetails
        self.tz = tz
        self.opsgenie_priority = opsgenie_priority
        self.ingestionPattern = ingestionPattern
        self.taskType = taskType
        self.last_task = last_task
        self.last_task_num = last_task_num
        self.superGroupId = superGroupId
        self.custom_labels = custom_labels if custom_labels != "None" else None
        self.fileSensorDetails = fileSensorDetails
        self.alertTeamName = alertTeamName if alertTeamName != "None" else None
        self.sub_lob_alert = sub_lob_alert if sub_lob_alert != "None" else None


    def preLoadHiveToBq(self, **context):
        variables = self.variables
        params = self.metadataParams
        bucketNameVars = self.bucketNameVars
        dagId = self.dagId
        projectDetails = self.projectDetails
        tz = self.tz
        opsgenie_priority = self.opsgenie_priority
        alertTeamName = self.alertTeamName
        sub_lob_alert = self.sub_lob_alert
        ingestionPattern = self.ingestionPattern
        taskType = self.taskType
        last_task = self.last_task
        custom_labels = self.custom_labels
        dict_obs = context['ti'].xcom_pull(key='dict_obs')

        print("variables : ", variables)

        # get the project details
        project_space = projectDetails[2]

        # import the necessary modules
        BASE_DIR = "/home/airflow/gcs/dags/" + project_space + "/beamx"
        sys.path.append(f"{BASE_DIR}/utils")
        from dynamic_params import checkDynamicParams
        from hive_to_bq_loader import preChecksAndInsertJobConfiguration

        # checking and parsing dynamic params
        params = checkDynamicParams(context, params, taskType)

        result = preChecksAndInsertJobConfiguration(context, bucketNameVars, variables, params, projectDetails, dagId, tz, dict_obs, opsgenie_priority,
                   last_task, ingestionPattern, custom_labels=custom_labels)

        xcoms = {'params': params, 'result': result}
        print("xcoms : ", xcoms)
        print("gcs_to_bq_xcom : ", xcoms)
        context['ti'].xcom_push(key='hive_to_bq_xcom', value=xcoms)
        job_id = context['ti'].task_id + "_" + context['dag_run'].run_id[:63]
        context['ti'].xcom_push(key='hive_to_bq_job_id', value=job_id)

        if result['run_status'].lower() == 'failure':
            raise AirflowFailException(result['error_message'])
        if result['run_status'].lower() == 'skipped':
            raise AirflowSkipException

    def branchFunction(self, **context):

        result = context['ti'].xcom_pull(task_ids=f"{self.group_id}.create_config_python_operator", key='hive_to_bq_xcom')[
            'result']
        if result['run_status'] != 'success':
            return f"{self.group_id}.skip_bq_load"
        else:
            return f"{self.group_id}.gcs_to_bq_load_bigquery_operator"

    def FailureAlert(self,context):
        projectDetails = self.projectDetails
        projectSpace = projectDetails[2]

        BASE_DIR = "/home/airflow/gcs/dags/" + projectSpace+ "/beamx"
        sys.path.append(f"{BASE_DIR}/utils")

        from common_utility_functions import pushFailureStatus,pushLoadStatusResult

        exception = context.get('exception')
        if exception:
            error_msg = str(exception)
            run_status = "FAILURE"
            gcstobqrunstatus = {'error_msg': error_msg, 'run_status': run_status}
            context['ti'].xcom_push(key='gcstobqrunstatus',value = gcstobqrunstatus )
            pushFailureStatus(context)
            pushLoadStatusResult(context, self.group_id, "failure")

    def postLoadHiveToBq(self,**context):

        variables = self.variables
        params = self.metadataParams
        dagId = self.dagId
        projectDetails = self.projectDetails
        tz = self.tz
        opsgenie_priority = self.opsgenie_priority
        ingestionPattern = self.ingestionPattern
        last_task = self.last_task
        fileSensorDetails = self.fileSensorDetails
        last_task_num = self.last_task_num
        superGroupId = self.superGroupId
        taskType = self.taskType
        alertTeamName = self.alertTeamName
        sub_lob_alert = self.sub_lob_alert

        # get the project details
        project_space = projectDetails[2]

        # import the necessary modules
        BASE_DIR = "/home/airflow/gcs/dags/" + project_space + "/beamx"
        sys.path.append(f"{BASE_DIR}/utils")
        from dynamic_params import checkDynamicParams
        from hive_to_bq_loader import postLoad

        try:
           preLoadResult = context['ti'].xcom_pull(task_ids=f"{self.group_id}.create_config_python_operator",key='hive_to_bq_xcom') ['result']
           sourceFileName = preLoadResult['sourceFileName']
           dict_obs = preLoadResult['dict_obs']

        except TypeError as e:
            raise AirflowSkipException

        result = postLoad(context, self.group_id, variables, params, projectDetails, dagId, tz, opsgenie_priority,
                          last_task,sourceFileName,dict_obs, ingestionPattern, superGroupId, last_task_num, preLoadResult,alertTeamName,
                          sub_lob_alert, fileSensorDetails)
        xcoms = {'params': params, 'result': result}
        context['ti'].xcom_push(key='beamx_audit', value=xcoms)


        if result['run_status'].lower() == 'failure':
            raise AirflowFailException(result['error_message'])
        if result['run_status'].lower() == 'skipped':
            raise AirflowSkipException

    def createTaskGroupStatus(self, **context):
        
        gcsToBqTaskId = f'{self.group_id}.gcs_to_bq_load_bigquery_operator'
        gcsToBqTaskRunState = (
            TaskInstance(context['dag'].get_task(gcsToBqTaskId), context['logical_date'])).current_state()
        skipTaskId = f'{self.group_id}.skip_bq_load'
        skipTaskRunState = (
            TaskInstance(context['dag'].get_task(skipTaskId), context['logical_date'])).current_state()
        
        if str(gcsToBqTaskRunState).lower() == 'skipped' and str(skipTaskRunState).lower() == 'skipped':
            raise AirflowSkipException("Upstream Skipped")  
        elif str(gcsToBqTaskRunState).lower() != 'skipped' and str(gcsToBqTaskRunState).lower() != 'success':
            raise AirflowFailException("GCS to BQ failed")

    def createTaskGroup(self):
        projectDetails = self.projectDetails
        projectSpace = projectDetails[2]
        BASE_DIR = "/home/airflow/gcs/dags/" + projectSpace + "/beamx"
        sys.path.append(f"{BASE_DIR}/utils")
        from common_utility_functions import pushFailureStatus

        with self:

            create_config_python_operator = PythonOperator(
                task_id='create_config_python_operator',
                python_callable=self.preLoadHiveToBq,
                on_failure_callback=pushFailureStatus
            )

            branch_task = BranchPythonOperator(
                task_id='branch_task',
                python_callable=self.branchFunction
            )

            gcs_to_bq_load_bigquery_operator = BigQueryInsertJobOperator(
                task_id="gcs_to_bq_load_bigquery_operator",
                deferrable=True,
                gcp_conn_id=self.variables[self.metadataParams["hook"]["gcp_conn_id"]],
                on_failure_callback=self.FailureAlert,
                configuration = f"{{{{ti.xcom_pull(task_ids='{self.superGroupId}.create_config_python_operator',key='hive_to_bq_xcom')['result']['bqInsertJobConfig']}}}}"

            )

            skip_bq_load = EmptyOperator(
                task_id='skip_bq_load'
            )

            observability_prep_python_operator = PythonOperator(
                task_id='observability_prep_python_operator',
                python_callable=self.postLoadHiveToBq,
                trigger_rule='all_done'
            )

            task_group_status = PythonOperator(
                    task_id="task_group_status",
                    python_callable=self.createTaskGroupStatus,
                    trigger_rule='all_done',
                    on_failure_callback=pushFailureStatus
                )

            create_config_python_operator >> branch_task >> gcs_to_bq_load_bigquery_operator >> observability_prep_python_operator >> task_group_status

            create_config_python_operator >> branch_task >> skip_bq_load >> observability_prep_python_operator >> task_group_status

            return self