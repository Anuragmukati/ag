from datetime import datetime
from functools import reduce
import logging
import traceback
import sys
import json
import teradatasql
import oracledb
import base64
import pandas as pd
from airflow.models import TaskInstance
from airflow.models import XCom
from airflow.utils.task_group import TaskGroup
from airflow.utils.state import State
from airflow.decorators import task
from airflow.providers.google.cloud.operators.bigquery import BigQueryInsertJobOperator
from airflow.operators.python import BranchPythonOperator
from airflow.exceptions import AirflowSkipException, AirflowFailException
from airflow.operators.empty import EmptyOperator
from airflow.operators.python_operator import PythonOperator
from airflow.providers.google.cloud.hooks.gcs import GCSHook
from airflow.providers.google.cloud.operators.dataproc import DataprocCreateBatchOperator, DataprocSubmitJobOperator
from airflow.providers.google.cloud.hooks.dataproc import DataprocHook
from airflow.models import DagRun
from airflow.models import XCom
from airflow.utils.session import create_session
from google.cloud import secretmanager
import pendulum
from google.cloud import storage
from datetime import date
from google.cloud import bigquery
from functools import reduce
import uuid
from datetime import datetime
from airflow.models import Variable
from airflow.exceptions import AirflowSkipException
from airflow.models import TaskInstance
from airflow.providers.google.cloud.hooks.bigquery import BigQueryHook
from airflow.providers.google.cloud.hooks.dataproc import DataprocHook
from airflow.providers.google.cloud.hooks.gcs import GCSHook
from google.cloud import storage
from datetime import date
from google.cloud import bigquery
from functools import reduce
import logging
import traceback
import sys
import json
import teradatasql
import oracledb
import base64
import pandas as pd
from datetime import date, timedelta, timezone, tzinfo
import pendulum
from airflow.models import XCom
from airflow.utils.session import create_session
from google.cloud import secretmanager
import re
import uuid


class CustomTaskGroupJdbcToBQLoader(TaskGroup):

    def __init__(self, group_id, params, variables, varMap, dagId, projectDetails, tz, jdbc_check_load_status,
                 opsgenie_priority, serverless, alertTeamName=None, sub_lob_alert =None,custom_labels=None, **kwargs):
        super().__init__(group_id=group_id, **kwargs)
        self.groupId = group_id
        self.params = params
        self.variables = variables
        self.varMap = varMap
        self.dagId = dagId
        self.projectDetails = projectDetails
        self.tz = tz
        self.jdbc_check_load_status = jdbc_check_load_status
        self.opsgenie_priority = opsgenie_priority
        self.serverless = serverless
        self.alertTeamName = alertTeamName
        self.sub_lob_alert = sub_lob_alert
        self.custom_labels = kwargs['custom_labels'] if 'custom_labels' in kwargs else None

    def FailureAlert(self,context):
        projectDetails = self.projectDetails
        projectSpace = projectDetails[2]

        BASE_DIR = "/home/airflow/gcs/dags/" + projectSpace+ "/beamx"
        sys.path.append(f"{BASE_DIR}/utils")

        from common_utility_functions import pushFailureStatus,pushLoadStatusResult
        pushFailureStatus(context)
        pushLoadStatusResult(context, self.group_id, "failure")

    """
    Check the result of the previus step ie. readLookUpTable. If not success, send an alert and terminate the job. Else, proceed to bq load step. 
    """
    def FailureAlertForAudit(self,context):
        projectDetails = self.projectDetails
        projectSpace = projectDetails[2]
        BASE_DIR = "/home/airflow/gcs/dags/" + projectSpace+ "/beamx"
        sys.path.append(f"{BASE_DIR}/utils")
        from common_utility_functions import pushFailureStatus
        from ops_genie import send_alert_to_opsgenie
        #pushFailureStatus(context)
        exception = context.get('exception')
        error_msg = str(exception)
        audit_run_status = "FAILURE"
        opsgenie_message = self.variables.get("environment") + " Alert | JDBC TD to BQ audit insert job failed"
        opsgenie_description = error_msg
        opsgenie_priority = self.params['hook']['OpsgeniePriority']
        alertTeamName = None
        if self.params['hook']['alertTeamName'] != None:
            alertTeamName = self.params['hook']['alertTeamName']
        else:
            alertTeamName = None
        opsgenie_details = {"DAG ID": self.dagId, "Error Step": "JDBC TD to BQ audit insert job failed",
                            "Error message": error_msg}

        send_alert_to_opsgenie(opsgenie_message, opsgenie_description, opsgenie_details, opsgenie_priority,
                                   projectDetails=projectDetails, alertTeamName=self.alertTeamName,sub_lob_alert=self.sub_lob_alert)


    def jdbcCheckLoadStatusResult(self, **context):

        dict_obs = context['ti'].xcom_pull(key="dict_obs",
                                           task_ids="startTask")
        # import the necessary modules
        project_space = self.projectDetails[2]
        BASE_DIR = "/home/airflow/gcs/dags/" + project_space + "/beamx"
        sys.path.append(f"{BASE_DIR}/utils")
        from ops_genie import send_alert_to_opsgenie
        alertTeamName = self.alertTeamName
        sub_lob_alert= self.sub_lob_alert
        task_instance = context['task_instance']
        retries = task_instance.max_tries
        source_table = self.params["hook"]["lookup_table"]
        upstreamTaskId = next(iter(context['task'].upstream_task_ids))
        print("upstream task id is :", upstreamTaskId)
        prevTaskRunState = (
            TaskInstance(context['dag'].get_task(upstreamTaskId), context['logical_date'])).current_state()
        print("previous task run status is :", prevTaskRunState)

        if prevTaskRunState.lower() != 'success':
            sys.tracebacklimit = 0
            task_instance = context['task_instance']
            opsgenie_message = "Beamx|" + self.variables["environment"] + "|Failure|" + task_instance.task_id + "|" + \
                               dict_obs['running_instance_id']
            opsgenie_description = f"Failure |Load Status Check Failed for {source_table}|" + dict_obs[
                'running_instance_id']
            # opsgenie_message = variables["environment"]+" Alert | Load Status Check Criteria Failed"
            # opsgenie_description = f"Load Status Check Failed for {source_table}"
            opsgenie_details = {"DAG ID": self.dagId, "Error Step": "Load Status Check", "Source Table": source_table,
                                "Error Message": "Teradata Table load not completed. Please follow up with source"}
            if (retries == 0 and task_instance.try_number == 1) or (
                    retries > 0 and task_instance.try_number == retries + 1):
                send_alert_to_opsgenie(opsgenie_message, opsgenie_description, opsgenie_details, self.opsgenie_priority,
                                       projectDetails=self.projectDetails, alertTeamName=alertTeamName,sub_lob_alert=sub_lob_alert)
            return {"run_status": "failure", "error_message": "Load Status Check Criteria Failed...exiting"}

        return {"run_status": "success", "error_message": "none"}

    def get_bq_target_count(self, context, params, variables, project_space, tz, dict_obs, opsgenie_priority, dagId, varMap,
                            project_id, source_dbtype, port, SID, projectDetails, bq_dbname):

        bq_hook = BigQueryHook(gcp_conn_id=variables[params["hook"]["gcp_conn_id"]])
        client = bigquery.Client(project=bq_hook._get_field("project"), credentials=bq_hook.get_credentials())
        bq_dbname = bq_dbname[bq_dbname.index(".") + 1:] if bq_dbname else None
        if bq_dbname is not None :
            count_query = f'''SELECT count(*) FROM {bq_dbname}.{params["hook"]["target_table"]} ;'''
            query_job = client.query(count_query)
            results = query_job.to_dataframe()
            results = results.iloc[0, 0]
        else:
            results = '0'
            raise AirflowSkipException(
                "no records present to be processed")
        return results

    def get_secret_from_sm(self, project_id, secret_name, dpHook):
        client = secretmanager.SecretManagerServiceClient(credentials=dpHook.get_credentials())
        secret_name = f"projects/{project_id}/secrets/{secret_name}/versions/latest"
        response = client.access_secret_version(name=secret_name)
        return response.payload.data.decode("UTF-8")

    def getLabelsDictServerless(self, labelsList, dagId, run_id, task_id, composer_name):
        labels_dict = {
            "job_id": dagId.lower()[-63:],
            "task_type": "jdbc_to_bqserverless",
            "run_id": re.sub(r'[^A-Za-z0-9 _-]+', '', run_id).lower()[-63:],
            "task_id": task_id.lower().replace('.', "")[-63:],
            "instance_name": composer_name.lower()
        }
        return labels_dict

    """
    get the labels to be passed to the dataproc job
    """

    def getLabelsDict(self, labelsList, dagId, run_id, task_id, composer_name):
        labels_dict = {
            "job_id": dagId.lower()[-63:],
            "task_type": "jdbc_to_bq",
            "run_id": re.sub(r'[^A-Za-z0-9 _-]+', '', run_id).lower()[-63:],
            "task_id": task_id.lower().replace('.', ""),
            "instance_name": composer_name.lower()
        }
        # if labelsList:
        #     if isinstance (labelsList ,list):
        #         for label in labelsList:
        #             key = label.split(':')[0]
        #             value = label.split(':')[1]
        #             labels_dict[key] = value
        #     else:
        #         key = labelsList.split(':')[0]
        #         value = labelsList.split(':')[1]
        #         labels_dict[key] = value

        return labels_dict

    """
    This function gets the static and the dynamic params to send to observability logs. The static params come from metadata and the dynamic params are calculated in this script at run time.
    """

    def getObsParams(self, context, params, varMap, dict_obs, dagId, project_id, tz):

        # capturing obs static values
        dict_obs_static = json.loads(
            reduce(lambda key, value: key.replace(*value), varMap.items(), (str(self.params["obs"])).replace("'", '"')))

        # capturing obs dynamic values
        dict_obs["start_time"] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
        dict_obs["process_date"] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))[0:10]
        data_interval_endtime = context['data_interval_end'].in_timezone(tz)
        dict_obs["run_date"] = str(data_interval_endtime.strftime('%Y%m%d'))
        dict_obs["run_day"] = str(data_interval_endtime.strftime('%A'))
        dict_obs["run_hour"] = str(data_interval_endtime.strftime("%H:%M:%S"))
        dict_obs["process_name"] = dagId
        dict_obs["gcp_project"] = project_id
        dict_obs["target_type"] = "Table"
        dict_obs["log_file"] = varMap['log_file']

        # merge static and dynamic ob params
        dict_obs.update(dict_obs_static)
        return dict_obs

    """
    This function calls audit_log method which inserts a row with the necessary details in audit table for each run
    """

    def auditTableEntry(self, context, params, variables, logs, project_id, audit_db_td_bq, dagId,
                        jdbc_check_load_status,
                        project_space, opsgenie_priority, projectDetails, tz, alertTeamName,sub_lob_alert,  record_count):

        # import the necessary modules
        BASE_DIR = "/home/airflow/gcs/dags/" + project_space + "/beamx"
        sys.path.append(f"{BASE_DIR}/utils")
        from jdbc_to_bq_loader import audit_log
        from ops_genie import send_alert_to_opsgenie

        run_id_dag = str(context["dag_run"].run_id)[0: str(context["dag_run"].run_id).index("+")] \
                         .replace(".", "-").replace(":", "-").replace("__", "-").lower()
        # if run_id_dag.endswith("-"):
        #     run_id_dag = run_id_dag[:-1]
        process_run_id = f"{self.dagId}_" + str(run_id_dag)
        running_instance_id = process_run_id
        task_instance = context['task_instance']
        retries = task_instance.max_tries
        logs["target_name"] = self.params["hook"]["target_table"]
        final_target_table = self.params["hook"]["final_target_table"] if "final_target_table" in self.params[
            "hook"] else ""
        context['ti'].xcom_push(key="final_target_table", value=final_target_table)
        td_load_completion_timestamp = context['ti'].xcom_pull(key='td_load_completion_ts',
                                                               task_ids='load_status') if jdbc_check_load_status == "yes" else "None"
        source_dbtype = self.params["hook"]["source_dbtype"].lower()
        logs["target_name"] = final_target_table
        logs["td_load_completion_timestamp"] = td_load_completion_timestamp
        logs['project_id'] = project_id
        logs['bq_dataset'] = audit_db_td_bq
        logs["running_instance_id"] = running_instance_id
        logs["sql_query"] = "None"
        logs["source_count"] = record_count
        print("source count: ", logs["source_count"])
        #if source_dbtype == 'teradata':
        try:
            insert_query = audit_log(self.params, variables, logs)
            result = {}
            audit_configuration = {
                "jobType": "QUERY",
                "query": {
                    "query": insert_query,
                    "useLegacySql": False
                }
            }
            result['audit_configuration'] = audit_configuration
            print("audit xcom sucess")
            return result
        except Exception as e:
            error_msg = str(e)
            logging.error(traceback.format_exc())
            sys.tracebacklimit = 0
            task_instance = context['task_instance']
            opsgenie_message = "Beamx|" + variables[
                "environment"] + "|Failure|" + task_instance.task_id + "|" + running_instance_id1
            opsgenie_description = f"Failure|Insert into jdbc audit table {audit_db_td_bq}.audit failed. Please refer values in {logs}|" + running_instance_id1
            # opsgenie_message = variables["environment"] + " Alert | Insert into jdbc audit table failed"
            # opsgenie_description = f"Insert into jdbc audit table {audit_db_td_bq}.audit failed. Please refer values in {logs}"
            opsgenie_details = {"DAG ID": self.dagId, "Error Step": "Insert into jdbc audit table failed",
                                "Error Message": error_msg}

            send_alert_to_opsgenie(opsgenie_message, opsgenie_description, opsgenie_details, opsgenie_priority,
                                       projectDetails=projectDetails, alertTeamName=alertTeamName,sub_lob_alert=sub_lob_alert)
            print("error message is: ", error_msg)

    """
    This function returns the record count of the input query
    """

    def getSourceQueryCount(self, context, params, host_name, username, password, query, variables, project_space, tz,
                            dict_obs, opsgenie_priority, dagId, varMap, project_id, source_dbtype, port, SID,
                            projectDetails, alertTeamName,sub_lob_alert):

        # import the necessary modules
        BASE_DIR = "/home/airflow/gcs/dags/" + project_space + "/beamx"
        sys.path.append(f"{BASE_DIR}/utils")
        from ops_genie import send_alert_to_opsgenie
        from observability import ingestion_obs

        sql_keywords = ["join", "group by", "having"]
        task_instance = context['task_instance']
        retries = task_instance.max_tries
        if source_dbtype == "oracle":
            count_check_query = "select count(*) from " + query.lower().split("from")[-1]
            if "where" in count_check_query:
                count_check_query = count_check_query.split("where")[0] + " " + "WHERE ROWNUM <= 1;"
        else:
            count_check_query = "select cast(count(*) as bigint) from " + query.lower().split("from")[-1]

        if query.lower().count("select") > 1 or query.lower().count("from") > 1:
            if source_dbtype == "oracle":
                count_check_query = f"select count(*) from ({query}) a"
            else:
                count_check_query = f"select cast(count(*) as bigint) from ({query}) a"
        else:
            for keyword in sql_keywords:
                if keyword in query.lower():
                    if source_dbtype == "oracle":
                        count_check_query = f"select count(*) from ({query}) a"
                    else:
                        count_check_query = f"select cast(count(*) as bigint) from ({query}) a"
                    break
        print("count_check_query: ", count_check_query)

        # Check the count returned by query
        if source_dbtype == "oracle":
            try:
                with oracledb.connect(host=host_name, port=port, service_name=SID, user=username,
                                      password=password) as connect:
                    df = pd.read_sql(count_check_query, connect)
                    record_count = df.iloc[0][-1]
            except Exception as e:
                print("Error in oracle conn ", str(e))
                record_count = 1
                error_msg = str(e)
                logging.error(traceback.format_exc())
        else:
            try:
                with teradatasql.connect(host=host_name, user=username, password=password) as connect:
                    df = pd.read_sql(count_check_query, connect)
                    record_count = df.iloc[0][-1]
            except Exception as e:
                record_count = 1
                error_msg = str(e)
                logging.error(traceback.format_exc())

        if not record_count > 0:
            message = "count_check_query result is 0, No results returned by query, hence skipping the load step"
            print(message)
            try:
                # get obs static and dynamic parameters
                dict_obs = self.getObsParams(context, self.params, varMap, dict_obs, dagId, project_id, tz)
                logger_name = self.params["obs"]["logger_name"]
                dict_obs["error_message"] = message
                dict_obs["run_status"] = "SKIPPED"
                dict_obs["end_time"] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
                dict_obs["process_end_time"] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
                dict_obs["inserted_timestamp"] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
                ingestion_obs(dict_obs, logger_name)
            except Exception as e:
                print("error_msg : ", str(e))
                logging.error(traceback.format_exc())
                print("Could not send observability log")
            task_instance = context['task_instance']
            opsgenie_message = "Beamx|" + variables["environment"] + "|Skipped|" + task_instance.task_id + "|" + \
                               dict_obs['running_instance_id']
            opsgenie_description = "Skipped|count_check_query result is 0, No results returned by query, hence skipping the load step|" + \
                                   dict_obs['running_instance_id']
            opsgenie_details = {"DAG ID": dagId, "Error Step": "jdbc to BQ Load",
                                "Error Message": message}
            if (retries == 0 and task_instance.try_number == 1) or (
                    retries > 0 and task_instance.try_number == retries + 1):
                if 'skipped_alert' in self.params['hook']:
                    if self.params['hook']['skipped_alert'].lower() == 'yes':
                        print("Skipped Alert sending")
                        if (retries == 0 and task_instance.try_number == 1) or (
                                retries > 0 and task_instance.try_number == retries + 1):
                            send_alert_to_opsgenie(opsgenie_message, opsgenie_description, opsgenie_details,
                                                   opsgenie_priority, projectDetails=projectDetails,
                                                   alertTeamName=alertTeamName,sub_lob_alert=sub_lob_alert)
            raise AirflowSkipException
        return record_count

    def sendObsLogs(self, params, variables, dict_obs, run_status, end_time, target_dbname, error_message, bq_table,
                    project_id, project_space, tz, target_load_count):
        # import the necessary modules
        BASE_DIR = "/home/airflow/gcs/dags/" + project_space + "/beamx"
        sys.path.append(f"{BASE_DIR}/utils")
        from ops_genie import send_alert_to_opsgenie
        from observability import jdbc_to_bq_obs

        # add additional run time parameters to send to observability
        dict_obs["process_end_time"] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
        dict_obs["error_message"] = error_message
        dict_obs["run_status"] = run_status
        dict_obs["end_time"] = end_time
        dict_obs["inserted_timestamp"] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
        gcp_conn_id = variables[params["hook"]["gcp_conn_id"]]

        # calling the logger method in observability module
        try:
            logs = jdbc_to_bq_obs(dict_obs, gcp_conn_id, project_id, target_dbname, bq_table,target_load_count)
        except Exception as e:
            logs = {}
            error_msg = str(e)
            print("error_msg : ", error_msg)
            logging.error(traceback.format_exc())
            print("Could not send observability log")

        return logs

    def replace_query_xcom(self, context, query):
        print("Existing query ", query)
        ti = context["ti"]
        dag_id = context["dag"]._dag_id
        print("Dag id", dag_id)
        result = ti.xcom_pull(dag_id=dag_id, key='bq_result', include_prior_dates=False)
        print("Xcom record ...", result)

        if result and len(result[0].items()) > 0:
            print("Xcom record is not empty and length of result is - ", len(result[0].items()))
            record_dict = result[0].items()
            for key, value in record_dict:
                print(f"Key -- {key} , Value -- {value}")

            records_xcom = dict(map(lambda x: ('${xcom_' + x[0] + '}', x[1]), record_dict))
            query = reduce(lambda key, value: key.replace(*value), records_xcom.items(), query)
            print("Query .... ", query)
            return query
        else:
            print("Xcom record is empty or there is no result from BQ")
            return query

    def clean_bq_result_xcom(self, ti):
        print("Deleting the bq_result_xcom")
        with create_session() as session:
            xcom_value = session.query(XCom).filter(
                XCom.key == 'bq_result',
                XCom.dag_id == ti.dag_id
            ).delete()
        session.commit()
        print("bq_result Xcom deleted... - session committed")

    def jdbcToBqLoaderServerless(self, **context):

        print("params ", str(self.params))
        print("dagId ", str(self.dagId))
        print("projectDetails ", str(self.projectDetails))
        self.dagId = str(context["dag"].dag_id)
        dict_obs = context['ti'].xcom_pull(key="dict_obs",
                                           task_ids="startTask")
        # get the project details
        project_tag = self.projectDetails[0]
        business_line = self.projectDetails[1]
        project_space = self.projectDetails[2]

        # import the necessary modules
        BASE_DIR = "/home/airflow/gcs/dags/" + project_space + "/beamx"
        sys.path.append(f"{BASE_DIR}/utils")
        from ops_genie import send_alert_to_opsgenie
        alertTeamName = self.alertTeamName
        sub_lob_alert= self.sub_lob_alert
        task_instance = context['task_instance']
        retries = task_instance.max_tries
        project_id = reduce(lambda key, value: key.replace(*value), self.varMap.items(),
                            self.params["hook"]["projectId"])
        source_dbtype = (self.params["hook"]["source_dbtype"].lower()).replace("postgresql", "postgres")
        db_instance = self.params["hook"]["dbinstance"].lower() if "dbinstance" in self.params["hook"] else "default"
        db_config = self.variables[project_tag + '_db_config_jdbc_bq'][business_line] if business_line is not None else \
            self.variables[project_tag + '_db_config_jdbc_bq']
        db_config = db_config[source_dbtype][db_instance]
        host_name = db_config['host_name']
        port = str(db_config[
                       'port']) if source_dbtype == "postgres" or source_dbtype == "oracle" or source_dbtype == "mysql" or source_dbtype == "mssql" or source_dbtype == "db2" else ""
        SID = db_config['SID'] if source_dbtype == "oracle" else ""

        secret_name = db_config["secret_name"]
        dpHook = DataprocHook(gcp_conn_id=self.variables[self.params["hook"]["gcp_conn_id"]])
        payload = self.get_secret_from_sm(project_id, secret_name, dpHook)
        username, password = payload.strip().split(':')
        username = username.strip()
        password = password.strip()
        # username = Variable.get(db_config["username_key"])
        # password = Variable.get(db_config["password_key"])
        query = self.params["hook"]["query"] if "query" in self.params["hook"] else ""
        query = reduce(lambda key, value: key.replace(*value), self.varMap.items(), query)
        print("Query replacing xcom parameters")
        query = self.replace_query_xcom(context, query)
        print("load query is : ", query)
        bq_savemode = self.params["hook"]["save_mode"].lower()
        record_count = 0
        if source_dbtype == "teradata":
            record_count = self.getSourceQueryCount(context, self.params, host_name, username, password, query,
                                                    self.variables,
                                                    project_space, self.tz, dict_obs, self.opsgenie_priority,
                                                    self.dagId, self.varMap,
                                                    project_id, source_dbtype, port, SID, self.projectDetails,
                                                    alertTeamName,sub_lob_alert)

        context['ti'].xcom_push(key='record_count_xcom', value=record_count)

        # password = base64.b64encode(password.encode('utf-8'))
        password_encoded = 'true'

        # get all the details needed to run pyspark job
        dataprocConfigDict = self.variables["dataproc_config_" + source_dbtype + "_to_bq"]
        cluster_label = dataprocConfigDict["cluster_label"]
        file_uri = dataprocConfigDict["main_python_file_uri"]
        staging_bucket = dataprocConfigDict["staging_bucket"]
        temp_bucket = dataprocConfigDict["temp_bucket"]
        jar_file_uri = dataprocConfigDict["jar_file_uris"]
        bq_temp_bucket = dataprocConfigDict["temp_bucket"]
        service_account = dataprocConfigDict["service_account"]
        subnetwork_uri = dataprocConfigDict["subnetwork_uri"]
        phs_cluster_path = dataprocConfigDict["phs_cluster_path"]
        serverless_version = str(dataprocConfigDict["serverless_version"])
        kms_key = str(dataprocConfigDict["kms_key"])
        region = dataprocConfigDict["region"]
        job_id = self.dagId.lower() + '_' + str(datetime.now(self.tz).strftime("%Y%m%d%H%M%S"))
        dbtype = self.params["hook"]["source_dbtype"].lower()
        dbname = self.params["hook"]["source_dbname"]
        dbname = reduce(lambda key, value: key.replace(*value), self.varMap.items(), dbname)
        source_table = self.params["hook"]["source_table"] if "source_table" in self.params["hook"] else ""
        number_of_partitions = self.params["hook"]["number_of_partitions"] if "number_of_partitions" in self.params[
            "hook"] else ""
        source_split_by_column = self.params["hook"]["source_split_by_column"] if "source_split_by_column" in \
                                                                                  self.params[
                                                                                      "hook"] else ""
        bq_partition_col = self.params["hook"]["target_partition_column"] if "target_partition_column" in self.params[
            "hook"] else ""
        target_dbname = self.params["hook"]["target_dbname"]
        target_dbname = reduce(lambda key, value: key.replace(*value), self.varMap.items(), target_dbname)

        bq_dbname = project_id + "." + target_dbname
        bq_table = self.params["hook"]["target_table"]
        # port = str(db_config['port']) if source_dbtype == "postgres" else ""
        # SID = ''

        initial_target_count = self.get_bq_target_count(context, self.params, self.variables, project_space, self.tz,
                                                        dict_obs,
                                                        self.opsgenie_priority, self.dagId, self.varMap, project_id,
                                                        source_dbtype, port,
                                                        SID, self.projectDetails, bq_dbname)
        context['ti'].xcom_push(key='jdbc_SID_xcom', value=SID)
        context['ti'].xcom_push(key='jdbc_bq_dbname_xcom', value=bq_dbname)
        context['ti'].xcom_push(key='jdbc_source_dbtype_xcom', value=source_dbtype)
        context['ti'].xcom_push(key='jdbc_port_xcom', value=port)
        context['ti'].xcom_push(key='jdbc_initial_target_count_xcom', value=initial_target_count)
        if dbtype == 'oracle' or dbtype == 'db2' or dbtype == 'mysql' or dbtype == 'mssql':
            bq_savemode = 'append'
            bq_hook = BigQueryHook(gcp_conn_id=self.variables[self.params["hook"]["gcp_conn_id"]])
            client = bigquery.Client(project=bq_hook._get_field("project"), credentials=bq_hook.get_credentials())
            bq_query = f"truncate table {bq_dbname}.{bq_table}"
            try:
                query_job = client.query(bq_query)
                results = query_job.result()
                result = results.total_rows
            except Exception as e:
                error_message = str(e)
                error_msg = "Truncate step failed"
                logging.error(traceback.format_exc())
                end_time = str(datetime.now(self.tz).strftime("%Y-%m-%dT%H:%M:%S"))
                run_status = "FAILURE"

            if result == 0:
                print('truncate successfull, table ', bq_table)
            else:
                error_message = NONE
                error_msg = "Truncate step failed"
                end_time = str(datetime.now(self.tz).strftime("%Y-%m-%dT%H:%M:%S"))
                run_status = "FAILURE"

        truststore_filename = self.params["hook"]["truststore_filename"] if "truststore_filename" in self.params["hook"] else ""
        trustore_file_uri = [db_config["jks_file_uri"]] if "jks_file_uri" in db_config else []
        print(trustore_file_uri, type(trustore_file_uri))
        jks_secret = db_config["jks_secret"] if "jks_secret" in db_config else ""
        cast_column = str(self.params["hook"]["cast_columns"]) if "cast_columns" in self.params["hook"] else ""
        arg_list = [dbtype, dbname, source_table, query, secret_name, project_id, bq_partition_col, bq_savemode,
                    bq_dbname, bq_table, bq_temp_bucket, source_split_by_column, number_of_partitions, host_name, port,
                    SID, cast_column, password_encoded,truststore_filename,jks_secret]

        target_db = self.params["hook"]["target_dbname"]
        target_db = reduce(lambda key, value: key.replace(*value), self.varMap.items(), target_db)

        # get obs static and dynamic parameters
        dict_obs = self.getObsParams(context, self.params, self.varMap, dict_obs, self.dagId, project_id, self.tz)
        context['ti'].xcom_push(key='dict_obs_dataproc_prep', value=dict_obs)
        run_id = context['dag_run'].run_id
        task_id = context['task'].task_id
        import os
        composer_name = os.getenv('COMPOSER_ENVIRONMENT')

        labels_dict = self.getLabelsDictServerless(self.custom_labels, self.dagId, run_id, task_id, composer_name)

        # spark application name
        spark_app_name = "JDBCtoBQapp_ " + self.dagId.lower() + dict_obs["start_time"]

        # pyspark job properties
        properties = {
            "spark.app.name": spark_app_name,
            "spark.sql.legacy.parquet.int96RebaseModeInRead": "CORRECTED",
            "spark.sql.legacy.parquet.int96RebaseModeInWrite": "CORRECTED",
            "spark.sql.legacy.parquet.datetimeRebaseModeInRead": "CORRECTED",
            "spark.sql.legacy.parquet.datetimeRebaseModeInWrite": "CORRECTED",
            "spark.dynamicAllocation.enabled": "true",
            "spark.dynamicAllocation.initialExecutors": "15",  # // Assuming 4 cores per executor
            "spark.dynamicAllocation.minExecutors": "5",
            "spark.dynamicAllocation.maxExecutors": "400",
            "spark.dynamicAllocation.executorAllocationRatio": "1.0",
            "spark.dynamicAllocation.executorIdleTimeout": "5m",
            "spark.dynamicAllocation.cachedExecutorIdleTimeout": "5m",
            "spark.redaction.regex": "(?i)secret|password|token|access[.]key",
            "spark.redaction.string.regex":"(?i)secret|password|dbpass|token",
            "spark.hadoop.fs.gs.system.bucket": temp_bucket
        }

        # update spark properties if custom spark configuration sent from user metadata
        if "spark_conf" in self.params["hook"]:
            spark_conf = self.params["hook"]["spark_conf"]
            if "overwrite_default_properties" in self.params["hook"] and self.params["hook"][
                "overwrite_default_properties"] == 'yes':
                properties = {"spark.app.name": spark_app_name,
                              "spark.redaction.regex": "(?i)secret|password|token|access[.]key",
                              "spark.redaction.string.regex":"(?i)secret|password|dbpass|token"}
                properties.update(spark_conf)
            else:
                properties = {"spark.redaction.regex": "(?i)secret|password|token|access[.]key",
                              "spark.redaction.string.regex":"(?i)secret|password|dbpass|token"}
                properties.update(spark_conf)

        batch_id = (re.sub(r"[^a-zA-Z0-9-]", "-", self.dagId).lstrip('-').lower()[:31] +"-" +  uuid.uuid4().hex)[:63]
        print("batch_id is", job_id)

        batch_props = {
            "pyspark_batch": {
                "main_python_file_uri": file_uri,
                "jar_file_uris": jar_file_uri,
                "file_uris": trustore_file_uri,
                "args": arg_list
            },
            "labels": labels_dict,
            "runtime_config": {
                "version": serverless_version,
                "properties": properties
            },
            "environment_config": {
                "execution_config": {
                    "service_account": service_account,
                    "subnetwork_uri": subnetwork_uri,
                    "kms_key": kms_key,
                    "staging_bucket": staging_bucket
                    # "kms_key": 'projects/vz-it-np-d0sv-vsadkms-0/locations/us-east4/keyRings/vz-it-np-kr-aid/cryptoKeys/vz-it-np-kms-gk1v'
                },

            },
        }
        if "phs_cluster" in self.params["hook"]:
            if self.params["hook"]["phs_cluster"].lower() == "yes":
                phs_config = {"peripherals_config": {
                    "spark_history_server_config": {
                        "dataproc_cluster": phs_cluster_path,
                    },
                },
                }
                batch_props["environment_config"].update(phs_config)

        context['ti'].xcom_push(key='pyspark_job_config_xcom', value=batch_props)
        context['ti'].xcom_push(key='region_xcom', value=region)
        context['ti'].xcom_push(key='batch_id_xcom', value=batch_id)
        context['ti'].xcom_push(key='project_id_xcom', value=project_id)
        context['ti'].xcom_push(key='gcp_conn_id_xcom', value=self.variables[self.params["hook"]["gcp_conn_id"]])
        context['ti'].xcom_push(key='job_id_xcom', value=batch_id)
        # submit pyspark job to dataproc
        if bq_savemode == "overwrite" or dbtype != "teradata" or record_count > 0:
            return f"{self.groupId}.execute_dataproc_job"
        else:
            context['ti'].xcom_push(key='valid_flag', value=1)
            return f"{self.groupId}.observability_prep_python_operator"

    def jdbcToBqLoader(self, **context):

        # get the project details
        project_tag = self.projectDetails[0]
        business_line = self.projectDetails[1]
        project_space = self.projectDetails[2]
        self.dagId = str(context["dag"].dag_id)
        dict_obs = context['ti'].xcom_pull(key="dict_obs",
                                           task_ids="startTask")
        # import the necessary modules
        BASE_DIR = "/home/airflow/gcs/dags/" + project_space + "/beamx"
        sys.path.append(f"{BASE_DIR}/utils")
        from ops_genie import send_alert_to_opsgenie
        alertTeamName = self.alertTeamName
        sub_lob_alert= self.sub_lob_alert
        task_instance = context['task_instance']
        project_id = reduce(lambda key, value: key.replace(*value), self.varMap.items(),
                            self.params["hook"]["projectId"])
        source_dbtype = (self.params["hook"]["source_dbtype"].lower()).replace("postgresql", "postgres")
        db_instance = self.params["hook"]["dbinstance"].lower() if "dbinstance" in self.params["hook"] else "default"
        db_config = self.variables[project_tag + '_db_config_jdbc_bq'][business_line] if business_line is not None else \
            self.variables[project_tag + '_db_config_jdbc_bq']
        db_config = db_config[source_dbtype][db_instance]
        host_name = db_config['host_name']
        port = str(db_config[
                       'port']) if source_dbtype == "postgres" or source_dbtype == "oracle" or source_dbtype == "mssql" or source_dbtype == "db2" else ""
        SID = db_config['SID'] if source_dbtype == "oracle" else ""

        # username = Variable.get(db_config["username_key"])
        # password = Variable.get(db_config["password_key"])
        secret_name = db_config["secret_name"]
        dpHook = DataprocHook(gcp_conn_id=self.variables[self.params["hook"]["gcp_conn_id"]])
        payload = self.get_secret_from_sm(project_id, secret_name, dpHook)
        username, password = payload.strip().split(':')
        username = username.strip()
        password = password.strip()
        query = self.params["hook"]["query"] if "query" in self.params["hook"] else ""
        query = reduce(lambda key, value: key.replace(*value), self.varMap.items(), query)
        print("Query replacing xcom parameters")
        query = self.replace_query_xcom(context, query)
        print("load query is : ", query)
        bq_savemode = self.params["hook"]["save_mode"].lower()



        record_count = 0
        if source_dbtype == "teradata":
            record_count = self.getSourceQueryCount(context, self.params, host_name, username, password, query,
                                                    self.variables,
                                                    project_space, self.tz, dict_obs, self.opsgenie_priority,
                                                    self.dagId, self.varMap,
                                                    project_id, source_dbtype, port, SID, self.projectDetails,
                                                    alertTeamName,sub_lob_alert)

        context['ti'].xcom_push(key='record_count_xcom', value=record_count)

        # password = base64.b64encode(password.encode('utf-8'))
        password_encoded = 'true'

        # get all the details needed to run pyspark job
        dataprocConfigDict = self.variables["dataproc_config_" + source_dbtype + "_to_bq"]
        cluster_label = dataprocConfigDict["cluster_label"]
        file_uri = dataprocConfigDict["main_python_file_uri"]
        jar_file_uri = dataprocConfigDict["jar_file_uris"]
        bq_temp_bucket = dataprocConfigDict["temp_bucket"]
        region = dataprocConfigDict["region"]
        run_id_dag = str(context["dag_run"].run_id)[0: str(context["dag_run"].run_id).index("+")] \
                         .replace(".", "-").replace(":", "-").replace("__", "-").lower()[:61]

        job_id = self.dagId.lower() + '_' + run_id_dag
        job_id = job_id[:61]
        if job_id.endswith("-"):
            job_id = job_id[:-1]
        context['ti'].xcom_push(key='job_id_xcom', value=job_id)
        dbtype = self.params["hook"]["source_dbtype"].lower()
        dbname = self.params["hook"]["source_dbname"]
        dbname = reduce(lambda key, value: key.replace(*value), self.varMap.items(), dbname)
        source_table = self.params["hook"]["source_table"] if "source_table" in self.params["hook"] else ""
        number_of_partitions = self.params["hook"]["number_of_partitions"] if "number_of_partitions" in self.params[
            "hook"] else ""
        source_split_by_column = self.params["hook"]["source_split_by_column"] if "source_split_by_column" in \
                                                                                  self.params[
                                                                                      "hook"] else ""
        bq_partition_col = self.params["hook"]["target_partition_column"] if "target_partition_column" in self.params[
            "hook"] else ""
        target_dbname = self.params["hook"]["target_dbname"]
        target_dbname = reduce(lambda key, value: key.replace(*value), self.varMap.items(), target_dbname)
        bq_dbname = project_id + "." + target_dbname
        bq_table = self.params["hook"]["target_table"]
        # port = str(db_config['port']) if source_dbtype == "postgres" else ""
        # SID = ''
        initial_target_count = self.get_bq_target_count(context, self.params, self.variables, project_space, self.tz,
                                                        dict_obs,
                                                        self.opsgenie_priority, self.dagId, self.varMap, project_id,
                                                        source_dbtype, port,
                                                        SID, self.projectDetails, bq_dbname)
        context['ti'].xcom_push(key='jdbc_SID_xcom', value=SID)
        context['ti'].xcom_push(key='jdbc_bq_dbname_xcom', value=bq_dbname)
        context['ti'].xcom_push(key='jdbc_source_dbtype_xcom', value=source_dbtype)
        context['ti'].xcom_push(key='jdbc_port_xcom', value=port)
        context['ti'].xcom_push(key='jdbc_initial_target_count_xcom', value=initial_target_count)
        cast_column = str(self.params["hook"]["cast_columns"]) if "cast_columns" in self.params["hook"] else ""
        arg_list = [dbtype, dbname, source_table, query, secret_name, project_id, bq_partition_col, bq_savemode,
                    bq_dbname, bq_table, bq_temp_bucket, source_split_by_column, number_of_partitions, host_name, port,
                    SID, cast_column, password_encoded]

        target_db = self.params["hook"]["target_dbname"]
        target_db = reduce(lambda key, value: key.replace(*value), self.varMap.items(), target_db)

        # get obs static and dynamic parameters
        dict_obs = self.getObsParams(context, self.params, self.varMap, dict_obs, self.dagId, project_id, self.tz)
        context['ti'].xcom_push(key='dict_obs_dataproc_prep', value=dict_obs)

        run_id = context['dag_run'].run_id
        task_id = context['task'].task_id
        import os
        composer_name = os.getenv('COMPOSER_ENVIRONMENT')

        labels_dict = self.getLabelsDict(self.custom_labels, self.dagId, run_id, task_id, composer_name)

        # spark application name
        spark_app_name = "JDBCtoBQapp_ " + self.dagId.lower() + dict_obs["start_time"]

        # pyspark job properties
        properties = {
            "spark.master": "yarn",
            "spark.app.name": spark_app_name,
            "spark.submit.deployMode": "cluster",
            "spark.ui.view.acls": "*",
            "spark.sql.legacy.parquet.int96RebaseModeInRead": "CORRECTED",
            "spark.sql.legacy.parquet.int96RebaseModeInWrite": "CORRECTED",
            "spark.sql.legacy.parquet.datetimeRebaseModeInRead": "CORRECTED",
            "spark.sql.legacy.parquet.datetimeRebaseModeInWrite": "CORRECTED",
            "spark.redaction.regex": "(?i)secret|password|token|access[.]key",
            "spark.redaction.string.regex":"(?i)secret|password|dbpass|token"
        }

        # update spark properties if custom spark configuration sent from user metadata
        if "spark_conf" in self.params["hook"]:
            spark_conf = self.params["hook"]["spark_conf"]
            properties.update(spark_conf)

        # pyspark job configuration
        pyspark_job_config = {"reference": {"project_id": project_id, "job_id": job_id},
                              "placement": {"cluster_labels": cluster_label},
                              "labels": labels_dict,
                              "pyspark_job": {
                                  "main_python_file_uri": file_uri,
                                  "properties": properties,
                                  "jar_file_uris": jar_file_uri,
                                  "args": arg_list
                              }
                              }

        context['ti'].xcom_push(key='pyspark_job_config_xcom', value=pyspark_job_config)
        context['ti'].xcom_push(key='region_xcom', value=region)
        context['ti'].xcom_push(key='project_id_xcom', value=project_id)
        context['ti'].xcom_push(key='gcp_conn_id_xcom', value=self.variables[self.params["hook"]["gcp_conn_id"]])

        # submit pyspark job to dataproc
        validFlag = 0
        if bq_savemode == "overwrite" or dbtype != "teradata" or record_count > 0:
            return f"{self.groupId}.execute_dataproc_job"
        else:
            validFlag = 1
            return f"{self.groupId}.observability_prep_python_operator"

    def obsgenieAndLogs(self, **context):
        from ops_genie import send_alert_to_opsgenie

        try:
            logicalDate = context['logical_date']
            dataprocTaskResult = (TaskInstance(context['dag'].get_task(f"{self.groupId}.create_dataproc_config"), logicalDate)).current_state()
            if str(dataprocTaskResult).lower() != 'success':
                raise AirflowSkipException

        except TypeError as e:
            raise AirflowSkipException

        logicalDate = context['logical_date']
        task_instance_state = (TaskInstance(context['dag'].get_task(f"{self.groupId}.execute_dataproc_job"), logicalDate)).current_state()

        project_id = reduce(lambda key, value: key.replace(*value), self.varMap.items(),
                            self.params["hook"]["projectId"])
        project_space = self.projectDetails[2]
        dict_obs = context['ti'].xcom_pull(key='dict_obs_dataproc_prep')
        if dict_obs is None:
            dict_obs = {}
        target_dbname = self.params["hook"]["target_dbname"]
        target_dbname = reduce(lambda key, value: key.replace(*value), self.varMap.items(), target_dbname)
        bq_table = self.params["hook"]["target_table"]


        record_count = context['ti'].xcom_pull(task_ids=f'{self.groupId}.create_dataproc_config', key='record_count_xcom')
        port = context['ti'].xcom_pull(task_ids=f'{self.groupId}.create_dataproc_config',key='jdbc_port_xcom')
        bq_dbname = context['ti'].xcom_pull(task_ids=f'{self.groupId}.create_dataproc_config', key='jdbc_bq_dbname_xcom')
        source_dbtype = context['ti'].xcom_pull(task_ids=f'{self.groupId}.create_dataproc_config', key='jdbc_source_dbtype_xcom')
        SID = context['ti'].xcom_pull(task_ids=f'{self.groupId}.create_dataproc_config', key='jdbc_SID_xcom')
        initial_target_count = context['ti'].xcom_pull(task_ids=f'{self.groupId}.create_dataproc_config', key='jdbc_initial_target_count_xcom')

        final_target_count = self.get_bq_target_count(context, self.params, self.variables, project_space, self.tz,
                                                        dict_obs,
                                                        self.opsgenie_priority, self.dagId, self.varMap, project_id,
                                                        source_dbtype, port,
                                                        SID, self.projectDetails, bq_dbname)

        # print("final_target_count: ", final_target_count)
        paramsdbtype  = self.params["hook"]["source_dbtype"].lower()
        if self.params["hook"]["save_mode"].lower() == 'overwrite' or paramsdbtype == 'oracle' or paramsdbtype == 'db2' or paramsdbtype == 'mysql' or paramsdbtype == 'mssql':
            target_load_count = int(final_target_count)
        else:
            target_load_count = int(final_target_count) - int(initial_target_count)
        print("Total records loaded to target: ", target_load_count)

        print("task_instance 1 ", task_instance_state)
        if str(task_instance_state).lower() == 'success':
            error_msg = "NA"
            end_time = str(datetime.now(self.tz).strftime("%Y-%m-%dT%H:%M:%S"))
            run_status = "SUCCESS"
        else:
            error_message = ""
            error_msg = "JDBC to Bigquery load job Failed"
            logging.error(traceback.format_exc())
            end_time = str(datetime.now(self.tz).strftime("%Y-%m-%dT%H:%M:%S"))
            run_status = "FAILURE"

        logs = self.sendObsLogs(self.params, self.variables, dict_obs, run_status, end_time, target_dbname, error_msg,
                           bq_table,
                           project_id, project_space, self.tz, target_load_count)

        # insert a row in audit table
        audit_flag = "yes"
        if "audit_flag" in self.params["hook"]:
            audit_flag = self.params["hook"]["audit_flag"].lower()

        context['ti'].xcom_push(key='audit_flag', value=audit_flag)
        dbtype = self.params["hook"]["source_dbtype"].lower()
        audit_entry = False
        if audit_flag == "yes":
            audit_db_td_bq = self.variables["audit_db_td_bq"]
            context['ti'].xcom_push(key="dbtype", value=dbtype)
            result = self.auditTableEntry(context, self.params, self.variables, logs, project_id, audit_db_td_bq, self.dagId,
                                 self.jdbc_check_load_status,
                                 project_space, self.opsgenie_priority, self.projectDetails, self.tz, self.alertTeamName, self.sub_lob_alert, record_count)
            xcoms = {'params': self.params, 'result': result}
            context['ti'].xcom_push(key='beamx_audit', value=xcoms)
            audit_entry = True
        if run_status == 'FAILURE':
            task_instance = context['task_instance']
            opsgenie_message = "Beamx|" + self.variables["environment"] + "|Failure|" + task_instance.task_id + "|" + \
                               dict_obs['running_instance_id']
            opsgenie_description = "Failure |JDBC load == 'FAILURE'|" + dict_obs['running_instance_id']
            job_id = context['ti'].xcom_pull(key='job_id_xcom')
            bq_dbname = project_id + "." + target_dbname
            opsgenie_details = {"dataprocJobId": job_id, "DAG ID": self.dagId,
                                "Error Step": "JDBC to bq pyspark job failed",
                                "Target Table": bq_dbname + "." + bq_table, "Error Message": error_message}
            retries = task_instance.max_tries
            print("ops details ", opsgenie_details)
            print(" retries ", retries)
            upstreamTaskId = next(iter(context['task'].upstream_task_ids))
            print("upstream task ", upstreamTaskId)

            print("sending alert to opsgenie")
            send_alert_to_opsgenie(opsgenie_message, opsgenie_description, opsgenie_details, self.opsgenie_priority,
                                       projectDetails=self.projectDetails, alertTeamName=self.alertTeamName,sub_lob_alert=self.sub_lob_alert)



        self.clean_bq_result_xcom(context["ti"])
        if audit_entry:
            return f"{self.groupId}.jdbctobq_beamx_audit"

    def recordCountReconciliation(self,**context):

        from ops_genie import send_alert_to_opsgenie
        # check Record count reconciliation
        try:
            project_id = reduce(lambda key, value: key.replace(*value), self.varMap.items(),
                                self.params["hook"]["projectId"])
            
            dbtype = self.params["hook"]["source_dbtype"].lower()
            audit_flag = context['ti'].xcom_pull(key='audit_flag')
            
            if audit_flag == "yes":
                audit_db_td_bq = self.variables["audit_db_td_bq"]
            
            run_id_dag = str(context["dag_run"].run_id)[0: str(context["dag_run"].run_id).index("+")] \
                .replace(".", "-").replace(":", "-").replace("__", "-").lower()
            # if run_id_dag.endswith("-"):
            #     run_id_dag = run_id_dag[:-1]
            process_run_id = f"{self.dagId}_" + str(run_id_dag)
            running_instance_id = process_run_id
            task_instance = context['task_instance']
            task_instance_name=task_instance.task_id.split('.')[0]
            bq_hook = BigQueryHook(gcp_conn_id=self.variables[self.params["hook"]["gcp_conn_id"]])
            client = bigquery.Client(project=bq_hook._get_field("project"), credentials=bq_hook.get_credentials())
            reconciliation_query = f'''SELECT source_count,target_count,bad_records_count FROM `{project_id}`.`{audit_db_td_bq}`.audit where application_id ='{running_instance_id}' and sub_process ='{task_instance_name}' ORDER BY end_time DESC limit 1;'''
            print("reconciliation_query is :", reconciliation_query)
            query_job = client.query(reconciliation_query)
            results = query_job.to_dataframe()
            print(results)
            source_count_result = results.iloc[0, 0]
            target_count_result = results.iloc[0, 1]
            bad_records_count_result = results.iloc[0, 2]
            if bad_records_count_result == 'NA' or bad_records_count_result == '':
                bad_records_count_result = 0
            if source_count_result == 'NA' or source_count_result == '':
                source_count_result = 0
            if target_count_result == 'NA' or target_count_result == '':
                target_count_result = 0
            if int(source_count_result) == int(target_count_result):
                print("reconciliation of Count Matched")
            elif int(source_count_result) == int(target_count_result) + int(bad_records_count_result):
                print("reconciliation of Count Matched with adding bad_records_count_result in source_count_result")
            else:
                print("reconciliation of Count Not Matched")
                print("Checking reconciliation of Count Alert_flag provided is params")
                if "alert_on_record_mismatch" in self.params["hook"]:
                    alert_on_record_mismatch = self.params["hook"]["alert_on_record_mismatch"].lower()
                    if alert_on_record_mismatch == "yes":
                        task_instance = context['task_instance']
                        opsgenie_message = "Beamx|" + self.variables[
                            "environment"] + "|Failure|" + task_instance.task_id + "|" + dict_obs['running_instance_id']
                        opsgenie_description = "Failure |Reconciliation of record count not Matched|" + dict_obs[
                            'running_instance_id']
                        opsgenie_details = {"DAG ID": self.dagId,
                                            "Error Step": "Reconciliation of record count not Matched",
                                            "Target Table": audit_db_td_bq + ".audit"}
                        send_alert_to_opsgenie(opsgenie_message, opsgenie_description, opsgenie_details,
                                               self.opsgenie_priority, projectDetails=self.projectDetails,
                                               sub_lob_alert=self.sub_lob_alert)
                else:
                    print("alert_on_record_mismatch flag not found in params['hook']")
            print("reconciliation_query source_count_result  :", source_count_result)
            print("reconciliation_query target_count_result  :", target_count_result)
            print("reconciliation_query bad_records_count_result  :", bad_records_count_result)
        except Exception as e:
            print("Issue in audit reconciliation is :",e)

    def createTaskGroupStatus(self, **context):
        
        dataprocJobTaskId = f'{self.group_id}.execute_dataproc_job'
        dataprocJobTaskRunState = (TaskInstance(context['dag'].get_task(dataprocJobTaskId), context['logical_date'])).current_state()
        
        validFlag = context['ti'].xcom_pull(key='valid_flag')
        print("Flag=",validFlag)
        if str(dataprocJobTaskRunState).lower() != 'skipped' and str(dataprocJobTaskRunState).lower() != 'success':
            raise AirflowFailException("Dataproc Job Failed")
        elif str(dataprocJobTaskRunState).lower() == 'skipped' and validFlag == 1 and validFlag is not None:
            print("Dataproc Job skipped")
        elif str(dataprocJobTaskRunState).lower() == 'skipped' and validFlag is None:
            raise AirflowSkipException("Upstream skipped")
            

    def createTaskGroup(self):
        projectDetails = self.projectDetails
        projectSpace = projectDetails[2]
        BASE_DIR = "/home/airflow/gcs/dags/" + projectSpace + "/beamx"
        sys.path.append(f"{BASE_DIR}/utils")
        from common_utility_functions import pushFailureStatus

        with self:
            if not self.serverless:
                branch_task = BranchPythonOperator(
                    task_id='create_dataproc_config',
                    python_callable=self.jdbcToBqLoader,
                    provide_context=True,
                    on_failure_callback=pushFailureStatus
                )

                dataproc_submit_job_operator = DataprocSubmitJobOperator(
                    task_id='execute_dataproc_job',
                    job=f"{{{{ti.xcom_pull(task_ids='{self.groupId}.create_dataproc_config',key='pyspark_job_config_xcom')}}}}",
                    region=f"{{{{ti.xcom_pull(task_ids='{self.groupId}.create_dataproc_config',key='region_xcom')}}}}",
                    project_id=f"{{{{ti.xcom_pull(task_ids='{self.groupId}.create_dataproc_config',key='project_id_xcom')}}}}",
                    request_id=None,
                    retry=None,
                    timeout=None,
                    gcp_conn_id=self.variables[self.params["hook"]["gcp_conn_id"]],
                    asynchronous=False,
                    deferrable=True,
                    polling_interval_seconds=10,
                    cancel_on_kill=True,
                    wait_timeout=None,
                    on_failure_callback=self.FailureAlertForLoadStatus
                 )

                observability_prep_python_operator = PythonOperator(
                    task_id='observability_prep_python_operator',
                    python_callable=self.obsgenieAndLogs,
                    provide_context=True,
                    trigger_rule = "all_done"
                )

                jdbctobq_beamx_audit = BigQueryInsertJobOperator(
                    task_id="jdbctobq_beamx_audit",
                    deferrable=True,
                    gcp_conn_id=self.variables[self.params["hook"]["gcp_conn_id"]],
                    on_failure_callback=self.FailureAlertForAudit,
                    configuration=f"{{{{ti.xcom_pull(task_ids='{self.groupId}.observability_prep_python_operator',key='beamx_audit')['result']['audit_configuration']}}}}"

                )

                audit_record_count_reconciliation = PythonOperator(
                    task_id='audit_record_count_reconciliation',
                    python_callable=self.recordCountReconciliation,
                    provide_context=True,
                    trigger_rule="all_done"
                )

                task_group_status = PythonOperator(
                    task_id="task_group_status",
                    python_callable=self.createTaskGroupStatus,
                    trigger_rule='all_done',
                    on_failure_callback=pushFailureStatus
                )

                branch_task >> dataproc_submit_job_operator >> observability_prep_python_operator >> jdbctobq_beamx_audit >> audit_record_count_reconciliation >> task_group_status
                branch_task >> observability_prep_python_operator >> jdbctobq_beamx_audit >> audit_record_count_reconciliation >> task_group_status
            else:
                branch_task = BranchPythonOperator(
                    task_id='create_dataproc_config',
                    python_callable=self.jdbcToBqLoaderServerless,
                    provide_context=True
                )

                dataproc_submit_job_operator = DataprocCreateBatchOperator(
                    task_id='execute_dataproc_job',

                    region=f"{{{{ti.xcom_pull(task_ids='{self.groupId}.create_dataproc_config',key='region_xcom')}}}}",

                    batch=f"{{{{ti.xcom_pull(task_ids='{self.groupId}.create_dataproc_config',key='pyspark_job_config_xcom')}}}}",
                    batch_id=f"{{{{ti.xcom_pull(task_ids='{self.groupId}.create_dataproc_config',key='batch_id_xcom')}}}}",
                    project_id=f"{{{{ti.xcom_pull(task_ids='{self.groupId}.create_dataproc_config',key='project_id_xcom')}}}}",
                    request_id=None,
                    retry=None,
                    timeout=None,
                    gcp_conn_id=self.variables[self.params["hook"]["gcp_conn_id"]],
                    asynchronous=False,
                    deferrable=True,
                    on_failure_callback=self.FailureAlert,
                    polling_interval_seconds=5)

                observability_prep_python_operator = BranchPythonOperator(
                    task_id='observability_prep_python_operator',
                    python_callable=self.obsgenieAndLogs,
                    provide_context=True,
                    trigger_rule="all_done"
                )

                jdbctobq_beamx_audit = BigQueryInsertJobOperator(
                    task_id="jdbctobq_beamx_audit",
                    deferrable=True,
                    gcp_conn_id=self.variables[self.params["hook"]["gcp_conn_id"]],
                    on_failure_callback=self.FailureAlertForAudit,
                    configuration=f"{{{{ti.xcom_pull(task_ids='{self.groupId}.observability_prep_python_operator',key='beamx_audit')['result']['audit_configuration']}}}}"

                )

                audit_record_count_reconciliation = PythonOperator(
                    task_id='audit_record_count_reconciliation',
                    python_callable=self.recordCountReconciliation,
                    provide_context=True,
                    trigger_rule="all_done"
                )

                task_group_status = PythonOperator(
                    task_id="task_group_status",
                    python_callable=self.createTaskGroupStatus,
                    trigger_rule='all_done',
                    on_failure_callback=pushFailureStatus
                )

                branch_task >> dataproc_submit_job_operator >> observability_prep_python_operator >> jdbctobq_beamx_audit >> audit_record_count_reconciliation >> task_group_status
                branch_task >> observability_prep_python_operator >> jdbctobq_beamx_audit >> audit_record_count_reconciliation >> task_group_status

            return self
