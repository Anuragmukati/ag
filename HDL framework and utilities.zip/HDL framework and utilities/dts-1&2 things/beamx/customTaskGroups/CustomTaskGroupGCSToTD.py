from datetime import datetime
from functools import reduce
import logging
import traceback
import sys
import re
from airflow.models import TaskInstance
from airflow.models import XCom
from airflow.utils.task_group import TaskGroup
from airflow.decorators import task
from airflow.providers.google.cloud.operators.bigquery import BigQueryInsertJobOperator
from airflow.providers.teradata.operators.teradata import TeradataOperator
from airflow.operators.python import BranchPythonOperator
from airflow.exceptions import AirflowSkipException, AirflowFailException
from airflow.operators.empty import EmptyOperator
from airflow.operators.python_operator import PythonOperator
from airflow.providers.google.cloud.hooks.gcs import GCSHook
from google.cloud.dataproc_v1.types import ListJobsRequest
from airflow.providers.google.cloud.operators.dataproc import DataprocSubmitJobOperator
import os
import base64
from datetime import date, timedelta, timezone, tzinfo
from google.cloud import secretmanager
from airflow.providers.cncf.kubernetes.secret import Secret
from airflow.operators.python import get_current_context
from airflow.exceptions import AirflowSkipException, AirflowException
from airflow.providers.cncf.kubernetes.operators.pod import KubernetesPodOperator
from kubernetes.client import models as k8s
from airflow.providers.cncf.kubernetes.secret import Secret


class CustomTaskGroupGCSToTD(TaskGroup):

    def __init__(self, group_id, metadataParams, variables, varMap, dagId, projectDetails, tz,
                 opsgenie_priority,bucketNameVars,alertTeamName = None,sub_lob_alert = None, **kwargs):
        super().__init__(group_id=group_id, **kwargs)
        self.groupId = group_id
        self.metadataParams = metadataParams
        self.variables = variables
        self.varMap = varMap
        self.dagId = dagId
        self.projectDetails = projectDetails
        self.tz = tz
        self.opsgenie_priority = opsgenie_priority
        self.alertTeamName=alertTeamName
        self.bucketNameVars=bucketNameVars
        self.sub_lob_alert=sub_lob_alert
        self.custom_labels = kwargs['custom_labels'] if 'custom_labels' in kwargs else None
        if "gcp_conn_id" in self.metadataParams["hook"]:
            self.gcp_conn_id=self.variables[self.metadataParams["hook"]["gcp_conn_id"]]
        else:
            self.gcp_conn_id=self.variables["gcp_conn_id"]
   
    def fetch_arguments(self, **context):
        import tpt_bq_to_td_loader
        arguments,clean_up_sql=tpt_bq_to_td_loader.fetch_arguments(self,context,self.varMap, self.metadataParams, self.tz, self.dagId, self.projectDetails, self.bucketNameVars, self.variables)
        context['ti'].xcom_push(key='arguments_xcom', value=arguments)

    def createTaskGroup(self):
        import tpt_bq_to_td_loader
        projectDetails = self.projectDetails
        projectSpace = projectDetails[2]
        BASE_DIR = "/home/airflow/gcs/dags/" + projectSpace + "/beamx"
        sys.path.append(f"{BASE_DIR}/utils")
        from common_utility_functions import pushFailureStatus

        with self:

            fetch_arguemnts = PythonOperator(
                    task_id='fetch_arguments',
                    python_callable=self.fetch_arguments,
                    provide_context=True,
                    on_failure_callback=self.FailureAlert
            )
            argument_list = f"{{{{ti.xcom_pull(task_ids='{self.groupId}.fetch_arguments', key='arguments_xcom')}}}}"
            ssh_class_obj = tpt_bq_to_td_loader.secrets()
            TERADATA_PASSWORD = ssh_class_obj.TERADATA_PASSWORD
            GCS_ACCESS_KEY = ssh_class_obj.GCS_ACCESS_KEY
            GCS_SECRET_ACCESS_KEY = ssh_class_obj.GCS_SECRET_ACCESS_KEY
            gcs_to_td_load = KubernetesPodOperator(
                   task_id='gcs_to_td_load',
                   cmds=["bash"],
                   arguments= argument_list['arguments'],
                   container_resources=k8s.V1ResourceRequirements(
                       requests={
                            "cpu": "100m",
                            "memory": "64Mi",
                            },
                       limits={
                            "cpu": "2000m",
                            "memory": "512Mi",
                               },
                           ),
                  namespace="composer-2-6-6-airflow-2-7-3-dc435e82",
                  config_file="/home/airflow/composer_kube_config",
                  secrets=[TERADATA_PASSWORD, GCS_ACCESS_KEY, GCS_SECRET_ACCESS_KEY],
                  #env_vars={'username':'tpt_admin','password':'tptAdmin@2024'},
                  image="teradata/tpt:latest",
                  kubernetes_conn_id="kubernetes_default",
                  on_failure_callback=lambda context:tpt_bq_to_td_loader.on_failure_mail(context,self.dagId,self.projectDetails),
                  )
            # clean_up_execution = TeradataOperator(
            #     task_id='fetch_teradata_count',
            #     sql="",
            #     teradata_conn_id="wireless_tpt_td_conn",
            #     do_xcom_push=True,
            #     # on_failure_callback=pushFailureStatus
            # )
    
            fetch_arguemnts >> gcs_to_td_load
            

            return self
