"""
File Name: CustomTaskGroupGcsToBq.py
Desciption: This is a python utility to load data from jdbc table to bigquery
"""

from datetime import datetime
from functools import reduce
import logging
import traceback
import sys
import re
from airflow.models import TaskInstance
from airflow.models import XCom
from airflow.utils.task_group import TaskGroup
from airflow.decorators import task
from airflow.providers.google.cloud.operators.bigquery import BigQueryInsertJobOperator
from airflow.operators.python import BranchPythonOperator
from airflow.exceptions import AirflowSkipException, AirflowFailException
from airflow.operators.empty import EmptyOperator
from airflow.operators.python_operator import PythonOperator
from airflow.providers.google.cloud.hooks.gcs import GCSHook


class CustomTaskGroupGcsToBq(TaskGroup):

    def __init__(self, group_id, metadataParams, bucketNameVars, variables, dagId, projectDetails, tz,
                 opsgenie_priority, ingestionPattern, taskType, sourceFileObject, last_task=None, superGroupId="",
                 custom_labels=None, fileSensorDetails=None, alertTeamName=None, sub_lob_alert=None, last_task_num=None,
                 archival_task=None, parallelLoad="false", **kwargs):
        super().__init__(group_id=group_id, **kwargs)
        self.metadataParams = metadataParams
        self.bucketNameVars = bucketNameVars
        # self.group_id = group_id
        self.variables = variables
        self.dagId = dagId
        self.projectDetails = projectDetails
        self.tz = tz
        self.opsgenie_priority = opsgenie_priority
        self.ingestionPattern = ingestionPattern
        self.taskType = taskType
        self.sourceFileObject = sourceFileObject
        self.last_task = last_task
        self.last_task_num = last_task_num
        self.superGroupId = superGroupId
        self.custom_labels = custom_labels if custom_labels != "None" else None
        self.fileSensorDetails = fileSensorDetails
        self.alertTeamName = alertTeamName if alertTeamName != "None" else None
        self.sub_lob_alert = sub_lob_alert if sub_lob_alert != "None" else None
        self.archival_task = archival_task
        self.parallelLoad = parallelLoad

    def FailureAlertForAudit(self, context):
        projectDetails = self.projectDetails
        projectSpace = projectDetails[2]
        BASE_DIR = "/home/airflow/gcs/dags/" + projectSpace + "/beamx"
        sys.path.append(f"{BASE_DIR}/utils")
        from common_utility_functions import pushFailureStatus
        from ops_genie import send_alert_to_opsgenie
        # pushFailureStatus(context)
        exception = context.get('exception')
        error_msg = str(exception)
        audit_run_status = "FAILURE"
        opsgenie_message = self.variables.get("environment") + " Alert | GCS to BQ audit insert job failed"
        opsgenie_description = error_msg
        opsgenie_priority = self.metadataParams['hook']['OpsgeniePriority']
        alertTeamName = None
        if self.metadataParams['hook']['alertTeamName'] != None:
            alertTeamName = self.metadataParams['hook']['alertTeamName']
        else:
            alertTeamName = None
        opsgenie_details = {"DAG ID": self.dagId, "Error Step": "GCS to BQ audit insert job failed",
                            "Error message": error_msg}

        send_alert_to_opsgenie(opsgenie_message, opsgenie_description, opsgenie_details, opsgenie_priority,
                               projectDetails=projectDetails, alertTeamName=self.alertTeamName,
                               sub_lob_alert=self.sub_lob_alert)

    def preLoadGcsToBq(self, **context):
        variables = self.variables
        params = self.metadataParams
        bucketNameVars = self.bucketNameVars
        dagId = self.dagId
        projectDetails = self.projectDetails
        tz = self.tz
        opsgenie_priority = self.opsgenie_priority
        alertTeamName = self.alertTeamName
        sub_lob_alert = self.sub_lob_alert
        ingestionPattern = self.ingestionPattern
        taskType = self.taskType
        sourceFileObject = self.sourceFileObject
        last_task = self.last_task
        custom_labels = self.custom_labels
        dict_obs = context['ti'].xcom_pull(key='dict_obs')

        print("variables : ", variables)

        # get the project details
        project_space = projectDetails[2]

        # import the necessary modules
        BASE_DIR = "/home/airflow/gcs/dags/" + project_space + "/beamx"
        sys.path.append(f"{BASE_DIR}/utils")
        from dynamic_params import checkDynamicParams
        import bq_loader

        # checking and parsing dynamic params
        params = checkDynamicParams(context, params, taskType)

        # get the sourceFileObject
        sourceFileObject = context['ti'].xcom_pull(key=self.group_id.replace("preprocess_","")+'_sourceFileObject')
        print("Source file object Name is :", sourceFileObject)

        if "*" in params['hook']['sourceUris'] and "bulk load" not in self.taskType.lower()  and 'single_file_pattern' not in params["hook"]:
            # If the file is a placeholder file, skip the tasks
            dummyFileCheck = bq_loader.checkFilePresence(context, bucketNameVars, variables, sourceFileObject, params, projectDetails, dagId, tz, dict_obs, opsgenie_priority, taskType, self.parallelLoad)
            if dummyFileCheck['run_status'] == 'skipped':
                xcoms = {'params': params, 'run_status': 'skipped'}
                context['ti'].xcom_push(key='gcs_to_bq_xcom', value=xcoms)
                raise AirflowSkipException

        # Checking if preprocessing udf is executed for this object. If yes, the file inside the preprocessed folder is considered as the source instead
        if 'preProcessUdf' in params['hook']:
            sourceFileObjectSplit = sourceFileObject.rsplit('/', maxsplit=1)
            sourceFileObject = sourceFileObjectSplit[0] + "/preprocessed/" + sourceFileObjectSplit[1]

        sourceFileName = sourceFileObject.split("/")[-1]

        # The below if condition checks for jobs which have data files and ref files to load load; if passed, the logic for such jobs is executed before calling the generic bq load function

        if 'fileTableMap' in params['hook']:
            # get the process hour
            if 'verizontelecomomni_' in sourceFileObject:
                try:
                    matchObj = re.search(r'\d\d\d\d\d\d\d\d-\d\d\d\d\d\d', sourceFileObject.split("/")[-1])
                    processHour = datetime.strptime(matchObj.group(), '%Y%m%d-%H%M%S').strftime('%H')
                except Exception as e:
                    error_msg = str(e)
                    print("error_msg : ", error_msg)
                    logging.error(traceback.format_exc())
                    raise RuntimeError(" Failed to extract the process hour from the source file name")

                fileTypes = ['refFiles', 'dataFiles'] if str(processHour) == '00' else ['dataFiles']
            elif '.zip' in sourceFileObject:
                fileTypes = ['dataFiles']
            else:
                fileTypes = ['refFiles', 'dataFiles']
            fileTableMap = params["hook"]["fileTableMap"]
            tarFileName = sourceFileObject
            bqInsertJobConfigList = []
            resultList = []
            for key in fileTypes:
                for filename in fileTableMap[key]:
                    tableId = fileTableMap[key][filename]
                    sourceFileObject = tarFileName + "/" + filename
                    if ("*" in sourceFileObject):
                        bucketName = bucketNameVars["PROCESS_BUCKET"].split("/")[-1]
                        gcs_hook = GCSHook(gcp_conn_id=variables[params["hook"]["gcp_conn_id"]])
                        lst = gcs_hook.list(bucket_name=bucketName, match_glob=sourceFileObject)
                        if len(lst) == 1:
                            sourceFileObject = lst[0]

                    print("Loading file ", sourceFileObject, " to table ", tableId)
                    result = bq_loader.preChecksAndInsertJobConfig(context, bucketNameVars, variables, sourceFileObject,
                                                                   sourceFileName, params, projectDetails, dagId, tz,
                                                                   dict_obs, tableId, last_task, ingestionPattern,
                                                                   taskType, custom_labels, self.group_id)

        else:
            tableId = params["hook"]["tableId"]
            result = bq_loader.preChecksAndInsertJobConfig(context, bucketNameVars, variables, sourceFileObject,
                                                           sourceFileName, params, projectDetails, dagId, tz, dict_obs,
                                                           tableId, last_task, ingestionPattern, taskType,
                                                           custom_labels, self.group_id)

        xcoms = {'params': params, 'result': result}
        print("xcoms : ", xcoms)
        print("gcs_to_bq_xcom : ", xcoms)
        context['ti'].xcom_push(key='gcs_to_bq_xcom', value=xcoms)
        job_id = context['ti'].task_id + "_" + context['dag_run'].run_id[:63]
        context['ti'].xcom_push(key='gcs_to_bq_job_id', value=job_id)

        if result['run_status'].lower() == 'failure':
            raise AirflowFailException(result['error_message'])
        if result['run_status'].lower() == 'skipped':
            raise AirflowSkipException

    def branchFunction(self, **context):

        result = \
        context['ti'].xcom_pull(task_ids=f"{self.group_id}.create_config_python_operator", key='gcs_to_bq_xcom')[
            'result']
        if result['run_status'] != 'success':
            return f"{self.group_id}.skip_bq_load"
        else:
            return f"{self.group_id}.gcs_to_bq_load_bigquery_operator"

    def postLoadGcsToBq(self, **context):

        variables = self.variables
        params = self.metadataParams
        dagId = self.dagId
        projectDetails = self.projectDetails
        tz = self.tz
        opsgenie_priority = self.opsgenie_priority
        ingestionPattern = self.ingestionPattern
        sourceFileObject = self.sourceFileObject
        last_task = self.last_task
        fileSensorDetails = self.fileSensorDetails
        last_task_num = self.last_task_num
        superGroupId = self.superGroupId
        taskType = self.taskType
        alertTeamName = self.alertTeamName
        sub_lob_alert = self.sub_lob_alert

        # get the project details
        project_space = projectDetails[2]

        # import the necessary modules
        BASE_DIR = "/home/airflow/gcs/dags/" + project_space + "/beamx"
        sys.path.append(f"{BASE_DIR}/utils")
        from dynamic_params import checkDynamicParams
        from bq_loader import postLoad

        # checking and parsing dynamic params
        params = checkDynamicParams(context, params, taskType)

        try:
            preLoadResult = \
            context['ti'].xcom_pull(task_ids=f"{self.group_id}.create_config_python_operator", key='gcs_to_bq_xcom')[
                'result']

        except TypeError as e:
            raise AirflowSkipException

        result = postLoad(context, self.group_id, variables, sourceFileObject, params, projectDetails, dagId, tz,
                          opsgenie_priority, last_task, ingestionPattern, superGroupId, last_task_num, preLoadResult,
                          alertTeamName, sub_lob_alert, fileSensorDetails)
        xcoms = {'params': params, 'result': result}
        context['ti'].xcom_push(key='beamx_audit', value=xcoms)

        if result['run_status'].lower() == 'failure':
            raise AirflowFailException(result['error_message'])
        if result['run_status'].lower() == 'skipped':
            raise AirflowSkipException

        if result["audit_configuration"] is not None:
            return f"{self.group_id}.gcstobq_beamx_audit"

    def sourceFileArchival(self, **context):
        project_space = self.projectDetails[2]
        BASE_DIR = "/home/airflow/gcs/dags/" + project_space + "/beamx"
        sys.path.append(f"{BASE_DIR}/utils")
        # import the required modules
        from file_archival import multiSrcFileArchival, singleSrcFileArchival
        from dynamic_params import checkDynamicParams
        import bq_loader

        # archival of the source file
        params = self.metadataParams
        parallelLoad = self.parallelLoad

        # checking and parsing dynamic params
        params = checkDynamicParams(context, params, "load file from gcs")

        # get dict_obs
        dict_obs = context['ti'].xcom_pull(key='dict_obs')

        # get the sourceFileObject
        sourceFileObject = context['ti'].xcom_pull(key=self.group_id.replace("preprocess_","")+'_sourceFileObject')
        print("Source file object Name is :", sourceFileObject)

        # ingestion pattern
        ingestionPattern = self.ingestionPattern
        if "*" in params['hook']['sourceUris'] and "bulk load" not in self.taskType.lower() and 'single_file_pattern' not in params["hook"] :
            # get the source file object name
            #sourceFileObject = self.sourceFileObject

            # If the file is a placeholder file, skip the tasks
            dummyFileCheck = bq_loader.checkFilePresence(context, self.bucketNameVars, self.variables, sourceFileObject, params,self.projectDetails, self.dagId, self.tz, dict_obs, " ","multi_file_ingestion",self.parallelLoad)
            if dummyFileCheck['run_status'] == 'skipped':
                raise AirflowSkipException

            op_args = [sourceFileObject]

            multiSrcFileArchival(params, op_args, context, self.bucketNameVars, self.variables, self.tz,
                                 self.ingestionPattern, self.group_id, self.parallelLoad)
        else:
            fileSensorDetails = self.fileSensorDetails

            singleSrcFileArchival(context, params, self.bucketNameVars, self.variables, self.ingestionPattern,self.taskType,fileSensorDetails, self.group_id)

    def FailureAlert(self, context):
        projectDetails = self.projectDetails
        projectSpace = projectDetails[2]

        BASE_DIR = "/home/airflow/gcs/dags/" + projectSpace + "/beamx"
        sys.path.append(f"{BASE_DIR}/utils")

        from common_utility_functions import pushFailureStatus, pushLoadStatusResult

        exception = context.get('exception')
        if exception:
            error_msg = str(exception)
            errorDetails = {'error_msg': error_msg, 'run_status': "failure"}
            context['ti'].xcom_push(key=f'{self.group_id}_errorDetails', value=errorDetails)
            pushFailureStatus(context)
            pushLoadStatusResult(context, self.group_id, "failure")

    def gcsToBqSuccess(self, context):
        projectDetails = self.projectDetails
        projectSpace = projectDetails[2]

        BASE_DIR = "/home/airflow/gcs/dags/" + projectSpace + "/beamx"
        sys.path.append(f"{BASE_DIR}/utils")

        from common_utility_functions import pushFailureStatus, pushLoadStatusResult

        pushLoadStatusResult(context, self.group_id, "success")

    def taskGroupStatus(self, **context):

        #xcom pull to get the file size
        fileSize = context['ti'].xcom_pull(key=self.group_id.replace("preprocess_","")+'_fileSize')
       
        if fileSize is not None and fileSize <= 4:
            print("Task status success as file is zero byte")
       
        upstreamTaskId = f'{self.group_id}.archival_gcs_to_bq'
        prevTaskRunState = (
            TaskInstance(context['dag'].get_task(upstreamTaskId), context['logical_date'])).current_state()
        if str(prevTaskRunState).lower() != 'success' :
            raise AirflowSkipException("upstream job failed")
        # get the load status of bq load and xcom push for bqtrasnform step
        gcsToBqLoadStatus = context['ti'].xcom_pull(
            key=(context['ti'].task_id).replace(".task_group_status", "") + "_loadStatus")
        gcsToBqLoadStatus = "failure" if gcsToBqLoadStatus == None else gcsToBqLoadStatus
        context['ti'].xcom_push(key='load_status', value=gcsToBqLoadStatus)
        gcsToBqTaskId = f'{self.group_id}.gcs_to_bq_load_bigquery_operator'
        gcsToBqTaskIdRunState = (
            TaskInstance(context['dag'].get_task(gcsToBqTaskId), context['logical_date'])).current_state()
        if (gcsToBqTaskIdRunState.lower() == 'skipped' or gcsToBqTaskIdRunState.lower() == 'upstream_failed')  and fileSize is not None and fileSize > 4:
            raise AirflowSkipException("skipping as the upstream skipped")
        elif gcsToBqTaskIdRunState.lower() != 'success' and fileSize is not None and fileSize > 4:
            context['ti'].xcom_push(key='taskgrpstatus', value='failure')
            raise AirflowFailException(" gcs to bq job failed")
        elif self.taskType == "bulk load from gcs to bq":
            bulkLoadFileList = context['ti'].xcom_pull(key=self.group_id + '_bulk_load_file_list_final')
            print("bulkLoadFileList : ", bulkLoadFileList)       
            if bulkLoadFileList is None or bulkLoadFileList == []:
                return
        elif fileSize is None:
            context['ti'].xcom_push(key='taskgrpstatus', value='failure')
            raise AirflowFailException("fileSize is None")            
        context['ti'].xcom_push(key='taskgrpsuccess', value='success')

    def createTaskGroup(self):
        projectDetails = self.projectDetails
        projectSpace = projectDetails[2]
        BASE_DIR = "/home/airflow/gcs/dags/" + projectSpace + "/beamx"
        sys.path.append(f"{BASE_DIR}/utils")
        from common_utility_functions import pushFailureStatus

        with self:
            if self.archival_task is not None:

                create_config_python_operator = PythonOperator(
                    task_id='create_config_python_operator',
                    python_callable=self.preLoadGcsToBq,
                    on_failure_callback=pushFailureStatus
                )
                create_config_python_operator.doc_md = """ GCS to BQ Staging load"""

                branch_task = BranchPythonOperator(
                    task_id='branch_task',
                    python_callable=self.branchFunction
                )

                gcs_to_bq_load_bigquery_operator = BigQueryInsertJobOperator(
                    task_id="gcs_to_bq_load_bigquery_operator",
                    deferrable=True,
                    gcp_conn_id=self.variables[self.metadataParams["hook"]["gcp_conn_id"]],
                    on_failure_callback=self.FailureAlert,
                    on_success_callback=self.gcsToBqSuccess,
                    configuration=f"{{{{ ti.xcom_pull(task_ids='{self.group_id}.create_config_python_operator',key='gcs_to_bq_xcom')['result']['bqInsertJobConfig'] }}}}"
                    # job_id=f"{{{{ ti.xcom_pull(task_ids='{self.group_id}.create_config_python_operator',key='gcs_to_bq_job_id') }}}}"
                )

                skip_bq_load = EmptyOperator(
                    task_id='skip_bq_load'
                )

                observability_prep_python_operator = BranchPythonOperator(
                    task_id='observability_prep_python_operator',
                    python_callable=self.postLoadGcsToBq,
                    trigger_rule='all_done'
                )

                gcstobq_beamx_audit = BigQueryInsertJobOperator(
                    task_id="gcstobq_beamx_audit",
                    deferrable=True,
                    gcp_conn_id=self.variables[self.metadataParams["hook"]["gcp_conn_id"]],
                    on_failure_callback=self.FailureAlertForAudit,
                    configuration=f"{{{{ti.xcom_pull(task_ids='{self.group_id}.observability_prep_python_operator',key='beamx_audit')['result']['audit_configuration']}}}}"

                )

                archival_gcs_to_bq = PythonOperator(
                    task_id=f'archival_gcs_to_bq',
                    python_callable=self.sourceFileArchival,
                    trigger_rule='all_done',
                    on_failure_callback=pushFailureStatus
                )

                task_group_status = PythonOperator(
                    task_id="task_group_status",
                    python_callable=self.taskGroupStatus,
                    trigger_rule='all_done',
                    on_failure_callback=pushFailureStatus
                )

                create_config_python_operator >> branch_task >> [gcs_to_bq_load_bigquery_operator,
                                                                 skip_bq_load] >> observability_prep_python_operator >> gcstobq_beamx_audit >> archival_gcs_to_bq >> task_group_status
            else:
                create_config_python_operator = PythonOperator(
                    task_id='create_config_python_operator',
                    python_callable=self.preLoadGcsToBq,
                    on_failure_callback=pushFailureStatus
                )
                create_config_python_operator.doc_md = """ GCS to BQ Staging load"""

                branch_task = BranchPythonOperator(
                    task_id='branch_task',
                    python_callable=self.branchFunction
                )

                gcs_to_bq_load_bigquery_operator = BigQueryInsertJobOperator(
                    task_id="gcs_to_bq_load_bigquery_operator",
                    deferrable=True,
                    gcp_conn_id=self.variables[self.metadataParams["hook"]["gcp_conn_id"]],
                    on_failure_callback=self.FailureAlert,
                    on_success_callback=self.gcsToBqSuccess,
                    configuration=f"{{{{ ti.xcom_pull(task_ids='{self.group_id}.create_config_python_operator',key='gcs_to_bq_xcom')['result']['bqInsertJobConfig'] }}}}"
                    # job_id=f"{{{{ ti.xcom_pull(task_ids='{self.group_id}.create_config_python_operator',key='gcs_to_bq_job_id') }}}}"
                )

                skip_bq_load = EmptyOperator(
                    task_id='skip_bq_load'
                )

                observability_prep_python_operator = BranchPythonOperator(
                    task_id='observability_prep_python_operator',
                    python_callable=self.postLoadGcsToBq,
                    trigger_rule='all_done'
                )

                gcstobq_beamx_audit = BigQueryInsertJobOperator(
                    task_id="gcstobq_beamx_audit",
                    deferrable=True,
                    gcp_conn_id=self.variables[self.metadataParams["hook"]["gcp_conn_id"]],
                    on_failure_callback=self.FailureAlertForAudit,
                    configuration=f"{{{{ti.xcom_pull(task_ids='{self.group_id}.observability_prep_python_operator',key='beamx_audit')['result']['audit_configuration']}}}}"

                )

                create_config_python_operator >> branch_task >> [gcs_to_bq_load_bigquery_operator,
                                                                 skip_bq_load] >> observability_prep_python_operator >> gcstobq_beamx_audit

            return self
