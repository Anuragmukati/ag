"""
File Name: CustomTaskGroupBQToJdbc.py
Desciption: This is a python utility to load data from jdbc table to bigquery
"""

from datetime import datetime
from functools import reduce
import logging
import traceback
import sys
import re
from airflow.models import TaskInstance
from airflow.models import XCom
from airflow.utils.task_group import TaskGroup
from airflow.decorators import task
from airflow.providers.google.cloud.operators.bigquery import BigQueryInsertJobOperator
from airflow.operators.python import BranchPythonOperator
from airflow.exceptions import AirflowSkipException, AirflowFailException
from airflow.operators.empty import EmptyOperator
from airflow.operators.python_operator import PythonOperator
from airflow.providers.google.cloud.hooks.gcs import GCSHook
#from airflow.providers.teradata.operators.teradata import TeradataOperator
from airflow.exceptions import AirflowSkipException, AirflowFailException

class CustomTaskGroupBqToJdbc(TaskGroup):

    def __init__(self, group_id, metadataParams, bucketNameVars,varMap,variables, dagId, projectDetails, tz,
                 opsgenie_priority, ingestionPattern, taskType, last_task=None, last_task_num=None, superGroupId=None,
                 custom_labels=None, alertTeamName=None, sub_lob_alert=None, jdbc_check_load_status=None, **kwargs):

        super().__init__(group_id=group_id, **kwargs)
        self.metadataParams = metadataParams
        self.bucketNameVars = bucketNameVars
        self.varMap = varMap
        self.variables = variables
        self.dagId = dagId
        self.projectDetails = projectDetails
        self.tz = tz
        self.opsgenie_priority = opsgenie_priority
        self.ingestionPattern = ingestionPattern
        self.taskType = taskType
        self.last_task = last_task
        self.last_task_num = last_task_num
        self.superGroupId = superGroupId
        self.custom_labels = custom_labels
        self.alertTeamName = alertTeamName
        self.sub_lob_alert = sub_lob_alert
        self.jdbc_check_load_status = jdbc_check_load_status

    def jdbc_transform_load(self, **context):
        variables = self.variables
        params = self.metadataParams
        bucketNameVars = self.bucketNameVars
        dagId = self.dagId
        projectDetails = self.projectDetails
        tz = self.tz
        opsgenie_priority = self.opsgenie_priority
        ingestionPattern = self.ingestionPattern
        taskType = self.taskType
        last_task = self.last_task
        last_task_num = self.last_task_num
        superGroupId = self.superGroupId
        custom_labels = self.custom_labels
        alertTeamName = self.alertTeamName
        sub_lob_alert =self.sub_lob_alert
        # get the project details
        project_tag = projectDetails[0]
        business_line = projectDetails[1]
        project_space = projectDetails[2]

        # import the necessary modules
        BASE_DIR = "/home/airflow/gcs/dags/" + project_space+ "/beamx"
        sys.path.append(f"{BASE_DIR}/utils")
        from dynamic_params import checkDynamicParams
        from common_utility_functions import pushFailureStatus
        import bq_transformer
        import jdbc_to_bq_loader
        import jdbc_transformer

        # checking and parsing dynamic params
        params = checkDynamicParams(context, params, "run jdbc query")
        dict_obs = context['ti'].xcom_pull(key='dict_obs')

        gcs_to_td_tpt_status = context['ti'].xcom_pull(key='gcs_to_td_status')
        print(gcs_to_td_tpt_status)
        if gcs_to_td_tpt_status is not None and gcs_to_td_tpt_status in ["upstream_failed", "skipped", "failed"]:
            raise AirflowSkipException

        result = jdbc_transformer.jdbcTransform(context, self.metadataParams, self.variables, self.varMap, self.dagId, dict_obs, self.projectDetails, self.tz,
                                                self.opsgenie_priority, ingestion_pattern="jdbc_to_bq",
                                                alertTeamName=self.alertTeamName, sub_lob_alert=self.sub_lob_alert)

        xcoms = {'params': params, 'result': result}
        print("xcoms : ", xcoms)
        if result['run_status'].lower() == 'failure':
            raise AirflowFailException

    def branchFunction(self, **context):
        table_details = context['ti'].xcom_pull(key='final_target_table')

        if table_details is not None:
            return f"{self.group_id}.final_target_table_audit"
        else:
            return f"{self.group_id}.skip_audit"

    def audit_table(self,**context):
        projectDetails = self.projectDetails
        project_space = projectDetails[2]
        BASE_DIR = "/home/airflow/gcs/dags/" + project_space+ "/beamx"
        sys.path.append(f"{BASE_DIR}/utils")
        import tpt_bq_to_td_loader
        final_target_table = context['ti'].xcom_pull(key='final_target_table')
        final_target_dbname = context['ti'].xcom_pull(key='final_target_dbname')
        audit_table_db = context['ti'].xcom_pull(key='audit_table_db')

        tpt_bq_to_td_loader.audit_table_entry(self.varMap,self.metadataParams,self.tz,self.dagId, self.projectDetails,self.bucketNameVars, self.variables,final_target_table,final_target_dbname,audit_table_db)

    def createTaskGroupStatus(self, **context):
        
        jdbcTaskId = f'{self.group_id}.jdbc_transform_load'
        jdbcTaskRunState = (
            TaskInstance(context['dag'].get_task(jdbcTaskId), context['logical_date'])).current_state()
        
        if str(jdbcTaskRunState).lower() == 'skipped' :
            raise AirflowSkipException("***Dataproc Job Skipped***")
        elif str(jdbcTaskRunState).lower() != 'success' :
            raise AirflowFailException("***Dataproc Job Failed***")    


    def createTaskGroup(self):
        projectDetails = self.projectDetails
        projectSpace = projectDetails[2]
        BASE_DIR = "/home/airflow/gcs/dags/" + projectSpace + "/beamx"
        sys.path.append(f"{BASE_DIR}/utils")
        from common_utility_functions import pushFailureStatus

        with self:

            jdbc_transform_load = PythonOperator(
                task_id='jdbc_transform_load',
                python_callable=self.jdbc_transform_load,
                on_failure_callback=pushFailureStatus
            )
            branch_task = BranchPythonOperator(
                task_id='branch_task',
                python_callable=self.branchFunction
            )
            final_target_table_audit = PythonOperator(
                task_id='final_target_table_audit',
                python_callable=self.audit_table,
                on_failure_callback=pushFailureStatus
            )
            skip_audit = EmptyOperator(
                task_id='skip_audit'
            )

            task_group_status = PythonOperator(
                    task_id="task_group_status",
                    python_callable=self.createTaskGroupStatus,
                    trigger_rule='all_done',
                    on_failure_callback=pushFailureStatus
                )

            jdbc_transform_load >> branch_task >> [final_target_table_audit,skip_audit] >> task_group_status

            return self
