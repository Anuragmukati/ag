"""
File Name: CustomTaskGroupGcsToBqTPT.py
Desciption: This is a python utility to load data from jdbc table to bigquery
"""

from datetime import datetime
from functools import reduce
import logging
import traceback
import sys
import re
from airflow.models import TaskInstance
from airflow.models import XCom
from airflow.utils.task_group import TaskGroup
from airflow.decorators import task
from airflow.providers.google.cloud.operators.bigquery import BigQueryInsertJobOperator
from airflow.operators.python import BranchPythonOperator
from airflow.providers.google.cloud.hooks.bigquery import BigQueryHook
from google.cloud import bigquery
from airflow.exceptions import AirflowSkipException, AirflowFailException
from airflow.operators.empty import EmptyOperator
from airflow.operators.python_operator import PythonOperator
from airflow.providers.google.cloud.hooks.gcs import GCSHook
#from airflow.providers.teradata.operators.teradata import TeradataOperator
from airflow.exceptions import AirflowSkipException, AirflowFailException

class CustomTaskGroupGcsToBqTpt(TaskGroup):

    def __init__(self, group_id, metadataParams, bucketNameVars,varMap, variables, dagId, projectDetails, tz,
                 opsgenie_priority, ingestionPattern, taskType, last_task=None, last_task_num=None, superGroupId=None,
                 custom_labels=None, alertTeamName=None, sub_lob_alert=None, jdbc_check_load_status=None, **kwargs):
        super().__init__(group_id=group_id, **kwargs)
        self.metadataParams = metadataParams
        self.params =metadataParams
        self.bucketNameVars = bucketNameVars
        self.varMap = varMap
        self.variables = variables
        self.dagId = dagId
        self.projectDetails = projectDetails
        self.tz = tz
        self.opsgenie_priority = opsgenie_priority
        self.ingestionPattern = ingestionPattern
        self.taskType = taskType
        self.last_task = last_task
        self.last_task_num = last_task_num
        self.superGroupId = superGroupId
        self.custom_labels = custom_labels
        self.alertTeamName = alertTeamName
        self.sub_lob_alert = sub_lob_alert
        self.jdbc_check_load_status = jdbc_check_load_status

    def preLoadGcsToBq(self, **context):
        variables = self.variables
        params = self.metadataParams
        bucketNameVars = self.bucketNameVars
        dagId = self.dagId
        projectDetails = self.projectDetails
        tz = self.tz
        opsgenie_priority = self.opsgenie_priority
        ingestionPattern = self.ingestionPattern
        taskType = self.taskType
        last_task = self.last_task
        last_task_num = self.last_task_num
        superGroupId = self.superGroupId
        custom_labels = self.custom_labels
        alertTeamName = self.alertTeamName
        sub_lob_alert =self.sub_lob_alert
        # get the project details
        project_tag = projectDetails[0]
        business_line = projectDetails[1]
        project_space = projectDetails[2]

        # import the necessary modules
        BASE_DIR = "/home/airflow/gcs/dags/" + project_space+ "/beamx"
        sys.path.append(f"{BASE_DIR}/utils")
        from dynamic_params import checkDynamicParams
        from common_utility_functions import pushFailureStatus
        import tpt_td_to_bq_loader

        # checking and parsing dynamic params
        params = checkDynamicParams(context, params, taskType)
        tableId = params["hook"]["tableId"]

        result = tpt_td_to_bq_loader.preChecksAndJobConfiguration(params, dagId, projectDetails, tz, context, bucketNameVars, variables,
                                         last_task, ingestionPattern, opsgenie_priority, last_task_num, superGroupId,
                                         custom_labels, alertTeamName,sub_lob_alert, taskType)


        xcoms = {'params': params, 'result': result}
        context['ti'].xcom_push(key='preloadresult', value=xcoms)
        print("xcoms : ", xcoms)
        if result['run_status'].lower() == 'failure':
            raise AirflowFailException

    def branchFunction(self, **context):
        result = context['ti'].xcom_pull(task_ids=f"{self.superGroupId}.create_config_python_operator",
                                key='preloadresult')['result']
        print(f"""{{{{ ti.xcom_pull(task_ids='{self.superGroupId}.create_config_python_operator',key='preloadresult')['result']['bqInsertJobConfig'] }}}}""")

        if result['run_status'] != 'SUCCESS':
            return f"{self.superGroupId}.skip_bq_load"
        else:
            return f"{self.superGroupId}.gcs_to_bq_load_bigquery_operator"


    def FailureAlert(self,context):
        projectDetails = self.projectDetails
        projectSpace = projectDetails[2]

        BASE_DIR = "/home/airflow/gcs/dags/" + projectSpace+ "/beamx"
        sys.path.append(f"{BASE_DIR}/utils")

        from common_utility_functions import pushFailureStatus,pushLoadStatusResult

        exception = context.get('exception')
        if exception:
            error_msg = str(exception)
            run_status = "FAILURE"
            gcstobqrunstatus = {'error_msg': error_msg, 'run_status': run_status}
            context['ti'].xcom_push(key='gcstobqrunstatus',value = gcstobqrunstatus )
            pushFailureStatus(context)
            pushLoadStatusResult(context, self.group_id, "failure")

    def FailureAlertForAudit(self,context):
        projectDetails = self.projectDetails
        projectSpace = projectDetails[2]
        BASE_DIR = "/home/airflow/gcs/dags/" + projectSpace+ "/beamx"
        sys.path.append(f"{BASE_DIR}/utils")
        from common_utility_functions import pushFailureStatus
        from ops_genie import send_alert_to_opsgenie

        exception = context.get('exception')
        error_msg = str(exception)
        audit_run_status = "FAILURE"
        opsgenie_message = Variable.get("environment") + " Alert | TPT TD to BQ audit insert job failed"
        opsgenie_description = audit_error_msg
        opsgenie_priority = params['hook']['OpsgeniePriority']
        alertTeamName = self.alertTeamName
        sub_lob_alert =self.sub_lob_alert
        opsgenie_details = {"DAG ID": dagId, "Error Step": "TPT TD to BQ audit insert job failed",
                            "Error message": audit_error_msg}
        if (retries == 0 and task_instance.try_number == 1) or (
                retries > 0 and task_instance.try_number == retries + 1):
            send_alert_to_opsgenie(opsgenie_message, opsgenie_description, opsgenie_details, opsgenie_priority,
                                   projectDetails=projectDetails, alertTeamName=alertTeamName,sub_lob_alert=sub_lob_alert)
        #pushFailureStatus(context)


    def postLoadGcsToBq(self, **context):
        variables = self.variables
        params = self.metadataParams
        dagId = self.dagId
        projectDetails = self.projectDetails
        tz = self.tz
        taskType = self.taskType
        opsgenie_priority = self.opsgenie_priority
        ingestionPattern = self.ingestionPattern
        last_task = self.last_task
        last_task_num = self.last_task_num
        superGroupId = self.superGroupId
        projectSpace = projectDetails[2]
        alertTeamName = self.alertTeamName
        sub_lob_alert =self.sub_lob_alert
        # import the necessary modules
        BASE_DIR = "/home/airflow/gcs/dags/" + projectSpace + "/beamx"
        sys.path.append(f"{BASE_DIR}/utils")
        from dynamic_params import checkDynamicParams
        from common_utility_functions import pushFailureStatus
        from tpt_td_to_bq_loader import postLoad

        # checking and parsing dynamic params
        params = checkDynamicParams(context, params, taskType)

        try:
            preLoadResult = \
            context['ti'].xcom_pull(task_ids=f"{self.superGroupId}.create_config_python_operator",
                                    key='preloadresult')['result']
            if preLoadResult['run_status'].lower() == 'failure':
                raise AirflowSkipException

        except TypeError as e:
            raise AirflowSkipException

        result = postLoad(context, variables, params, projectDetails, dagId, tz, opsgenie_priority, last_task,
                 ingestionPattern, superGroupId, last_task_num,alertTeamName,sub_lob_alert, preLoadResult)

        xcoms = {'params': params, 'result': result}
        context['ti'].xcom_push(key='beamx_audit', value=xcoms)


    def recordCountReconciliation(self,**context):

        params = self.metadataParams

        from ops_genie import send_alert_to_opsgenie
        # check Record count reconciliation
        try:
            preLoadResult = \
            context['ti'].xcom_pull(task_ids=f"{self.superGroupId}.create_config_python_operator",
                                    key='preloadresult')['result']
            if preLoadResult['run_status'].lower() == 'failure':
                raise AirflowSkipException

        except TypeError as e:
            raise AirflowSkipException

        if "audit_table_db" in params["hook"]:
            audit_db_td_bq = params["hook"]["audit_table_db"]
        else:
            audit_db_td_bq = self.variables["audit_db_td_bq"]

        if "projectId" in params["hook"]:
            gcp_project = reduce(lambda key, value: key.replace(*value), self.varMap.items(), params["hook"]["projectId"])
            print(gcp_project)
        else:
            gcp_project = project_id
        print("preLoadResult:",preLoadResult)
        dict_obs = preLoadResult['dict_obs']
 
        run_id_dag = str(context["dag_run"].run_id)[0: str(context["dag_run"].run_id).index("+")] \
            .replace(".", "-").replace(":", "-").replace("__", "-").lower()
        # if run_id_dag.endswith("-"):
        #     run_id_dag = run_id_dag[:-1]
        process_run_id = f"{self.dagId}_" + str(run_id_dag)
        running_instance_id = process_run_id
        task_instance = context['task_instance']
        bq_hook = BigQueryHook(gcp_conn_id=self.variables[self.params["hook"]["gcp_conn_id"]])
        client = bigquery.Client(project=bq_hook._get_field("project"), credentials=bq_hook.get_credentials())
        reconciliation_query = f'''SELECT
                       COALESCE(MAX(CASE WHEN sub_process like "%td_to_gcs%" THEN source_count END),"NA") AS source_count,
                    COALESCE(MAX(CASE WHEN sub_process like "%gcs_to_bq%" THEN target_count END),"NA") AS target_count,
                   COALESCE(MAX(CASE WHEN sub_process like "%gcs_to_bq%" THEN bad_records_count END),"NA") as bad_records_count
                    FROM
                    (SELECT source_count,target_count,sub_process,bad_records_count,end_time,
                        ROW_NUMBER() OVER (PARTITION BY application_id ORDER BY end_time DESC) AS rn
                    FROM `{gcp_project}`.`{audit_db_td_bq}`.audit where application_id ='{running_instance_id}') AS latest_audit WHERE source_count is not NULL and target_count is not NULL;'''
        print("reconciliation_query is :", reconciliation_query)
        query_job = client.query(reconciliation_query)
        results = query_job.to_dataframe()
        source_count_result = results.iloc[0, 0]
        target_count_result = results.iloc[0, 1]
        bad_records_count_result = results.iloc[0, 2]
        if bad_records_count_result == 'NA' or bad_records_count_result == '':
            bad_records_count_result = 0
        if source_count_result == 'NA' or source_count_result == '':
            source_count_result = 0
        if target_count_result == 'NA' or target_count_result == '':
            target_count_result = 0
        if int(source_count_result) == int(target_count_result):
            print("reconciliation of Count Matched")
        elif int(source_count_result) == int(target_count_result) + int(bad_records_count_result):
            print("reconciliation of Count Matched with adding bad_records_count_result in source_count_result")
        else:
            print("reconciliation of Count Not Matched")
            print("Checking reconciliation of Count Alert_flag provided is params")
            if "alert_on_record_mismatch" in params["hook"]:
                alert_on_record_mismatch = params["hook"]["alert_on_record_mismatch"].lower()
                if alert_on_record_mismatch == "yes":
                    task_instance = context['task_instance']
                    opsgenie_message = "Beamx|" + variables["environment"] + "|Failure|" + task_instance.task_id + "|" + \
                                       dict_obs['running_instance_id']
                    opsgenie_description = "Failure |Reconciliation of record count not Matched|" + dict_obs[
                        'running_instance_id']
                    opsgenie_details = {"DAG ID": self.dagId, "Error Step": "Reconciliation of record count not Matched",
                                        "Target Table": audit_db_td_bq + ".audit"}
                    send_alert_to_opsgenie(opsgenie_message, opsgenie_description, opsgenie_details, opsgenie_priority,
                                           projectDetails=projectDetails, sub_lob_alert=sub_lob_alert)
            else:
                print("alert_on_record_mismatch flag not found in params['hook']")
        print("reconciliation_query source_count_result  :", source_count_result)
        print("reconciliation_query target_count_result  :", target_count_result)
        print("reconciliation_query bad_records_count_result  :", bad_records_count_result)

    def createTaskGroup(self):
        projectDetails = self.projectDetails
        projectSpace = projectDetails[2]
        BASE_DIR = "/home/airflow/gcs/dags/" + projectSpace + "/beamx"
        sys.path.append(f"{BASE_DIR}/utils")
        from common_utility_functions import pushFailureStatus

        with self:

            #fetch_teradata_count = TeradataOperator(
            #    task_id='fetch_teradata_count',
            #    sql="",
            #    teradata_conn_id="wireless_tpt_td_conn",
            #    do_xcom_push=True,
            #    on_failure_callback=pushFailureStatus
            #)
            create_config_python_operator = PythonOperator(
                task_id='create_config_python_operator',
                python_callable=self.preLoadGcsToBq,
                on_failure_callback=pushFailureStatus
            )

            branch_task = BranchPythonOperator(
                task_id='branch_task',
                python_callable=self.branchFunction
            )

            gcs_to_bq_load_bigquery_operator = BigQueryInsertJobOperator(
                task_id="gcs_to_bq_load_bigquery_operator",
                deferrable=True,
                gcp_conn_id=self.variables[self.metadataParams["hook"]["gcp_conn_id"]],
                on_failure_callback=self.FailureAlert,
                configuration = f"{{{{ti.xcom_pull(task_ids='{self.superGroupId}.create_config_python_operator',key='preloadresult')['result']['bqInsertJobConfig']}}}}"

            )

            skip_bq_load = EmptyOperator(
                task_id='skip_bq_load'
            )

            observability_prep_python_operator = PythonOperator(
                task_id='observability_prep_python_operator',
                python_callable=self.postLoadGcsToBq,
                trigger_rule='all_done'
            )

            gcstobq_beamx_audit = BigQueryInsertJobOperator(
                task_id="gcstobq_beamx_audit",
                deferrable=True,
                gcp_conn_id=self.variables[self.metadataParams["hook"]["gcp_conn_id"]],
                on_failure_callback=self.FailureAlertForAudit,
                configuration = f"{{{{ti.xcom_pull(task_ids='{self.superGroupId}.observability_prep_python_operator',key='beamx_audit')['result']['audit_configuration']}}}}"

            )

            audit_record_count_reconciliation = PythonOperator(
                task_id='audit_record_count_reconciliation',
                python_callable=self.recordCountReconciliation,
                provide_context=True,
                trigger_rule="all_done"
            )

            create_config_python_operator >> branch_task >> [gcs_to_bq_load_bigquery_operator,
                                                             skip_bq_load] >> observability_prep_python_operator >> gcstobq_beamx_audit >> audit_record_count_reconciliation

            return self
