"""
File Name: CustomTaskGroupGcsToBqTPT.py
Desciption: This is a python utility to load data from jdbc table to bigquery
"""

from datetime import datetime
from functools import reduce
import logging
import traceback
import sys
import re
from airflow.models import TaskInstance
from airflow.models import XCom
from airflow.utils.task_group import TaskGroup
from airflow.decorators import task
from airflow.providers.google.cloud.operators.dataproc import DataprocCreateBatchOperator, DataprocSubmitJobOperator
from google.cloud import bigquery
from airflow.exceptions import AirflowSkipException, AirflowFailException
from airflow.operators.python_operator import PythonOperator

class CustomTaskGroupCustomSparkJob(TaskGroup):

    def __init__(self, group_id, metadataParams, bucketNameVars,varMap, variables, dagId, projectDetails, tz, opsgenie_priority, ingestionPattern, taskType, serverless, custom_labels=None, alertTeamName=None, sub_lob_alert=None, last_task = None,superGroupId=None, **kwargs):
        super().__init__(group_id=group_id, **kwargs)
        self.groupId = group_id
        self.metadataParams = metadataParams
        self.params =metadataParams
        self.bucketNameVars = bucketNameVars
        self.varMap = varMap
        self.variables = variables
        self.dagId = dagId
        self.projectDetails = projectDetails
        self.tz = tz
        self.opsgenie_priority = opsgenie_priority
        self.ingestionPattern = ingestionPattern
        self.taskType = taskType
        self.serverless = serverless
        self.custom_labels = custom_labels
        self.alertTeamName = alertTeamName
        self.sub_lob_alert = sub_lob_alert
        self.last_task = last_task
        self.superGroupId = superGroupId


    def getSparkJobConfig(self, **context):
        variables = self.variables
        params = self.metadataParams
        bucketNameVars = self.bucketNameVars
        dagId = self.dagId
        projectDetails = self.projectDetails
        tz = self.tz
        opsgenie_priority = self.opsgenie_priority
        ingestionPattern = self.ingestionPattern
        taskType = self.taskType
        custom_labels = self.custom_labels
        alertTeamName = self.alertTeamName
        sub_lob_alert = self.sub_lob_alert
        superGroupId = self.superGroupId
        serverless = self.serverless

        # get the project details
        project_space = projectDetails[2]

        # import the necessary modules
        BASE_DIR = "/home/airflow/gcs/dags/" + project_space+ "/beamx"
        sys.path.append(f"{BASE_DIR}/utils")
        from dynamic_params import checkDynamicParams
        from common_utility_functions import pushFailureStatus
        import custom_spark_job

        # checking and parsing dynamic params
        params = checkDynamicParams(context, params, taskType)

        result = custom_spark_job.createSparkJobConfig(params, dagId, projectDetails, tz, context, bucketNameVars, variables, ingestionPattern, opsgenie_priority, superGroupId, custom_labels, alertTeamName,sub_lob_alert, taskType, serverless, self.group_id)


        xcoms = {'params': params, 'result': result}
        print("xcoms : ", xcoms)
        context['ti'].xcom_push(key='getSparkJobConfigResult', value=xcoms)

        if result['run_status'].lower() == 'failure':
            raise AirflowFailException(result['error_message'])


    def FailureAlert(self,context):
        projectDetails = self.projectDetails
        projectSpace = projectDetails[2]

        BASE_DIR = "/home/airflow/gcs/dags/" + projectSpace+ "/beamx"
        sys.path.append(f"{BASE_DIR}/utils")

        from common_utility_functions import pushFailureStatus

        exception = context.get('exception')
        if exception:
            error_msg = str(exception)
            run_status = "failure"
            pushFailureStatus(context)
            context['ti'].xcom_push(key='error_message', value = error_msg)



    def sendObservabilityLogs(self, **context):
        variables = self.variables
        params = self.metadataParams
        dagId = self.dagId
        projectDetails = self.projectDetails
        tz = self.tz
        taskType = self.taskType
        opsgenie_priority = self.opsgenie_priority
        ingestionPattern = self.ingestionPattern
        projectSpace = projectDetails[2]
        alertTeamName = self.alertTeamName
        sub_lob_alert =self.sub_lob_alert
        last_task = self.last_task

        # import the necessary modules
        BASE_DIR = "/home/airflow/gcs/dags/" + projectSpace + "/beamx"
        sys.path.append(f"{BASE_DIR}/utils")
        from dynamic_params import checkDynamicParams
        from common_utility_functions import pushFailureStatus
        import custom_spark_job

        # checking and parsing dynamic params
        params = checkDynamicParams(context, params, taskType)

        try:
            getSparkJobConfigResult = \
            context['ti'].xcom_pull(task_ids=f"{self.group_id}.create_config_python_operator",
                                    key='getSparkJobConfigResult')['result']
            # if getSparkJobConfigResult['run_status'].lower() == 'failure':
            #     raise AirflowSkipException

        except TypeError as e:
            raise AirflowSkipException

        result = custom_spark_job.sendObservabilityLogs(context, variables, params, projectDetails, dagId, tz, opsgenie_priority,
                 ingestionPattern,alertTeamName,sub_lob_alert, last_task, getSparkJobConfigResult)

        xcoms = {'params': params, 'result': result}
        context['ti'].xcom_push(key='beamx_audit', value=xcoms)

    def createTaskGroupStatus(self, **context):
        
        dataprocTaskId = f'{self.group_id}.execute_custom_spark_job'
        dataprocTaskRunState = (
            TaskInstance(context['dag'].get_task(dataprocTaskId), context['logical_date'])).current_state()
        
        if str(dataprocTaskRunState).lower() == 'skipped' :
            raise AirflowSkipException("***Dataproc Job Skipped***")
        elif str(dataprocTaskRunState).lower() != 'success' :
            raise AirflowFailException("***Dataproc Job Failed***")


    def createTaskGroup(self):
        projectDetails = self.projectDetails
        projectSpace = projectDetails[2]
        BASE_DIR = "/home/airflow/gcs/dags/" + projectSpace + "/beamx"
        sys.path.append(f"{BASE_DIR}/utils")
        from common_utility_functions import pushFailureStatus

        with self:
            if not self.serverless:

                create_config_python_operator = PythonOperator(
                    task_id='create_config_python_operator',
                    python_callable=self.getSparkJobConfig,
                    on_failure_callback=pushFailureStatus
                )

                submit_spark_job_dataproc_operator = DataprocSubmitJobOperator(
                    task_id='execute_custom_spark_job',
                    job=f"{{{{ti.xcom_pull(task_ids='{self.group_id}.create_config_python_operator',key='getSparkJobConfigResult')['result']['job']}}}}",
                    region=f"{{{{ti.xcom_pull(task_ids='{self.group_id}.create_config_python_operator',key='getSparkJobConfigResult')['result']['region']}}}}",
                    project_id=f"{{{{ti.xcom_pull(task_ids='{self.group_id}.create_config_python_operator',key='getSparkJobConfigResult')['result']['project_id']}}}}",
                    request_id=None,
                    retry=None,
                    timeout=None,
                    gcp_conn_id=self.variables[self.params["hook"]["gcp_conn_id"]],
                    asynchronous=False,
                    deferrable=True,
                    polling_interval_seconds=10,
                    cancel_on_kill=True,
                    wait_timeout=None,
                    on_failure_callback=self.FailureAlertForLoadStatus
                 )


                observability_prep_python_operator = PythonOperator(
                    task_id='observability_prep_python_operator',
                    python_callable=self.sendObservabilityLogs,
                    trigger_rule='all_done'
                )

                task_group_status = PythonOperator(
                    task_id="task_group_status",
                    python_callable=self.createTaskGroupStatus,
                    trigger_rule='all_done',
                    on_failure_callback=pushFailureStatus
                )

                create_config_python_operator >> submit_spark_job_dataproc_operator >> observability_prep_python_operator >> task_group_status

            else:
                create_config_python_operator = PythonOperator(
                    task_id='create_config_python_operator',
                    python_callable=self.getSparkJobConfig,
                    on_failure_callback=pushFailureStatus
                )

                submit_spark_job_dataproc_operator = DataprocCreateBatchOperator(
                    task_id='execute_custom_spark_job',
                    region=f"{{{{ti.xcom_pull(task_ids='{self.group_id}.create_config_python_operator',key='getSparkJobConfigResult')['result']['region']}}}}",
                    batch=f"{{{{ti.xcom_pull(task_ids='{self.group_id}.create_config_python_operator',key='getSparkJobConfigResult')['result']['pyspark_job_config']}}}}",
                    batch_id=f"{{{{ti.xcom_pull(task_ids='{self.group_id}.create_config_python_operator',key='getSparkJobConfigResult')['result']['batch_id']}}}}",
                    project_id=f"{{{{ti.xcom_pull(task_ids='{self.group_id}.create_config_python_operator',key='getSparkJobConfigResult')['result']['project_id']}}}}",
                    request_id=None,
                    retry=None,
                    timeout=None,
                    gcp_conn_id=self.variables[self.params["hook"]["gcp_conn_id"]],
                    asynchronous=False,
                    deferrable=True,
                    on_failure_callback=self.FailureAlert,
                    polling_interval_seconds=5)

                observability_prep_python_operator = PythonOperator(
                    task_id='observability_prep_python_operator',
                    python_callable=self.sendObservabilityLogs,
                    trigger_rule='all_done'
                )

                task_group_status = PythonOperator(
                    task_id="task_group_status",
                    python_callable=self.createTaskGroupStatus,
                    trigger_rule='all_done',
                    on_failure_callback=pushFailureStatus
                )

                create_config_python_operator >> submit_spark_job_dataproc_operator >> observability_prep_python_operator >> task_group_status


            return self
