from airflow.sensors.external_task import ExternalTaskSensor
from airflow.models import DagRun
from airflow.utils.state import State
from airflow.utils.session import provide_session
from datetime import datetime, date, timedelta, timezone, tzinfo
import pytz
from airflow.models.dag import DAG
from airflow.operators.python import get_current_context
import pendulum
import google.auth
from google.auth.transport.requests import AuthorizedSession
import requests
from airflow.hooks.base_hook import BaseHook
from google.auth import credentials
from google.oauth2 import service_account
from google.auth import impersonated_credentials
from airflow.providers.google.cloud.hooks.gcs import GCSHook
import time
import json


class ExternalTaskSensorWithApi(ExternalTaskSensor):
    def __init__(self, execution_date_fn, min_count=1, mode='poke', op_kwargs=None, *args, **kwargs):
        """Custom ExternalTaskSensor that counts dag runs within an interval.
        :param min_count: Minimum number of successful DAG runs required.
        :param execution_date_fn: A function to calculate(start_date, end_date)
        :param mode: The mode of operation ('poke' or 'reschedule').
        """
        print("INITIALIZING ExternalTaskSensorWithApi")
        super().__init__(*args, **kwargs)
        self.op_kwargs = op_kwargs or {}
        self.min_count = min_count
        self.execution_date_fn = execution_date_fn
        self.mode = mode
        self.log.info(f"execution_date_fn assigned: {self.execution_date_fn}")

    def make_composer2_web_server_request(
            self, url, method= "GET", credentials = None, **kwargs
    ) -> google.auth.transport.Response:
        """
        Make a request to Cloud Composer 2 environment's web server.
        Args:
          url: The URL to fetch.
          method: The request method to use ('GET', 'OPTIONS', 'HEAD', 'POST', 'PUT',
            'PATCH', 'DELETE')
          **kwargs: Any of the parameters defined for the request function:
                    https://github.com/requests/requests/blob/master/requests/api.py
                      If no timeout is provided, it is set to 90 by default.
        """
        print("new cred ")
        authed_session = AuthorizedSession(credentials)

        # Set the default timeout, if missing
        if "timeout" not in kwargs:
            kwargs["timeout"] = 90

        return authed_session.request(method, url, **kwargs)

    @provide_session
    def get_count(self, context, session=None):
        """ Fetches the count of successful DAG runs in the
         interval from execution_date_fn."""
        self.log.info("Inside get_count")
        if 'tz' in self.op_kwargs.keys():
            tz = self.op_kwargs.get("tz")
            print("Timezone is: ", tz)
        else:
            tz = "UTC"
        if 'for_any_last_exec_flag' in self.op_kwargs.keys():
            for_any_last_exec_flag = self.op_kwargs.get("for_any_last_exec_flag")
        else:
            for_any_last_exec_flag = 0
        if 'delta_hour' in self.op_kwargs.keys():
            delta_hour = self.op_kwargs.get("delta_hour")
        else:
            delta_hour = 0
        if 'delta' in self.op_kwargs.keys():
            delta = self.op_kwargs.get("delta")
        else:
            delta = 0
        if 'dag_query_days' in self.op_kwargs.keys():
            dag_query_days = self.op_kwargs.get("dag_query_days")
        else:
            dag_query_days = 0
        if 'threshold' in self.op_kwargs.keys():
            threshold = self.op_kwargs.get("threshold")
        else:
            threshold = 0
        start_date, end_date, ld_dt, ld_hr, dt_s = self.execution_date_fn(context, for_any_last_exec_flag, delta_hour,
                                                                          delta, dag_query_days, threshold,
                                                                          self.op_kwargs)
        self.log.info(type(start_date), type(ld_dt), type(ld_hr), type(dt_s))

        variables = self.op_kwargs.get("variables")
        params = self.op_kwargs.get("params")
        if "composer_url" in params:
            web_server_url = variables["composer_instance_endpoints"][params["composer_url"]]
        else:
            web_server_url = variables["composer_url"]
        gcs_hook = GCSHook(gcp_conn_id=variables["gcp_conn_id"])
        credentials = gcs_hook.get_credentials()
        request = google.auth.transport.requests.Request()
        credentials.refresh(request)
        endpoint = f"api/v1/dags/{self.external_dag_id}/dagRuns"
        request_url = f"{web_server_url}/{endpoint}"

        if for_any_last_exec_flag == 0:
            start_date = datetime.strptime(ld_dt, "%Y-%m-%d").astimezone(tz)
            end_date = datetime.strptime(ld_hr, "%Y-%m-%d %H").astimezone(tz)
            self.log.info(f"start_date: {start_date}, end_date: {end_date}")
            self.log.info(f"Checking DAG runs for {self.external_dag_id} between {start_date} and {end_date}.")

            response = self.make_composer2_web_server_request(
                request_url, method="GET", credentials=credentials,
                params={"start_date_gte": start_date,
                        "end_date_lte": end_date}
            )

            if response.status_code == 403:
                raise requests.HTTPError(
                    "You do not have a permission to perform this operation. "
                    "Check Airflow RBAC roles for your account."
                    f"{response.headers} / {response.text}"
                )
            elif response.status_code != 200:
                raise requests.HTTPError(
                    "error occured while triggering the dag"
                    f"{response.headers} / {response.text}"
                )
            else:
                count = 0
                print("check")
                print(response.text)
                for runs in json.loads(response.text)["dag_runs"]:
                    if runs["state"] == "success":
                        count = count + 1
                print("number of dag runs found - ", str(count))
                return count

        elif for_any_last_exec_flag == 1:
            if threshold > 0:
                if start_date.date() < (datetime.strptime(dt_s, "%Y-%m-%d") - timedelta(days=threshold)).date():
                    print("Threshold datetime: ", datetime.strptime(dt_s, "%Y-%m-%d") - timedelta(days=threshold))
                    start_date = (datetime.strptime(dt_s, "%Y-%m-%d") - timedelta(days=threshold)).astimezone(tz)
                else:
                    print("Threshold datetime: ", datetime.strptime(dt_s, "%Y-%m-%d") - timedelta(days=threshold))
            self.log.info(f"start_date: {start_date}, end_date: {end_date}")
            self.log.info(f"Checking DAG runs for {self.external_dag_id} between {start_date} and {end_date}.")
            response = self.make_composer2_web_server_request(
                request_url, method="get", credentials=credentials,
                params={"start_date_gte": str(start_date).replace(' ', 'T'),
                        "end_date_lte": str(end_date).replace(' ', 'T')}
            )

            if response.status_code == 403:
                raise requests.HTTPError(
                    "You do not have a permission to perform this operation. "
                    "Check Airflow RBAC roles for your account."
                    f"{response.headers} / {response.text}"
                )
            elif response.status_code != 200:
                raise requests.HTTPError(
                    "error occured while triggering the dag"
                    f"{response.headers} / {response.text}"
                )
            else:
                count = 0
                print(response.text)
                for runs in json.loads(response.text)["dag_runs"]:
                    if runs["state"] == "success":
                        count = count + 1
                print("number of dag runs found - ", str(count))
                return count

        return count

    def poke(self, context):
        """Pokes for the required count of DAG runs within the interval."""
        # execution_date = context['execution_date']
        self.log.info("Inside Poke")
        # self.log.info(f"execution_date is: {execution_date}")
        count = self.get_count(context)
        self.log.info(f"Found {count} successful DAG runs for {self.external_dag_id}.")
        return count >= self.min_count
