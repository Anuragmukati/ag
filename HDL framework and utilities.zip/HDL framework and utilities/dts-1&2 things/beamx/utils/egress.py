from airflow import DAG
from airflow.providers.google.cloud.hooks.bigquery import BigQueryHook
from airflow.providers.google.cloud.hooks.gcs import GCSHook
from airflow.operators.python_operator import PythonOperator
from datetime import datetime
from google.cloud import bigquery
from google.cloud import storage
from airflow.models import Variable
import fnmatch
from functools import reduce
import observability
import sys
import json
import logging
import traceback

current_datetime = datetime.now().strftime("%Y%m%d%H%M%S")

def compose_batch(params, variables, bucketNameVars, batch, output_name):
    gcs_hook = GCSHook(gcp_conn_id = variables[params["hook"]["gcp_conn_id"]])
    gcs_client=storage.Client(credentials=gcs_hook.get_credentials())
    bucket_name = bucketNameVars["OUTBOUND_BUCKET"].split("/")[-1]
    #bucket_name = 'httv-dev-edwpr-0-usre-outbound'
    bucket = gcs_client.bucket(bucket_name)
    source_blobs = [bucket.blob(blob_name) for blob_name in batch]
    destination_blob = bucket.blob(output_name)
    destination_blob.compose(source_blobs)
    print(f"Composed {len(batch)} blobs into {output_name}")
    return output_name

def compose_files(params, dagId, projectDetails, tz, context, opsgenie_priority, bucketNameVars, variables, dict_obs, group_id):
    try:
        #gcs_hook = GCSHook(gcp_conn_id = variables[params["hook"]["gcp_conn_id"]])
        gcs_hook = GCSHook(gcp_conn_id = variables[params["hook"]["gcp_conn_id"]])
        gcs_client=storage.Client(credentials=gcs_hook.get_credentials())
        bucket_name = bucketNameVars["OUTBOUND_BUCKET"].split("/")[-1]
        #bucket_name = 'httv-dev-edwpr-0-usre-outbound'
        bucket = gcs_client.bucket(bucket_name)
        projectTag = projectDetails[0]
        varMap = variables[projectTag+"_vars"]
        dict_obs_static = str(params["obs"])
        dict_obs_static = json.loads((reduce(lambda key, value: key.replace(*value), varMap.items(), dict_obs_static)).replace("'", '"'))
        dict_obs.update(dict_obs_static)
        dict_obs = getObsParams(context, bucketNameVars, variables, params, projectDetails, dagId, tz, dict_obs)
        # pattern will be same as source_uri or destination uri for run_extract
        # define prefix for matching files
        if 'extract_name' in params["hook"]:
            #extract_file_name = params["hook"]["extract_name"]
            if '/' in params["hook"]["extract_name"]:
                extract_dir = params["hook"]["extract_name"].rsplit("/", 1)[0]
                extract_file_name = params["hook"]["extract_name"].rsplit("/", 1)[1]
            else:
                extract_dir = 'temporary'
                extract_file_name = params["hook"]["extract_name"]
            extract_dir_temp = extract_dir+"_temp"
            prefix_extract_file_name = extract_file_name.split(".",1)[0]
            suffix_extract_file_name = extract_file_name.split(".",1)[1]
            pattern = extract_dir_temp + "/" + prefix_extract_file_name + "*"
            print("pattern is: ", pattern)
        #pattern = 'shakespeare*.txt'
        # prefix will be fetched by rsplit /
        prefix = pattern.rsplit("/")[0]
        print("prefix is: ", prefix)
        # List all blobs in the bucket with the given prefix
        blobs = list(bucket.list_blobs(prefix=prefix))
        #print("blobs matching the prefix are: ", blobs)
    
        # filter blobs matching the wildcard pattern using fnmatch
        source_blobs = [blob for blob in blobs if fnmatch.fnmatch(blob.name, pattern)]
        composed_blobs = [blob.name for blob in blobs if fnmatch.fnmatch(blob.name, pattern)]
        #print("Data Files are: ", source_blobs)
        print("composed_blobs are: ", composed_blobs)
    
        if not source_blobs:
            raise ValueError(f"No files found matching pattern:{pattern}")
        
        #Check if number of blobs are greater than 32
        #if len(source_blobs) > 32:
            #raise ValueError("GCS Compose only supports upto 32 files.")
        
        # if header is present in dir
        if 'header_query' in params["hook"]:
            header_file_name = extract_dir_temp + "/header_" + extract_file_name
            print("header file name is: ",bucket.blob(header_file_name))
            source_blobs.insert(0,bucket.blob(header_file_name))
            composed_blobs.insert(0,header_file_name)
            print("source blobs to compose after header file is: ", source_blobs)
    
        # if footer is present in dir
        if 'footer_query' in params["hook"]:
            footer_file_name = extract_dir_temp + "/footer_" + extract_file_name
            print("footer file name is: ",bucket.blob(footer_file_name))
            source_blobs.append(bucket.blob(footer_file_name))
            #composed_blobs.append(footer_file_name)
            print("source blobs to compose after footer file is: ", source_blobs)
    
        # Define the destination blob
        #destination_blob = bucket.blob('composed_shakespeare.txt')
        
        if params["hook"]["compose"].lower() == "true":
            if extract_dir != 'temporary':
                if "current_date" in params["hook"] or "sql_datefile" in params["hook"] or "current_datetime" in params["hook"] or "file_query" in params["hook"]:
                   current_datetime_yyymmdd = getfiledate(params, projectDetails,bucketNameVars, variables)
                   destination_file_name = extract_dir + "/" + extract_file_name.split(".",1)[0] + current_datetime_yyymmdd + "." + extract_file_name.split(".",1)[1]
                else:
                   destination_file_name = extract_dir + "/" + extract_file_name.split(".",1)[0] + "_"+ current_datetime + "." + extract_file_name.split(".",1)[1]
            else:
                destination_file_name = extract_file_name.split(".",1)[0] + "_"+ current_datetime + "." + extract_file_name.split(".",1)[1]
            print("Destination file name will be: ", destination_file_name)
            #destination_blob = bucket.blob(destination_file_name)
    
            temp_counter = 0
            while len(composed_blobs) > 1:
                next_round_blobs = []
                # compose the blobs in batches of 32 or less
                for i in range(0, len(composed_blobs),32):
                    batch = composed_blobs[i:i+32]
                    print("batch of files: ", batch)
                    temp_blob_name = f"{extract_dir_temp}/{prefix_extract_file_name}_temp_composed_{temp_counter}.{suffix_extract_file_name}"
                    print("temporary blob name for batch of files is: ", temp_blob_name)
                    composed_blob_name = compose_batch(params, variables, bucketNameVars, batch, temp_blob_name)
                    next_round_blobs.append(composed_blob_name)
                    # appending it to source_blobs to delete it at the last
                    print("composed blob name: ",bucket.blob(composed_blob_name))
                    '''if len(next_round_blobs) > 1:
                        source_blobs.append(bucket.blob(composed_blob_name))'''
                    temp_counter += 1
                composed_blobs = next_round_blobs
                if len(next_round_blobs) > 1:
                    for next_blob in next_round_blobs:
                        source_blobs.append(bucket.blob(next_blob))
            if composed_blobs:
                if 'footer_query' in params["hook"]:
                    composed_blobs.append(footer_file_name)
                    temp_blob_name = f"{extract_dir_temp}/{prefix_extract_file_name}_temp_composed_{temp_counter}.{suffix_extract_file_name}"
                    composed_blob_name = compose_batch(params, variables, bucketNameVars, composed_blobs, temp_blob_name)
                    if composed_blobs[0] not in [blob.name for blob in source_blobs]:
                        print("source_blobs is:" ,source_blobs)
                        source_blobs.append(bucket.blob(composed_blobs[0]))
                    composed_blobs[0] = composed_blob_name
                final_blob = bucket.blob(composed_blobs[0])
                bucket.rename_blob(final_blob, destination_file_name)
            #destination_blob.compose(source_blobs)
            print(f"Files matching pattern '{pattern}' composed successfully into {destination_file_name}")
        else:
            destination_blob_dir = extract_dir
            for blob in source_blobs:
                source_blob = bucket.blob(blob.name)
                print("source_blob is: ",source_blob)
                destination_file_name=((blob.name).rsplit("/", 1)[1]).split(".")[0] + "_"+ current_datetime + "." + ((blob.name).rsplit("/", 1)[1]).split(".")[1]
                if 'temporary_temp/' not in blob.name:
                    print("destination file_name is: ", destination_file_name)
                    if len(source_blobs) == 1:
                        print("Len of source_blobs is 1")
                        final_blob_name = destination_blob_dir + "/" + extract_file_name.split(".",1)[0] + "_"+ current_datetime + "." + extract_file_name.split(".",1)[1]
                    else:
                        final_blob_name = destination_blob_dir + "/" + destination_file_name
                    print("final blob name:", final_blob_name)
                    destination_blob = bucket.blob(final_blob_name)
                    print("destination_blob is: ",destination_blob)
                else:
                    if len(source_blobs) == 1:
                        destination_file_name = extract_file_name.split(".",1)[0] + "_"+ current_datetime + "." + extract_file_name.split(".",1)[1]
                        destination_blob = bucket.blob(destination_file_name)
                    else:
                        destination_blob = bucket.blob(destination_file_name)
                    print("destination_blob is: ",destination_blob)
                destination_blob.rewrite(source_blob)
        
        # Deleting the temp directory and blobs
        if len(source_blobs) > 1:
            for blob in source_blobs:
                print(f"Deleting blob: {blob.name}")
                blob.delete()
        end_time = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
        run_status = "SUCCESS"
        error_msg = "NA"
        dict_obs["run_status"] = run_status
        dict_obs["error_message"] = error_msg
        dict_obs["end_time"] = datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S")
        dict_obs["inserted_timestamp"] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
    except Exception as e:
        run_status = "FAILURE"
        end_time = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
        error_msg = str(e)
        logging.error(traceback.format_exc())
        dict_obs["run_status"] = run_status
        dict_obs["error_message"] = error_msg
        dict_obs["end_time"] = datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S")
        dict_obs["inserted_timestamp"] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
        
    return {'run_status': run_status, 'error_message': error_msg, 'end_time': end_time, 'dict_obs': dict_obs}

def getfiledate(params, projectDetails,bucketNameVars, variables):
    projectTag = projectDetails[0]
    varMap = variables[projectTag+"_vars"]
    current_datetime_yyymmdd = datetime.now().strftime("%Y%m%d")
    current_datetime_yyyymmdd_hhmm = datetime.now().strftime("%Y%m%d%H%M")
    if "current_date" in params["hook"] and params["hook"]["current_date"].lower()=="true":
        current_datetime="_"+ current_datetime_yyymmdd 
    elif "current_date" in params["hook"] and params["hook"]["current_date"].lower()=="false":
        current_datetime= ""
    elif "current_datetime" in params["hook"] and params["hook"]["current_datetime"].lower()=="true":
        current_datetime="_"+ current_datetime_yyyymmdd_hhmm 
    elif "sql_datefile" in params["hook"]:
        bq_hook=BigQueryHook(gcp_conn_id = variables[params["hook"]["gcp_conn_id"]])
        bq_client = bigquery.Client(project=bq_hook._get_field("project"), credentials=bq_hook.get_credentials())
        gcs_hook = GCSHook(gcp_conn_id = variables[params["hook"]["gcp_conn_id"]])
        sql_query = gcs_hook.download((bucketNameVars["SQL_BUCKET"]).split("/")[-1], params['hook']['sql_datefile']).decode("utf-8")
        final_query = reduce(lambda key, value: key.replace(*value), varMap.items(), sql_query)
        print("final query to extract the date", final_query)
        try:
            query_job = bq_client.query(final_query)
            query_result_date = query_job.result()
            print("query result date", query_result_date)
            row = next(query_result_date)  
            extracted_date = row[0]  
            print("extracted date:", extracted_date)
            data_run_status = "SUCCESS"
            data_error_msg = "NA"
        except Exception as e:
            data_run_status = "FAILURE"
            data_error_msg = str(e)
            logging.error(traceback.format_exc())
        current_datetime="_"+ str(extracted_date) 
    elif "file_query" in params["hook"]:
        bq_hook=BigQueryHook(gcp_conn_id = variables[params["hook"]["gcp_conn_id"]])
        bq_client = bigquery.Client(project=bq_hook._get_field("project"), credentials=bq_hook.get_credentials())
        gcs_hook = GCSHook(gcp_conn_id = variables[params["hook"]["gcp_conn_id"]])
        file_query = params['hook']['file_query']
        final_query = reduce(lambda key, value: key.replace(*value), varMap.items(), file_query)
        final_sql_query = final_query
        print("final query to extract the date", final_query)
        try:
            query_job = bq_client.query(final_query)
            query_result_date = query_job.result()
            row = next(query_result_date)  
            extracted_date = row[0]  
            print("extracted date:", extracted_date)
            data_run_status = "SUCCESS"
            data_error_msg = "NA"
        except Exception as e:
            print("Failure running file name query!!!!")
            data_run_status = "FAILURE"
            data_error_msg = str(e)
            logging.error(traceback.format_exc())
        current_datetime="_"+ str(extracted_date) 

    return current_datetime

def run_extract(params, projectDetails,variables, bucketNameVars, tableid, extract_type):
    print("Inside run_extract")
    bq_hook=BigQueryHook(gcp_conn_id = variables[params["hook"]["gcp_conn_id"]])
    gcs_hook = GCSHook(gcp_conn_id = variables[params["hook"]["gcp_conn_id"]])
    gcs_client=storage.Client(credentials=gcs_hook.get_credentials())
    bq_client = bigquery.Client(project=bq_hook._get_field("project"), credentials=bq_hook.get_credentials())
    #table_id = 'bigquery-public-data.samples.shakespeare'
    table_id = tableid
    current_datetime_yyymmdd = ""
    print("table_id is: ", table_id)
    outboundBucket = bucketNameVars["OUTBOUND_BUCKET"].split("/")[-1]
    if 'extract_name' in params["hook"]:
        if '/' in params["hook"]["extract_name"]:
            extract_dir = params["hook"]["extract_name"].rsplit("/", 1)[0]
            extract_file_name = params["hook"]["extract_name"].rsplit("/", 1)[1]
        else:
            extract_dir = 'temporary'
            extract_file_name = params["hook"]["extract_name"]
        extract_dir_temp = extract_dir+"_temp"
        if extract_type == 'header':
            prefix_extract_file_name = 'header_'+extract_file_name
            if "compose" in params["hook"] and params["hook"]["compose"].lower() == "true":
                destination_uri = "gs://" + outboundBucket + "/" + extract_dir_temp + "/" + prefix_extract_file_name
            else:
                destination_uri = "gs://" + outboundBucket + "/" + extract_dir + "/" + prefix_extract_file_name
        elif extract_type == 'footer':
            prefix_extract_file_name = 'footer_'+extract_file_name
            if "compose" in params["hook"] and params["hook"]["compose"].lower() == "true":
                destination_uri = "gs://" + outboundBucket + "/" + extract_dir_temp + "/" + prefix_extract_file_name
            else:
                destination_uri = "gs://" + outboundBucket + "/" + extract_dir + "/" + prefix_extract_file_name
        else:
            prefix_extract_file_name = extract_file_name.split(".",1)[0]
            suffix_extract_file_name = extract_file_name.split(".",1)[1]
            if "compose" in params["hook"] and params["hook"]["compose"].lower() == "true":
                destination_uri = "gs://" + outboundBucket + "/" + extract_dir_temp + "/" + prefix_extract_file_name +"*."+suffix_extract_file_name
            elif "current_date" in params["hook"] or "sql_datefile" in params["hook"] or "current_datetime" in params["hook"] or "file_query" in params["hook"]:
                current_datetime_yyymmdd = getfiledate(params, projectDetails,bucketNameVars, variables)
                destination_uri = "gs://" + outboundBucket + "/" + extract_dir + "/" + prefix_extract_file_name + current_datetime_yyymmdd + "_*." +suffix_extract_file_name
            else:
                destination_uri = "gs://" + outboundBucket + "/" + extract_dir + "/" + prefix_extract_file_name + "_" + current_datetime + "_*."+suffix_extract_file_name
        print("destination_uri is: ", destination_uri.replace("_*.", "*."))

    #destination_uri = 'gs://httv-dev-edwpr-0-usre-outbound/shakespeare_custom_delim*.txt'
    if 'export_format' in params["hook"]:
        if (params["hook"]["export_format"]).lower() in ['csv', 'txt', 'dat', 'ctl']:
            export_format = 'csv'
            print("export format is: ", export_format)
            if 'delimiter' in params["hook"]:
                delimiter = params["hook"]["delimiter"]
                print("delimiter is: ", delimiter)
            else:
                delimiter = ','
                print("delimiter is: ", delimiter)
        else:
            export_format = params["hook"]["export_format"]
            print("export format is: ", export_format)
    else:
        export_format = 'csv'
        print("export format is: ", export_format)
    
    if 'compression' in params["hook"]:
        compression_type = params["hook"]["compression"]
        print("compression_type is: ", compression_type)
    else:
        compression_type = 'None'
        print("compression_type is: ", compression_type)

    header = False
    if export_format.lower() == 'csv':
        job_config=bigquery.job.ExtractJobConfig(destination_format=export_format, compression=compression_type, field_delimiter=delimiter, print_header=header )
    else:
        job_config=bigquery.job.ExtractJobConfig(destination_format=export_format, compression=compression_type )
    extract_job = bq_client.extract_table(table_id, destination_uris=[destination_uri], job_config=job_config)
    extract_job.result()
    print("extract job completed!")
    print(extract_job.result())
    print("job_id is: ", extract_job.job_id)
    if "compose" not in params["hook"] or params["hook"]["compose"].lower() != "true":
        if current_datetime_yyymmdd != "":
            pattern = extract_dir + "/" + prefix_extract_file_name + current_datetime_yyymmdd + "*"
        else:
            pattern = extract_dir + "/" + prefix_extract_file_name + "_" + current_datetime + "*"
        print("pattern is: ", pattern)
        prefix = pattern.rsplit("/")[0]
        print("prefix is: ", prefix)
        # List all blobs in the bucket with the given prefix
        bucket = gcs_client.bucket(outboundBucket)
        blobs = list(bucket.list_blobs(prefix=prefix))
        print("blobs matching the prefix are: ", blobs)
    
        # filter blobs matching the wildcard pattern using fnmatch
        source_blobs = [blob for blob in blobs if fnmatch.fnmatch(blob.name, pattern)]
        print("source_blobs are: ", source_blobs)
        if len(source_blobs) == 1:
            if current_datetime_yyymmdd != "":
                final_blob_name = extract_dir + "/" + prefix_extract_file_name + current_datetime_yyymmdd + "." + suffix_extract_file_name
            else:
                final_blob_name = extract_dir + "/" + prefix_extract_file_name + "_" + current_datetime + "." +suffix_extract_file_name
            print("final_blob_name is: ", final_blob_name)
            #destination_blob = bucket.blob(final_blob_name)
            #print("destination_blob is: ", destination_blob)
            for blob in source_blobs:
                #destination_blob.rewrite(blob)
                bucket.rename_blob(blob, final_blob_name)

    #print("Calling compose_files")
    #compose_files()

def run_query(context, params, dagId, projectDetails, tz, opsgenie_priority, bucketNameVars, variables, dict_obs, group_id):
    bq_hook=BigQueryHook(gcp_conn_id = variables[params["hook"]["gcp_conn_id"]])
    projectTag = projectDetails[0]
    varMap = variables[projectTag+"_vars"]
    # import the necessary modules
    BASE_DIR = "/home/airflow/gcs/dags/" + projectDetails[2] + "/beamx"
    sys.path.append(f"{BASE_DIR}/utils")
    import observability
    bq_client = bigquery.Client(project=bq_hook._get_field("project"), credentials=bq_hook.get_credentials())
    extract_type = 'data'
    dict_obs_static = str(params["obs"])
    dict_obs_static = json.loads(
        (reduce(lambda key, value: key.replace(*value), varMap.items(), dict_obs_static)).replace("'", '"'))
    dict_obs.update(dict_obs_static)
    dict_obs = getObsParams(context, bucketNameVars, variables, params, projectDetails, dagId, tz, dict_obs)
    data_run_status = header_run_status = footer_run_status = None
    data_error_msg = header_error_msg = footer_error_msg = ""
    final_sql_query = ''
    queryReplacementFile = {}
    queryReplacement = {}
    if "queryReplacement" in params["hook"]:
        print("queryReplacement in hook")
        queryReplacement = params["hook"]["queryReplacement"]
        for var in queryReplacement:
            sql_query = queryReplacement[var]
            final_query = reduce(lambda key, value: key.replace(*value), varMap.items(), sql_query)
            try:
                #records = bq_hook.get_pandas_df(final_query)
                query_job = bq_client.query(final_query)
                query_result_date = query_job.result()
                row = next(query_result_date)  
                records = row[0]
                print("records got: ",records)
                queryReplacement[var] = records
            except Exception as e:
                logging.error(traceback.format_exc())
        print("queryReplacement after running sql query from file: ", queryReplacement)

    if "queryReplacementFile" in params["hook"]:
        print("queryReplacementFile in hook")
        queryReplacementFile = params["hook"]["queryReplacementFile"]
        gcs_hook = GCSHook(gcp_conn_id = variables[params["hook"]["gcp_conn_id"]])
        for var in queryReplacementFile:
            sql_query = gcs_hook.download((bucketNameVars["SQL_BUCKET"]).split("/")[-1], queryReplacementFile[var]).decode("utf-8")
            final_query = reduce(lambda key, value: key.replace(*value), varMap.items(), sql_query)
            try:
                query_job = bq_client.query(final_query)
                query_result_date = query_job.result()
                row = next(query_result_date)  
                records = row[0]
                print("records got: ",records)
                queryReplacementFile[var] = records
            except Exception as e:
                logging.error(traceback.format_exc())
        print("queryReplacementFile after running sql query from file: ", queryReplacementFile)

    if "sqlFile" in params["hook"]:
        gcs_hook = GCSHook(gcp_conn_id = variables[params["hook"]["gcp_conn_id"]])
        sql_query = gcs_hook.download((bucketNameVars["SQL_BUCKET"]).split("/")[-1], params['hook']['sqlFile']).decode("utf-8")
        final_query = reduce(lambda key, value: key.replace(*value), varMap.items(), sql_query)
        if queryReplacement != {}:
            final_query = replace_placeholders_in_sql(final_query, queryReplacement)
        if queryReplacementFile != {}:
            final_query = replace_placeholders_in_sql(final_query, queryReplacementFile)
        final_sql_query = final_query
        print("final query", final_query)
        try:
            query_job = bq_client.query(final_query)
            query_job.result()
            #Get the reference to the temporary table
            temporary_table_id = query_job.destination
            #Get the details of the temporary table
            table_id = bq_client.get_table(temporary_table_id)
            run_extract(params, projectDetails,variables, bucketNameVars, table_id, extract_type)
            end_time = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
            data_run_status = "SUCCESS"
            data_error_msg = "NA"
        except Exception as e:
            data_run_status = "FAILURE"
            end_time = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
            data_error_msg = str(e)
            logging.error(traceback.format_exc())
    elif 'data_query' in params["hook"]:
        #sql_query = '''SELECT * FROM bigquery-public-data.samples.shakespeare'''
        sql_query = params['hook']['data_query']
        final_query = reduce(lambda key, value: key.replace(*value), varMap.items(), sql_query)
        if queryReplacement != {}:
            final_query = replace_placeholders_in_sql(final_query, queryReplacement)
        if queryReplacementFile != {}:
            final_query = replace_placeholders_in_sql(final_query, queryReplacementFile)
        final_sql_query = final_query
        print("final query", final_query)
        try:
            query_job = bq_client.query(final_query)
            query_job.result()
            #Get the reference to the temporary table
            temporary_table_id = query_job.destination
            #Get the details of the temporary table
            table_id = bq_client.get_table(temporary_table_id)
            run_extract(params, projectDetails,variables, bucketNameVars, table_id, extract_type)
            end_time = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
            data_run_status = "SUCCESS"
            data_error_msg = "NA"
        except Exception as e:
            print("Failure running data query!!!!")
            data_run_status = "FAILURE"
            end_time = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
            data_error_msg = str(e)
            logging.error(traceback.format_exc())
    elif 'extract_table' in params["hook"]:
        table_id = params['hook']['extract_table']
        final_sql_query = table_id
        try:
            run_extract(params, projectDetails,variables, bucketNameVars, table_id, extract_type)
            end_time = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
            data_run_status = "SUCCESS"
            data_error_msg = "NA"
        except Exception as e:
            data_run_status = "FAILURE"
            end_time = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
            data_error_msg = str(e)
            logging.error(traceback.format_exc())
    
    if 'header_query' in params["hook"]:
        #sql_query = '''SELECT * FROM bigquery-public-data.samples.shakespeare'''
        sql_query = params['hook']['header_query']
        final_query = reduce(lambda key, value: key.replace(*value), varMap.items(), sql_query)
        print("final query", final_query)
        try:
            query_job = bq_client.query(final_query)
            query_job.result()

            #Get the reference to the temporary table
            temporary_table_id = query_job.destination
            #Get the details of the temporary table
            table_id = bq_client.get_table(temporary_table_id)
            extract_type = 'header'
            run_extract(params, projectDetails,variables, bucketNameVars, table_id, extract_type)
            end_time = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
            header_run_status = "SUCCESS"
            header_error_msg = "NA"
        except Exception as e:
            header_run_status = "FAILURE"
            end_time = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
            header_error_msg = str(e)
            logging.error(traceback.format_exc())
    if 'footer_query' in params["hook"]:
        #sql_query = '''SELECT * FROM bigquery-public-data.samples.shakespeare'''
        sql_query = params['hook']['footer_query']
        final_query = reduce(lambda key, value: key.replace(*value), varMap.items(), sql_query)
        print("final query", final_query)
        try:
            query_job = bq_client.query(final_query)
            query_job.result()

            #Get the reference to the temporary table
            temporary_table_id = query_job.destination
            #Get the details of the temporary table
            table_id = bq_client.get_table(temporary_table_id)
            extract_type = 'footer'
            run_extract(params, projectDetails,variables, bucketNameVars, table_id, extract_type)
            end_time = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
            footer_run_status = "SUCCESS"
            footer_error_msg = "NA"
            logger_name = params["obs"]["logger_name"]
            observability.ingestion_obs(dict_obs, logger_name)
            dict_obs["inserted_timestamp"] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
        except Exception as e:
            footer_run_status = "FAILURE"
            end_time = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
            footer_error_msg = str(e)
            logging.error(traceback.format_exc())
    if  (header_run_status == 'SUCCESS' or header_run_status == None) and (footer_run_status == 'SUCCESS' or footer_run_status == None) and (data_run_status == 'SUCCESS'):
        run_status = 'SUCCESS'
        error_msg = "NA"
        dict_obs["run_status"] = run_status
        dict_obs["error_message"] = error_msg
        dict_obs["end_time"] = datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S")
        dict_obs["inserted_timestamp"] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
    else:
        run_status = "FAILURE"
        error_msg = "header-"+header_error_msg+"footer-"+footer_error_msg+"data-"+data_error_msg
        dict_obs["run_status"] = run_status
        dict_obs["error_message"] = str(error_msg).replace('\n', '')
        dict_obs["end_time"] = datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S")
        dict_obs["inserted_timestamp"] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
        
    return {'run_status': run_status, 'error_message': error_msg, 'end_time': end_time, 'dict_obs': dict_obs, 'sql_query': final_sql_query}

"""
Replace placeholder in sql file
"""   
def replace_placeholders_in_sql(query, replacements):
    for key, value in replacements.items():
        query = query.replace(key, f'"{value}"')
    print("sql after replacing placeholders: ", query)

    return query

"""
get the parameters to send to observability logs
"""
def getObsParams(context, bucketNameVars, variables, params, projectDetails, dagId, tz, dict_obs):

    #get the variable map based on the project
    projectTag = projectDetails[0]
    varMap = variables[ projectTag+"_vars"]

    dict_obs["start_time"] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
    target_name = bucketNameVars["OUTBOUND_BUCKET"]+"/"+params["hook"]['extract_name']
    print("target name is ", target_name)
    dict_obs["target_name"] = str(target_name)
    dict_obs["source_type"] = "Table"
    dict_obs["target_type"] = "File"
    dict_obs["source_count"] = "0"
    dict_obs["target_count"] = "0"
    dict_obs["process_name"] = dagId
    gcp_project = projectTag + "_project_id"
    dict_obs["gcp_project"] = varMap[gcp_project]
    dict_obs["process_date"] = str(datetime.now(tz).strftime('%Y-%m-%d'))
    data_interval_endtime = context['data_interval_end'].in_timezone(tz)
    dict_obs["run_date"] = str(data_interval_endtime.strftime('%Y%m%d'))
    dict_obs["run_day"] = str(data_interval_endtime.strftime('%A'))
    dict_obs["run_hour"] = str(data_interval_endtime.strftime("%H:%M:%S"))
    dict_obs['running_instance_id'] = f"{dagId}_" + str(datetime.now(tz).strftime("%Y%m%d%H%M%S"))

    return dict_obs

def postgcs_to_bq_load(context, variables, params, projectDetails, dagId, tz, opsgenie_priority, last_task, ingestionPattern, alertTeamName, sub_lob_alert, BqToGcsLoadResult, grp_id):
    # get the variable map based on the project
    projectTag = projectDetails[0]
    projectSpace = projectDetails[2]
    varMap = variables[projectTag + "_vars"]
    current_task = context['task'].task_id
    run_status = "success"
    # import the necessary modules
    BASE_DIR = "/home/airflow/gcs/dags/" + projectSpace + "/beamx"
    sys.path.append(f"{BASE_DIR}/utils")
    import observability
    from ops_genie import send_alert_to_opsgenie
    from bq_transformer import auditTableEntry

    # required values from xcoms
    BqToGcs_dict_obs = BqToGcsLoadResult['dict_obs']
    print("dict_obs is: ", BqToGcs_dict_obs)
    error_message = str(BqToGcs_dict_obs['error_message'])
    sql_query = BqToGcsLoadResult['sql_query']
    if BqToGcsLoadResult['run_status'].lower() == "failure":
        opsgenie_message = "Beamx|" + variables["environment"] + "|Failure|" + current_task + "|" + BqToGcs_dict_obs['running_instance_id']
        opsgenie_description = "Failure | BQ to GCS step FAILED|" + BqToGcs_dict_obs['running_instance_id']
        opsgenie_details = {"DAG ID": dagId, "Error Step": "BQ to GCS", "Error Message": error_message}
        send_alert_to_opsgenie(opsgenie_message, opsgenie_description, opsgenie_details, opsgenie_priority, projectDetails=projectDetails, alertTeamName=alertTeamName,sub_lob_alert=sub_lob_alert)
    try:
        logger_name = params["obs"]["logger_name"]
        ## capturing process end time for the last task of dag##
        if current_task in last_task:
            BqToGcs_dict_obs["process_end_time"] = datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S")
        else:
            print(" current task not in last task ")
            print(" current task is ", current_task)
            print(" last task is ", last_task)
            BqToGcs_dict_obs["process_end_time"] = "NA"
        BqToGcs_dict_obs["inserted_timestamp"] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
        observability.ingestion_obs(BqToGcs_dict_obs, logger_name)
    except Exception as e:
        run_status = "failure"
        error_message = str(e)
        print("error_message : ", error_message)
        logging.error(traceback.format_exc())
        print("Could not send observability log")
    target_table = BqToGcs_dict_obs["target_name"]
    ingestion_query = auditTableEntry(context, params, variables, varMap, BqToGcs_dict_obs, dagId, 'N/A', projectSpace, opsgenie_priority, target_table, ingestionPattern, projectDetails, sql_query, alertTeamName,sub_lob_alert)

    audit_configuration = None
    if ingestion_query is not None:
        audit_configuration = {
            "jobType": "QUERY",
            "query": {
                "query": ingestion_query,
                "useLegacySql": False,
            }
        }

    return {"audit_configuration": audit_configuration, "run_status": run_status}

    
def postgcs_compose(context, variables, params, projectDetails, dagId, tz, opsgenie_priority, last_task, ingestionPattern, alertTeamName, sub_lob_alert, GcsComposeResult, grp_id):
    # get the variable map based on the project
    projectTag = projectDetails[0]
    projectSpace = projectDetails[2]
    varMap = variables[projectTag + "_vars"]
    current_task = context['task'].task_id
    run_status = "success"
    # import the necessary modules
    BASE_DIR = "/home/airflow/gcs/dags/" + projectSpace + "/beamx"
    sys.path.append(f"{BASE_DIR}/utils")
    import observability
    from ops_genie import send_alert_to_opsgenie
    from bq_transformer import auditTableEntry
    ingestion_query = None
    # required values from xcoms
    if GcsComposeResult is not None:
        GcsCompose_dict_obs = GcsComposeResult['dict_obs']
        sql_query = "NA"
        print("dict_obs is: ", GcsCompose_dict_obs)
        error_message = str(GcsCompose_dict_obs['error_message'])
        GcsCompose_dict_obs["source_type"] = "File"
        if GcsCompose_dict_obs['run_status'].lower() == "failure":
            opsgenie_message = "Beamx|" + variables["environment"] + "|Failure|" + current_task + "|" + GcsCompose_dict_obs['running_instance_id']
            opsgenie_description = "Failure | GCS Compose step FAILED|" + GcsCompose_dict_obs['running_instance_id']
            opsgenie_details = {"DAG ID": dagId, "Error Step": "BQ to GCS", "Error Message": error_message}
            send_alert_to_opsgenie(opsgenie_message, opsgenie_description, opsgenie_details, opsgenie_priority, projectDetails=projectDetails, alertTeamName=alertTeamName,sub_lob_alert=sub_lob_alert)
        try:
            logger_name = params["obs"]["logger_name"]
            ## capturing process end time for the last task of dag##
            if current_task in last_task and (params["hook"]["compose"].lower() == "false" or "compose" not in params["hook"]):
                GcsCompose_dict_obs["process_end_time"] = datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S")
            else:
                print(" current task not in last task ")
                print(" current task is ", current_task)
                print(" last task is ", last_task)
                GcsCompose_dict_obs["process_end_time"] = "NA"
            GcsCompose_dict_obs["inserted_timestamp"] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
            observability.ingestion_obs(GcsCompose_dict_obs, logger_name)
        except Exception as e:
            run_status = "failure"
            error_message = str(e)
            print("error_message : ", error_message)
            logging.error(traceback.format_exc())
            print("Could not send observability log")
        
        target_table = GcsCompose_dict_obs["target_name"]
        ingestion_query = auditTableEntry(context, params, variables, varMap, GcsCompose_dict_obs, dagId, 'N/A', projectSpace, opsgenie_priority, target_table, ingestionPattern, projectDetails, sql_query, alertTeamName,sub_lob_alert)

    audit_configuration = None
    if ingestion_query is not None:
        audit_configuration = {
            "jobType": "QUERY",
            "query": {
                "query": ingestion_query,
                "useLegacySql": False,
            }
        }

    return {"audit_configuration": audit_configuration, "run_status": run_status}
