from datetime import datetime
from airflow.models import TaskInstance
from functools import reduce
import logging
import traceback
import json
import sys
import re
import pytz
from datetime import date, timedelta, timezone, tzinfo
import pendulum
from collections import OrderedDict
import numpy as np
from airflow.models import DagRun
from croniter import croniter


def convertScheduleInterval(schedule_interval,exec_date,tz,days=0):
    try:
        if schedule_interval is None:
            days_interval=0
        elif isinstance(schedule_interval,timedelta):
            days_interval = int(schedule_interval.total_seconds()/3600)
            print("days_interval_as_timedelta",days_interval)
        elif isinstance(schedule_interval, str):
            if 'timedelta' in schedule_interval:
                days_interval = int(eval(schedule_interval).total_seconds()/3600)
            else:
                utc_tz = pytz.utc
                execdateconvert = datetime.strptime(exec_date,'%Y-%m-%dT%H:%M:%S').strftime('%Y-%m-%d %H:%M:%S')
                timeval = utc_tz.localize(datetime.strptime(execdateconvert,'%Y-%m-%d %H:%M:%S')).astimezone(tz)
                iter = croniter(schedule_interval,timeval)
                next_time = iter.get_next(datetime)
                days_interval = ((next_time - timeval).total_seconds() /3600)
                print("days_interval",days_interval)
        return days_interval
    except Exception as e:
        print("Exception occured in schedule conversion")
        return days

def fetch_run_date(dict_obs=None,tz=None):
    if dict_obs is not None and tz is not None:
        if re.search(r'\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}', dict_obs['running_instance_id']):
            dict_obs['exec_date'] = ''.join(re.findall(r'\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}', dict_obs['running_instance_id'].split('__', 1)[1]))
        else:
            dict_obs['exec_date'] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
        if 'scheduled' in dict_obs['running_instance_id'].lower():
            days_interval = 0
            if 'schedule_interval' in dict_obs:
                days_interval = convertScheduleInterval(dict_obs['schedule_interval'], dict_obs['exec_date'],tz)
                current_date = pendulum.parse(dict_obs['exec_date'], tz='UTC').in_timezone(tz) + timedelta(hours=days_interval)
            else:
                current_date = pendulum.now()
        else:
            current_date = pendulum.parse(dict_obs['exec_date'], tz='UTC').in_timezone(tz)
    else:
        current_date = pendulum.now()
    print("date value returned",current_date)
    return current_date
