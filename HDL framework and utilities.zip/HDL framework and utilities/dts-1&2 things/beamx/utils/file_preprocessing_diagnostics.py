"""
File Name: file_preprocessing_diagnostics.py
Description: This python script is specific to dignostics job and is used for preprocessing the source files before bq load via the ingestion framework.
"""
#stdlib imports
import json
from datetime import datetime
import logging
import sys
import traceback
import uuid
from functools import reduce

'''
This function submits a dataproc job which runs the preprocessing pyspark script for diagnostics job
'''
def diagnostics(sourceBucket, processBucket, variables,  sourceFileObject, params, dagId, projectDetails, opsgenie_priority, tz, **kwargs):
    #get the variable map based on the project
    projectTag = projectDetails[0]
    projectSpace = projectDetails[2]
    varMap = variables[ projectTag+"_vars"]
    projectId = params["hook"]["projectId"]
    projectId  = reduce(lambda key, value: key.replace(*value), varMap.items(), projectId)
    # import the necessary modules
    BASE_DIR = "/home/airflow/gcs/dags/"+projectSpace +"/beamx"
    sys.path.append(f"{BASE_DIR}/utils")
    from ops_genie import send_alert_to_opsgenie

    alertTeamName = kwargs['alertTeamName'] if 'alertTeamName' in kwargs else None
    sub_lob_alert = kwargs['sub_lob_alert'] if 'sub_lob_alert' in kwargs else None
    '''
    submit diagnostics job to dataproc and move output json to process bucket
    '''
    dataprocConfigDict = variables["diagnostic_batch_config"]
    cluster_label = dataprocConfigDict["cluster_label"]
    job_id = dagId +'_' + str(datetime.now(tz).strftime("%Y%m%d%H%M%S"))
    PYSPARK_JOB = {
        "reference": {"project_id": projectId, "job_id": job_id},
        "placement": {"cluster_labels": cluster_label},
        "labels": {
            "job_name": dagId.lower(),
            "job_type": "file_to_bq",
            "job_mode": "modern"
        },
        "pyspark_job": {
            "main_python_file_uri": dataprocConfigDict["main_python_file_uri"],
            "properties": {
                "spark.master": "yarn",
                "spark.app.name": "diagnostics" + dagId,
                "spark.submit.deployMode": "cluster"
            },
            "args": ["gs://" + sourceBucket + "/" + sourceFileObject,
                     processBucket,
                     sourceFileObject.rsplit('/', maxsplit=1)[0]
                     ]
        }
    }
    return {"run_status": "success", "error_message": "NA",
                "pysparkJobConfig": PYSPARK_JOB, "region": dataprocConfigDict["region"],
                "sourceBucket": sourceBucket, "processBucket": processBucket,
                "variables": variables, "sourceFileObject": sourceFileObject, "params": params, "dagId": dagId,
                "projectSpace": projectSpace, "project_id":projectId, "tz": tz}


