import requests
import json
import sys
import pytz
from datetime import datetime
from datetime import date, timedelta, timezone, tzinfo
from functools import reduce

def send_alert_to_opsgenie(message, description, details, priority, **kwargs):

    print("triggered ops_genie function")
    final_message = details["DAG ID"] + " | " + datetime.now(tz=pytz.UTC).strftime("%Y-%m-%dT%H:%M:%S") + " |" + message
    detail_dagID = details["DAG ID"]
    env=details["env"]
    yarn_application=details["Spark Application Name"]
    airflow_url=details["airflow url"]
    final_description = "Yarn application name : " + yarn_application + "\n" +"DAG URL: " +airflow_url+details["DAG ID"]+"/grid\n" + "Description: " + description

    if priority == "None":
        return

    prod_alert_dict={"GenieKey 51c3465b-c4cd-47d6-bb8b-52262d757184":"VZ-AID-DataIngestion","GenieKey 5e1f420c-5e64-4853-ad69-c888d583d6e7":"VZ-AID-DataOperations"}


    print("Finalizing the alert")
    print("Authenticating the Ops-Genie")
    print("Environment: ",env)

    proxies={}    
    if env == "DEV" or  env == "TEST":
        proxies={ 'http': 'http://proxy.ebiz.verizon.com:80',
                    'https': 'http://proxy.ebiz.verizon.com:80'}
        ops_genie_auth_headers = {
            "Content-Type": "application/json",
            "Authorization": "GenieKey 51c3465b-c4cd-47d6-bb8b-52262d757184",
        }
        # Prepare json data which needs to send to OpsGenie
        print("Preparing the Json Data")
        responder = [{"name": "VZ-AID-DataIngestion", "type": "team"}]
        json_data = {
            "message": final_message,
            "description": final_description,
            "details": details,
            "priority": priority,
            "responders": responder
        }
        call_process_ops_genie(ops_genie_auth_headers, json_data, proxies)
    else:
        proxies = { 'http': 'http://vzproxy.verizon.com:9290',
                    'https': 'http://vzproxy.verizon.com:9290'}
        print("sending two alerts")
        for key,group in prod_alert_dict.items():
            print("Preparing the Json Data")
            ops_genie_auth_headers = {
                "Content-Type": "application/json",
                "Authorization": key,
            }
            print("Preparing the Json Data")
            responder = [{"name": group, "type": "team"}]
            json_data = {
                "message": final_message,
                "description": final_description,
                "details": details,
                "priority": priority,
                "responders": responder
            }
        call_process_ops_genie(ops_genie_auth_headers, json_data, proxies)


def call_process_ops_genie(genie_headers, json_data, proxies):
    print("json_data:", json_data)
    # Retry 5 times if the API request is failed.
    print("Sending the Response")
    try:
        response = requests.post("https://api.opsgenie.com/v2/alerts",
                                 headers = genie_headers, json = json_data,proxies=proxies)
        print("HTTP Response:", response.text)
    except Exception as e:
        print("error message", str(e))
        print("Sending Alert to Ops-Genie Failed....")
        return
    if response.status_code == 202:
        api_response = json.loads(response.text)
        print("Response:", api_response)
        return api_response["requestId"]
    
