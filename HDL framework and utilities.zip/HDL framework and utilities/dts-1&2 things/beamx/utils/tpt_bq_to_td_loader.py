import logging
import traceback
import re
import pytz
import pendulum
import requests
import json
import sys
import pytz
import base64
from datetime import datetime
from datetime import date
from airflow.models import Variable
from datetime import date, timedelta, timezone, tzinfo
from functools import reduce
from airflow.providers.google.cloud.hooks.bigquery import BigQueryHook
from airflow.providers.google.cloud.hooks.gcs import GCSHook
from airflow.models import TaskInstance
import re
import pandas as pd
from airflow.models import DagRun
from airflow.exceptions import AirflowSkipException, AirflowFailException
from airflow.providers.cncf.kubernetes.secret import Secret
import teradatasql
import google.auth.transport.requests
from airflow.providers.cncf.kubernetes.secret import Secret
from airflow.operators.python import get_current_context
from airflow.exceptions import AirflowSkipException, AirflowException
import sqlalchemy
import os
from google.cloud import secretmanager
from airflow.providers.google.cloud.hooks.dataproc import DataprocHook
from google.cloud import bigquery

def get_secret_from_sm( project_id, secret_name, dpHook):
    client = secretmanager.SecretManagerServiceClient(credentials=dpHook.get_credentials())
    secret_name = f"projects/{project_id}/secrets/{secret_name}/versions/latest"
    response = client.access_secret_version(name=secret_name)
    return response.payload.data.decode("UTF-8")

class secrets:

    def __init__(self, varMap=None, params=None,variables=None,composer=None,projectDetails=None,kubernetes_namespace=None):
        composer = os.getenv('COMPOSER_ENVIRONMENT')
        print("composer",composer)
        projectTag = projectDetails[0]
        business_line = projectDetails[1]
        target_dbtype = "teradata"
        db_instance = params["hook"]["dbinstance"].lower() if "dbinstance" in params["hook"] else "default"
        if projectTag + '_composer_buckets' in variables and composer in variables[projectTag + '_composer_buckets']:
            kubernetes_namespace = variables[projectTag + '_composer_buckets'][composer]['kubernetes_namespace']
            db_config = variables[projectTag + '_composer_buckets'][composer]
            print("db_config_composer",db_config)
            db_config = db_config[projectTag + '_db_config_bq_jdbc'][business_line] if business_line is not None else db_config[projectTag + '_db_config_bq_jdbc']
            db_config = db_config[target_dbtype][db_instance]
            gke_secret = db_config["gke_secret"]
            tpt_passwd = db_config["tpt_passwd"]
            gcs_secret_acc = db_config["gcs_secret_acc"]
            gcs_acc_key = db_config["gcs_acc_key"]
        else:
            kubernetes_namespace = variables['kubernetes_namespace']
            db_config = variables[projectTag + '_db_config_bq_jdbc'][business_line] if business_line is not None else variables[projectTag + '_db_config_bq_jdbc']
            db_config = db_config[target_dbtype][db_instance]
            print("db_config", db_config)
            gke_secret = db_config["gke_secret"]
            tpt_passwd = db_config["tpt_passwd"]
            gcs_secret_acc = db_config["gcs_secret_acc"]
            gcs_acc_key = db_config["gcs_acc_key"]

        self.kubernetes_namespace = kubernetes_namespace
        self.TERADATA_PASSWORD = Secret(
            deploy_type="env",
            deploy_target="TERADATA_PASSWORD",
            secret=f"{gke_secret}",
            key=f"{tpt_passwd}"
        )

        self.GCS_ACCESS_KEY = Secret(
            deploy_type="env",
            deploy_target="GCS_ACCESS_KEY_ID",
            secret=f"{gke_secret}",
            key=f"{gcs_acc_key}"
        )

        self.GCS_SECRET_ACCESS_KEY = Secret(
            deploy_type="env",
            deploy_target="GCS_SECRET_ACCESS_KEY",
            secret=f"{gke_secret}",
            key=f"{gcs_secret_acc}"
        )
    def fetch_arguments(self, context, varMap, params, tz, dagId, projectDetails, bucketNameVars, variables):
        projectTag = projectDetails[0]
        project_tag = projectTag
        projectSpace = projectDetails[2]
        business_line = projectDetails[1]

        target_dbtype = "teradata"
        db_instance = params["hook"]["dbinstance"].lower() if "dbinstance" in params["hook"] else "default"
        composer = os.getenv('COMPOSER_ENVIRONMENT')
        print("composer",composer)
        if projectTag + '_composer_buckets' in variables and composer in variables[projectTag + '_composer_buckets']:
            db_config = variables[projectTag + '_composer_buckets'][composer]
            print("composer config")
            db_config = db_config[projectTag + '_db_config_bq_jdbc'][business_line] if business_line is not None else \
            db_config[projectTag + '_db_config_bq_jdbc']
            db_config = db_config[target_dbtype][db_instance]
            teradata_host = db_config["host_name"]
            teradata_user = db_config['teradata_user']
        else:
            db_config = variables[projectTag + '_db_config_bq_jdbc'][business_line] if business_line is not None else \
            variables[projectTag + '_db_config_bq_jdbc']
            print("default config")
            db_config = db_config[target_dbtype][db_instance]
            teradata_host = db_config["host_name"]
            teradata_user = db_config['teradata_user']

        target_dbname = reduce(lambda key, value: key.replace(*value), varMap.items(), params['hook']['target_dbname'])
        target_log_dbname = reduce(lambda key, value: key.replace(*value), varMap.items(),
                                   params['hook']['target_log_dbname'])
        # changed
        def read_import_tpt():
            with open(f"/home/airflow/gcs/dags/{projectSpace}/beamx/utils/dpf_import.tpt", "r") as f:
                return f.read().replace("$", r"\$")

        def read_cleanup_bteq():
            with open(f"/home/airflow/gcs/dags/{projectSpace}/beamx/utils/tpt_cleanup_script.sh", "r") as f:
                return f.read().replace("$", r"\$")

        if projectSpace == 'vz-it-zdwv-vbgpr-0':
            logon_file = 'Target_VBG.logon'  # changed

        try:
            read_instances = 1
            write_instances = 1
            # target_dbname=reduce(lambda key, value: key.replace(*value), varMap.items(), params['hook']['target_dbname'])
            # target_log_dbname=reduce(lambda key, value: key.replace(*value), varMap.items(), params['hook']['target_log_dbname'])
            # source_gcs_bucket=reduce(lambda key, value: key.replace(*value), varMap.items(), params['hook']['source_gcs_bucket'])
            # source_gcs_path=source_gcs_bucket+'/'+params['hook']['source_gcs_path']
            Bucket = reduce(lambda key, value: key.replace(*value), varMap.items(), params['hook']['source_gcs_bucket'])
            Object = params['hook']['source_gcs_path']
            #Object = "gk1v-dev-edwpr-0-usre-inbound/cust_acct_credit_score/*.csv"
            target_dbname = reduce(lambda key, value: key.replace(*value), varMap.items(),
                                   params['hook']['target_dbname'])
            target_table = target_dbname + "." + params['hook']['target_table']
            LoadLogTable = target_log_dbname + "." + params['hook']['target_table']+"_log"
            LoadErrorTable1 = target_log_dbname + "." + params['hook']['target_table']+"_et"
            LoadErrorTable2 = target_log_dbname+"."+params['hook']['target_table']+"_uv"
            #target_table = "udm_dev_tbls.cust_acct_credit_score_poc_stg"
            target_table_name = params['hook']['target_table']
            # MinSessions = params['hook']['min_sessions']
            # Maxsessions = params['hook']['max_sessions']
            delimiter = ''
            if params['hook']['delimiter'] == 'CNTRLA':
                delimiter = ''
            else:
                delimiter = params['hook']['delimiter']

            if delimiter == 'ctrla' or not delimiter:
                Datadelimiter = '\x01'
            else:
                Datadelimiter = delimiter
            tptscript_args = [
                "-c",
                rf"""
                set -e && \
                echo "{read_import_tpt()}" > import.tpt && \
                more import.tpt && \
                tbuild -f import.tpt -u "\
                jobvar_tdpid='{teradata_host}', \
                jobvar_username='{teradata_user}', \
                jobvar_password='$TERADATA_PASSWORD', \
                jobvar_num_read_instances={read_instances}, \
                jobvar_num_write_instances={write_instances}, \
                jobvar_delimiter='{Datadelimiter}', \
                jobvar_target='{target_table}', \
                jobvar_accessmoduleinitstr='\
                Bucket={Bucket} \
                Object={Object} \
                BufferCount=40 \
                ConnectionCount=20', \
                TargetErrorList = [ '3706','3803','3807' ], \
                LoadPrivateLogName = 'LOAD_OPERATOR_LOG'
                FileReaderFormat = 'Delimited' \
                FileReaderPrivateLogName = '{target_table_name}', \
                DDLPrivateLogName = 'DDL_OPERATOR_LOG' , \
                FileReaderOpenMode = 'Read' , \
                LoadInstances = 1 , \
                LoadTargetTable = '{target_table}', \
                LoadLogTable ='{LoadLogTable}', \
                LoadErrorTable1 = '{LoadErrorTable1}' , \
                LoadErrorTable2 = '{LoadErrorTable2}' , \
                FileReaderInstances = 1 " \
                            """,
            ]
            cleanupscript_args = [
                f"""
                set -e && \
                echo "{read_cleanup_bteq()}" > /tmp/tpt_cleanup_script.sh && \
                chmod +x /tmp/tpt_cleanup_script.sh && \
                sh /tmp/tpt_cleanup_script.sh '{target_dbname}' '{target_table_name}' '{target_log_dbname}' '{teradata_host}' '{teradata_user}' $TERADATA_PASSWORD; """
            ]
            return {"tptscript_args": tptscript_args,"cleanupscript_args":cleanupscript_args}
        except:
            raise AirflowException


def read_source_table(context, params, variables, varMap, projectDetails, tz, opsgenie_priority,**kwargs):
    project_space = projectDetails[2]
    BASE_DIR = "/home/airflow/gcs/dags/" + project_space + "/beamx"
    sys.path.append(f"{BASE_DIR}/utils")
    from ops_genie import send_alert_to_opsgenie
    from observability import get_records_inserted_from_bq_api
    from observability import bq_to_gcs_obs
    projectTag = projectDetails[0]
    varMap = variables[projectTag + "_vars"]
    run_status = 'SUCCESS'
    dict_obs = context['ti'].xcom_pull(key='dict_obs')
    dict_obs = dict(dict_obs)
    dict_obs["start_time"] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
    data_interval_endtime = context['data_interval_end'].in_timezone(tz)
    dict_obs["run_date"] = str(data_interval_endtime.strftime('%Y%m%d'))
    dict_obs["run_day"] = str(data_interval_endtime.strftime('%A'))
    dict_obs["run_hour"] = str(data_interval_endtime.strftime("%H:%M:%S"))
    dict_obs["process_name"] = context["dag"].dag_id
    dagId = context["dag"].dag_id
    logger_name = params["obs"]["logger_name"]
    opsgenie_priority= opsgenie_priority
    task_instance = context['task_instance']
    error_msg = None
    retries = task_instance.max_tries
    print("max_retries",retries)
    source_table = params["hook"]["source_table"]
    source_table = reduce(lambda key, value: key.replace(*value), varMap.items(), source_table)
    load_check_condition = params["hook"]["load_check_condition"]
    project_id = params["hook"]["projectId"]
    sub_lob_alert = kwargs['sub_lob_alert'] if 'sub_lob_alert' in kwargs else None
    project_id = reduce(lambda key, value: key.replace(*value), varMap.items(), project_id)
    bq_hook = BigQueryHook(gcp_conn_id=variables[params["hook"]["gcp_conn_id"]])
    client = bigquery.Client(project=bq_hook._get_field("project"), credentials=bq_hook.get_credentials())
    try:
        load_check_query = f"SELECT count(1) from {source_table} {load_check_condition}"
        df = client.query(load_check_query).to_dataframe()
        load_check_count = df.iloc[0][-1]
        print("load_check_count:", load_check_count)
    except Exception as e:
        load_check_count = 0
        error_msg = str(e)
        logging.error(traceback.format_exc())
        sys.tracebacklimit = 0

    end_time = datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S")
    dict_obs["end_time"] = end_time
    dict_obs_static = str(params["obs"])
    dict_obs_static = json.loads(
        (reduce(lambda key, value: key.replace(*value), varMap.items(), dict_obs_static)).replace("'", '"'))
    dict_obs.update(dict_obs_static)

    if load_check_count > 0:
        dict_obs["run_status"] = "success"
        dict_obs["error_message"] = None
        bq_to_gcs_obs(logger_name, dict_obs)
        print("load status: ", "yes")
        return {"run_status": "success", "error_message": "none"}
    else:
        error_msg = "Load Status Check Criteria Failed...exiting" if error_msg is None else error_msg
        print(error_msg)
        opsgenie_message = "Beamx|" + Variable.get("environment") + "Failure|" + task_instance.task_id + "|" + dict_obs["process_date"] + "|" +dict_obs[
            'running_instance_id']
        print(opsgenie_message)
        opsgenie_description = error_msg
        opsgenie_priority= opsgenie_priority
        AlertTeamName = None
        if 'AlertTeamName' in params['hook'] and params['hook']['AlertTeamName'] != None:
            AlertTeamName= params['hook']['AlertTeamName']
        else:
            AlertTeamName=None
        opsgenie_details = {"DAG ID": dagId, "Error Step": "TPT check load status failed",
                             "Error message": error_msg}
        print("task_instance.try_number",task_instance.try_number)
        if (retries == 0 and task_instance.try_number == 1) or (
                retries > 0 and task_instance.try_number == retries + 1):
            send_alert_to_opsgenie(opsgenie_message, opsgenie_description, opsgenie_details, opsgenie_priority, projectDetails=projectDetails,AlertTeamName=AlertTeamName)
        logging.error(traceback.format_exc())
        dict_obs["run_status"] = "failure"
        dict_obs["error_message"] = error_msg
        bq_to_gcs_obs(logger_name, dict_obs)
        print("load status: ", "yes")
        return {"run_status": "failure", "error_message": error_msg}

def teradata_table_count(database_name, table_name, host_name, user_name, password):
    # destination count #
    try:
        teradata_count = f"Select count(*) from {database_name}.{table_name} ;"
        print("count query", teradata_count)
        with teradatasql.connect(host=host_name, user=user_name, password=password) as connect:
            df = pd.read_sql(teradata_count, connect)
            total_count = str(df.iloc[0][-1])
            print("total :", total_count)
    except Exception as e:
        error_msg = str(e)
        print("error_msg : ", error_msg)
        logging.error(traceback.format_exc())
        total_count = "NA"
        pass
    return total_count


def audit_table_entry(varMap,params,tz,dagId, projectDetails,bucketNameVars, variables,final_target_table=None,final_target_dbname=None,audit_table_db=None):
    project_tag = projectDetails[0]
    business_line = projectDetails[1]
    project_space = projectDetails[2]
    business_line = projectDetails[1]
    target_dbtype = "teradata"
    composer = os.getenv('COMPOSER_ENVIRONMENT')
    db_instance = params["hook"]["dbinstance"].lower() if "dbinstance" in params["hook"] else "default"
    if project_tag + '_composer_buckets' in variables and composer in variables[project_tag + '_composer_buckets']:
        db_config = variables[project_tag + '_composer_buckets'][composer]
        db_config = db_config[project_tag + '_db_config_bq_jdbc'][business_line] if business_line is not None else \
        db_config[project_tag + '_db_config_bq_jdbc']
        db_config = db_config[target_dbtype][db_instance]
        host_name = db_config['host_name']
        secret_name = db_config["secret_name"]
    else:
        db_config = variables[project_tag + '_db_config_bq_jdbc'][business_line] if business_line is not None else variables[
        project_tag + '_db_config_bq_jdbc']
        db_config = db_config[target_dbtype][db_instance]
        host_name = db_config['host_name']
        secret_name = db_config["secret_name"]

    project_id = variables['projectId']
    dpHook = DataprocHook(gcp_conn_id=variables["gcp_conn_id"])
    payload = get_secret_from_sm(project_id, secret_name, dpHook)
    username, password = payload.strip().split(':')
    username = username.strip()
    password = password.strip()

    if final_target_table is not None and final_target_dbname is not None:
        target_table = final_target_table
        target_dbname = reduce(lambda key, value: key.replace(*value), varMap.items(), final_target_dbname)
        audit_db_bq_td = reduce(lambda key, value: key.replace(*value), varMap.items(), audit_table_db)
    else:
        target_table=params["hook"]["target_table"]
        target_dbname = reduce(lambda key, value: key.replace(*value), varMap.items(), params["hook"]["target_dbname"])
        audit_db_bq_td = reduce(lambda key, value: key.replace(*value), varMap.items(),
                                params["hook"]["audit_table_db"])
    insert_cnt = teradata_table_count(target_dbname, target_table, host_name, username, password)

    try:
        td_engine = sqlalchemy.create_engine(f'teradatasql://{host_name}/?user={username}&password={password}')
        insert_query = f'''INSERT INTO {audit_db_bq_td}.TABLE_LOAD_STATUS
                            VALUES('{target_table}',NULL,DATE,CAST(CURRENT_TIME AS TIME(0)),CAST(CURRENT_TIME AS TIMESTAMP(0)),DATE
                            ,CAST (CURRENT_TIME AS TIME(0)),CAST (CURRENT_TIME AS TIMESTAMP(0)),{insert_cnt}, 
                            0, 0, 0, 0, 'BTEQ', '{dagId}');'''
        result = td_engine.execute(insert_query)
        print("Audit Entry Done")
    except Exception as e:
        error_message = str(e)
        logging.error(traceback.format_exc())
        raise RuntimeError(error_message)
        sys.tracebacklimit = 0


def preChecksAndJobConfiguration(params, dagId, projectDetails, tz, context, bucketNameVars, variables,
                                 last_task, ingestionPattern, opsgenie_priority, group_id,
                                 custom_labels, alertTeamName,sub_lob_alert, taskType):
    project_space = projectDetails[2]
    BASE_DIR = "/home/airflow/gcs/dags/" + project_space+ "/beamx"
    sys.path.append(f"{BASE_DIR}/utils")
    from ops_genie import send_alert_to_opsgenie
    from observability import bq_to_gcs_obs
    project_id = projectDetails[2]
    projectTag = projectDetails[0]
    sub_lob_alert = sub_lob_alert
    dict_obs = context['ti'].xcom_pull(key='dict_obs')
    dict_obs = dict(dict_obs)
    dict_obs["start_time"] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
    data_interval_endtime = context['data_interval_end'].in_timezone(tz)
    dict_obs["run_date"] = str(data_interval_endtime.strftime('%Y%m%d'))
    dict_obs["run_day"] = str(data_interval_endtime.strftime('%A'))
    dict_obs["run_hour"] = str(data_interval_endtime.strftime("%H:%M:%S"))
    logger_name = params["obs"]["logger_name"]
    varMap = variables[projectTag + "_vars"]
    opsgenie_priority=opsgenie_priority
    task_instance = context['task_instance']
    retries = task_instance.max_tries

    try:
        target_gcs_bucket = reduce(lambda key, value: key.replace(*value), varMap.items(),
                                   params["hook"]["target_gcs_bucket"])
        target_gcs_path = 'gs://' + target_gcs_bucket + '/' + params['hook'][
            'target_gcs_path']

        delimiter = ''
        if params['hook']['delimiter'] == 'CNTRLA':
            delimiter = ''
        else:
            delimiter = params['hook']['delimiter']
        query = reduce(lambda key, value: key.replace(*value), varMap.items(), params['hook']['query'])
        print('query: ' + query)
        final_query = "EXPORT DATA OPTIONS (uri = " + "'" + target_gcs_path + "'" + ", format = 'CSV', overwrite = true, header = true, field_delimiter = " + "'" + delimiter + "'" + ") AS (" + query + ");"
        sql_query = reduce(lambda key, value: key.replace(*value), varMap.items(), final_query)
        get_sql_query_status = "SUCCESS"
        error_msg = None
    except Exception as e:
        get_sql_query_status = "FAILURE"
        error_msg = str(e)
        opsgenie_message ="Beamx|" + Variable.get("environment") + "Failure|" + task_instance.task_id + "|" + dict_obs[
            "process_date"] + "|" + dict_obs['running_instance_id']
        opsgenie_description = error_msg
        opsgenie_priority = opsgenie_priority
        AlertTeamName = None
        if 'AlertTeamName' in params['hook'] and params['hook']['AlertTeamName'] != None:
            AlertTeamName = params['hook']['AlertTeamName']
        else:
            AlertTeamName = None
        opsgenie_details = {"DAG ID": dagId, "Error Step": "TPT BQ to TD query failed",
                            "Error message": error_msg}
        send_alert_to_opsgenie(opsgenie_message, opsgenie_description, opsgenie_details, opsgenie_priority,
                                   projectDetails=projectDetails, AlertTeamName=AlertTeamName)
        logging.error(traceback.format_exc())

    dict_obs["end_time"] = datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S")
    dict_obs_static = str(params["obs"])
    dict_obs_static = json.loads(
        (reduce(lambda key, value: key.replace(*value), varMap.items(), dict_obs_static)).replace("'", '"'))
    dict_obs.update(dict_obs_static)
    dict_obs["error_message"] = error_msg
    AlertTeamName = None
    if 'AlertTeamName' in params['hook'] and params['hook']['AlertTeamName'] != None:
        AlertTeamName = params['hook']['AlertTeamName']
    else:
        AlertTeamName = None
    dict_obs["run_status"] = get_sql_query_status
    bq_to_gcs_obs(logger_name, dict_obs)

    if get_sql_query_status == 'FAILURE':
        return ({'run_status': 'FAILURE', 'error_msg': error_msg})
    print("SQL query to run :", sql_query)
    configuration = {
        "jobType": "QUERY",
        "query": {
            "query": sql_query,
            "useLegacySql": False,
        }
    }
    run_status = "SUCCESS"
    return {"InsertJobConfig": configuration, "error_msg": "NA", "run_status": run_status, "dict_obs": dict_obs,
            "sql_query": sql_query}


def postLoad(context, variables, params, projectDetails, dagId, tz, opsgenie_priority,
             ingestionPattern, group_id,alertTeamName,sub_lob_alert, fileSensorDetails=None):
    project_space = projectDetails[2]
    BASE_DIR = "/home/airflow/gcs/dags/" + project_space+ "/beamx"
    sys.path.append(f"{BASE_DIR}/utils")
    from ops_genie import send_alert_to_opsgenie
    from observability import get_records_inserted_from_bq_api
    from observability import bq_to_gcs_obs
    end_time = datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S")
    projectTag = projectDetails[0]
    varMap = variables[projectTag + "_vars"]
    dict_obs = context['ti'].xcom_pull(key='dict_obs')
    run_status = 'SUCCESS'
    dict_obs = dict(dict_obs)
    logger_name = params["obs"]["logger_name"]
    error_msg = None
    #check_load_status_failure = context['ti'].xcom_pull(key='load_status', task_ids=f'load_status_{self.group_id}')
    #if check_load_status_failure is not None and check_load_status_failure['run_status'] == 'failure':
    #    run_status = check_load_status_failure.get("run_status")
    #    error_msg = check_load_status_failure.get("error_message")
    upstreamTaskId = group_id + '.bq_to_gcs_load_bigquery_operator'
    prevTaskRunState = (TaskInstance(context['dag'].get_task(upstreamTaskId), context['logical_date'])).current_state()
    bq_to_gcs_status= str(prevTaskRunState).lower()
    context['ti'].xcom_push(key='bq_to_gcs_status', value=bq_to_gcs_status)
    if str(prevTaskRunState).lower() == 'failed':
        failure_xcom = context['ti'].xcom_pull(key='bqtogcsrunstatus', task_ids=upstreamTaskId)
        run_status = failure_xcom.get("run_status")
        error_msg = failure_xcom.get("error_msg")
        opsgenie_message = "Beamx|" + Variable.get("environment") + "Failure|" + task_instance.task_id + "|" + dict_obs[
            "process_date"] + "|" + dict_obs['running_instance_id']
        opsgenie_description = error_msg
        opsgenie_priority=opsgenie_priority
        AlertTeamName = None
        if params['hook']['AlertTeamName'] != None:
            AlertTeamName= params['hook']['AlertTeamName']
        else:
            AlertTeamName=None
        opsgenie_details = {"DAG ID": dagId, "Error Step": "TPT BQ to GCS Load failed",
                             "Error message": error_msg}
        send_alert_to_opsgenie(opsgenie_message, opsgenie_description, opsgenie_details, opsgenie_priority, projectDetails=projectDetails,AlertTeamName=AlertTeamName)
        logging.error(traceback.format_exc())

    print("RUN STATUS :", run_status)
    run_status = 'upstream_failed' if str(prevTaskRunState).lower() == 'upstream_failed' else run_status
    dict_obs["run_status"] = run_status
    dict_obs["end_time"] = end_time
    dict_obs_static = str(params["obs"])
    dict_obs_static = json.loads((reduce(lambda key, value: key.replace(*value), varMap.items(), dict_obs_static)).replace("'", '"'))
    dict_obs.update(dict_obs_static)
    dict_obs["error_message"] = error_msg
    bq_to_gcs_obs(logger_name,dict_obs)
    #logger.log_struct( dict_obs )


def FileArchival(context,params,variables, varMap):
    #dag_status_info.task_cleanup(context)
    array_objects = []
    #get the upstream task id and its run state
    upstreamTaskId = next(iter(context['task'].upstream_task_ids))
    print("upstream task id is :", upstreamTaskId)
    #fileCompressionType = context['ti'].xcom_pull(task_ids=upstreamTaskId, key ='file_compression_type')
    logicalDate = context['logical_date']
    prevTaskRunState = (TaskInstance(context['dag'].get_task(upstreamTaskId), logicalDate)).current_state()
    print("previous task run status is :", prevTaskRunState)
    #get the required details for archival
    sourceBucket = params["hook"]["gcs_bucket"]
    sourceFileObject = params["hook"]["gcs_path"]
    destinationBucket=varMap['tpt_archival_bucket']
    object_pattern = '/'.join(params["hook"]["gcs_path"].split('/')[:-1])
    print("object_pattern",object_pattern)

    #connect to gcs
    gcs_hook = GCSHook(gcp_conn_id = variables[params["hook"]["gcp_conn_id"]])
    objects = gcs_hook.list(bucket_name=sourceBucket)
    for obj in objects:
        if re.match(object_pattern,obj):
            array_objects.append(obj)
    print("array_objects",array_objects)
    for arr in array_objects:
        today = str(date.today())
        file_path='tpt_archives/tpt_bq2td'+'/'+arr.split('/')[-2]+'/'+today
        file_name=arr.split('/')[-1]
        destinationObject= file_path+'/'+file_name
        print("destination",destinationObject)
        gcs_hook.copy(source_bucket=sourceBucket, source_object=arr, destination_bucket=destinationBucket, destination_object=destinationObject)
        print("file '{}' archived..".format(destinationObject))


def on_failure_mail(context, dagId, projectDetails):
    from ops_genie import send_alert_to_opsgenie
    from airflow.models import DagRun
    from common_utility_functions import pushFailureStatus
    pushFailureStatus(context)
    error_msg = str(context.get('exception'))
    tptrunstatus = {'run_status': 'FAILED', 'error_msg':error_msg}
    context['ti'].xcom_push(key='tptrunstatus', value=tptrunstatus)
    dagId = dagId
    projectDetails = projectDetails
    dag_run_id = context['dag_run'].run_id
    if dag_run_id:
        process_run_id = f"{dagId}_" + str(dag_run_id)
        running_instance_id = dag_run_id
    else:
        process_run_id = f"{dagId}_" + str(datetime.now(tz).strftime("%Y%m%d%H%M%S"))
        running_instance_id = process_run_id
    task_instance = context['task_instance']
    opsgenie_message = "Beamx|" + Variable.get(
        "environment") + "|Failure|" + task_instance.task_id + "|" + running_instance_id
    opsgenie_description = f"Failure|TPT BQ to TD script execution failed {error_msg}|" + running_instance_id
    # opsgenie_message = Variable.get("environment") + " Alert | TPT BQ to TD getting SSH Command execution failed"
    # opsgenie_description = str(error_msg)
    opsgenie_priority = "P3"
    opsgenie_details = {"DAG ID": dagId, "Error Step": "TPT BQ to TD script execution failed",
                        "Error message": error_msg}
    send_alert_to_opsgenie(opsgenie_message, opsgenie_description, opsgenie_details, opsgenie_priority,
                           projectDetails=projectDetails)

    print("On failure SSH command method called Reason", context['exception'])

def postLoadToTD(context, variables, params, projectDetails, dagId, tz, opsgenie_priority, last_task,
                    ingestionPattern, group_id, last_task_num,alertTeamName,sub_lob_alert, preLoadResult):
    project_space = projectDetails[2]
    BASE_DIR = "/home/airflow/gcs/dags/" + project_space+ "/beamx"
    sys.path.append(f"{BASE_DIR}/utils")
    from ops_genie import send_alert_to_opsgenie
    from observability import get_records_inserted_from_bq_api
    from observability import bq_to_gcs_obs
    end_time = datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S")
    projectTag = projectDetails[0]
    varMap = variables[projectTag + "_vars"]
    dict_obs = context['ti'].xcom_pull(key='dict_obs')
    run_status = 'SUCCESS'
    error_msg = None
    upstreamTaskId = group_id + '.gcs_to_td_load'
    prevTaskRunState = (TaskInstance(context['dag'].get_task(upstreamTaskId), context['logical_date'])).current_state()
    gcs_to_td_status= str(prevTaskRunState).lower()
    context['ti'].xcom_push(key='gcs_to_td_status', value=gcs_to_td_status)
    if preLoadResult is not None:
        error_msg = preLoadResult['error_msg']
        run_status = preLoadResult['run_status']
    dict_obs = dict(dict_obs)
    logger_name = params["obs"]["logger_name"]
    dict_obs["run_status"] = run_status
    dict_obs["end_time"] = end_time
    dict_obs_static = str(params["obs"])
    dict_obs_static = json.loads((reduce(lambda key, value: key.replace(*value), varMap.items(), dict_obs_static)).replace("'", '"'))
    dict_obs.update(dict_obs_static)
    dict_obs["error_message"] = error_msg
    bq_to_gcs_obs(logger_name,dict_obs)