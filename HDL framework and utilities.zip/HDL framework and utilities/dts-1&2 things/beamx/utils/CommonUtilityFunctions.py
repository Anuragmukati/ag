def pushFailureStatus(context):
    context['ti'].xcom_push(key=f"dag_status", value=False)
