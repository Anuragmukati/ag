
from datetime import datetime
from datetime import date, timedelta, timezone, tzinfo
from ops_genie import send_alert_to_opsgenie



def fileSensorSuccess(context, params, variables, projectDetails):

    print("file was successfully detected")

    import observability

    projectTag = projectDetails[0]
    varMap = variables[projectTag + "_vars"]
    dict_obs = context['ti'].xcom_pull(key="dict_obs")

    task_instance = context['task_instance']
    retries = task_instance.max_tries
    dict_obs_static = str(params["obs"])
    dict_obs_static = json.loads(
        (reduce(lambda key, value: key.replace(*value), varMap.items(), dict_obs_static)).replace("'", '"'))
    dict_obs.update(dict_obs_static)
    dict_obs["process_date"] = str(date.today().strftime("%Y-%m-%d"))
    data_interval_endtime = context['data_interval_end'].in_timezone(tz)
    dict_obs["run_date"] = str(data_interval_endtime.strftime('%Y%m%d')) if processDate == None else str(
        datetime.strptime(processDate, '%Y-%m-%d').strftime("%Y%m%d"))
    dict_obs["run_day"] = str(data_interval_endtime.strftime('%A')) if processDate == None else str(
        datetime.strptime(processDate, '%Y-%m-%d').strftime('%A'))
    dict_obs["run_hour"] = str(data_interval_endtime.strftime("%H:%M:%S")) if processTime == None else str(
        datetime.strptime(processTime, '%H:%M:%S').strftime("%H:%M:%S"))
    dict_obs["error_message"] = "File Detected"
    dict_obs["run_status"] = "Success"
    dict_obs["log_file"] = varMap['log_file']
    try:
        ## passing the process end time based on that task sequence in the dag ##
        logger_name = params["obs"]["logger_name"]
        dict_obs["inserted_timestamp"] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
        observability.filecheck_obs(dict_obs, logger_name)
    except Exception as e:
        error_msg = str(e)
        print("error_msg : ", error_msg)
        print("Could not send observability log")


def fileSensorFailure(context, params, variables, projectDetails, opsgenie_priority=None, alertTeamName=None):
    print("file was not detected")

    # import the necessary modules
    import observability

    projectTag = projectDetails[0]
    varMap = variables[projectTag + "_vars"]
    dict_obs = context['ti'].xcom_pull(key="dict_obs")
    task_instance = context['task_instance']
    retries = task_instance.max_tries

    # send opsgenie alert
    opsgenie_message = "Beamx|" + variables["environment"] + "|FileWatcher|" + task_instance.task_id + "|" + dict_obs[
        'running_instance_id']
    opsgenie_description = "Filewatcher Failure|File was not detected|" + dict_obs['running_instance_id']
    opsgenie_details = {"DAG ID": dagId, "Error Step": " File Check", "Error Message": "File was not detected"}

    if (retries == 0 and task_instance.try_number == 1) or (retries > 0 and task_instance.try_number == retries + 1):
        send_alert_to_opsgenie(opsgenie_message, opsgenie_description, opsgenie_details, opsgenie_priority,
                               projectDetails=projectDetails, alertTeamName=alertTeamName)

    # send obs params
    dict_obs_static = str(params["obs"])
    dict_obs_static = json.loads(
        (reduce(lambda key, value: key.replace(*value), varMap.items(), dict_obs_static)).replace("'", '"'))
    dict_obs.update(dict_obs_static)
    print("file was not detected")
    dict_obs["process_date"] = str(date.today().strftime("%Y-%m-%d"))
    data_interval_endtime = context['data_interval_end'].in_timezone(tz)
    dict_obs["run_date"] = str(data_interval_endtime.strftime('%Y%m%d')) if processDate == None else str(
        datetime.strptime(processDate, '%Y-%m-%d').strftime("%Y%m%d"))
    dict_obs["run_day"] = str(data_interval_endtime.strftime('%A')) if processDate == None else str(
        datetime.strptime(processDate, '%Y-%m-%d').strftime('%A'))
    dict_obs["run_hour"] = str(data_interval_endtime.strftime("%H:%M:%S")) if processTime == None else str(
        datetime.strptime(processTime, '%H:%M:%S').strftime("%H:%M:%S"))
    dict_obs["error_message"] = "File was not detected"
    dict_obs["run_status"] = "Failure"
    dict_obs["log_file"] = varMap['log_file']
    try:
        ## passing the process end time based on that task sequence in the dag ##
        logger_name = params["obs"]["logger_name"]
        dict_obs["inserted_timestamp"] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
        observability.filecheck_obs(dict_obs, logger_name)
    except Exception as e:
        error_msg = str(e)
        print("error_msg : ", error_msg)
        logging.error(traceback.format_exc())
        print("Could not send observability log")

def fileCountSensorFailure(context, params, variables, projectDetails, opsgenie_priority=None, alertTeamName=None):
    print("file count sensor failed")
    task_instance = context['task_instance']
    retries = task_instance.max_tries
    opsgenie_message = "Beamx|" + variables["environment"] + "|FileCountCheck|" + task_instance.task_id + "|" + \
                       dict_obs['running_instance_id']
    opsgenie_description = "File count sensor Failure|Expected file count didnot match|" + dict_obs[
        'running_instance_id']
    opsgenie_details = {"DAG ID": dagId, "Error Step": "FileCountSensor", "Error Message": "File count sensor failed"}

    if (retries == 0 and task_instance.try_number == 1) or (retries > 0 and task_instance.try_number == retries + 1):
        send_alert_to_opsgenie(opsgenie_message, opsgenie_description, opsgenie_details, opsgenie_priority,
                               projectDetails=projectDetails, alertTeamName=alertTeamName)

def cntrlFileSensorSucess(context, params, variables, projectDetails):
    from control_file_loader import upload_control_file
    import observability

    fileSensorDetails = {{ fileSensorDetails }}
    upload_control_file(context,variables,bucketNameVars,fileSensorDetails,projectDetails)
    projectTag = projectDetails[0]
    varMap = variables[ projectTag+"_vars"]
    dict_obs = context['ti'].xcom_pull(key="dict_obs")
    task_instance =context['task_instance']
    retries=task_instance.max_tries

    # send dict_obs to obs
    dict_obs_static = str(params["obs"])
    dict_obs_static = json.loads((reduce(lambda key, value: key.replace(*value), varMap.items(), dict_obs_static)).replace("'", '"'))
    dict_obs.update(dict_obs_static)
    dict_obs["process_date"] = str(date.today().strftime("%Y-%m-%d"))
    data_interval_endtime = context['data_interval_end'].in_timezone(tz)
    dict_obs["run_date"] = str(data_interval_endtime.strftime('%Y%m%d')) if processDate == None else str(datetime.strptime(processDate, '%Y-%m-%d').strftime("%Y%m%d"))
    dict_obs["run_day"] = str(data_interval_endtime.strftime('%A')) if processDate == None else str(datetime.strptime(processDate, '%Y-%m-%d').strftime('%A'))
    dict_obs["run_hour"] = str(data_interval_endtime.strftime("%H:%M:%S")) if processTime == None else str(datetime.strptime(processTime, '%H:%M:%S').strftime("%H:%M:%S"))
    dict_obs["error_message"] = "Control File Detected"
    dict_obs["run_status"] = "Success"
    dict_obs["log_file"] = varMap['log_file']
    try:
        ## passing the process end time based on that task sequence in the dag ##
        logger_name = params["obs"]["logger_name"]
        dict_obs["inserted_timestamp"] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
        observability.filecheck_obs(dict_obs, logger_name)
    except Exception as e:
        error_msg = str(e)
        print("error_msg : ", error_msg)
        print("Could not send observability log")


def cntrlFileSensorFailure(context, params, variables, projectDetails, opsgenie_priority=None, alertTeamName=None):
    # import the necessary modules
    import observability

    projectTag = projectDetails[0]
    varMap = variables[ projectTag+"_vars"]
    dict_obs = context['ti'].xcom_pull(key="dict_obs")

    print("file was not detected")
    task_instance =context['task_instance']
    retries=task_instance.max_tries

    # send ops genie alert
    opsgenie_message = "Beamx|"+variables["environment"]+"|FileWatcher|"+task_instance.task_id+"|"+ dict_obs['running_instance_id']
    opsgenie_description = "Filewatcher | File was not detected|" + dict_obs['running_instance_id']
    opsgenie_details = {"DAG ID": dagId, "Error Step": " File Check", "Error Message": "control File was not detected"}
    opsgenie_priority = "{{ opsgeniePriority }}"
    alertTeamName = "{{ alertTeamName }}"

    if (retries == 0 and task_instance.try_number == 1) or (retries > 0 and  task_instance.try_number == retries + 1):
        send_alert_to_opsgenie(opsgenie_message, opsgenie_description, opsgenie_details, opsgenie_priority, projectDetails=projectDetails,alertTeamName=alertTeamName)

    # send obs params
    dict_obs_static = str(params["obs"])
    dict_obs_static = json.loads((reduce(lambda key, value: key.replace(*value), varMap.items(), dict_obs_static)).replace("'", '"'))
    dict_obs.update(dict_obs_static)
    print("file was not detected")
    dict_obs["process_date"] = str(date.today().strftime("%Y-%m-%d"))
    data_interval_endtime = context['data_interval_end'].in_timezone(tz)
    dict_obs["run_date"] = str(data_interval_endtime.strftime('%Y%m%d')) if processDate == None else str(datetime.strptime(processDate, '%Y-%m-%d').strftime("%Y%m%d"))
    dict_obs["run_day"] = str(data_interval_endtime.strftime('%A')) if processDate == None else str(datetime.strptime(processDate, '%Y-%m-%d').strftime('%A'))
    dict_obs["run_hour"] = str(data_interval_endtime.strftime("%H:%M:%S")) if processTime == None else str(datetime.strptime(processTime, '%H:%M:%S').strftime("%H:%M:%S"))
    dict_obs["error_message"] = "Control File was not detected"
    dict_obs["run_status"] = "Failure"
    dict_obs["log_file"] = varMap['log_file']
    try:
        ## passing the process end time based on that task sequence in the dag ##
        logger_name = params["obs"]["logger_name"]
        dict_obs["inserted_timestamp"] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
        observability.filecheck_obs(dict_obs, logger_name)
    except Exception as e:
        error_msg = str(e)
        print("error_msg : ", error_msg)
        logging.error(traceback.format_exc())
        print("Could not send observability log")



    
