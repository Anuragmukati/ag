from airflow.providers.google.cloud.hooks.bigquery import BigQueryHook
from datetime import datetime
from datetime import date, timedelta, timezone, tzinfo
import pytz
import pendulum

tz = pendulum.timezone("EST")
def audit_log(params, variables, audit_logs):
    
    if "error_messages" not in audit_logs:
        audit_logs['error_messages'] = "\"" + "\""

    if "file_record_count" not in audit_logs:
        audit_logs['file_record_count'] = None

    if "footer_record_count" not in audit_logs:
        audit_logs['footer_record_count'] = None

    #application_id = str(datetime.now(tz).strftime("%Y%m%d%H%M%S"))
    application_id = audit_logs['running_instance_id']

    if 'error_msg' in audit_logs:
        error_msg = audit_logs['error_msg']
    elif 'error_message' in audit_logs:
        error_msg = audit_logs['error_message']
    
    if 'keyvalue' not in audit_logs:
        audit_logs['keyvalue'] = 'NA'
    if 'scheduler' not in audit_logs:
        audit_logs['scheduler'] = 'airflow'
    if 'source_environment' not in audit_logs:
        audit_logs['source_environment'] = 'NA'
    if 'target_environment' not in audit_logs:
        audit_logs['target_environment'] = 'NA'
    if 'source_servername' not in audit_logs:
        audit_logs['source_servername'] = 'NA'
    if 'target_servername' not in audit_logs:
        audit_logs['target_servername'] = 'NA'
    if 'source_type' not in audit_logs:
        audit_logs['source_type'] = 'Table'
    if 'target_type' not in audit_logs:
        audit_logs['target_type'] = 'Table'
    if 'bad_records_count' not in audit_logs:
        audit_logs['bad_records_count'] = 'NA'
    if 'footer_record' not in audit_logs:
        audit_logs['footer_record'] = 'NA'
    if 'header_record' not in audit_logs:
        audit_logs['header_record'] = 'NA'
    if 'footer_cntrl_record' not in audit_logs:
        audit_logs['footer_cntrl_record'] = 'NA'
    if 'header_cntrl_record' not in audit_logs:
        audit_logs['header_cntrl_record'] = 'NA'
    if 'source_count' not in audit_logs:
        audit_logs['source_count'] = 'NA'

    insert_query = """
            Insert into {0}.{1}.audit
            SELECT
            '{2}'   AS application_id,
            '{3}'   AS end_time,
            '{4}'   AS error_msg,
            '{0}'   AS gcp_project,
            '{5}'   AS inserted_timestamp,
            '{6}'   AS keyvalue,
            '{7}'   AS logger_name,
            '{8}'   AS process_date,
            '{9}'   AS process_name,
            '{10}'  AS project_name,
            '{11}'  AS run_date,
            '{12}'  AS run_day,
            '{13}'  AS run_hour,
            '{14}'  AS run_status,
            '{15}'  AS scheduler,
            '{16}'  AS source_environment,
            r'''{17}'''  AS source_name,
            '{18}'  AS source_servername,
            '{19}'  AS source_type,
            '{20}'  AS start_time,
            '{21}'  AS sub_process,
            '{22}'  AS system_name,
            '{23}'  AS target_count,
            '{24}'  AS target_environment,
            r'''{25}'''  AS target_name,
            '{26}'  AS target_servername,
            '{27}'  AS target_type,
            '{28}'  AS td_load_completion_timestamp,
            '{29}'  AS tool_name,
            '''{30}'''  AS sql_query,
            '{31}' as bad_records_count,
            r'''{32}'''  AS footer,
            r'''{33}'''  AS header,
            {34}  AS errors,
            '{35}'  AS file_record_count,
            '{36}'  AS footer_record_count,
            '{37}'  AS footer_cntrl_record,
            '{38}'  AS header_cntrl_record,
            '{39}' as source_count

    """.format(audit_logs['project_id'], audit_logs['bq_dataset'], application_id, audit_logs['end_time'], error_msg,
               audit_logs['inserted_timestamp'], audit_logs['keyvalue'], audit_logs['logger_name'],
               audit_logs['process_date'], audit_logs['process_name'], audit_logs['project_name'],
               audit_logs['run_date'], audit_logs['run_day'], audit_logs['run_hour'], audit_logs['run_status'],
               audit_logs['scheduler'], audit_logs['source_environment'], audit_logs['source_name'],
               audit_logs['source_servername'], audit_logs['source_type'], audit_logs['start_time'],
               audit_logs['sub_process'], audit_logs['system_name'], audit_logs['target_count'],
               audit_logs['target_environment'], audit_logs['target_name'], audit_logs['target_servername'],
               audit_logs['target_type'], audit_logs['td_load_completion_timestamp'], audit_logs['tool_name'], 
               audit_logs['sql_query'],audit_logs['bad_records_count'],audit_logs['footer_record'],audit_logs['header_record'],
               audit_logs['error_messages'], audit_logs['file_record_count'], audit_logs['footer_record_count'], audit_logs['footer_cntrl_record'], audit_logs['header_cntrl_record'],audit_logs['source_count'])

    bq_hook = BigQueryHook(gcp_conn_id=variables[params["hook"]["gcp_conn_id"]], use_legacy_sql=False)
    bq_cursor = bq_hook.get_cursor()
    print("Audit Insert Query is: ", insert_query)
    bq_cursor.execute(insert_query)
    print("Audit Entry done")
