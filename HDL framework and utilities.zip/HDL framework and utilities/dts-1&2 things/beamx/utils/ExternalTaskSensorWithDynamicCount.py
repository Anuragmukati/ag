from airflow.sensors.external_task import ExternalTaskSensor
from airflow.models import DagRun
from airflow.utils.state import State
from airflow.utils.session import provide_session
from datetime import datetime, date, timedelta, timezone, tzinfo
import pytz
from airflow.models.dag import DAG
from airflow.operators.python import get_current_context
import pendulum

class ExternalTaskSensorWithDynamicCount(ExternalTaskSensor):
    def __init__(self, execution_date_fn, min_count=1, mode='poke', op_kwargs=None, *args, **kwargs):
        """Custom ExternalTaskSensor that counts dag runs within an interval.
        :param min_count: Minimum number of successful DAG runs required.
        :param execution_date_fn: A function to calculate(start_date, end_date)
        :param mode: The mode of operation ('poke' or 'reschedule').
        """
        print("INITIALIZING ExternalTaskSensorWithDynamicCount")
        super().__init__( *args, **kwargs)
        self.op_kwargs = op_kwargs or {}
        self.min_count = min_count
        self.execution_date_fn = execution_date_fn
        self.mode = mode
        self.log.info(f"execution_date_fn assigned: {self.execution_date_fn}")

        
    @provide_session
    def get_count(self, context, session=None):
        """ Fetches the count of successful DAG runs in the interval from execution_date_fn."""
        self.log.info("Inside get_count")
        if 'tz' in self.op_kwargs.keys():
            tz = self.op_kwargs.get("tz")
            print("Timezone is: ", tz)
        else:
            tz = "UTC"
        if 'for_any_last_exec_flag' in self.op_kwargs.keys():
            for_any_last_exec_flag = self.op_kwargs.get("for_any_last_exec_flag")
        else:
            for_any_last_exec_flag = 0
        if 'delta_hour' in self.op_kwargs.keys():
            delta_hour = self.op_kwargs.get("delta_hour")
        else:
            delta_hour = 0
        if 'delta' in self.op_kwargs.keys():
            delta = self.op_kwargs.get("delta")
        else:
            delta = 0
        if 'dag_query_days' in self.op_kwargs.keys():
            dag_query_days = self.op_kwargs.get("dag_query_days")
        else:
            dag_query_days = 0
        if 'threshold' in self.op_kwargs.keys():
            threshold = self.op_kwargs.get("threshold")
        else:
            threshold = 0
        start_date, end_date, ld_dt, ld_hr, dt_s = self.execution_date_fn(context, for_any_last_exec_flag, delta_hour, delta, dag_query_days, threshold, self.op_kwargs)
        self.log.info(type(start_date), type(ld_dt), type(ld_hr), type(dt_s))
        if for_any_last_exec_flag == 0:
            start_date = datetime.strptime(ld_dt, "%Y-%m-%d").astimezone(tz)
            end_date = datetime.strptime(ld_hr, "%Y-%m-%d %H").astimezone(tz)
            self.log.info(f"start_date: {start_date}, end_date: {end_date}")
            self.log.info(f"Checking DAG runs for {self.external_dag_id} between {start_date} and {end_date}.")
            count = session.query(DagRun).filter(
            DagRun.dag_id == self.external_dag_id,
            DagRun.execution_date >= start_date,
            DagRun.execution_date <= end_date,
            DagRun.state == State.SUCCESS
            ).count()
        elif for_any_last_exec_flag == 1:
            if threshold > 0:
                if start_date.date() < (datetime.strptime(dt_s,"%Y-%m-%d") - timedelta(days=threshold)).date():
                    print("Threshold datetime: ", datetime.strptime(dt_s,"%Y-%m-%d") - timedelta(days=threshold))
                    start_date = (datetime.strptime(dt_s,"%Y-%m-%d") - timedelta(days=threshold)).astimezone(tz)
                else:
                    print("Threshold datetime: ", datetime.strptime(dt_s,"%Y-%m-%d") - timedelta(days=threshold))
            self.log.info(f"start_date: {start_date}, end_date: {end_date}")
            self.log.info(f"Checking DAG runs for {self.external_dag_id} between {start_date} and {end_date}.")
            count = session.query(DagRun).filter(
            DagRun.dag_id == self.external_dag_id,
            DagRun.execution_date >= start_date,
            DagRun.execution_date <= end_date,
            DagRun.state == State.SUCCESS
            ).count()
        
        return count
        
    def poke(self, context):
        """Pokes for the required count of DAG runs within the interval."""
        #execution_date = context['execution_date']
        self.log.info("Inside Poke")
        #self.log.info(f"execution_date is: {execution_date}")
        count = self.get_count(context)
        self.log.info(f"Found {count} successful DAG runs for {self.external_dag_id}.")
        return count >= self.min_count