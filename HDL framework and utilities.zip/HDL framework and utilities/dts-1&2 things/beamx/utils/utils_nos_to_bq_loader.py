import logging
import traceback
import re
import pytz
import pendulum
import requests
import json
import sys
import pytz
import base64
from datetime import datetime
from datetime import date
from airflow.models import Variable
from datetime import date, timedelta, timezone, tzinfo
from functools import reduce
from airflow.providers.google.cloud.hooks.bigquery import BigQueryHook
from airflow.providers.google.cloud.hooks.gcs import GCSHook
from airflow.models import TaskInstance
import re
import pandas as pd
from airflow.models import DagRun
from airflow.exceptions import AirflowSkipException, AirflowFailException
from airflow.providers.cncf.kubernetes.secret import Secret
import teradatasql
import google.auth.transport.requests
from google.cloud import secretmanager
from airflow.operators.python import task, get_current_context
from airflow.providers.google.cloud.hooks.dataproc import DataprocHook

def get_secret_from_sm( project_id, secret_name, dpHook):
    client = secretmanager.SecretManagerServiceClient(credentials=dpHook.get_credentials())
    secret_name = f"projects/{project_id}/secrets/{secret_name}/versions/latest"
    response = client.access_secret_version(name=secret_name)
    return response.payload.data.decode("UTF-8")

class secrets:

    def __init__(self, varMap=None, params=None,variables=None,composer=None,projectDetails=None,kubernetes_namespace=None):

        projectTag = projectDetails[0]
        if composer is not None and projectTag + '_composer_buckets' in variables \
                and composer in variables[projectTag + '_composer_buckets']:

            nos_conn_id = variables[projectTag + '_composer_buckets'][composer]['nos_conn_id'] \
                if 'nos_conn_id' in variables[projectTag + '_composer_buckets'][composer] else variables[
                'nos_conn_id']
            authorization = variables[projectTag + '_composer_buckets'][composer]['authorization'] \
                if 'authorization' in variables[projectTag + '_composer_buckets'][composer] else variables[
                'authorization']
        else:

            nos_conn_id = variables['nos_conn_id']
            authorization  = variables['authorization']

        self.authorization = authorization
        self.nos_conn_id = nos_conn_id

    def fetch_nos_arguments(self, context, varMap, params, tz, dagId, projectDetails, bucketNameVars, variables):
        projectSpace = projectDetails[2]
        BASE_DIR = "/home/airflow/gcs/dags/" + projectSpace + "/beamx"
        sys.path.append(f"{BASE_DIR}/utils")
        from dynamic_params import checkDynamicParams
        from common_utility_functions import pushFailureStatus
        projectTag = projectDetails[0]
        business_line = projectDetails[1]

        teradata_host = varMap['teradata_host']
        teradata_user = varMap['teradata_user']
        target_dbtype = "teradata"
        db_instance = params["hook"]["dbinstance"].lower() if "dbinstance" in params["hook"] else "default"
        db_config = variables[projectTag + '_db_config_jdbc_bq'][business_line] if business_line is not None else \
            variables[projectTag + '_db_config_jdbc_bq']
        db_config = db_config[target_dbtype][db_instance]
        secret_name = db_config["secret_name"]
        project_id = variables['projectId']
        dpHook = DataprocHook(gcp_conn_id=variables["gcp_conn_id"])
        payload = get_secret_from_sm(project_id, secret_name, dpHook)
        username, password = payload.strip().split(':')
        username = username.strip()
        password = password.strip()
        host_name = db_config['host_name']
        query = reduce(lambda key, value: key.replace(*value), varMap.items(), params['hook']['query'])
        source_audit_config,source_count = teradata_table_count(host_name, username, password, varMap, params, tz, dagId, projectDetails,
                                                                bucketNameVars, query, variables, context)

        print("source_count for setting queryband: ",source_count)
        print("source_audit_config", source_audit_config)


        try:
            #if '_wln_' in params['obs']['system_name']:
            #    teradata_conn_id = varMap['wireline_tpt_td_conn']
            #else:
            #    teradata_conn_id = varMap['wireless_tpt_td_conn']
            query = reduce(lambda key, value: key.replace(*value), varMap.items(), params['hook']['query'])
            Bucket = reduce(lambda key, value: key.replace(*value), varMap.items(), params['hook']['target_gcs_bucket'])
            Object = varMap['nos_source_gcs_path'] + params['hook']['nos_gcs_path_uri']


            sql_query = rf"""SELECT * FROM WRITE_NOS (
            ON ( 
            {query} 
            )
            USING
            LOCATION('/gs/storage.googleapis.com/{Bucket}/{Object}')
            AUTHORIZATION({self.authorization})
            STOREDAS('parquet')
            MAXOBJECTSIZE('16MB')
            COMPRESSION('SNAPPY')
            ) AS d;
            """
            arguments = sql_query

            context['ti'].xcom_push(key='arguments', value=arguments)
            context['ti'].xcom_push(key='query', value=query)
            context['ti'].xcom_push(key='audit_configuration', value=source_audit_config)
            # context['ti'].xcom_push(key='teradata_conn_id', value=teradata_conn_id)
            return {"arguments": arguments, "query": query, "audit_configuration": source_audit_config}
        except:
            pushFailureStatus(context)
            raise AirflowFailException

def teradata_table_count(host_name, user_name, password, varMap, params, tz, dagId, projectDetails, bucketNameVars,
                         query, variables, context):
    # destination count #
    # query_test=task_instance.xcom_pull(task_ids='ssh_command',key='query')
    # print("query_test is:",query_test)
    project_id = projectDetails[2]
    projectTag = projectDetails[0]
    projectSpace = projectDetails[2]
    print("projectDetails is ", projectDetails)
    #updated_query = re.sub(r"''([^'']*)''", r"'\1'", query)
    pattern = r"(?i)^select\s+.*?\s+from"
    updated_query = re.sub(pattern, "select count(1) from", query, count=1)
    try:
        #teradata_count = f"Select count(1) from ({updated_query}) As Subquery ;"
        teradata_count = f"{updated_query}"
        print("count query", teradata_count)
        with teradatasql.connect(host=host_name, user=user_name, password=password) as connect:
            df = pd.read_sql(teradata_count, connect)
            total_count = str(df.iloc[0][-1])
            print("total :", total_count)
            run_status = "Success"
    except Exception as e:
        error_msg = str(e)
        print("error_msg : ", error_msg)
        logging.error(traceback.format_exc())
        total_count = "NA"
        run_status = "Failure"
        pass
    varMap = varMap
    gcs_to_bq_dict = {}
    dict_obs = {}
    dict_obs["start_time"] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
    data_interval_endtime = context['data_interval_end'].in_timezone(tz)
    dict_obs["run_date"] = str(data_interval_endtime.strftime('%Y%m%d'))
    dict_obs["run_day"] = str(data_interval_endtime.strftime('%A'))
    dict_obs["run_hour"] = str(data_interval_endtime.strftime("%H:%M:%S"))
    logger_name = params["obs"]["logger_name"]
    dict_obs["process_name"] = dagId

    run_id_dag = str(context["dag_run"].run_id)[0: str(context["dag_run"].run_id).index("+")] \
        .replace(".", "-").replace(":", "-").replace("__", "-").lower()
    # if run_id_dag.endswith("-"):
    #     run_id_dag = run_id_dag[:-1]
    process_run_id = f"{dagId}_" + str(run_id_dag)
    running_instance_id = process_run_id
    if "projectId" in params["hook"]:
        gcp_project = reduce(lambda key, value: key.replace(*value), varMap.items(), params["hook"]["projectId"])
        print("gcp_project is if case", gcp_project)
    else:
        gcp_project = project_id
        print("gcp_project is else case", gcp_project)
    if "audit_table_db" in params["hook"]:
        audit_db_td_bq = params["hook"]["audit_table_db"]
    else:
        audit_db_td_bq = variables["audit_db_td_bq"]
    target_count = 'NA'
    source_count = total_count
    dict_obs["run_status"] = run_status
    dict_obs["end_time"] = datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S")
    dict_obs["inserted_timestamp"] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
    dict_obs["process_date"] = str(date.today())
    dict_obs["target_count"] = target_count
    dict_obs["source_count"] = source_count
    dict_obs["error_message"] = ''
    dict_obs_static = str(params["obs"])
    dict_obs_static = json.loads(
        (reduce(lambda key, value: key.replace(*value), varMap.items(), dict_obs_static)).replace("'", '"'))
    dict_obs.update(dict_obs_static)
    gcs_to_bq_dict.update(dict_obs)
    if "target_servername" in params["obs"]:
        gcp_project1 = reduce(lambda key, value: key.replace(*value), varMap.items(),
                              params["obs"]["target_servername"])
        print("gcp_project1 is if case", gcp_project1)
    else:
        gcp_project1 = project_id
    print("gcs_to_bq_dict is : ", gcs_to_bq_dict)
    # print("test1", dict_obs_static)
    try:
        insert_query = "INSERT INTO `" + gcp_project1 + "`." + audit_db_td_bq + ".audit (application_id, end_time, error_msg, gcp_project, inserted_timestamp, keyvalue, logger_name, process_date, process_name, project_name, run_date, run_day, run_hour, run_status, scheduler, source_environment, source_name, source_servername, source_type, start_time, sub_process, system_name, target_count, target_environment, target_name, target_servername, target_type, tool_name, td_load_completion_timestamp, sql_query, source_count) VALUES(CAST('" + running_instance_id + "' AS STRING), CAST('" + \
                       gcs_to_bq_dict['end_time'] + "' AS STRING), CAST('" + gcs_to_bq_dict[
                           'error_message'] + "' AS STRING), CAST('" + gcp_project1 + "' AS STRING), CAST('" + \
                       gcs_to_bq_dict['inserted_timestamp'] + "' AS STRING), CAST('" + gcs_to_bq_dict[
                           'keyvalue'] + "' AS STRING), CAST('" + gcs_to_bq_dict[
                           'logger_name'] + "' AS STRING), CAST('" + gcs_to_bq_dict[
                           'process_date'] + "' AS STRING), CAST('" + dagId + "' AS STRING), CAST('" + gcs_to_bq_dict[
                           'project_name'] + "' AS STRING), CAST('" + gcs_to_bq_dict[
                           'run_date'] + "' AS STRING), CAST('" + gcs_to_bq_dict['run_day'] + "' AS STRING), CAST('" + \
                       gcs_to_bq_dict['run_hour'] + "' AS STRING), CAST('" + gcs_to_bq_dict[
                           'run_status'] + "' AS STRING), CAST('" + gcs_to_bq_dict[
                           'scheduler'] + "' AS STRING), CAST('" + gcs_to_bq_dict[
                           'source_environment'] + "' AS STRING), CAST('" + gcs_to_bq_dict[
                           'source_name'] + "' AS STRING), CAST('" + gcs_to_bq_dict[
                           'source_servername'] + "' AS STRING), CAST('" + gcs_to_bq_dict[
                           'source_type'] + "' AS STRING), CAST('" + gcs_to_bq_dict[
                           'start_time'] + "' AS STRING), CAST('" + gcs_to_bq_dict[
                           'sub_process'] + "' AS STRING), CAST('" + gcs_to_bq_dict[
                           'system_name'] + "' AS STRING), CAST('" + gcs_to_bq_dict[
                           'target_count'] + "' AS STRING), CAST('" + gcs_to_bq_dict[
                           'target_environment'] + "' AS STRING), CAST('" + gcs_to_bq_dict[
                           'target_name'] + "' AS STRING), CAST('" + gcs_to_bq_dict[
                           'target_servername'] + "' AS STRING), CAST('" + gcs_to_bq_dict[
                           'target_type'] + "' AS STRING), CAST('" + gcs_to_bq_dict[
                           'tool_name'] + "' AS STRING), CAST('null' as string), CAST('None' AS STRING),CAST('" + \
                       gcs_to_bq_dict['source_count'] + "' AS STRING))"
        get_insert_query_status = "SUCCESS"
        audit_error_msg = None
        print("Audit Insert SQL query to run :", insert_query)
    except Exception as e:
        get_insert_query_status = "FAILURE"
        audit_error_msg = str(e)
        logging.error(traceback.format_exc())
    if get_insert_query_status == 'FAILURE':
        print('Failure in getting the SQL query... exiting')
    audit_configuration = {
        "jobType": "{{ jobType }}",
        "query": {
            "query": insert_query,
            "useLegacySql": False
        }
    }

    return audit_configuration,source_count

'''
TERADATA_PASSWORD = Secret(
    deploy_type="env",
    deploy_target="TERADATA_PASSWORD",
    secret="tpt-secrets",
    key="TERADATA_PASSWORD",
)

GCS_ACCESS_KEY = Secret(
    deploy_type="env",
    deploy_target="GCS_ACCESS_KEY_ID",
    secret="tpt-secrets",
    key="GCS_ACCESS_KEY_ID",
)

GCS_SECRET_ACCESS_KEY = Secret(
    deploy_type="env",
    deploy_target="GCS_SECRET_ACCESS_KEY",
    secret="tpt-secrets",
    key="GCS_SECRET_ACCESS_KEY",
)
'''

def getObsParams(params, varMap, dagId, tz, dict_obs, projectTag, context):
    """
    This function sets default values for observability related keys
    """
    dict_obs["start_time"] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
    dict_obs["error_message"] = ""
    dict_obs["inserted_timestamp"] = ""
    dict_obs["process_date"] = str(datetime.now(tz).strftime('%Y-%m-%d'))
    data_interval_endtime = context['data_interval_end'].in_timezone(tz)
    dict_obs["run_date"] = str(data_interval_endtime.strftime('%Y%m%d'))
    dict_obs["run_hour"] = str(data_interval_endtime.strftime("%H:%M:%S"))
    dict_obs["run_day"] = str(data_interval_endtime.strftime('%A'))
    dict_obs["source_count"] = "0"
    dict_obs["target_count"] = "0"
    dict_obs["source_type"] = "File"
    dict_obs["target_type"] = "Table"
    dict_obs["process_name"] = dagId
    gcp_project = projectTag + "_project_id"
    dict_obs["gcp_project"] = varMap[gcp_project]
    dict_obs["log_file"] = varMap['log_file']
    dict_obs["process_end_time"] = ""

    return dict_obs

'''
def fetch_tpt_arguments(context, varMap, params, tz, dagId, projectDetails, bucketNameVars, variables):
    projectSpace = projectDetails[2]
    BASE_DIR = "/home/airflow/gcs/dags/" + projectSpace + "/beamx"
    sys.path.append(f"{BASE_DIR}/utils")
    from common_utility_functions import pushFailureStatus
    projectTag = projectDetails[0]
    business_line = projectDetails[1]
    def read_export_tpt():
        with open(f"/home/airflow/gcs/dags/{projectSpace}/utils/dpf_export.tpt", "r") as f:
            return f.read().replace("$", r"\$")
    try:
        if '_wln_' in params['obs']['system_name']:
            teradata_conn_id = varMap['wireline_tpt_td_conn']
        else:
            teradata_conn_id = varMap['wireless_tpt_td_conn']

        target_dbtype = "teradata"
        db_instance = "default"
        db_config = variables[project_tag + '_db_config_bq_jdbc'][business_line] if business_line is not None else variables[project_tag + '_db_config_bq_jdbc']
        db_config = db_config[target_dbtype][db_instance]
        jobvar_tdpid = db_config['host_name']

        query = reduce(lambda key, value: key.replace(*value), varMap.items(), params['hook']['query'])
        read_instances = 1
        write_instances = 1
        Bucket = reduce(lambda key, value: key.replace(*value), varMap.items(), params['hook']['target_gcs_bucket'])
        Object = varMap['tpt_source_gcs_path'] + params['hook']['target_gcs_path']
        Minsessions = params['hook']['min_sessions']
        Maxsessions = params['hook']['max_sessions']
        delimiter = ''
        if params['hook']['delimiter'] == 'CNTRLA':
            delimiter = ''
        else:
            delimiter = params['hook']['delimiter']

        if delimiter == 'ctrla' or not delimiter:
            Datadelimiter = '\x01'
        else:
            Datadelimiter = delimiter

        arguments = [
            "-c",
            rf"""
            set -e && \
            echo "{read_export_tpt()}" > export.tpt && \
            more export.tpt && \
            tbuild -f export.tpt -u "\
                jobvar_tdpid='{jobvar_tdpid}', \
                jobvar_username='UDBABQGCPDTS', \
                jobvar_password='$TERADATA_PASSWORD', \
                jobvar_num_read_instances={read_instances}, \
                jobvar_num_write_instances={write_instances}, \
                jobvar_delimiter='{Datadelimiter}', \
                jobvar_selectstmt='{query}', \
                jobvar_accessmoduleinitstr='\
                Bucket={Bucket} \
                Object={Object} \
                MaxObjectSize=500M \
                BufferSize=16M \
                MaxSessions = {Maxsessions} \
                MinSessions = {MinSessions} \
                ConnectionCount=20'" \
            """,
        ]
        context['ti'].xcom_push(key='arguments', value=arguments)
        context['ti'].xcom_push(key='query', value=query)
        context['ti'].xcom_push(key='teradata_conn_id', value=teradata_conn_id)
        return {"arguments": arguments, "query": query , "teradata_conn_id": teradata_conn_id}

    except:
        pushFailureStatus(context)
        raise AirflowFailException
'''

def on_failure_mail(context, dagId, projectDetails,sub_lob_alert, **kwargs):
    projectSpace = projectDetails[2]
    BASE_DIR = "/home/airflow/gcs/dags/" + projectSpace+ "/beamx"
    sys.path.append(f"{BASE_DIR}/utils")
    from common_utility_functions import pushFailureStatus
    from ops_genie import send_alert_to_opsgenie
    pushFailureStatus(context)
    task_instance = context['task_instance']
    retries = task_instance.max_tries
    error_msg = str(context.get('exception'))
    dagId = dagId
    params = kwargs['params'] if 'params' in kwargs else None
    projectDetails = projectDetails
    opsgenie_message = Variable.get("environment") + " Alert | TPT TD to BQ TPT script execution failed"
    opsgenie_description = str(error_msg)
    opsgenie_priority = params['hook']['OpsgeniePriority']
    alertTeamName = None
    if 'alertTeamName' in params and params['hook']['alertTeamName'] != None:
        alertTeamName = params['hook']['alertTeamName']
    else:
        alertTeamName = None
    sub_lob_alert=sub_lob_alert
    opsgenie_details = {"DAG ID": dagId, "Error Step": "TPT TD to BQ TPT script execution failed",
                        "Error message": error_msg}
    send_alert_to_opsgenie(opsgenie_message, opsgenie_description, opsgenie_details, opsgenie_priority,
                           projectDetails=projectDetails, alertTeamName=alertTeamName,sub_lob_alert=sub_lob_alert)

    print("On failure tpt script method called Reason", context['exception'])


def FileArchival(context, params, variables, varMap):
    array_objects = []
    # get the upstream task id and its run state
    upstreamTaskId = next(iter(context['task'].upstream_task_ids))
    print("upstream task id is :", upstreamTaskId)
    fileCompressionType = context['ti'].xcom_pull(task_ids=upstreamTaskId, key='file_compression_type')
    logicalDate = context['logical_date']
    prevTaskRunState = (TaskInstance(context['dag'].get_task(upstreamTaskId), logicalDate)).current_state()
    print("previous task run status is :", prevTaskRunState)
    # get the required details for archival
    sourceBucket = params["hook"]["gcs_bucket"]
    if 'nos_gcs_path_uri' in params['hook']:
        destinationBucket = varMap['nos_archival_bucket']
        object_pattern = params["hook"]["gcs_path"]
    else:
        destinationBucket = varMap['tpt_archival_bucket']
        object_pattern = '/'.join(params["hook"]["gcs_path"].split('/')[:-1])

    # connect to gcs
    gcs_hook = GCSHook(gcp_conn_id=variables[params["hook"]["gcp_conn_id"]])
    objects = gcs_hook.list(bucket_name=sourceBucket)
    for obj in objects:
        if re.match(object_pattern, obj):
            array_objects.append(obj)
    print(array_objects)
    for arr in array_objects:
        today = str(date.today())
        if 'nos_gcs_path_uri' in params["hook"]:
            file_path = 'nos_archives/nos_td2bq' + '/' + arr.split('/')[-2] + '/' + today
        else:
            file_path = 'tpt_archives/tpt_td2bq' + '/' + arr.split('/')[-2] + '/' + today
        file_name = arr.split('/')[-1]
        destinationObject = file_path + '/' + file_name
        gcs_hook.copy(source_bucket=sourceBucket, source_object=arr, destination_bucket=destinationBucket,
                      destination_object=destinationObject)
        print("file '{}' archived..".format(destinationObject))


def preChecksAndJobConfiguration(params, dagId, projectDetails, tz, context, bucketNameVars, variables,
                                 last_task, ingestionPattern, opsgenie_priority, last_task_num, superGroupId,
                                 custom_labels, alertTeamName,sub_lob_alert, taskType):
    project_space = projectDetails[2]
    BASE_DIR = "/home/airflow/gcs/dags/" + project_space+ "/beamx"
    sys.path.append(f"{BASE_DIR}/utils")
    from ops_genie import send_alert_to_opsgenie
    from observability import gcs_to_bq_obs
    project_id = projectDetails[2]
    projectTag = projectDetails[0]
    business_line = projectDetails[1]
    gcs_to_bq_dict = {}
    task_instance = context['task_instance']
    retries = task_instance.max_tries
    dict_obs = context['ti'].xcom_pull(key='dict_obs')
    dict_obs = dict(dict_obs)
    dict_obs["start_time"] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
    # dict_obs["run_date"] = str(datetime.now(tz).strftime('%Y%m%d'))
    # dict_obs["run_day"] = str(datetime.now(tz).strftime('%A'))
    # dict_obs["run_hour"] = str(datetime.now(tz).strftime('%X'))
    data_interval_endtime = context['data_interval_end'].in_timezone(tz)
    dict_obs["run_date"] = str(data_interval_endtime.strftime('%Y%m%d'))
    dict_obs["run_day"] = str(data_interval_endtime.strftime('%A'))
    dict_obs["run_hour"] = str(data_interval_endtime.strftime("%H:%M:%S"))
    ### logging obs parameters to cloud logging ###
    # logging_client = gcplogging.Client()
    logger_name = params["obs"]["logger_name"]
    dict_obs["process_name"] = dagId
    varMap = variables[projectTag + "_vars"]

    try:
        source_gcs_bucket = reduce(lambda key, value: key.replace(*value), varMap.items(),
                                   params['hook']['source_gcs_bucket'])


        nos_gcs_path_uri = varMap['nos_source_gcs_path'] + params['hook']['nos_gcs_path_uri']
        params['hook']['gcs_path'] = 'gs://' + source_gcs_bucket + "/" + nos_gcs_path_uri +"*"


        final_query = " LOAD DATA OVERWRITE " + params['hook'][
            'target_table'] + " FROM FILES (format = 'PARQUET',uris = ['" + \
                      params["hook"]["gcs_path"] + "'])"
        sql_query = reduce(lambda key, value: key.replace(*value), varMap.items(), final_query)
        get_sql_query_status = "SUCCESS"
        error_msg = None
    except Exception as e:
        get_sql_query_status = "FAILURE"
        error_msg = str(e)
    if get_sql_query_status == 'FAILURE':
        dict_obs["run_status"] = get_sql_query_status
        dict_obs["end_time"] = datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S")
        dict_obs_static = str(params["obs"])
        dict_obs_static = json.loads(
            (reduce(lambda key, value: key.replace(*value), varMap.items(), dict_obs_static)).replace("'", '"'))
        dict_obs.update(dict_obs_static)
        dict_obs["error_message"] = error_msg
        gcs_to_bq_obs(logger_name, dict_obs)
        # logger.log_struct( dict_obs )
        # error_msg = str(e)
        opsgenie_message = Variable.get("environment") + " Alert | TPT TD to BQ getting SQL query failed"
        opsgenie_description = error_msg
        opsgenie_priority = params['hook']['OpsgeniePriority']
        opsgenie_details = {"DAG ID": dagId, "Error Step": "TPT TD to BQ getting SQL query failed",
                            "Error message": error_msg}
        alertTeamName = alertTeamName
        sub_lob_alert=sub_lob_alert
        if (retries == 0 and task_instance.try_number == 1) or (
                retries > 0 and task_instance.try_number == retries + 1):
            send_alert_to_opsgenie(opsgenie_message, opsgenie_description, opsgenie_details, opsgenie_priority,
                                   projectDetails=projectDetails, alertTeamName=alertTeamName,sub_lob_alert=sub_lob_alert)
        logging.error(traceback.format_exc())
        sys.tracebacklimit = 0
        return ({'run_status': 'FAILURE', 'error_msg': 'Failure in getting the SQL query... exiting'})
    print("SQL query to run :", sql_query)
    configuration = {
        "jobType": "QUERY",
        "query": {
            "query": sql_query,
            "useLegacySql": False,
        }
    }
    run_status = "SUCCESS"
    return {"bqInsertJobConfig": configuration, "error_msg": "NA", "run_status": run_status, "dict_obs": dict_obs,
            "sql_query": sql_query}


def postLoad(context, variables, params, projectDetails, dagId, tz, opsgenie_priority, last_task,
             ingestionPattern, superGroupId, last_task_num, preLoadResult,alertTeamName,sub_lob_alert, fileSensorDetails=None):
    project_space = projectDetails[2]
    BASE_DIR = "/home/airflow/gcs/dags/" + project_space+ "/beamx"
    sys.path.append(f"{BASE_DIR}/utils")
    from ops_genie import send_alert_to_opsgenie
    from observability import get_records_inserted_from_bq_api
    from observability import gcs_to_bq_obs
    dict_obs = context['ti'].xcom_pull(key='dict_obs')
    dict_obs = dict(dict_obs)
    dict_obs["inserted_timestamp"] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
    logger_name = params["obs"]["logger_name"]
    projectTag = projectDetails[0]
    varMap = variables[projectTag + "_vars"]
    task_instance = context['task_instance']
    retries = task_instance.max_tries
    gcs_to_bq_dict = {}
    project_id = projectDetails[2]
    dict_obs["start_time"] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
    run_status = 'SUCCESS'
    error_msg = None
    end_time = datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S")
    dict_obs["process_date"] = str(date.today())
    data_interval_endtime = context['data_interval_end'].in_timezone(tz)
    dict_obs["run_date"] = str(data_interval_endtime.strftime('%Y%m%d'))
    dict_obs["run_day"] = str(data_interval_endtime.strftime('%A'))
    dict_obs["run_hour"] = str(data_interval_endtime.strftime("%H:%M:%S"))
    upstreamTaskId = superGroupId + '.gcs_to_bq_load_bigquery_operator'
    prevTaskRunState = (TaskInstance(context['dag'].get_task(upstreamTaskId), context['logical_date'])).current_state()
    if str(prevTaskRunState).lower() == 'failed':
        failure_xcom = context['ti'].xcom_pull(key='gcstobqrunstatus', task_ids=upstreamTaskId)
        run_status = failure_xcom.get("run_status")
        error_msg = failure_xcom.get("error_msg")
        opsgenie_message = Variable.get("environment") + " Alert | TPT TD to BQ insert job failed"
        opsgenie_description = error_msg
        opsgenie_priority = params['hook']['OpsgeniePriority']
        alertTeamName = alertTeamName
        opsgenie_details = {"DAG ID": dagId, "Error Step": "TPT TD to BQ insert job failed",
                            "Error message": error_msg}
        if (retries == 0 and task_instance.try_number == 1) or (
                retries > 0 and task_instance.try_number == retries + 1):
            send_alert_to_opsgenie(opsgenie_message, opsgenie_description, opsgenie_details, opsgenie_priority,
                                   projectDetails=projectDetails, alertTeamName=alertTeamName,sub_lob_alert=sub_lob_alert)
        end_time = datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S")
        run_status = "FAILURE"
    if run_status == 'FAILURE':
        opsgenie_message = Variable.get("environment") + " Alert | TPT TD to BQ insert job failed"
        opsgenie_description = error_msg
        opsgenie_priority = params['hook']['OpsgeniePriority']
        alertTeamName = alertTeamName
        opsgenie_details = {"DAG ID": dagId, "Error Step": "TPT TD to BQ insert job failed",
                            "Error message": error_msg}
        if (retries == 0 and task_instance.try_number == 1) or (
                retries > 0 and task_instance.try_number == retries + 1):
            send_alert_to_opsgenie(opsgenie_message, opsgenie_description, opsgenie_details, opsgenie_priority,
                                   projectDetails=projectDetails, alertTeamName=alertTeamName,sub_lob_alert=sub_lob_alert)
        end_time = datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S")
    print("RUN STATUS :", run_status)

    if run_status == 'SUCCESS':
        job_id = context['ti'].xcom_pull(task_ids=upstreamTaskId,key='job_id_path')
        job_id = job_id.split(":")[2]
        print("job_id",job_id)
    if "gcp_conn_id" in params["hook"]:
        bq_hook = BigQueryHook(gcp_conn_id=variables[params["hook"]["gcp_conn_id"]])
    else:
        bq_hook = BigQueryHook(gcp_conn_id=variables["gcp_conn_id"])

    records_inserted = get_records_inserted_from_bq_api(job_id, bq_hook, variables, projectTag, varMap, params)
    dict_obs["run_status"] = run_status
    dict_obs["end_time"] = end_time
    dict_obs_static = str(params["obs"])
    dict_obs_static = json.loads(
        (reduce(lambda key, value: key.replace(*value), varMap.items(), dict_obs_static)).replace("'", '"'))
    dict_obs.update(dict_obs_static)
    if error_msg is not None:
        dict_obs["error_message"] = error_msg.replace('\n', '')
    else:
        dict_obs["error_message"] = error_msg
    gcs_to_bq_obs(logger_name, dict_obs)
    gcs_to_bq_dict.update(dict_obs)
    print("gcs_to_bq_dict is : ", gcs_to_bq_dict)
    run_id_dag = str(context["dag_run"].run_id)[0: str(context["dag_run"].run_id).index("+")] \
        .replace(".", "-").replace(":", "-").replace("__", "-").lower()
    # if run_id_dag.endswith("-"):
    #     run_id_dag = run_id_dag[:-1]
    process_run_id = f"{dagId}_" + str(run_id_dag)
    running_instance_id = process_run_id
    # gcs_to_bq_dict['sql_query'] = sql_query.replace('\n','')

    if "projectId" in params["hook"]:
        gcp_project = reduce(lambda key, value: key.replace(*value), varMap.items(), params["hook"]["projectId"])
        print(gcp_project)
    else:
        gcp_project = project_id

    if "audit_table_db" in params["hook"]:
        audit_db_td_bq = params["hook"]["audit_table_db"]
    else:
        audit_db_td_bq = variables["audit_db_td_bq"]

    try:
        if gcs_to_bq_dict['error_message'] == None:
            insert_query="INSERT INTO `"+gcp_project+"`."+audit_db_td_bq+".audit (application_id, end_time, error_msg, gcp_project, inserted_timestamp, keyvalue, logger_name, process_date, process_name, project_name, run_date, run_day, run_hour, run_status, scheduler, source_environment, source_name, source_servername, source_type, start_time, sub_process, system_name, target_count, target_environment, target_name, target_servername, target_type, tool_name, td_load_completion_timestamp, sql_query,source_count) VALUES(CAST('"+ running_instance_id +"' AS STRING), CAST('"+ gcs_to_bq_dict['end_time']+"' AS STRING), CAST('None' AS STRING), CAST('"+ gcp_project+"' AS STRING), CAST('"+gcs_to_bq_dict['inserted_timestamp'] +"' AS STRING), CAST('"+gcs_to_bq_dict['keyvalue']+"' AS STRING), CAST('"+gcs_to_bq_dict['logger_name']+"' AS STRING), CAST('"+ gcs_to_bq_dict['process_date']+"' AS STRING), CAST('"+ dagId+"' AS STRING), CAST('"+ gcs_to_bq_dict['project_name']+"' AS STRING), CAST('"+ gcs_to_bq_dict['run_date']+"' AS STRING), CAST('"+ gcs_to_bq_dict['run_day']+"' AS STRING), CAST('"+ gcs_to_bq_dict['run_hour'] +"' AS STRING), CAST('"+ gcs_to_bq_dict['run_status']+"' AS STRING), CAST('"+ gcs_to_bq_dict['scheduler']+"' AS STRING), CAST('"+ gcs_to_bq_dict['source_environment']+"' AS STRING), CAST('"+ gcs_to_bq_dict['source_name']+"' AS STRING), CAST('"+ gcs_to_bq_dict['source_servername']+"' AS STRING), CAST('"+ gcs_to_bq_dict['source_type']+"' AS STRING), CAST('"+ gcs_to_bq_dict['start_time']+"' AS STRING), CAST('"+gcs_to_bq_dict['sub_process']+"' AS STRING), CAST('"+ gcs_to_bq_dict['system_name']+"' AS STRING), CAST('"+ records_inserted +"' AS STRING), CAST('"+ gcs_to_bq_dict['target_environment']+"' AS STRING), CAST('"+ gcs_to_bq_dict['target_name']+"' AS STRING), CAST('"+gcs_to_bq_dict['target_servername']+"' AS STRING), CAST('"+ gcs_to_bq_dict['target_type']+"' AS STRING), CAST('"+ gcs_to_bq_dict['tool_name']+"' AS STRING), CAST('null' as string), CAST('None' AS STRING),CAST('NA' as string))"
        else:
            insert_query="INSERT INTO `"+gcp_project+"`."+audit_db_td_bq+".audit (application_id, end_time, error_msg, gcp_project, inserted_timestamp, keyvalue, logger_name, process_date, process_name, project_name, run_date, run_day, run_hour, run_status, scheduler, source_environment, source_name, source_servername, source_type, start_time, sub_process, system_name, target_count, target_environment, target_name, target_servername, target_type, tool_name, td_load_completion_timestamp, sql_query,source_count) VALUES(CAST('"+ running_instance_id +"' AS STRING), CAST('"+ gcs_to_bq_dict['end_time']+"' AS STRING), CAST('"+gcs_to_bq_dict['error_message']+"' AS STRING), CAST('"+ gcp_project+"' AS STRING), CAST('"+gcs_to_bq_dict['inserted_timestamp'] +"' AS STRING), CAST('"+gcs_to_bq_dict['keyvalue']+"' AS STRING), CAST('"+gcs_to_bq_dict['logger_name']+"' AS STRING), CAST('"+ gcs_to_bq_dict['process_date']+"' AS STRING), CAST('"+ dagId+"' AS STRING), CAST('"+ gcs_to_bq_dict['project_name']+"' AS STRING), CAST('"+ gcs_to_bq_dict['run_date']+"' AS STRING), CAST('"+ gcs_to_bq_dict['run_day']+"' AS STRING), CAST('"+ gcs_to_bq_dict['run_hour'] +"' AS STRING), CAST('"+ gcs_to_bq_dict['run_status']+"' AS STRING), CAST('"+ gcs_to_bq_dict['scheduler']+"' AS STRING), CAST('"+ gcs_to_bq_dict['source_environment']+"' AS STRING), CAST('"+ gcs_to_bq_dict['source_name']+"' AS STRING), CAST('"+ gcs_to_bq_dict['source_servername']+"' AS STRING), CAST('"+ gcs_to_bq_dict['source_type']+"' AS STRING), CAST('"+ gcs_to_bq_dict['start_time']+"' AS STRING), CAST('"+gcs_to_bq_dict['sub_process']+"' AS STRING), CAST('"+ gcs_to_bq_dict['system_name']+"' AS STRING), CAST('"+ records_inserted +"' AS STRING), CAST('"+ gcs_to_bq_dict['target_environment']+"' AS STRING), CAST('"+ gcs_to_bq_dict['target_name']+"' AS STRING), CAST('"+gcs_to_bq_dict['target_servername']+"' AS STRING), CAST('"+ gcs_to_bq_dict['target_type']+"' AS STRING), CAST('"+ gcs_to_bq_dict['tool_name']+"' AS STRING), CAST('null' as string), CAST('None' AS STRING),CAST('NA' as string))"
        get_insert_query_status = "SUCCESS"
        audit_error_msg = None
    except Exception as e:
        get_insert_query_status = "FAILURE"
        audit_error_msg = str(e)
        logging.error(traceback.format_exc())
    if get_insert_query_status == 'FAILURE':
        print('Failure in getting the SQL query... exiting')
    print("Audit Insert SQL query to run :", insert_query)
    audit_configuration = {
        "jobType": "{{ jobType }}",
        "query": {
            "query": insert_query,
            "useLegacySql": False
        }
    }
    return {"audit_configuration": audit_configuration, "run_status": run_status, "dict_obs": dict_obs,
            "sql_query": insert_query}

    '''
    bq_hook = BigQueryHook(gcp_conn_id=variables["gcp_conn_id"])
    try:
        bq_hook.insert_job(configuration=audit_configuration, nowait=False)
        end_time = datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S")
        audit_run_status = "SUCCESS"
        audit_error_msg = None
    except Exception as e:
        audit_error_msg = str(e)
        audit_run_status = "FAILURE"
        logging.error(traceback.format_exc())
        sys.tracebacklimit = 0
        opsgenie_message = Variable.get("environment") + " Alert | TPT TD to BQ audit insert job failed"
        opsgenie_description = audit_error_msg
        opsgenie_priority = params['hook']['OpsgeniePriority']
        alertTeamName = None
        if params['hook']['alertTeamName'] != None:
            alertTeamName = params['hook']['alertTeamName']
        else:
            alertTeamName = None
        opsgenie_details = {"DAG ID": dagId, "Error Step": "TPT TD to BQ audit insert job failed",
                            "Error message": audit_error_msg}
        if (retries == 0 and task_instance.try_number == 1) or (
                retries > 0 and task_instance.try_number == retries + 1):
            send_alert_to_opsgenie(opsgenie_message, opsgenie_description, opsgenie_details, opsgenie_priority,
                                   projectDetails=projectDetails, alertTeamName=alertTeamName)

    print("AUDIT ENTRY RUN STATUS :", audit_run_status)
    '''





