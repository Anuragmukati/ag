from airflow.sensors.sql_sensor import SqlSensor
from airflow.providers.google.cloud.hooks.bigquery import BigQueryHook

class BigQuerySqlSensor(SqlSensor):
    def _get_hook(self):
        return BigQueryHook(gcp_conn_id=self.conn_id, use_legacy_sql=False,location="us")
