from google.cloud import logging as gcplogging
import logging
import traceback
from airflow.providers.google.cloud.hooks.bigquery import BigQueryHook
import teradatasql
import pandas as pd
from google.cloud import bigquery
from functools import reduce
import re
import requests
import json
import google.auth.transport.requests


def ingestion_obs(obs_param, log_name):
    # cloud logging #
    cloud_logging(log_name, obs_param)

def udfcf_obs(obs_param, log_name):
    # cloud logging #
    cloud_logging(log_name, obs_param)

def filecheck_obs(obs_param, log_name):
    # cloud logging #
    cloud_logging(log_name, obs_param)

def get_count_file_based(params, varMap, project, credentials):
    ### calculate the table count ###
    client = bigquery.Client(project=project, credentials=credentials)
    try:
        if 'datasetId' in params["hook"] and 'tableId' in params["hook"] :
            if "projectId" in params["hook"]:
                project_id= varMap[params["hook"]["projectId"]]
            else:
                project_id = varMap["projectId"]
            query_job = client.query("select count(*) from " + project_id+"."+varMap[params["hook"]["datasetId"]] + "."+ params["hook"]["tableId"])
            results=list(query_job.result())
            counts=str(results[0]).split(',')
            final_count=re.findall('[0-9]+', str(counts[0]))
            final_count = final_count[0]
        elif "partitionDetails" in params["hook"] :
            if params["hook"]["partitionDetails"]["partitionType"] == "truncate with partitiontime column" :
                query_job = client.query("select count(*) from " + params["obs"]["target_name"])
                query_job = reduce(lambda key, value: key.replace(*value), varMap.items(), query_job)
                results=list(query_job.result())
                counts=str(results[0]).split(',')
                final_count=re.findall('[0-9]+', str(counts[0]))
                final_count = final_count[0]
        else:
            final_count = 'NA'
        count_query_status = 'SUCCESS'
    except:
        count_query_status = 'FAILURE'
        final_count = 'NA'
        print(" Error occured while getting the table count")
        logging.error(traceback.format_exc())
    print("Count query status :", count_query_status)
    return final_count



def bq_to_teradata_obs(dict_obs, tera_db, tera_tb, host_nm, host_usr, host_pwd, log_name):

    print("dict_obs is ", dict_obs)
    # teradata table count ##
    dest_count = teradata_table_count(tera_db, tera_tb, host_nm, host_usr, host_pwd)
    dict_obs["target_count"] = dest_count
    # cloud logging #
    cloud_logging(log_name, dict_obs)
    return dict_obs

def kafka_to_bq_obs(dict_obs, gcp_conn_id, proj_id, bq_dbnme, bq_tbnme):
    print("dict_obs is ", dict_obs)
    # BQ table count #
    dest_count = bq_table_count(gcp_conn_id, proj_id, bq_dbnme, bq_tbnme)
    dict_obs["target_count"] = dest_count
    # cloud logging #
    log_name = dict_obs["logger_name"]
    cloud_logging(log_name, dict_obs)
    return dict_obs

def hybrid_obs(dict_obs,static_param,project_id ):
    dict_obs.update(static_param)
    print("dict_obs is ", dict_obs)
    # cloud logging #
    log_name = static_param["logger_name"]
    cloud_logging(log_name, dict_obs)
    return dict_obs

def bq_to_gcs_obs(logger_name,dict_obs ):
    #dict_obs.update(static_param)
    print("dict_obs is ", dict_obs)
    # cloud logging #
    log_name = logger_name
    cloud_logging(log_name, dict_obs)
    return dict_obs

def gcs_to_bq_obs(logger_name,dict_obs ):
    #dict_obs.update(static_param)
    print("dict_obs is ", dict_obs)
    # cloud logging #
    log_name = logger_name
    cloud_logging(log_name, dict_obs)
    return dict_obs


def teradata_to_bq_obs(dynamic_param, static_param, gcp_conn_id, proj_id, bq_dbnme, bq_tbnme):
    dict_obs = dynamic_param
    dict_obs["target_type"] = "Table"
    dict_obs.update(static_param)
    print("dict_obs is ", dict_obs)
    # BQ table count #
    dest_count = bq_table_count(gcp_conn_id, proj_id, bq_dbnme, bq_tbnme)
    dict_obs["target_count"] = dest_count
    # cloud logging #
    log_name = static_param["logger_name"]
    cloud_logging(log_name, dict_obs)
    return dict_obs

def jdbc_to_bq_obs(dict_obs, gcp_conn_id, proj_id, bq_dbnme, bq_tbnme,target_load_count):
    dict_obs["target_type"] = "Table"
    print("dict_obs is ", dict_obs)
    # BQ table count #
    #dest_count = bq_table_count(gcp_conn_id, proj_id, bq_dbnme, bq_tbnme)
    dict_obs["target_count"] = target_load_count
    #dict_obs["target_count"] = dest_count
    print("dict_obs is ", dict_obs)
    #dict_obs["target_count"] = dest_count
    # cloud logging #
    log_name = dict_obs["logger_name"]
    cloud_logging(log_name, dict_obs)
    return dict_obs


def bq_table_count(gcp_conn_id, project_id, dataset_name, table_name):
    # extracting the destination count ##
    try:
        bq_hook = BigQueryHook(gcp_conn_id=gcp_conn_id)
        client = bigquery.Client(project=bq_hook._get_field("project"), credentials=bq_hook.get_credentials())
        query_job = client.query("select count(*) from " + project_id + "." + dataset_name + "." + table_name)
        print("query_job is ", query_job)
        results = list(query_job.result())
        counts = str(results[0]).split(',')
        final_count = re.findall('[0-9]+', str(counts[0]))
        total_count = final_count[0]
    except Exception as e:
        error_msg = str(e)
        print("error_msg : ", error_msg)
        logging.error(traceback.format_exc())
        total_count = "NA"
        pass
    return total_count


def teradata_table_count(database_name, table_name, host_name, user_name, password):
    # destination count #
    try:
        teradata_count = f"Select count(*) from {database_name}.{table_name} ;"
        print("count query", teradata_count)
        with teradatasql.connect(host=host_name, user=user_name, password=password) as connect:
            df = pd.read_sql(teradata_count, connect)
            total_count = str(df.iloc[0][-1])
            print("total :", total_count)
    except Exception as e:
        error_msg = str(e)
        print("error_msg : ", error_msg)
        logging.error(traceback.format_exc())
        total_count = "NA"
        pass
    return total_count


# logging obs parameters to cloud logging
def cloud_logging(logger_name, obs_val):
    logging_client = gcplogging.Client()
    logger = logging_client.logger(logger_name)
    logger.log_struct(obs_val)

def find_records_written(data):
    """Recursively search for the first occurrence of 'recordsWritten' in the dictionary."""
    # If the input is a dictionary
    print("Inside File records Written")
    if isinstance(data, dict):
        # Iterate over all key-value pairs
        for key, value in data.items():
            # If 'recordsWritten' is found, return its value
            if key == 'recordsWritten':
                print("recordsWritten found",value)
                return value
                break
            # Recursively search in nested dictionaries or lists
            result = find_records_written(value)
            if result is not None:
                return result
        # If the input is a list, check each item
    elif isinstance(data, list):
        for item in data:
            result = find_records_written(item)
            if result is not None:
                return result
    return None    
def get_records_inserted_from_bq_api(job_id,bq_hook,variables,projectTag,varMap,params):
    import requests
    if "projectId" in params["hook"]:
        project_id = varMap[params["hook"]["projectId"]]
    else:
        project_id = variables["projectId"]
    job_details_api ='https://bigquery.googleapis.com/bigquery/v2/projects/'+str(project_id)+'/jobs/'+str(job_id)

    print("fetching job details from api: ",job_details_api)
    source_credentials = bq_hook.get_credentials()

    from google.auth import impersonated_credentials

    auth_req = google.auth.transport.requests.Request()
    source_credentials.refresh(auth_req)

    job_details = requests.get(job_details_api,headers={'Authorization': f"Bearer {source_credentials.token}", "Content-Type": "application/json"})
    print("api response code: ",job_details)
    #print(str(job_details.text))
    job_details = json.loads(str(job_details.text))
    print("job_details is:",job_details)
    records_inserted = find_records_written(job_details)
    print("records_inserted is",records_inserted)

    return records_inserted


