"""
File Name: bq_transformer.py
Description: This python script is used to read and execute a SQL query (either from a file or inline in metadata) and load data from one bigquery table to another via the ingestion framework supporting multiple features and custom use cases.
"""
from airflow.providers.google.cloud.hooks.bigquery import BigQueryHook
from datetime import datetime
from airflow.providers.google.cloud.hooks.gcs import GCSHook
from datetime import date, timedelta, timezone, tzinfo
from airflow.models import TaskInstance
from airflow.exceptions import AirflowSkipException, AirflowFailException
from google.cloud import bigquery
from google.cloud import storage
import logging
import traceback
import re
import pytz
from airflow.models import Variable
from functools import reduce
import sys
import json
import pendulum
from airflow.models import XCom
from airflow.utils.session import create_session

"""
get the labels to be passed to the dataproc job
"""


def getLabelsDict(labelsList, dagId, run_id, task_id, composer_name):
    labels_dict = {
        "job_id": dagId.lower()[-63:],
        "job_type": "bq_transform",
        "run_id": re.sub(r'[^A-Za-z0-9 _-]+', '', run_id).lower()[-63:],
        "task_id": task_id.lower().replace('.', "")[-63:],
        "instance_name": composer_name.lower()
    }
    # if labelsList:
    #     if isinstance (labelsList ,list):
    #         for label in labelsList:
    #             key = label.split(':')[0]
    #             value = label.split(':')[1]
    #             labels_dict[key] = value
    #     else:
    #         key = labelsList.split(':')[0]
    #         value = labelsList.split(':')[1]
    #         labels_dict[key] = value

    return labels_dict


"""
get the parameters needed to determine the touch file path
"""


def get_touch_file_params(params, dagId, projectDetails, tz, context, bucketNameVars, variables, last_task,
                          ingestionPattern, opsgenie_priority, **kwargs):
    # get the variable map based on the project
    projectTag = projectDetails[0]
    projectSpace = projectDetails[2]
    varMap = variables[projectTag + "_vars"]

    # collect required details for touch file sensor
    time_delta = {'days': 0, 'hours': 0}
    if 'timeDelta' in params["hook"]:
        time_delta['days'] = int(params["hook"]['timeDelta']['days']) if 'days' in params["hook"]['timeDelta'] else 0
        time_delta['hours'] = int(params["hook"]['timeDelta']['hours']) if 'hours' in params["hook"]['timeDelta'] else 0
    process_dt = (datetime.now(tz) - timedelta(days=time_delta['days'])).strftime('%Y-%m-%d')
    process_hr = (datetime.now(tz) - timedelta(hours=time_delta['hours'])).strftime('%H')

    data_interval_start = context['data_interval_start'].in_timezone(tz)
    data_interval_end = context['data_interval_end'].in_timezone(tz)

    # Prev load date
    prev_load_date = (data_interval_start - timedelta(days=time_delta['days'])).strftime('%Y-%m-%d')
    # current load date logic
    load_date = (data_interval_end - timedelta(days=time_delta['days'])).strftime('%Y-%m-%d')
    load_date_modified = (data_interval_end - timedelta(days=time_delta['days'])).strftime('%Y%m%d')
    # date time logic - for hourly jobs Prev load date hour
    prev_load_datetime = (data_interval_start - timedelta(hours=time_delta['hours'])).strftime('%H')
    # current load date hour logic
    load_datetime = (data_interval_end - timedelta(hours=time_delta['hours'])).strftime('%H')
    load_datetime_modified = (data_interval_end - timedelta(hours=time_delta['hours'])).strftime('%H%M%S')

    touchFilePath = params['hook']['touchFilePath'].replace('{load_dt}', load_date).replace('{prev_load_date}',
                                                                                            prev_load_date).replace(
        '{load_datetime}', load_datetime).replace('{prev_load_datetime}', prev_load_datetime).replace('{process_dt}',
                                                                                                      process_dt).replace(
        '{process_hr}', process_hr).replace('{load_dt_modified}', load_date_modified).replace(
        '{load_datetime_modified}', load_datetime_modified)

    touchFile = reduce(lambda key, value: key.replace(*value), varMap.items(), touchFilePath)

    print(touchFile)

    context['ti'].xcom_push(key='touch_file', value=touchFile)


def sourceFilePartition(hook, queryParameters, dagId, variables, tz, opsgenie_priority, varMap, dict_obs, projectSpace,
                        logger_name, projectDetails, alertTeamName,sub_lob_alert):
    BASE_DIR = "/home/airflow/gcs/dags/" + projectSpace + "/beamx"
    sys.path.append(f"{BASE_DIR}/utils")
    import observability
    from ops_genie import send_alert_to_opsgenie

    tableID = hook["tableId"]
    partitiontableID = None
    targetTable = varMap[hook["projectId"]] + '.' + varMap[hook["datasetId"]] + '.' + tableID

    bq_hook = BigQueryHook(gcp_conn_id=variables[hook["gcp_conn_id"]])
    client = bigquery.Client(project=bq_hook._get_field("project"), credentials=bq_hook.get_credentials())

    try:
        table_details = client.get_table(targetTable)
        dict_obs["run_status"] = "SUCCESS"
        print("table details :", table_details)
    except Exception as e:
        dict_obs["end_time"] = datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S")
        dict_obs["run_status"] = "FAILURE"
        dict_obs["error_message"] = str(e)
        print("error_message : ", dict_obs["error_message"])
        logging.error(traceback.format_exc())

    if dict_obs["run_status"] == 'FAILURE':
        opsgenie_message = "Beamx|" + variables["environment"] + "|Failure|Failed to get partition table details|" + \
                           dict_obs['running_instance_id']
        opsgenie_description = "Failure | Failed to get partition table details during DAG execution|" + dict_obs[
            'running_instance_id']
        opsgenie_details = {"DAG ID": dagId, "Error Step": "BQ Transform", "Table Details": targetTable,
                            "Error Message": dict_obs["error_message"]}
        send_alert_to_opsgenie(opsgenie_message, opsgenie_description, opsgenie_details, opsgenie_priority,
                               projectDetails=projectDetails, alertTeamName=alertTeamName,sub_lob_alert=sub_lob_alert)
        print('Cannot get table details , please verify the table details... exiting')
        return {"dict_obs": dict_obs}

    if (table_details.time_partitioning == None):
        opsgenie_message = "Beamx|" + variables[
            "environment"] + "|Failure|Mentioned table is not a partitioned table|" + dict_obs['running_instance_id']
        opsgenie_description = "Failure | The table mentioned in the user metadata is not partitioned|" + dict_obs[
            'running_instance_id']
        opsgenie_details = {"DAG ID": dagId, "Error Step": "BQ Transform", "Table Details": targetTable,
                            "Error Message": "Mentioned table is not a partitioned table"}
        send_alert_to_opsgenie(opsgenie_message, opsgenie_description, opsgenie_details, opsgenie_priority,
                               projectDetails=projectDetails, alertTeamName=alertTeamName,sub_lob_alert=sub_lob_alert)
        error_message = 'Table you mentioned is not a partition table , please verify the table details... exiting'
        dict_obs["end_time"] = datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S")
        dict_obs["run_status"] = "FAILURE"
        dict_obs["error_message"] = str(error_message)
        print("error_message : ", error_message)
        logging.error(traceback.format_exc())
        return {"dict_obs": dict_obs}

    if (queryParameters["processDate"] != None and table_details.time_partitioning.type_ == "DAY"):
        partitionID = datetime.strptime(queryParameters['processDate'], '%Y-%m-%d').strftime('%Y%m%d')
        partitiontableID = tableID + "$" + partitionID
    elif (queryParameters["processDate"] != None and table_details.time_partitioning.type_ == "MONTH"):
        partitionID = datetime.strptime(queryParameters['processDate'], '%Y-%m-%d').strftime('%Y%m')
        partitiontableID = tableID + "$" + partitionID
    elif (queryParameters["processDate"] != None and table_details.time_partitioning.type_ == "YEAR"):
        partitionID = datetime.strptime(queryParameters['processDate'], '%Y-%m-%d').strftime('%Y')
        partitiontableID = tableID + "$" + partitionID
    elif (queryParameters["sourceFileName"] != None and queryParameters[
        'processDate'] != None and table_details.time_partitioning.type_ == "HOUR"):
        if re.search(r'\d\d\d\d.\d\d.\d\d_\d\d-\d\d-\d\d', queryParameters['sourceFileName']):
            matchObj = re.search(r'\d\d\d\d.\d\d.\d\d_\d\d-\d\d-\d\d', queryParameters['sourceFileName'])
            partitionID = datetime.strptime(matchObj.group(), '%Y.%m.%d_%H-%M-%S').strftime('%Y%m%d%H')
            partitiontableID = tableID + "$" + partitionID
        elif re.search(r'\d\d\d\d\d\d\d\d-\d\d\d\d\d\d', queryParameters['sourceFileName']):
            matchObj = re.search(r'\d\d\d\d\d\d\d\d-\d\d\d\d\d\d', queryParameters['sourceFileName'])
            partitionID = datetime.strptime(matchObj.group(), '%Y%m%d-%H%M%S').strftime('%Y%m%d%H')
            partitiontableID = tableID + "$" + partitionID
        elif re.search(r'\d\d\d\d\d\d\d\d\d\d\d\d\d\d', queryParameters['sourceFileName']):
            matchObj = re.search(r'\d\d\d\d\d\d\d\d\d\d\d\d\d\d', queryParameters['sourceFileName'])
            partitionID = datetime.strptime(matchObj.group(), '%Y%m%d%H%M%S').strftime('%Y%m%d%H')
            partitiontableID = tableID + "$" + partitionID
        elif re.search(r'\d\d\d\d\d\d\d\d_\d\d', queryParameters['sourceFileName']):
            matchObj = re.search(r'\d\d\d\d\d\d\d\d_\d\d', queryParameters['sourceFileName'])
            partitionID = datetime.strptime(matchObj.group(), '%Y%m%d_%H').strftime('%Y%m%d%H')
            partitiontableID = tableID + "$" + partitionID
        elif re.search(r'\d\d\d\d.\d\d.\d\d.\d\d', queryParameters['sourceFileName']):
            matchObj = re.search(r'\d\d\d\d.\d\d.\d\d.\d\d', queryParameters['sourceFileName'])
            partitionID = datetime.strptime(matchObj.group(), '%Y.%m.%d.%H').strftime('%Y%m%d%H')
            partitiontableID = tableID + "$" + partitionID

    if (queryParameters["processDate"] != None and hook["partitionDetails"]["partitionType"] == "None"):
        partitiontableID = tableID

    if (partitiontableID == None):
        opsgenie_message = "Beamx|" + variables["environment"] + "|Failure|Missing partition detail from filename|" + \
                           dict_obs['running_instance_id']
        opsgenie_description = "Failure |Partition details from filename could not be obtained|" + dict_obs[
            'running_instance_id']
        opsgenie_details = {"DAG ID": dagId, "Error Step": "BQ Transform", "Table Details": targetTable,
                            "Error Message": "Failure in getting partition detail from filename"}
        send_alert_to_opsgenie(opsgenie_message, opsgenie_description, opsgenie_details, opsgenie_priority,
                               projectDetails=projectDetails, alertTeamName=alertTeamName,sub_lob_alert=sub_lob_alert)
        error_message = 'Failure in getting partition detail from filename... exiting'
        dict_obs["end_time"] = datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S")
        dict_obs["run_status"] = "FAILURE"
        dict_obs["error_message"] = str(error_message)
        print("error_message : ", error_message)
        logging.error(traceback.format_exc())
        return {"dict_obs": dict_obs}
    else:
        tableID = partitiontableID
    print("final tableID is :", tableID)

    return {"tableId": tableID}


def columnPartition(hook, queryParameters, dagId, variables, tz, opsgenie_priority, varMap, sql_query, dict_obs,
                    projectSpace, logger_name, projectDetails, alertTeamName,sub_lob_alert):
    BASE_DIR = "/home/airflow/gcs/dags/" + projectSpace + "/beamx"
    sys.path.append(f"{BASE_DIR}/utils")
    import observability
    from ops_genie import send_alert_to_opsgenie

    bq_hook = BigQueryHook(gcp_conn_id=variables[hook["gcp_conn_id"]])
    client = bigquery.Client(project=bq_hook._get_field("project"), credentials=bq_hook.get_credentials())
    tableID = hook["tableId"]
    partitionDetails = hook["partitionDetails"]
    source_partition_column_transformation = partitionDetails["source_partition_column_transformation"]
    source_table = partitionDetails["sourceTable"]
    sourceTable = varMap[source_table.split('.', 2)[0]] + '.' + varMap[source_table.split('.', 2)[1]] + '.' + \
                  source_table.split('.', 2)[2]
    targetTable = varMap[hook["projectId"]] + '.' + varMap[hook["datasetId"]] + '.' + tableID
    try:
        table_details = client.get_table(targetTable)
        dict_obs["run_status"] = "SUCCESS"
    except Exception as e:
        dict_obs["end_time"] = datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S")
        dict_obs["run_status"] = "FAILURE"
        dict_obs["error_message"] = str(e)
        print("error_message : ", dict_obs["error_message"])
        logger_name = logger_name
        logging.error(traceback.format_exc())

    if dict_obs["run_status"] == 'FAILURE':
        opsgenie_message = "Beamx|" + variables["environment"] + "|Failure|Failed to get partition table details|" + \
                           dict_obs['running_instance_id']
        opsgenie_description = "Failure | Failed to get partition table details during DAG execution|" + dict_obs[
            'running_instance_id']
        opsgenie_details = {"DAG ID": dagId, "Error Step": "BQ Transform", "Table Details": targetTable,
                            "Error Message": dict_obs["error_message"]}
        send_alert_to_opsgenie(opsgenie_message, opsgenie_description, opsgenie_details, opsgenie_priority,
                               projectDetails=projectDetails, alertTeamName=alertTeamName,sub_lob_alert=sub_lob_alert)
        return {"dict_obs": dict_obs}

    if (table_details.time_partitioning == None or table_details.time_partitioning.field == None):
        opsgenie_message = "Beamx|" + variables["environment"] + "|Failure|Mismatch in partition Type|" + dict_obs[
            'running_instance_id']
        opsgenie_description = "Failure | Partition Type mentioned in metadata does not match with the target table|" + \
                               dict_obs['running_instance_id']
        opsgenie_details = {"DAG ID": dagId, "Error Step": "BQ Transform", "Table Details": tableID,
                            "Error Message": "Partition Type mentioned in metadata does not match with the target table"}
        send_alert_to_opsgenie(opsgenie_message, opsgenie_description, opsgenie_details, opsgenie_priority,
                               projectDetails=projectDetails, alertTeamName=alertTeamName,sub_lob_alert=sub_lob_alert)
        error_message = 'Partition Type mentioned in metadata does not match with the target table , please verify the table details... exiting'
        dict_obs["end_time"] = datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S")
        dict_obs["run_status"] = "FAILURE"
        dict_obs["error_message"] = error_message
        print("error_message : ", error_message)
        logging.error(traceback.format_exc())
        return {"dict_obs": dict_obs}

    if (partitionDetails[
        "partitionType"] == "truncate with column partition" and table_details.time_partitioning.type_ == "DAY"):
        delete_sql = "DELETE FROM " + targetTable + " WHERE " + table_details.time_partitioning.field + " IN (SELECT distinct " + source_partition_column_transformation + " FROM " + sourceTable + " WHERE " + source_partition_column_transformation + " is not null )"
    elif (partitionDetails[
              "partitionType"] == "truncate with column partition" and table_details.time_partitioning.type_ == "MONTH"):
        delete_sql = "DELETE FROM " + targetTable + " WHERE DATE_TRUNC(" + table_details.time_partitioning.field + ",month) IN (SELECT distinct DATE_TRUNC(" + source_partition_column_transformation + ",month) FROM " + sourceTable + " WHERE " + source_partition_column_transformation + " is not null )"
    elif (partitionDetails[
              "partitionType"] == "truncate with column partition" and table_details.time_partitioning.type_ == "YEAR"):
        delete_sql = "DELETE FROM " + targetTable + " WHERE DATE_TRUNC(" + table_details.time_partitioning.field + ",year) IN (SELECT distinct DATE_TRUNC(" + source_partition_column_transformation + ",year) FROM " + sourceTable + " WHERE " + source_partition_column_transformation + " is not null )"
    elif (partitionDetails[
              "partitionType"] == "truncate with column partition" and table_details.time_partitioning.type_ == "HOUR"):
        delete_sql = "DELETE FROM " + targetTable + " WHERE DATE_TRUNC(" + table_details.time_partitioning.field + ",hour) IN (SELECT distinct DATE_TRUNC(" + source_partition_column_transformation + ",hour) FROM " + sourceTable + " WHERE " + source_partition_column_transformation + " is not null )"

    sql_query = f"""
    BEGIN
    BEGIN TRANSACTION ;
    {delete_sql};
    INSERT INTO {targetTable}
    {sql_query}
    COMMIT TRANSACTION ;
    END
    """
    return {"sql_query": sql_query}

def check_upstream_task_status(upstreamTaskId, dag_run, **kwargs):
    upstream_task_id = upstreamTaskId
    dag_run = dag_run
    all_task_instances = dag_run.get_task_instances()

    upstream_task_instances = [ti for ti in all_task_instances if ti.task_id == upstream_task_id]
    upstream_task_states = set()
    for upstream_ti in upstream_task_instances:
        upstream_task_states.add(upstream_ti.state)

    if "failed" in upstream_task_states:
        return "failed"
    elif "skipped" in upstream_task_states:
        return "skipped"  
    elif "success" in upstream_task_states:
        return "success"
    else:
        return None
        
def partitiontime_columnPartition(hook, bq_hook, queryParameters, dagId, variables, tz, opsgenie_priority, varMap,
                                  sql_query, dict_obs, projectSpace, logger_name, projectDetails, alertTeamName,sub_lob_alert):
    BASE_DIR = "/home/airflow/gcs/dags/" + projectSpace + "/beamx"
    sys.path.append(f"{BASE_DIR}/utils")
    import observability
    from ops_genie import send_alert_to_opsgenie

    partitionDetails = hook["partitionDetails"]
    source_partition_column_transformation = partitionDetails["source_partition_column_transformation"]
    source_table = partitionDetails["sourceTable"]
    sourceTable = varMap[source_table.split('.', 2)[0]] + '.' + varMap[source_table.split('.', 2)[1]] + '.' + \
                  source_table.split('.', 2)[2]
    target_table = partitionDetails["targetTable"]
    targetTable = varMap[target_table.split('.', 2)[0]] + '.' + varMap[target_table.split('.', 2)[1]] + '.' + \
                  target_table.split('.', 2)[2]
    tableID = targetTable
    client = bigquery.Client(project=bq_hook._get_field("project"), credentials=bq_hook.get_credentials())
    try:
        table_details = client.get_table(targetTable)
        dict_obs["run_status"] = "SUCCESS"
        print("table_details : ", table_details)
    except Exception as e:
        dict_obs["end_time"] = datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S")
        dict_obs["run_status"] = "FAILURE"
        dict_obs["error_message"] = str(e)
        print("error_message : ", dict_obs["error_message"])
        logging.error(traceback.format_exc())

    if dict_obs["run_status"] == 'FAILURE':
        opsgenie_message = "Beamx|" + variables["environment"] + "|Failure|Failed to get partition table details|" + \
                           dict_obs['running_instance_id']
        opsgenie_description = "Failure | Failed to get partition table details during DAG execution|" + dict_obs[
            'running_instance_id']
        opsgenie_details = {"DAG ID": dagId, "Error Step": "BQ Transform", "Table Details": targetTable,
                            "Error Message": dict_obs["error_message"]}
        send_alert_to_opsgenie(opsgenie_message, opsgenie_description, opsgenie_details, opsgenie_priority,
                               projectDetails=projectDetails, alertTeamName=alertTeamName,sub_lob_alert=sub_lob_alert)
        print('Cannot get table details , please verify the table details... exiting')
        return {"dict_obs": dict_obs}

    if (table_details.time_partitioning == None or table_details.time_partitioning.field != None):
        opsgenie_message = "Beamx|" + variables["environment"] + "|Failure|Mismatch in partition Type|" + dict_obs[
            'running_instance_id']
        opsgenie_description = "Failure | Partition Type mentioned in metadata does not match with the target table|" + \
                               dict_obs['running_instance_id']
        opsgenie_details = {"DAG ID": dagId, "Error Step": "BQ Transform", "Table Details": tableID,
                            "Error Message": "Partition Type mentioned in metadata does not match with the target table"}
        send_alert_to_opsgenie(opsgenie_message, opsgenie_description, opsgenie_details, opsgenie_priority,
                               projectDetails=projectDetails, alertTeamName=alertTeamName,sub_lob_alert=sub_lob_alert)
        sys.tracebacklimit = 0
        error_message = 'Partition Type mentioned in metadata does not match with the target table , please verify the table details... exiting'
        dict_obs["end_time"] = datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S")
        dict_obs["run_status"] = "FAILURE"
        dict_obs["error_message"] = error_message
        print("error_message : ", error_message)
        logging.error(traceback.format_exc())
        return {"dict_obs": dict_obs}

    if (partitionDetails[
        "partitionType"] == "truncate with partitiontime column" and table_details.time_partitioning.type_ == "YEAR"):
        delete_sql = "DELETE FROM " + targetTable + " WHERE DATE_TRUNC(_PARTITIONTIME,year) IN (SELECT distinct (DATE_TRUNC(" + source_partition_column_transformation + ",year)) FROM " + sourceTable + " WHERE " + source_partition_column_transformation + " is not null )"
    elif (partitionDetails[
              "partitionType"] == "truncate with partitiontime column" and table_details.time_partitioning.type_ == "MONTH"):
        delete_sql = "DELETE FROM " + targetTable + " WHERE DATE_TRUNC(_PARTITIONTIME,month) IN (SELECT distinct (DATE_TRUNC(" + source_partition_column_transformation + ",month)) FROM " + sourceTable + " WHERE " + source_partition_column_transformation + " is not null )"
    elif (partitionDetails[
              "partitionType"] == "truncate with partitiontime column" and table_details.time_partitioning.type_ == "DAY"):
        delete_sql = "DELETE FROM " + targetTable + " WHERE DATE(_PARTITIONTIME) IN (SELECT distinct (" + source_partition_column_transformation + ") FROM " + sourceTable + " WHERE " + source_partition_column_transformation + " is not null )"
    elif (partitionDetails[
              "partitionType"] == "truncate with partitiontime column" and table_details.time_partitioning.type_ == "HOUR"):
        delete_sql = "DELETE FROM " + targetTable + " WHERE DATE_TRUNC(_PARTITIONTIME,hour) IN (SELECT distinct (DATE_TRUNC(" + source_partition_column_transformation + ",hour)) FROM " + sourceTable + " WHERE " + source_partition_column_transformation + " is not null )"

    sql_query = f"""
    BEGIN
    BEGIN TRANSACTION ;
    {delete_sql};
    {sql_query}
    COMMIT TRANSACTION ;
    END
    """

    return {"sql_query": sql_query}


"""
get the job configuration needed to insert data to bigquery table using bigquery hook's insert_job method
"""


def getinsertJobConfiguration(params, bq_hook, sql_query, dict_obs, queryParameters, dagId, variables, tz,
                              opsgenie_priority, varMap, projectSpace, logger_name, projectDetails, custom_labels,
                              run_id, task_id, composer_name, alertTeamName,sub_lob_alert):
    if "datasetId" in params["hook"] and "tableId" in params["hook"]:
        tableId = params["hook"]["tableId"]
    # check for partition type
    partitionType = None
    if "partitionDetails" in params["hook"]:
        if "partitionType" in params["hook"]["partitionDetails"]:
            partitionType = params["hook"]["partitionDetails"]["partitionType"]
            if partitionType == "source file":
                result = sourceFilePartition(params["hook"], queryParameters, dagId, variables, tz, opsgenie_priority,
                                             varMap, dict_obs, projectSpace, logger_name, projectDetails, alertTeamName,sub_lob_alert)
                if "dict_obs" in result:
                    return {"dict_obs": result["dict_obs"]}
                else:
                    tableId = result["tableId"]
            elif partitionType == "truncate with column partition":
                result = columnPartition(params["hook"], queryParameters, dagId, variables, tz, opsgenie_priority,
                                         varMap, sql_query, dict_obs, projectSpace, logger_name, projectDetails,
                                         alertTeamName,sub_lob_alert)
                if "dict_obs" in result:
                    return {"dict_obs": result["dict_obs"]}
                else:
                    sql_query = result["sql_query"]
            elif partitionType == "truncate with partitiontime column":
                result = partitiontime_columnPartition(params["hook"], bq_hook, queryParameters, dagId, variables, tz,
                                                       opsgenie_priority, varMap, sql_query, dict_obs, projectSpace,
                                                       logger_name, projectDetails, alertTeamName,sub_lob_alert)
                if "dict_obs" in result:
                    return {"dict_obs": result["dict_obs"]}
                else:
                    sql_query = result["sql_query"]

    labels_dict = getLabelsDict(custom_labels, dagId, run_id, task_id, composer_name)
    configuration = {
        "jobType": "QUERY",
        "query": {
            "query": sql_query,
        },
        "labels": labels_dict
    }
    for key, value in params["hook"].items():
        if key not in (
                'query', 'sqlFile', 'projectId', 'datasetId', 'queryParameters', 'tableId', 'gcp_conn_id',
                'writeDisposition',
                'partitionDetails', 'audit_flag', 'target_table'):
            if value.lower() == 'true':
                configuration["query"][key] = True
            if value.lower() == 'false':
                configuration["query"][key] = False
            elif value.isnumeric():
                configuration["query"][key] = int(value)
            else:
                configuration["query"][key] = value
    if partitionType == None or partitionType == "source file":
        if "datasetId" in params["hook"] and "tableId" in params["hook"]:
            if "projectId" in params["hook"]:
                project_id = varMap[params["hook"]["projectId"]]
            else:
                project_id = variables["projectId"]
            configuration["query"]["destinationTable"] = {
                "projectId": project_id,
                "datasetId": varMap[params["hook"]["datasetId"]],
                "tableId": tableId
            }
        if "writeDisposition" in params["hook"]:
            configuration["query"]["writeDisposition"] = params["hook"]["writeDisposition"]
    userInput = {"date from filename": "processDate", "time from filename": "processTime",
                 "name from filename": "sourceFileName", "previous load date": "prev_load_date",
                 "load date": "load_date",
                 "current date": "current_date", "previous load datetime": "prev_load_datetime",
                 "load datetime": "load_datetime", "current datetime": "current_datetime", "dag run id": "dag_run_id"}
    print("queryParameters : ", queryParameters)
    if "queryParameters" in params["hook"]:
        for elem in params["hook"]["queryParameters"]:
            if elem["parameterValue"]["value"] in userInput:
                elem["parameterValue"]["value"] = userInput[elem["parameterValue"]["value"]]
        for elem in params["hook"]["queryParameters"]:
            if elem["parameterValue"]["value"] in queryParameters:
                elem["parameterValue"]["value"] = queryParameters[elem["parameterValue"]["value"]]
        configuration["query"]["queryParameters"] = params["hook"]["queryParameters"]
    
    if "queryParameters" in params["hook"]:
        for param in configuration['query']['queryParameters']:
            placeholder = f"@{param['name']}" 
            value = param['parameterValue']['value']
            resolved_sql_query = sql_query.replace(placeholder, value)
            logging.info(f"resolved sql: {resolved_sql_query}")

    print(configuration)

    return {"configuration": configuration}


def collectContext(context, dict_obs, logger_name, tz, upstreamTaskId, ingestionPattern):
    queryParameters = context['ti'].xcom_pull(key='queryParameters')
    if queryParameters is None:
        queryParameters = {"sourceFileName": None, "processTime": None, "processDate": None}
    print("process date: ", queryParameters['processDate'], ", process time: ", queryParameters['processTime'],
                  ", source filename: ", queryParameters['sourceFileName'])

    ## Prev load date
    data_interval_start = context['data_interval_start'].in_timezone(tz)
    data_interval_end = context['data_interval_end'].in_timezone(tz)
    queryParameters["prev_load_date"] = data_interval_start.to_datetime_string()[:10]
    ## current load date logic
    ## load_date = str(context['data_interval_end'])[:10]
    queryParameters["load_date"] = data_interval_end.to_datetime_string()[:10]
    ## current date logic
    queryParameters["current_date"] = str(datetime.now(tz))[:10]

    ## date time logic - for hourly jobs Prev load date hour
    ## prev_load_datetime = str(context['data_interval_start'])[11:13]
    queryParameters["prev_load_datetime"] = data_interval_start.to_datetime_string()[11:13]

    ## current load date hour logic
    ## load_datetime = str(context['data_interval_end'])[11:13]
    queryParameters["load_datetime"] = data_interval_end.to_datetime_string()[11:13]
    ## current date hour logic
    queryParameters["current_datetime"] = str(datetime.now(tz))[11:13]
    queryParameters["dag_run_id"] = dict_obs['running_instance_id']
    print("Prev_load_date,load_date,current_date:", queryParameters['prev_load_date'], queryParameters['load_date'],
          queryParameters['current_date'])
    print("Prev_load_date_time,load_date_time,current_date_time:", queryParameters['prev_load_datetime'],
          queryParameters['load_datetime'], queryParameters['current_datetime'])
    print("queryParameters dag_run_id:", queryParameters["dag_run_id"])
    print("dag run id", dict_obs['running_instance_id'])
    return queryParameters


def getSQL(params, bucketNameVars, varMap, variables):
    if "sqlFile" in params["hook"]:
        gcs_hook = GCSHook(gcp_conn_id=variables['gcp_conn_id'])
        sql_query = gcs_hook.download((bucketNameVars["SQL_BUCKET"]).split("/")[-1], params['hook']['sqlFile']).decode(
            "utf-8")
    elif "query" in params["hook"]:
        sql_query = params["hook"]["query"]
    sql_query = reduce(lambda key, value: key.replace(*value), varMap.items(), sql_query)
    print("SQL query to run :", sql_query)

    return sql_query


"""
This function gets the static and the dynamic params to send to observability logs. The static params come from metadata and the dynamic params are calculated in this script at run time.
"""
def getObsParams(context, params, varMap, dagId, tz, dict_obs, projectTag):
    dict_obs["start_time"] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
    dict_obs["error_message"] = "NA"
    # dict_obs["inserted_timestamp"] = "NA"
    dict_obs["process_date"] = str(datetime.now(tz).strftime('%Y-%m-%d'))
    data_interval_endtime = context['data_interval_end'].in_timezone(tz)
    # dict_obs["run_date"] = str(datetime.now(tz).strftime('%Y%m%d'))
    # dict_obs["run_day"] = str(datetime.now(tz).strftime('%A'))
    # dict_obs["run_hour"] = str(datetime.now(tz).strftime("%H:%M:%S"))
    dict_obs["run_date"] = str(data_interval_endtime.strftime('%Y%m%d'))
    dict_obs["run_day"] = str(data_interval_endtime.strftime('%A'))
    # dict_obs["run_hour"] = str(datetime.now(tz).strftime("%H:%M:%S"))
    # run_hour = context['data_interval_end']
    dict_obs["run_hour"] = str(data_interval_endtime.strftime("%H:%M:%S"))
    # run_hour = context['data_interval_end']
    # dict_obs["run_hour"] = str(run_hour.in_timezone(tz).strftime("%H:%M:%S"))
    dict_obs["source_count"] = "0"
    dict_obs["target_count"] = "0"
    dict_obs["source_type"] = "Table"
    dict_obs["target_type"] = "Table"
    dict_obs["process_name"] = dagId
    gcp_project = projectTag + "_project_id"
    dict_obs["gcp_project"] = varMap[gcp_project]
    dict_obs["log_file"] = varMap['log_file']
    dict_obs["process_end_time"] = "NA"

    return dict_obs


tz = pendulum.timezone("EST")

def audit_log(params, variables, audit_logs):
    if "error_messages" not in audit_logs:
        audit_logs['error_messages'] = "\"" + "\""

    if "file_record_count" not in audit_logs:
        audit_logs['file_record_count'] = None

    if "footer_record_count" not in audit_logs:
        audit_logs['footer_record_count'] = None

    # application_id = str(datetime.now(tz).strftime("%Y%m%d%H%M%S"))
    application_id = audit_logs['running_instance_id']

    if 'error_msg' in audit_logs:
        error_msg = audit_logs['error_msg']
    elif 'error_message' in audit_logs:
        error_msg = audit_logs['error_message']

    if 'keyvalue' not in audit_logs:
        audit_logs['keyvalue'] = 'NA'
    if 'scheduler' not in audit_logs:
        audit_logs['scheduler'] = 'airflow'
    if 'source_environment' not in audit_logs:
        audit_logs['source_environment'] = 'NA'
    if 'target_environment' not in audit_logs:
        audit_logs['target_environment'] = 'NA'
    if 'source_servername' not in audit_logs:
        audit_logs['source_servername'] = 'NA'
    if 'target_servername' not in audit_logs:
        audit_logs['target_servername'] = 'NA'
    if 'source_type' not in audit_logs:
        audit_logs['source_type'] = 'Table'
    if 'target_type' not in audit_logs:
        audit_logs['target_type'] = 'Table'
    if 'bad_records_count' not in audit_logs:
        audit_logs['bad_records_count'] = 'NA'
    if 'footer_record' not in audit_logs:
        audit_logs['footer_record'] = 'NA'
    if 'header_record' not in audit_logs:
        audit_logs['header_record'] = 'NA'
    if 'footer_cntrl_record' not in audit_logs:
        audit_logs['footer_cntrl_record'] = 'NA'
    if 'header_cntrl_record' not in audit_logs:
        audit_logs['header_cntrl_record'] = 'NA'
    if 'source_count' not in audit_logs:
        audit_logs['source_count'] = 'NA'

    insert_query = """
            Insert into {0}.{1}.audit
            SELECT
            '{2}'   AS application_id,
            '{3}'   AS end_time,
            '{4}'   AS error_msg,
            '{0}'   AS gcp_project,
            '{5}'   AS inserted_timestamp,
            '{6}'   AS keyvalue,
            '{7}'   AS logger_name,
            '{8}'   AS process_date,
            '{9}'   AS process_name,
            '{10}'  AS project_name,
            '{11}'  AS run_date,
            '{12}'  AS run_day,
            '{13}'  AS run_hour,
            '{14}'  AS run_status,
            '{15}'  AS scheduler,
            '{16}'  AS source_environment,
            r'''{17}'''  AS source_name,
            '{18}'  AS source_servername,
            '{19}'  AS source_type,
            '{20}'  AS start_time,
            '{21}'  AS sub_process,
            '{22}'  AS system_name,
            '{23}'  AS target_count,
            '{24}'  AS target_environment,
            r'''{25}'''  AS target_name,
            '{26}'  AS target_servername,
            '{27}'  AS target_type,
            '{28}'  AS td_load_completion_timestamp,
            '{29}'  AS tool_name,
            r'''{30}'''  AS sql_query,
            '{31}' as bad_records_count,
            r'''{32}'''  AS footer,
            r'''{33}'''  AS header,
            {34}  AS errors,
            '{35}'  AS file_record_count,
            '{36}'  AS footer_record_count,
            '{37}'  AS footer_cntrl_record,
            '{38}'  AS header_cntrl_record,
            '{39}' as source_count

    """.format(audit_logs['project_id'], audit_logs['bq_dataset'], application_id, audit_logs['end_time'], error_msg,
               audit_logs['inserted_timestamp'], audit_logs['keyvalue'], audit_logs['logger_name'],
               audit_logs['process_date'], audit_logs['process_name'], audit_logs['project_name'],
               audit_logs['run_date'], audit_logs['run_day'], audit_logs['run_hour'], audit_logs['run_status'],
               audit_logs['scheduler'], audit_logs['source_environment'], audit_logs['source_name'],
               audit_logs['source_servername'], audit_logs['source_type'], audit_logs['start_time'],
               audit_logs['sub_process'], audit_logs['system_name'], audit_logs['target_count'],
               audit_logs['target_environment'], audit_logs['target_name'], audit_logs['target_servername'],
               audit_logs['target_type'], audit_logs['td_load_completion_timestamp'], audit_logs['tool_name'],
               audit_logs['sql_query'], audit_logs['bad_records_count'], audit_logs['footer_record'],
               audit_logs['header_record'],
               audit_logs['error_messages'], audit_logs['file_record_count'], audit_logs['footer_record_count'],
               audit_logs['footer_cntrl_record'], audit_logs['header_cntrl_record'], audit_logs['source_count'])
    return insert_query

"""
This function calls audit_log method which inserts a row with the necessary details in audit table for each run
"""


def auditTableEntry(context, params, variables, varMap, audit_logs, dagId, jdbc_check_load_status, projectSpace,
                    opsgenie_priority, final_target_table, ingestionPattern, projectDetails, sql_query, alertTeamName,sub_lob_alert):
    # import the necessary modules
    BASE_DIR = "/home/airflow/gcs/dags/" + projectSpace + "/beamx"
    sys.path.append(f"{BASE_DIR}/utils")
    from ops_genie import send_alert_to_opsgenie
    dag_run_id = context['dag_run'].run_id
    if dag_run_id:
        process_run_id = f"{dagId}_" + str(dag_run_id)
        running_instance_id = dag_run_id
    else:
        process_run_id = f"{dagId}_" + str(datetime.now(tz).strftime("%Y%m%d%H%M%S"))
        running_instance_id = process_run_id
    print("process_run_id is: ", process_run_id)
    if "projectId" in params["hook"]:
        project_id = reduce(lambda key, value: key.replace(*value), varMap.items(), params["hook"]["projectId"])
    else:
        project_id = variables["projectId"]
    audit_db_td_bq = variables["audit_db_td_bq"]

    td_load_completion_timestamp = context['ti'].xcom_pull(key='td_load_completion_ts',
                                                           task_ids='load_status') if jdbc_check_load_status == "yes" else "None"
    audit_logs["target_name"] = final_target_table
    audit_logs["td_load_completion_timestamp"] = td_load_completion_timestamp
    audit_logs['project_id'] = project_id
    audit_logs['bq_dataset'] = audit_db_td_bq
    audit_logs['running_instance_id'] = process_run_id
    audit_logs['sql_query'] = "".join(sql_query.splitlines())
    print("SQL Query is: ", audit_logs['sql_query'])

    try:
        result_query = audit_log(params, variables, audit_logs)
        return result_query
    except Exception as e:
        error_msg = str(e)
        sys.tracebacklimit = 0
        logging.error(traceback.format_exc())
        task_instance = context['task_instance']
        opsgenie_message = "Beamx|" + variables[
            "environment"] + "|Failure|" + task_instance.task_id + "|" + running_instance_id
        opsgenie_description = f"Failure|Insert into jdbc audit table {audit_db_td_bq}.audit failed. Please refer values in {audit_logs}|" + running_instance_id
        opsgenie_details = {"DAG ID": dagId, "Error Step": "Insert into audit table failed", "Error Message": error_msg}
        send_alert_to_opsgenie(opsgenie_message, opsgenie_description, opsgenie_details, opsgenie_priority,
                               projectDetails=projectDetails, alertTeamName=alertTeamName,sub_lob_alert=sub_lob_alert)
        return None


"""
function to check prerequisistes and fetch job configuration for bq transform
"""
def preChecksAndJobConfiguration(params, dagId, projectDetails, tz, context, bucketNameVars, variables, dict_obs,
                                 last_task, ingestionPattern, opsgenie_priority, last_task_num, superGroupId,
                                 custom_labels, alertTeamName,sub_lob_alert, taskType):
    # get the variable map based on the project
    projectTag = projectDetails[0]
    projectSpace = projectDetails[2]
    varMap = variables[projectTag + "_vars"]

    # import the necessary modules
    BASE_DIR = "/home/airflow/gcs/dags/" + projectSpace + "/beamx"
    sys.path.append(f"{BASE_DIR}/utils")
    import observability
    from ops_genie import send_alert_to_opsgenie

    # get task instance details
    task_instance = context['task_instance']
    if ingestionPattern == 'multi_file_ingestion':
        last_task_name = last_task
        last_task = []
        last_task_num = last_task_num  # last task number
        group_id = superGroupId
        for last in last_task_name:
            last_task = []
            last_task.append(str(group_id + "." + last + '_' + str(last_task_num)))
    print("last_task is ", last_task)

    # create connection to bq using bq hook
    bq_hook = BigQueryHook(gcp_conn_id=variables[params['hook']["gcp_conn_id"]])

    ##### get observability details #####
    # get Static obs
    dict_obs_static = str(params["obs"])
    dict_obs_static = json.loads(
        (reduce(lambda key, value: key.replace(*value), varMap.items(), dict_obs_static)).replace("'", '"'))
    dict_obs.update(dict_obs_static)
    # get Dynamic obs
    dict_obs = getObsParams(context, params, varMap, dagId, tz, dict_obs, projectTag)
    dict_obs["process_date"] = str(datetime.now(tz).strftime('%Y-%m-%d'))
    logger_name = params["obs"]["logger_name"]

    # get the current task id and the upstream task id, if applicable
    current_task = context['task'].task_id
    run_id = context['dag_run'].run_id
    import os
    composer_name = os.getenv('COMPOSER_ENVIRONMENT')
    try:
        upstreamTaskId = next(iter(context['task'].upstream_task_ids))
        print("upstream task is :", upstreamTaskId)
    except Exception as e:
        upstreamTaskId = None
    
    if "nos_td_to_bq" in ingestionPattern:
        # check the status of previous task and skip if it was  not succesful
        gcsToBqLoadStatus = context['ti'].xcom_pull(task_ids=upstreamTaskId, key='gcs_to_bq_status_nos')
        if (gcsToBqLoadStatus is not None):
            prevTaskRunState = gcsToBqLoadStatus
        else:
            prevTaskRunState = (
                TaskInstance(context['dag'].get_task(upstreamTaskId), context['logical_date'])).current_state()

        print("upstream task run status is :", prevTaskRunState)
        if prevTaskRunState.lower() != 'success':
            print("skipping the current task as one or more upstream tasks either failed/skipped")
            dict_obs["run_status"] = "SKIPPED"
            dict_obs["error_message"] = "one or more upstream tasks either failed/skipped"
            try:
                ## capturing process end time for the last task of dag##
                dict_obs["process_end_time"] = "NA"
                dict_obs["inserted_timestamp"] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
                observability.ingestion_obs(dict_obs, logger_name)
            except Exception as e:
                error_message = str(e)
                print("error_message : ", error_message)
                logging.error(traceback.format_exc())
                print("Could not send observability log")
            return {"dict_obs": dict_obs, 'run_status': 'skipped'}


    #if "file_ingestion" in ingestionPattern:
    #    # check the status of previous task and skip if it was  not succesful
    #    gcsToBqLoadStatus = context['ti'].xcom_pull(task_ids=upstreamTaskId, key='load_status')
    #    if (gcsToBqLoadStatus is not None):
    #        prevTaskRunState = gcsToBqLoadStatus
    #    else:
    #        prevTaskRunState = (
    #            TaskInstance(context['dag'].get_task(upstreamTaskId), context['logical_date'])).current_state()
    #    if prevTaskRunState is None:
    #        dag_run = context['dag_run']
    #        prevTaskRunState = check_upstream_task_status(upstreamTaskId,dag_run)
    #    print("upstream task run status is :", prevTaskRunState)
    #    if prevTaskRunState.lower() != 'success':
    #        print("skipping the current task as one or more upstream tasks either failed/skipped")
    #        dict_obs["run_status"] = "SKIPPED"
    #        dict_obs["error_message"] = "one or more upstream tasks either failed/skipped"
    #        try:
    #            ## capturing process end time for the last task of dag##
    #            if current_task in last_task:
    #                dict_obs["process_end_time"] = datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S")
    #            else:
    #                print(" current task not in last task ")
    #                print(" current task is ", current_task)
    #                print(" last task is ", last_task)
    #                dict_obs["process_end_time"] = "NA"
    #            dict_obs["inserted_timestamp"] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
    #            observability.ingestion_obs(dict_obs, logger_name)
    #        except Exception as e:
    #            error_message = str(e)
    #            print("error_message : ", error_message)
    #            logging.error(traceback.format_exc())
    #            print("Could not send observability log")
    #        return {"dict_obs": dict_obs, 'run_status': 'skipped'}


    # collect Context
    queryParameters = collectContext(context, dict_obs, logger_name, tz, upstreamTaskId, ingestionPattern)
    if "processDate" in queryParameters:
        if queryParameters["processDate"] != None:
            # dict_obs["process_date"] = str(date.today().strftime('%Y-%m-%d'))
            dict_obs["process_date"] = str(datetime.now(tz).strftime('%Y-%m-%d'))
            dict_obs["run_date"] = datetime.strptime(queryParameters['processDate'], '%Y-%m-%d').strftime('%Y%m%d')
            dict_obs["run_day"] = datetime.strptime(queryParameters['processDate'], '%Y-%m-%d').strftime('%A')
    if "processTime" in queryParameters:
        if queryParameters["processTime"] != None:
            dict_obs["run_hour"] = str(
                datetime.strptime(queryParameters["processTime"], '%H:%M:%S').strftime("%H:%M:%S"))
    # get SQL
    try:
        sql_query = getSQL(params, bucketNameVars, varMap, variables)
        run_status = "SUCCESS"
        error_message = "None"
    except Exception as e:
        error_message = str(e)
        run_status = "FAILURE"
        logging.error(traceback.format_exc())
        # opsgenie call
        opsgenie_message = "Beamx|" + variables["environment"] + "|Failure|" + task_instance.task_id + "|" + dict_obs[
            'running_instance_id']
        opsgenie_description = "Failure | Failed to get sql input|" + dict_obs['running_instance_id']
        if "sqlFile" in params["hook"]:
            opsgenie_details = {"DAG ID": dagId, "Error Step": "BQ Transform",
                                "Failed SQL file": params["hook"]["sqlFile"], "Error Message": error_message}
        elif "query" in params["hook"]:
            opsgenie_details = {"DAG ID": dagId, "Error Step": "BQ Transform",
                                "Failed SQL query": params["hook"]["query"], "Error Message": error_message}
        send_alert_to_opsgenie(opsgenie_message, opsgenie_description, opsgenie_details, opsgenie_priority,
                               projectDetails=projectDetails, alertTeamName=alertTeamName,sub_lob_alert=sub_lob_alert)
        logging.error('Failure in getting the SQL query... exiting')

    if run_status == 'FAILURE':
        dict_obs["run_status"] = run_status
        dict_obs["end_time"] = datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S")
        dict_obs["error_message"] = error_message
        try:
            logger_name = params["obs"]["logger_name"]
            ## capturing process end time for the last task of dag##
            if last_task is not None and current_task in last_task:
                dict_obs["process_end_time"] = datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S")
            else:
                print(" current task not in last task ")
                print(" current task is ", current_task)
                print(" last task is ", last_task)
                dict_obs["process_end_time"] = "NA"
            dict_obs["inserted_timestamp"] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
            observability.ingestion_obs(dict_obs, logger_name)
        except Exception as e:
            error_message = str(e)
            print("error_message : ", error_message)
            logging.error(traceback.format_exc())
            print("Could not send observability log")
        return {"dict_obs": dict_obs, "run_status": "failure"}

    # get insert job configuration for bq load
    try:
        resultConfiguration = getinsertJobConfiguration(params, bq_hook, sql_query, dict_obs, queryParameters, dagId,
                                                        variables, tz, opsgenie_priority, varMap, projectSpace,
                                                        logger_name, projectDetails, custom_labels, run_id,
                                                        current_task, composer_name, alertTeamName,sub_lob_alert)
        run_status = "SUCCESS"
        error_message = "None"
    except Exception as e:
        run_status = "FAILURE"
        error_message = str(e)
        print("error_message : ", error_message)
        logging.error(traceback.format_exc())
        print("Could not get configuration")

        # opsgenie call
        opsgenie_message = "Beamx|" + variables["environment"] + "|Failure|" + task_instance.task_id + "|" + dict_obs[
            'running_instance_id']
        opsgenie_description = "Failure | Building configuration FAILURE|" + dict_obs['running_instance_id']
        opsgenie_details = {"DAG ID": dagId, "Error Step": "BQ Transform", "Error Message": error_message}
        send_alert_to_opsgenie(opsgenie_message, opsgenie_description, opsgenie_details, opsgenie_priority,
                               projectDetails=projectDetails, alertTeamName=alertTeamName,sub_lob_alert=sub_lob_alert)
        print('Configuration Step failed... exiting')

    if run_status == 'FAILURE':
        dict_obs["run_status"] = run_status
        dict_obs["end_time"] = datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S")
        dict_obs["error_message"] = error_message
        try:
            logger_name = params["obs"]["logger_name"]
            ## capturing process end time for the last task of dag##
            if current_task in last_task:
                dict_obs["process_end_time"] = datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S")
            else:
                print(" current task not in last task ")
                print(" current task is ", current_task)
                print(" last task is ", last_task)
                dict_obs["process_end_time"] = "NA"
            dict_obs["inserted_timestamp"] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
            observability.ingestion_obs(dict_obs, logger_name)
        except Exception as e:
            error_message = str(e)
            print("error_message : ", error_message)
            logging.error(traceback.format_exc())
            print("Could not send observability log")
        return {"dict_obs": dict_obs, 'run_status': 'failure'}

    if "dict_obs" in resultConfiguration:
        dict_obs = resultConfiguration["dict_obs"]
        dict_obs["run_status"] = 'FAILURE'
        try:
            logger_name = params["obs"]["logger_name"]
            ## capturing process end time for the last task of dag##
            if current_task in last_task:
                dict_obs["process_end_time"] = datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S")
            else:
                print(" current task not in last task ")
                print(" current task is ", current_task)
                print(" last task is ", last_task)
                dict_obs["process_end_time"] = "NA"
            dict_obs["inserted_timestamp"] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
            observability.ingestion_obs(dict_obs, logger_name)
        except Exception as e:
            error_message = str(e)
            print("error_message : ", error_message)
            logging.error(traceback.format_exc())
            print("Could not send observability log")
        return {"dict_obs": dict_obs, 'run_status': 'failure'}
    else:
        configuration = resultConfiguration["configuration"]

    return {"queryParameters": queryParameters, "error_message": "NA", "run_status": run_status, "dict_obs": dict_obs,
            "bqInsertJobConfig": configuration, "sql_query": sql_query}


def postLoad(context, variables, params, projectDetails, dagId, tz, opsgenie_priority, last_task, ingestionPattern,
             alertTeamName,sub_lob_alert, jdbc_check_load_status, preLoadResult, grp_id):
    from observability import get_records_inserted_from_bq_api
    # get the variable map based on the project
    projectTag = projectDetails[0]
    projectSpace = projectDetails[2]
    varMap = variables[projectTag + "_vars"]

    # import the necessary modules
    BASE_DIR = "/home/airflow/gcs/dags/" + projectSpace + "/beamx"
    sys.path.append(f"{BASE_DIR}/utils")
    import observability
    from ops_genie import send_alert_to_opsgenie

    # required values from xcoms
    dict_obs = preLoadResult['dict_obs']
    current_task = context['task'].task_id
    run_status = "success"

    if preLoadResult['run_status'].lower() == "failure":
        dict_obs["run_status"] = preLoadResult['run_status'].lower()
        dict_obs["end_time"] = datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S")
        # dict_obs["error_message"] = ""
        try:
            logger_name = params["obs"]["logger_name"]
            ## capturing process end time for the last task of dag##
            if current_task in last_task:
                dict_obs["process_end_time"] = datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S")
            else:
                print(" current task not in last task ")
                print(" current task is ", current_task)
                print(" last task is ", last_task)
                dict_obs["process_end_time"] = "NA"
            dict_obs["inserted_timestamp"] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
            observability.ingestion_obs(dict_obs, logger_name)
        except Exception as e:
            run_status = "failure"
            error_message = str(e)
            print("error_message : ", error_message)
            logging.error(traceback.format_exc())
            print("Could not send observability log")
        opsgenie_message = "Beamx|" + variables["environment"] + "|Failure|" + current_task + "|" + dict_obs[
            'running_instance_id']
        opsgenie_description = "Failure | BQ transform step FAILED|" + dict_obs['running_instance_id']
        opsgenie_details = {"DAG ID": dagId, "Error Step": "BQ Transform", "Error Message": error_message}
        send_alert_to_opsgenie(opsgenie_message, opsgenie_description, opsgenie_details, opsgenie_priority,
                               projectDetails=projectDetails, alertTeamName=alertTeamName,sub_lob_alert=sub_lob_alert)
        return {"dict_obs": dict_obs, run_status : "success"}

    dict_obs["end_time"] = datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S")

    # get table counts for observability
    bq_hook = BigQueryHook(gcp_conn_id=variables[params['hook']["gcp_conn_id"]])
    upstreamTaskId = grp_id + '.bq_to_bq_load_bigquery_operator'
    job_id = ""
    if run_status == "success":
        job_id = context['ti'].xcom_pull(task_ids=upstreamTaskId, key='job_id_path')
        job_id = job_id.split(":")[2]  if job_id else None
        print("job_id", job_id)
    project = bq_hook._get_field("project")
    credentials = bq_hook.get_credentials()
    dict_obs["source_count"] = "0"
    final_count = "0"
    try:
        # final_count = observability.get_count_file_based(params, varMap, project, credentials)
        final_count = get_records_inserted_from_bq_api(job_id, bq_hook, variables, projectTag, varMap, params)
        dict_obs["target_count"] = final_count
    except Exception as e:
        print("error in hitting bq api ", str(e))
        dict_obs["target_count"] = final_count

    print(" bqload target count ", final_count)

    dict_obs["error_message"] = "NA"
    dict_obs["run_status"] = "SUCCESS"
    ingestion_query = ""

    try:
        logger_name = params["obs"]["logger_name"]
        ## capturing process end time for the last task of dag##
        if last_task is not None and current_task in last_task:
            dict_obs["process_end_time"] = datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S")
        else:
            print(" current task not in last task ")
            print(" current task is ", current_task)
            print(" last task is ", last_task)
            dict_obs["process_end_time"] = "NA"
        dict_obs["inserted_timestamp"] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
        observability.ingestion_obs(dict_obs, logger_name)
    except Exception as e:
        run_status = "failure"
        error_message = str(e)
        print("error_message : ", error_message)
        logging.error(traceback.format_exc())
        print("Could not send observability log")

    if 'jdbc_to_bq' in ingestionPattern.lower():
        ingestion_query = auditTableEntry(context, params, variables, varMap, dict_obs, dagId, jdbc_check_load_status,
                                          projectSpace, opsgenie_priority, "", ingestionPattern,
                                          projectDetails,
                                          "None", alertTeamName, sub_lob_alert)

    elif 'ingestioncuration' in ingestionPattern.lower() :
        #audit_flag = params["hook"]["audit_flag"].lower() if 'audit_flag' in params['hook'] else 'no'
        #if audit_flag == 'yes':
        try:
            target_table = f"{params['hook']['datasetId']}.{params['hook']['tableId']}" if 'tableId' in params['hook'] else params['hook']['target_table']
            target_table = reduce(lambda key, value: key.replace(*value), varMap.items(), target_table)
        except Exception as e:
            target_table = ''
        ingestion_query = auditTableEntry(context, params, variables, varMap, dict_obs, dagId, 'N/A', projectSpace, opsgenie_priority, target_table, ingestionPattern, projectDetails, preLoadResult['sql_query'], alertTeamName,sub_lob_alert)

    elif 'bq_to_jdbc' in ingestionPattern.lower():
        target_table = dict_obs['target_name']
        print("target table is ", target_table)
        ingestion_query = auditTableEntry(context, params, variables, varMap, dict_obs, dagId, 'N/A', projectSpace, opsgenie_priority,
                        target_table, ingestionPattern, projectDetails, "None", alertTeamName,sub_lob_alert)

    elif "file_ingestion" in ingestionPattern.lower() :
        target_table = dict_obs['target_name']
        print("target table is ", target_table)
        ingestion_query = auditTableEntry(context, params, variables, varMap, dict_obs, dagId, 'N/A', projectSpace, opsgenie_priority,
                        target_table, ingestionPattern, projectDetails, preLoadResult['sql_query'], alertTeamName,sub_lob_alert)

    elif "tpt_td_to_bq" in ingestionPattern.lower():
        target_table = dict_obs['target_name']
        print("target table is ", target_table)
        ingestion_query = auditTableEntry(context, params, variables, varMap, dict_obs, dagId, 'N/A', projectSpace,
                                          opsgenie_priority,
                                          target_table, ingestionPattern, projectDetails, preLoadResult['sql_query'],
                                          alertTeamName, sub_lob_alert)
    elif "nos_td_to_bq" in ingestionPattern.lower():
        target_table = dict_obs['target_name']
        print("target table is ", target_table)
        ingestion_query = auditTableEntry(context, params, variables, varMap, dict_obs, dagId, 'N/A', projectSpace,
                                          opsgenie_priority,
                                          target_table, ingestionPattern, projectDetails, preLoadResult['sql_query'],
                                          alertTeamName, sub_lob_alert)
    else:
        try:
            target_table = f"{params['hook']['datasetId']}.{params['hook']['tableId']}" if 'tableId' in params['hook'] else params['hook']['target_table']
            target_table = reduce(lambda key, value: key.replace(*value), varMap.items(), target_table)
        except Exception as e:
            target_table = ''
        ingestion_query = auditTableEntry(context, params, variables, varMap, dict_obs, dagId, 'N/A', projectSpace, opsgenie_priority, target_table, ingestionPattern, projectDetails, preLoadResult['sql_query'], alertTeamName, sub_lob_alert)

    upstreamTaskId = next(iter(context['task'].upstream_task_ids))
    prevTaskRunState = (TaskInstance(context['dag'].get_task(upstreamTaskId), context['logical_date'])).current_state()
    audit_configuration = None
    if ingestion_query is not None:
        audit_configuration = {
            "jobType": "QUERY",
            "query": {
                "query": ingestion_query,
                "useLegacySql": False,
            }
        }

    return {"audit_configuration": audit_configuration, "queryParameters": preLoadResult['queryParameters'] if 'queryParameters' in preLoadResult else None, "error_message": preLoadResult['error_message'] if 'error_message' in preLoadResult else None,
            "bq_to_bq_load_status": prevTaskRunState, "final_count": final_count, "dict_obs": dict_obs, "run_status": run_status}


def save_bq_result_xcom(preLoadResult, variables, params, context):
    # required values from xcoms
    dict_obs = preLoadResult['dict_obs']
    configuration = preLoadResult['bqInsertJobConfig']

    dict_obs["inserted_timestamp"] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
    print("Configuration - query is ", configuration['query']['query'])
    print("Is save result", 'save_result' in params['hook'])
    bq_hook = BigQueryHook(gcp_conn_id=variables[params['hook']["gcp_conn_id"]])
    try:
        print("Clean up of any xcom variables")
        with create_session() as session:
            xcom_value = session.query(XCom).filter(
                XCom.key == 'bq_result',
                XCom.dag_id == context['ti'].dag_id
            ).delete()

        session.commit()
        print("Deleted up any xcom variables")

        query = configuration['query']['query']
        if query.endswith(";"):
            query = query[:-1]

        query = "Select * from (" + query + ") limit 1;"

        print("Query... for xcom-- ", query)
        records_dict = bq_hook.get_pandas_df(query, dialect='standard').to_dict(orient='records')
        print("Records dict ", records_dict)
        context['ti'].xcom_push(key='bq_result', value=records_dict)
        print("Added the record to xcom")


    except Exception as e:
        error_message = str(e)
        print("Error while saving the BQ result to xcom variable : ", error_message)
        logging.error(traceback.format_exc())
        raise AirflowFailException("Error while saving the result to xcom", e)

