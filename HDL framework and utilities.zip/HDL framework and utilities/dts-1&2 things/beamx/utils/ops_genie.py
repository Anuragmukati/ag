import requests
import json
import sys
import pytz

from airflow.models import Variable
from datetime import datetime

from datetime import date, timedelta, timezone, tzinfo
from functools import reduce

def send_alert_to_opsgenie(message, description, details, priority, **kwargs):
    print("In Opsgenie method")
    projectDetails = kwargs['projectDetails'] if 'projectDetails' in kwargs else ["gk1v","wireless","vz-it-gk1v-cwlspr-0"]
    projectTag = projectDetails[0]
    businessLine = projectDetails[1]
    projectSpace = projectDetails[2]
    msg1 = message.split('|')[:3]
    msg2 = message.split('|')[3:]
    msg1= '|'.join(msg1)
    msg2= '|'.join(msg2)
    final_message = msg1 + "|" + details["DAG ID"] + "|" + msg2
    print("final_message:",final_message)
    BASE_DIR = "/home/airflow/gcs/dags/"+projectSpace  + "/beamx"
    sys.path.append(f"{BASE_DIR}/utils")
    from variables import getVariables
    sub_lob_alert = kwargs['sub_lob_alert'] if 'sub_lob_alert' in kwargs else None
    # get all the variables from yaml
    variables = getVariables(projectDetails)
    env_name=projectTag+'_vars'
    env_vars=variables[env_name]
    print("triggered ops_genie function")
    detail_dagID = details["DAG ID"]
    final_description = "Incident URL : " + variables["Airflow_DAG_URL"] + detail_dagID + "/grid\nDescription : " + description
    #if variables["environment"] == "DEV":
    #    final_description = "Incident URL : " + variables["Airflow_DAG_URL"] + detail_dagID + "/grid\nDescription : " + description
    #else:
    #    final_description = "Incident URL : " + variables["Airflow_DAG_URL"] + detail_dagID + "\nDescription : " + description

    # ops_genie key should be received as a list with genie key as key
    # and responder name as value {"key": "genie_key", "name": "group_name"}

    if priority == "None":
        print("Priority provided None. opsgenie not trigger")
        return
    print("Finalizing the alert")
    print("Authenticating the Ops-Genie")
    print("Environment",variables["environment"])
    print("sub_lob_alert:",sub_lob_alert)
    if 'alert_team' in env_vars:
        alert_dict=eval(env_vars['alert_team'])
    else:
        alert_dict= None
    print("alert_dict found under ENV :",alert_dict)
    if 'opsgenie_api_key' in env_vars:
        opsgenie_api_key=eval(env_vars['opsgenie_api_key'])
    else:
        opsgenie_api_key=None
    print("opsgenie_api_key found under ENV :",opsgenie_api_key)
    if sub_lob_alert != None and variables["environment"] != "DEV" and variables["environment"] != "TEST" and variables["environment"] != "PLE" and alert_dict!= None:
        if sub_lob_alert=='None-None':
            teamname='default'
        else:
            teamname=sub_lob_alert
        print("sub_lob_alert is ",sub_lob_alert)
        print("sending Prod alerts")
        for key,group in alert_dict.items():
            print("Preparing the Json Data")
            teamname1='default'
            if key == teamname:
                teamname1=None
                key1=group.split(':')[0]
                group1=group.split(':')[1]
                print(key1)
                print(group1)
                print("Team Found in Dict:",group1)
                ops_genie_auth_headers = {
                    "Content-Type": "application/json",
                    "Authorization": key1,
                }
                print("Preparing the Json Data")
                responder = [{"name": group1, "type": "team"}]
                json_data = {
                    "message": final_message,
                    "description": final_description,
                    "details": details,
                    "priority": priority,
                    "responders": responder
                }
                call_process_ops_genie(ops_genie_auth_headers, json_data)
                break
            else:
                print("Mentioned Alert team is not present in YMAL Dict Team name:",sub_lob_alert)
        if teamname1  == 'default':
            for key,group in alert_dict.items():
                print("Preparing the Json Data")
                if key == teamname1:
                    key1=group.split(':')[0]
                    group1=group.split(':')[1]
                    print(key1)
                    print(group1)
                    print("Default Team Found in Dict:",group1)
                    ops_genie_auth_headers = {
                        "Content-Type": "application/json",
                        "Authorization": key1,
                    }
                    print("Preparing the Json Data")
                    responder = [{"name": group1, "type": "team"}]
                    json_data = {
                        "message": final_message,
                        "description": final_description,
                        "details": details,
                        "priority": priority,
                        "responders": responder
                    }
                    call_process_ops_genie(ops_genie_auth_headers, json_data)
                    break
                else:
                    print("Mentioned Default  Alert team is not present in YMAL Dict Team name:")
    elif sub_lob_alert != None and variables["environment"] != "DEV" and variables["environment"] != "TEST" and variables["environment"] == "PLE" and alert_dict!= None:
        if sub_lob_alert=='None-None':
            teamname='default'
        else:
            teamname=sub_lob_alert
        print("sub_lob_alert is ",sub_lob_alert)
        alert_dict=eval(env_vars['alert_team'])
        print("sending Prod PLE alerts")
        for key,group in alert_dict.items():
            print("Preparing the Json Data")
            teamname1='default'
            if key == teamname:
                teamname1=None
                key1=group.split(':')[0]
                group1=group.split(':')[1]
                print(key1)
                print(group1)
                print("Team Found in Dict:",group1)
                ops_genie_auth_headers = {
                    "Content-Type": "application/json",
                    "Authorization": key1,
                }
                print("Preparing the Json Data")
                responder = [{"name": group1, "type": "team"}]
                json_data = {
                    "message": final_message,
                    "description": final_description,
                    "details": details,
                    "priority": priority,
                    "responders": responder
                }
                call_process_ops_genie(ops_genie_auth_headers, json_data)
                break
            else:
                print("Mentioned Alert team is not present in YMAL Dict Team name:",sub_lob_alert)
        if teamname1  == 'default':
            for key,group in alert_dict.items():
                print("Preparing the Json Data")
                if key == teamname1:
                    key1=group.split(':')[0]
                    group1=group.split(':')[1]
                    print(key1)
                    print(group1)
                    print("Default Team Found in Dict:",group1)
                    ops_genie_auth_headers = {
                        "Content-Type": "application/json",
                        "Authorization": key1,
                    }
                    print("Preparing the Json Data")
                    responder = [{"name": group1, "type": "team"}]
                    json_data = {
                        "message": final_message,
                        "description": final_description,
                        "details": details,
                        "priority": priority,
                        "responders": responder
                    }
                    call_process_ops_genie(ops_genie_auth_headers, json_data)
                    break
                else:
                    print("Mentioned Default  Alert team is not present in YMAL Dict Team name:")
    elif (variables["environment"] == "DEV" or variables["environment"] == "TEST") and alert_dict!= None:
        if sub_lob_alert=='None-None':
            teamname='default'
        else:
            teamname=sub_lob_alert
        print("sub_lob_alert is ",sub_lob_alert)
        print("sending DEV/TEST alerts")
        for key,group in alert_dict.items():
            print("Preparing the Json Data")
            teamname1='default'
            if key == teamname:
                teamname1=None
                key1=group.split(':')[0]
                group1=group.split(':')[1]
                print(key1)
                print(group1)
                print("Team Found in Dict:",group1)
                ops_genie_auth_headers = {
                    "Content-Type": "application/json",
                    "Authorization": key1,
                }
                print("Preparing the Json Data")
                responder = [{"name": group1, "type": "team"}]
                json_data = {
                    "message": final_message,
                    "description": final_description,
                    "details": details,
                    "priority": priority,
                    "responders": responder
                }
                call_process_ops_genie(ops_genie_auth_headers, json_data)
                break
            else:
                print("Mentioned Alert team is not present in YMAL Dict Team name:",sub_lob_alert)
        if teamname1  == 'default':
            for key,group in alert_dict.items():
                print("Preparing the Json Data")
                if key == teamname1:
                    key1=group.split(':')[0]
                    group1=group.split(':')[1]
                    print(key1)
                    print(group1)
                    print("Sending Alert to Default Team:",group1)
                    ops_genie_auth_headers = {
                        "Content-Type": "application/json",
                        "Authorization": key1,
                    }
                    print("Preparing the Json Data")
                    responder = [{"name": group1, "type": "team"}]
                    json_data = {
                        "message": final_message,
                        "description": final_description,
                        "details": details,
                        "priority": priority,
                        "responders": responder
                    }
                    call_process_ops_genie(ops_genie_auth_headers, json_data)
                    break
                else:
                    print("Mentioned Default  Alert team is not present in YMAL Dict Team name:")
    else:
        prod_alert_dict=eval(env_vars['opsgenie_api_key'])
        print("sending else alerts")
        for key,group in prod_alert_dict.items():
            print("Preparing the Json Data")
            ops_genie_auth_headers = {
                "Content-Type": "application/json",
                "Authorization": key,
            }
            print("Preparing the Json Data")
            responder = [{"name": group, "type": "team"}]
            json_data = {
                "message": final_message,
                "description": final_description,
                "details": details,
                "priority": priority,
                "responders": responder
            }
            call_process_ops_genie(ops_genie_auth_headers, json_data)


def call_process_ops_genie(genie_headers, json_data):
    print("json_data:", json_data)
    # Retry 5 times if the API request is failed.
    print("Sending the Response")
    try:
        response = requests.post("https://api.opsgenie.com/v2/alerts",
                                 headers = genie_headers, json = json_data)
        print("HTTP Response:", response.text)
    except Exception as e:
        print("error message", str(e))
        print("Sending Alert to Ops-Genie Failed....")
        return
    if response.status_code == 202:
        api_response = json.loads(response.text)
        print("Response:", api_response)
        return api_response["requestId"]