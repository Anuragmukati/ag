from google.cloud import bigquery
from google.cloud import logging as gcplogging

import logging
import traceback
import re
import pytz
import pendulum
import requests
import json
import sys
import pytz
import base64
from datetime import datetime
from datetime import date
from airflow.models import Variable
from datetime import date, timedelta, timezone, tzinfo
from functools import reduce
from airflow.providers.google.cloud.hooks.bigquery import BigQueryHook
from airflow.providers.google.cloud.hooks.gcs import GCSHook
from airflow.models import TaskInstance
import re
from airflow.models import DagRun
from observability import gcs_to_bq_obs

"""
get the parameters to send to observability logs
"""


def getObsParams(bucketNameVars, variables, params, projectDetails, dagId, tz, dict_obs):
    # get the variable map based on the project
    projectTag = projectDetails[0]
    varMap = variables[projectTag + "_vars"]

    dict_obs["process_date"] = str(date.today().strftime("%Y-%m-%d"))
    dict_obs["start_time"] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
    source_name = bucketNameVars["SOURCE_URI_BUCKET"] + params["hook"]['sourceUris']
    print("source name is ", source_name)
    dict_obs["source_name"] = str(source_name)
    dict_obs["source_type"] = "File"
    dict_obs["target_type"] = "Table"
    dict_obs["process_name"] = dagId
    dict_obs["gcp_project"] = varMap[params["hook"]["projectId"]]

    return dict_obs


def getLabelsDict(labelsList, dagId, run_id, task_id, composer_name):
    labels_dict = {
        "job_id": dagId.lower()[-63:],
        "task_type": "file_load_to_bq",
        "run_id": re.sub(r'[^A-Za-z0-9 _-]+', '', run_id).lower()[-63:],
        "task_id": task_id.lower().replace('.', "")[-63:],
        "instance_name": composer_name.lower()
    }


"""
Send oservability logs to logger
"""


def sendObsLogs(context, params, dict_obs, bq_hook, varMap, projectSpace, tz, processDate, processTime, error_msg,
                run_status, current_task, last_task):
    # import the necessary modules
    BASE_DIR = "/home/airflow/gcs/dags/" + projectSpace
    sys.path.append(f"{BASE_DIR}/utils")
    import observability

    dict_obs["end_time"] = datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S")
    # get table counts for observability
    project = bq_hook._get_field("project")
    credentials = bq_hook.get_credentials()
    final_count = observability.get_count_file_based(params, varMap, project, credentials)
    dict_obs["source_count"] = "0"
    dict_obs["destination_count"] = final_count
    print(" bqload target count ", final_count)
    dict_obs_static = str(params["obs"])
    dict_obs_static = json.loads(
        (reduce(lambda key, value: key.replace(*value), varMap.items(), dict_obs_static)).replace("'", '"'))
    dict_obs.update(dict_obs_static)
    dict_obs["process_date"] = str(date.today().strftime("%Y-%m-%d"))
    data_interval_endtime = context['data_interval_end'].in_timezone(tz)
    dict_obs["run_date"] = str(data_interval_endtime.strftime('%Y%m%d'))
    dict_obs["run_day"] = str(data_interval_endtime.strftime('%A'))
    dict_obs["run_hour"] = str(data_interval_endtime.strftime("%H:%M:%S"))
    dict_obs["error_message"] = error_msg
    dict_obs["run_status"] = run_status
    dict_obs["log_file"] = varMap['log_file']

    try:

        ## passing the process end time based on that task sequence in the dag ##
        logger_name = params["obs"]["logger_name"]
        if current_task in last_task:
            dict_obs["process_end_time"] = datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S")
        else:
            print(" current task not in last task ")
            print(" current task is ", current_task)
            print(" last task is ", last_task)
            dict_obs["process_end_time"] = "NA"
        dict_obs["inserted_timestamp"] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
        observability.ingestion_obs(dict_obs, logger_name)
    except Exception as e:
        error_msg = str(e)
        print("error_msg : ", error_msg)
        logging.error(traceback.format_exc())
        print("Could not send observability log")
    return dict_obs

def preChecksAndInsertJobConfiguration(context, bucketNameVars, variables, params, projectDetails, dagId, tz, dict_obs, opsgenie_priority,
                   last_task, ingestion_pattern, custom_labels=None, fileSensorDetails=None, **kwargs):
    projectTag = projectDetails[0]
    projectSpace = projectDetails[2]
    varMap = variables[projectTag + "_vars"]
    BASE_DIR = variables["packages_directory"]
    sys.path.append(f"{BASE_DIR}/utils")
    from ops_genie import send_alert_to_opsgenie
    from observability import gcs_to_bq_obs
    project_id = projectDetails[2]
    gcs_to_bq_dict = {}
    get_sql_query_status = "FAILURE"
    print('projectTag', projectTag)
    sub_lob_alert = kwargs['sub_lob_alert'] if 'sub_lob_alert' in kwargs else None
    # print('params',params )
    # print('varmap',varMap)
    dict_obs = getObsParams(bucketNameVars, variables, params, projectDetails, dagId, tz, dict_obs)
    dict_obs["start_time"] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
    # dict_obs["run_date"] = str(datetime.now(tz).strftime('%Y%m%d'))
    # dict_obs["run_day"] = str(datetime.now(tz).strftime('%A'))
    # dict_obs["run_hour"] = str(datetime.now(tz).strftime('%X'))
    data_interval_endtime = context['data_interval_end'].in_timezone(tz)
    dict_obs["run_date"] = str(data_interval_endtime.strftime('%Y%m%d'))
    dict_obs["run_day"] = str(data_interval_endtime.strftime('%A'))
    dict_obs["run_hour"] = str(data_interval_endtime.strftime("%H:%M:%S"))
    ### logging obs parameters to cloud logging ###
    # logging_client = gcplogging.Client()
    logger_name = params["obs"]["logger_name"]
    dict_obs["process_name"] = dagId
    # logger = logging_client.logger(logger_name)

    try:
        # source_gcs_bucket=reduce(lambda key, value: key.replace(*value), varMap.items(), params['hook']['source_gcs_bucket'])
        source_gcs_bucket = bucketNameVars["SOURCE_URI_BUCKET"]
        if params['hook']['hive_partitioning_mode'] == "CUSTOM":
            uri = source_gcs_bucket + "/" + params['hook']['hive_partitioning_source_uri_prefix'].split('{')[0] + "*"
            hive_partitioning_source_uri_prefix = source_gcs_bucket + "/" + params["hook"][
                "hive_partitioning_source_uri_prefix"]
        else:
            uri = source_gcs_bucket + "/" + params['hook']['hive_partitioning_source_uri_prefix'] + "/*"
            hive_partitioning_source_uri_prefix = source_gcs_bucket + "/" + params["hook"][
                "hive_partitioning_source_uri_prefix"]
        if 'savemode' in params['hook']:
            if params['hook']['savemode'] == 'replace':
                replace = "WRITE_TRUNCATE"
            else:
                replace = "WRITE_APPEND"
        else:
            replace = False
        if 'location' in params['hook']:
            location = params['hook']['location']
        else:
            location = "US"
        if "projectId" in params["hook"]:
            gcp_project = reduce(lambda key, value: key.replace(*value), varMap.items(), params["hook"]["projectId"])
            print(gcp_project)
        else:
            gcp_project = project_id

        # print("SQL query to run :", sql_query)
        import os
        composer_name = os.getenv('COMPOSER_ENVIRONMENT')
        run_id = context['dag_run'].run_id
        current_task = context['task'].task_id
        labels_dict = getLabelsDict(custom_labels, dagId, run_id, current_task, composer_name)
        configuration = {
            "jobType": "LOAD",
            # "location": location,
            "load": {

                "destinationTable": {
                    "projectId": gcp_project,
                    "datasetId": varMap[params["hook"]["datasetId"]],
                    "tableId": params["hook"]["tableId"]
                },
                "hivePartitioningOptions": {
                    "mode": params["hook"]["hive_partitioning_mode"],
                    "sourceUriPrefix": hive_partitioning_source_uri_prefix

                },
                "sourceUris": [uri],
                "writeDisposition": params["hook"]["writeDisposition"],
                "sourceFormat": params["hook"]["sourceformat"],
                "createDisposition": params["hook"]["createDisposition"]

            },
            "labels": labels_dict
        }
        #    if key not in ('sourceUris','projectId','datasetId','tableId','sourceFormat','gcp_conn_id', 'archiveLocation', 'filesToLoad', 'fileTableMap', 'customUdfArgs','hive_partitioning_mode','hive_partitioning_source_uri_prefix','writeDisposition'):
        #        if value.lower() == 'true':
        #            configuration["load"][key] =  True
        #        if value.lower() == 'false':
        #            configuration["load"][key] =  False
        #        elif value.isnumeric():
        #            configuration["load"][key] = int(value)
        #        else:
        #            configuration["load"][key] = value

        dict_obs["inserted_timestamp"] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
        dict_obs["process_date"] = str(date.today())
        print("configuration = ", configuration)
        print("load for the source file ", uri)
        return {"sourceFileName": uri, "error_message": "NA", "run_status": "success",
                "bqInsertJobConfig": configuration, "dict_obs": dict_obs}
    except Exception as e:
        print("Error during pre check activities ", str(e))
        logging.error(traceback.format_exc())
        return {"sourceFileName": uri,
            "error_message": "error occurred during pre-load activites for bq load", "run_status": "failure",
             "dict_obs": dict_obs}



def postLoad(context, group_id, variables, params, projectDetails, dagId, tz, opsgenie_priority,
                          last_task,sourceFileName, dict_obs, ingestionPattern, superGroupId, last_task_num, preLoadResult,alertTeamName,
                          sub_lob_alert, fileSensorDetails=None):
    # get the variable map based on the project
    projectTag = projectDetails[0]
    projectSpace = projectDetails[2]
    varMap = variables[projectTag + "_vars"]
    BASE_DIR = variables["packages_directory"]
    sys.path.append(f"{BASE_DIR}/utils")
    from email_utility import send_email_footer
    import observability
    from ops_genie import send_alert_to_opsgenie

    gcs_to_bq_dict = {}

    # required values from xcoms
    job_id = context['ti'].xcom_pull(task_ids=f'{group_id}.gcs_to_bq_load_bigquery_operator', key='job_id_path')
    job_id = job_id.split(":")[2]
    print("job_id : ", job_id)

    if "gcp_conn_id" in params["hook"]:
        bq_hook = BigQueryHook(gcp_conn_id=variables[params["hook"]["gcp_conn_id"]])
    else:
        bq_hook = BigQueryHook(gcp_conn_id=variables["gcp_conn_id"])

    logger_name = params["obs"]["logger_name"]
    dict_obs["process_name"] = dagId

    upstreamTaskId = superGroupId + '.gcs_to_bq_load_bigquery_operator'
    prevTaskRunState = (TaskInstance(context['dag'].get_task(upstreamTaskId), context['logical_date'])).current_state()
    if str(prevTaskRunState).lower() == 'failed':
        failure_xcom = context['ti'].xcom_pull(key='gcstobqrunstatus', task_ids=upstreamTaskId)
        run_status = failure_xcom.get("run_status")
        error_msg = failure_xcom.get("error_msg")
        opsgenie_message = "Beamx|" + Variable.get("environment") + "|Failure|" + task_instance.task_id + "|" + \
                           dict_obs['running_instance_id']
        opsgenie_description = f"Failure|Hive to BQ insert job failed {error_msg}|" + dict_obs['running_instance_id']
        # opsgenie_message = Variable.get("environment") + " Alert | TPT TD to BQ insert job failed"
        # opsgenie_description = error_msg
        # opsgenie_priority=params['hook']['OpsgeniePriority']
        AlertTeamName = None
        if 'AlertTeamName' in params['hook']:
            AlertTeamName = params['hook']['AlertTeamName']
        else:
            AlertTeamName = None
        opsgenie_details = {"DAG ID": dagId, "Error Step": "TPT TD to BQ insert job failed",
                            "Error message": error_msg}
        send_alert_to_opsgenie(opsgenie_message, opsgenie_description, opsgenie_details, opsgenie_priority,
                               projectDetails=projectDetails, AlertTeamName=AlertTeamName, sub_lob_alert=sub_lob_alert)
        end_time = datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S")
        run_status = "FAILURE"
        logging.error(traceback.format_exc())

    else:
        run_status = "SUCCESS"
        error_msg = None
        end_time = datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S")
    current_task = context['task'].task_id

    data_interval_endtime = context['data_interval_end'].in_timezone(tz)
    dict_obs["run_date"] = str(data_interval_endtime.strftime('%Y%m%d'))
    dict_obs["run_hour"] = str(data_interval_endtime.strftime("%H:%M:%S"))
    dict_obs["run_day"] = str(data_interval_endtime.strftime('%A'))
    dict_obs = sendObsLogs(context, params, dict_obs, bq_hook, varMap, projectSpace, tz, dict_obs["run_date"],
                               dict_obs["run_hour"], error_msg, run_status, current_task, last_task)
    final_count = dict_obs['destination_count'] if 'destination_count' in dict_obs else '0'
    error_messages = "\"" + "\""
    print("RUN STATUS :", run_status)
    dict_obs["run_status"] = run_status
    dict_obs["end_time"] = end_time
    dict_obs_static = str(params["obs"])
    dict_obs_static = json.loads(
        (reduce(lambda key, value: key.replace(*value), varMap.items(), dict_obs_static)).replace("'", '"'))
    dict_obs.update(dict_obs_static)
    if error_msg is not None:
        dict_obs["error_message"] = error_msg.replace('\n', '')
    else:
        dict_obs["error_message"] = error_msg
    gcs_to_bq_obs(logger_name, dict_obs)
    gcs_to_bq_dict.update(dict_obs)

    print("gcs_to_bq_dict is : ", gcs_to_bq_dict)
    DagRun_Details = DagRun.find(dag_id=f"{dagId}", state="running")
    if DagRun_Details:
        process_run_id = f"{dagId}_" + str(DagRun_Details[0].run_id)
    else:
        process_run_id = f"{dagId}_" + str(datetime.now(tz).strftime("%Y%m%d%H%M%S"))
    running_instance_id = process_run_id
    # gcs_to_bq_dict['sql_query'] = sql_query.replace('\n','')

    if run_status == 'FAILURE':
        sys.tracebacklimit = 0
        return ({'run_status': 'FAILURE', 'error_msg': 'Failure in inserting data in BQ... exiting'})
    elif run_status == 'SUCCESS':
        return {"processDate": dict_obs["process_date"], "processTime": dict_obs["end_time"], "sourceFileName": sourceFileName,
                "error_message": 'NA', "run_status": 'success', "final_count": final_count}
