"""
File Name: bq_loader.py
Description: This python script is used to load data from a file in gcs to a bigquery table via the ingestion framework supporting multiple features and custom use cases.
"""
from datetime import datetime
from airflow.providers.google.cloud.hooks.bigquery import BigQueryHook
from airflow.providers.google.cloud.hooks.gcs import GCSHook
from airflow.providers.google.cloud.hooks.dataproc import DataprocHook
from datetime import date, timedelta, timezone, tzinfo
from google.cloud import bigquery
from google.cloud import storage
from airflow.models import TaskInstance
from functools import reduce
from airflow.operators.python import task, get_current_context
import logging
import pandas as pd
import io
import os
import traceback
import json
import sys
import re
import pytz
from datetime import date, timedelta, timezone, tzinfo
import pendulum
from collections import OrderedDict
import numpy as np
from airflow.models import DagRun
from croniter import croniter
import google.auth.transport.requests
from airflow.operators.email_operator import EmailOperator

source_uri_file = ""


tz = pendulum.timezone("EST")

def audit_log(params, variables, audit_logs):
    if "error_messages" not in audit_logs:
        audit_logs['error_messages'] = "\"" + "\""
    else:
        audit_logs['error_messages'] = str(audit_logs['error_messages']).replace("'","\"")

    if "file_record_count" not in audit_logs:
        audit_logs['file_record_count'] = None

    if "footer_record_count" not in audit_logs:
        audit_logs['footer_record_count'] = None

    # application_id = str(datetime.now(tz).strftime("%Y%m%d%H%M%S"))
    application_id = audit_logs['running_instance_id']
    print("check quotes with join ")
    if 'error_msg' in audit_logs:
        error_msg = audit_logs['error_msg']
    elif 'error_message' in audit_logs:
        error_msg = audit_logs['error_message']

    if 'keyvalue' not in audit_logs:
        audit_logs['keyvalue'] = 'NA'
    if 'scheduler' not in audit_logs:
        audit_logs['scheduler'] = 'airflow'
    if 'source_environment' not in audit_logs:
        audit_logs['source_environment'] = 'NA'
    if 'target_environment' not in audit_logs:
        audit_logs['target_environment'] = 'NA'
    if 'source_servername' not in audit_logs:
        audit_logs['source_servername'] = 'NA'
    if 'target_servername' not in audit_logs:
        audit_logs['target_servername'] = 'NA'
    if 'source_type' not in audit_logs:
        audit_logs['source_type'] = 'Table'
    if 'target_type' not in audit_logs:
        audit_logs['target_type'] = 'Table'
    if 'bad_records_count' not in audit_logs:
        audit_logs['bad_records_count'] = 'NA'
    if 'footer_record' not in audit_logs:
        audit_logs['footer_record'] = 'NA'
    if 'header_record' not in audit_logs:
        audit_logs['header_record'] = 'NA'
    if 'footer_cntrl_record' not in audit_logs:
        audit_logs['footer_cntrl_record'] = 'NA'
    if 'header_cntrl_record' not in audit_logs:
        audit_logs['header_cntrl_record'] = 'NA'
    if 'source_count' not in audit_logs:
        audit_logs['source_count'] = 'NA'

    insert_query = """
            Insert into {0}.{1}.audit
            SELECT
            '{2}'   AS application_id,
            '{3}'   AS end_time,
            r'''{4}'''   AS error_msg,
            '{0}'   AS gcp_project,
            '{5}'   AS inserted_timestamp,
            '{6}'   AS keyvalue,
            '{7}'   AS logger_name,
            '{8}'   AS process_date,
            '{9}'   AS process_name,
            '{10}'  AS project_name,
            '{11}'  AS run_date,
            '{12}'  AS run_day,
            '{13}'  AS run_hour,
            '{14}'  AS run_status,
            '{15}'  AS scheduler,
            '{16}'  AS source_environment,
            r'''{17}'''  AS source_name,
            '{18}'  AS source_servername,
            '{19}'  AS source_type,
            '{20}'  AS start_time,
            '{21}'  AS sub_process,
            '{22}'  AS system_name,
            '{23}'  AS target_count,
            '{24}'  AS target_environment,
            r'''{25}'''  AS target_name,
            '{26}'  AS target_servername,
            '{27}'  AS target_type,
            '{28}'  AS td_load_completion_timestamp,
            '{29}'  AS tool_name,
            r'''{30}'''  AS sql_query,
            '{31}' as bad_records_count,
            r'''{32}'''  AS footer,
            r'''{33}'''  AS header,
            '{34}'  AS errors,
            '{35}'  AS file_record_count,
            '{36}'  AS footer_record_count,
            '{37}'  AS footer_cntrl_record,
            '{38}'  AS header_cntrl_record,
            '{39}' as source_count

    """.format(audit_logs['project_id'], audit_logs['bq_dataset'], application_id, audit_logs['end_time'], error_msg,
               audit_logs['inserted_timestamp'], audit_logs['keyvalue'], audit_logs['logger_name'],
               audit_logs['process_date'], audit_logs['process_name'], audit_logs['project_name'],
               audit_logs['run_date'], audit_logs['run_day'], audit_logs['run_hour'], audit_logs['run_status'],
               audit_logs['scheduler'], audit_logs['source_environment'], audit_logs['source_name'],
               audit_logs['source_servername'], audit_logs['source_type'], audit_logs['start_time'],
               audit_logs['sub_process'], audit_logs['system_name'], audit_logs['target_count'],
               audit_logs['target_environment'], audit_logs['target_name'], audit_logs['target_servername'],
               audit_logs['target_type'], audit_logs['td_load_completion_timestamp'], audit_logs['tool_name'],
               audit_logs['sql_query'], audit_logs['bad_records_count'], audit_logs['footer_record'],
               audit_logs['header_record'],
               audit_logs['error_messages'], audit_logs['file_record_count'], audit_logs['footer_record_count'],
               audit_logs['footer_cntrl_record'], audit_logs['header_cntrl_record'], audit_logs['source_count'])
    return insert_query



def store_error_messages(job_id, bq_hook, varMap, params):
    import requests
    import json
    try:
        project_id = str(varMap[params["hook"]["projectId"]])
        job_details_api = 'https://bigquery.googleapis.com/bigquery/v2/projects/' + str(
            project_id) + '/jobs/' + str(job_id)

        print("fetching job details from api for error records: ", job_details_api)

        source_credentials = bq_hook.get_credentials()

        auth_req = google.auth.transport.requests.Request()
        source_credentials.refresh(auth_req)

        job_details = requests.get(job_details_api, headers={'Authorization': f"Bearer {source_credentials.token}",
                                                             "Content-Type": "application/json"})
        print("api response code store error: ", job_details)
        job_details = json.loads(str(job_details.text))
        error_messages = "\"" + "\""
        if job_details is not None and "status" in job_details and job_details["status"] is not None and "errors" in \
                job_details["status"] and job_details['status']['errors'] is not None:
            error_messages = "\"" + str(job_details['status']['errors']).replace("\"", "\\\"") + "\""
        return error_messages
    except Exception as ex:
        print("failed getting error messages from API ", str(ex))
        return "\"" + "\""


"""
get the labels to be passed to the dataproc job
"""
def getLabelsDict(labelsList, dagId,run_id,task_id, composer_name):
    labels_dict = {
        "job_id": dagId.lower()[-63:],
        "task_type": "file_load_to_bq",
        "run_id": re.sub(r'[^A-Za-z0-9 _-]+', '', run_id).lower()[-63:],
        "task_id": task_id.lower().replace('.', "")[-63:],
        "instance_name": composer_name.lower()
    }

    # if labelsList:
    #     if isinstance(labelsList, list):
    #         for label in labelsList:
    #             key = label.split(':')[0]
    #             value = label.split(':')[1]
    #             labels_dict[key] = value
    #     else:
    #         key = labelsList.split(':')[0]
    #         value = labelsList.split(':')[1]
    #         labels_dict[key] = value

    return labels_dict


def get_bad_records_from_api(job_id, bq_hook, variables, projectTag, varMap, params):
    import requests

    job_details_api = 'https://bigquery.googleapis.com/bigquery/v2/projects/' + str(
        varMap[params["hook"]["projectId"]]) + '/jobs/' + str(job_id)

    print("fetching job details from api: ", job_details_api)

    # import os
    # getenv = os.getenv('no_proxy')
    # new_proxy = job_details_api.replace('https://','')
    # getenv += ","+new_proxy
    # print("no_proxy is: ", getenv)
    # os.environ['no_proxy'] = getenv

    source_credentials = bq_hook.get_credentials()

    from google.auth import impersonated_credentials

    auth_req = google.auth.transport.requests.Request()
    source_credentials.refresh(auth_req)

    job_details = requests.get(job_details_api, headers={'Authorization': f"Bearer {source_credentials.token}",
                                                         "Content-Type": "application/json"})
    print("api response code: ", job_details)
    # print(str(job_details.text))
    job_details = json.loads(str(job_details.text))
    bad_records = job_details['statistics']['load']['badRecords']

    return bad_records


"""
This function checks the presence of the source file in inbound path
"""


def detectSourceFile(context, bucketNameVars, variables, params, projectDetails, dagId, tz, dict_obs, opsgenie_priority,
                     ingestionPattern, **kwargs):
    gcs_hook = GCSHook(gcp_conn_id=variables[params["hook"]["gcp_conn_id"]])
    sourceFileObject = params['hook']['sourceUris']
    storage_client = storage.Client(credentials=gcs_hook.get_credentials())
    sourceBucket = bucketNameVars["SOURCE_URI_BUCKET"].split("/")[-1]
    bucket = storage_client.bucket(sourceBucket)
    # if not gcs_hook.exists(sourceBucket, sourceFileObject):
    blob = bucket.blob(blob_name=sourceFileObject)
    if not blob.exists():
        sys.tracebacklimit = 0
        raise RuntimeError(f"Failed to detect the source file gs://{sourceBucket}/{sourceFileObject}")
    else:
        print(f"source file detected ! - gs://{sourceBucket}/{sourceFileObject}")

"""
get the parameters to send to observability logs
"""
def getObsParams(bucketNameVars, variables, params, projectDetails, dagId, tz, dict_obs):

    #get the variable map based on the project
    projectTag = projectDetails[0]
    varMap = variables[ projectTag+"_vars"]

    dict_obs["process_date"] = str(date.today().strftime("%Y-%m-%d"))
    dict_obs["start_time"] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
    source_name = bucketNameVars["SOURCE_URI_BUCKET"]+params["hook"]['sourceUris']
    print("source name is ", source_name)
    dict_obs["source_name"] = str(source_name)
    dict_obs["source_type"] = "File"
    dict_obs["target_type"] = "Table"
    dict_obs["process_name"] = dagId
    dict_obs["gcp_project"] = varMap[ params["hook"]["projectId"] ]

    return dict_obs

def replaceWithCurrentDateForFormat(sourceFile, dagrun_startdate):
    date_format_to_convert = "%Y-%m-%dT%H:%M:%S"
    dagdate = datetime.strptime(dagrun_startdate, date_format_to_convert)
    if 'yyyymmdd' or 'mmddyyyy' or 'ddmmyyyy' or 'yyyyddmm' in sourceFile.lower():
        if re.search('yyyymmdd', sourceFile.lower()):
            sourceFile = re.sub('yyyymmdd', datetime.strftime(dagdate, '%Y%m%d'), sourceFile)
        elif re.search('ddmmyyyy', sourceFile.lower()):
            sourceFile = re.sub('ddmmyyyy', datetime.strftime(dagdate, '%d%m%Y'), sourceFile)
        elif re.search('mmddyyyy', sourceFile.lower()):
            sourceFile = re.sub('mmddyyyy', datetime.strftime(dagdate, '%m%d%Y'), sourceFile)
        elif re.search('yyyyddmm', sourceFile.lower()):
            sourceFile = re.sub('yyyyddmm', datetime.strftime(dagdate, '%Y%d%m'), sourceFile)
    else:
        sourceFile
    return sourceFile

def extract_date(file_name, date_format):
    if date_format == 'yyyymmdd' or date_format == 'ddmmyyyy' or date_format == 'mmddyyyy' or date_format == 'yyyyddmm':
        pattern = re.compile(r'\d{8}')
    else:
        raise ValueError("unknown date format",{date_format})
    match = pattern.search(file_name)
    if match:
        date_str = match.group(0)
        if date_format == 'yyyymmdd':
            try:
                datetime.strptime(date_str,'%Y%m%d')
                return date_str
            except ValueError:
                return None
        elif date_format == 'ddmmyyyy':
            try:
                datetime.strptime(date_str,'%d%m%Y')
                return date_str
            except ValueError:
                return None
        elif date_format == 'mmddyyyy':
            try:
                datetime.strptime(date_str,'%m%d%Y')
                return date_str
            except ValueError:
                return None
        elif date_format == 'yyyyddmm':
            try:
                datetime.strptime(date_str, '%Y%d%m')
                return date_str
            except ValueError:
                return None
        print("matching_group", match)
    return None

def file_pattern_check(sourceFile, run_date,dict_obs):
    yyyy = str(run_date.year)
    mm = '{:02d}'.format(run_date.month)
    dd = '{:02d}'.format(run_date.day)
    hh = '{:02d}'.format(run_date.hour)
    yy = run_date.strftime('%y')
    mmm = run_date.strftime('%b').lower()
    MMM = run_date.strftime('%b').upper()
    Mmm = run_date.strftime('%b')
    ddd = run_date.strftime("%j")

    sourcefileobj = sourceFile
    prefix_d =""
    prefix_t =""
    match = re.search(r'(?P<prefix_d>d|D)YYMMDD_(?P<prefix_t>t|T)HH',sourceFile,flags=re.IGNORECASE) #ici_events_DYYMMDD_THHMMSS.txt
    if match:
        prefix_d = match.group('prefix_d')
        prefix_t = match.group('prefix_t')

    #To replace files with mmm with Month based on the case
    month_formats ={
        r'MMM': f"{MMM}",
        r'mmm': f"{mmm}",
        r'Mmm': f"{Mmm}"
    }
    month_pattern_match = re.search(r"(mmm|MMM|Mmm)", sourceFile)
    if month_pattern_match:
        mmm = month_formats.get(month_pattern_match.group())

    #patterns are case insensitive
    format_patterns = {
        r'yyyymmddhh': f"{yyyy}{mm}{dd}{hh}",
        r'yyyymmdd_hh': f"{yyyy}{mm}{dd}_{hh}",
        r'yyyymmdd-hh': f"{yyyy}{mm}{dd}-{hh}",
        r'mmddyyyyhh': f"{mm}{dd}{yyyy}{hh}",
        r'mmddyyyy_hh': f"{mm}{dd}{yyyy}_{hh}",
        r'mmddyyyy-hh': f"{mm}{dd}{yyyy}-{hh}",
        r'ddmmyyyyhh': f"{dd}{mm}{yyyy}{hh}",
        r'ddmmyyyy_hh': f"{dd}{mm}{yyyy}_{hh}",
        r'ddmmyyyy-hh': f"{dd}{mm}{yyyy}-{hh}",
        r'yyyyddmmhh': f"{yyyy}{dd}{mm}{hh}",
        r'yyyyddmm_hh': f"{yyyy}{dd}{mm}_{hh}",
        r'yyyyddmm-hh': f"{yyyy}{dd}{mm}-{hh}",
        r'yymmddhh': f"{yy}{mm}{dd}{hh}",
        r'yymmdd_hh': f"{yy}{mm}{dd}_{hh}",
        r'yymmdd-hh': f"{yy}{mm}{dd}-{hh}",
        r'mmddyyhh': f"{mm}{dd}{yy}{hh}",
        r'mmddyy_hh': f"{mm}{dd}{yy}_{hh}",
        r'mmddyy-hh': f"{mm}{dd}{yy}-{hh}",
        r'ddmmyyhh': f"{dd}{mm}{yy}{hh}",
        r'ddmmyy_hh': f"{dd}{mm}{yy}_{hh}",
        r'ddmmyy-hh': f"{dd}{mm}{yy}-{hh}",
        r'yyddmmhh': f"{yy}{dd}{mm}{hh}",
        r'yyddmm_hh': f"{yy}{dd}{mm}_{hh}",
        r'yyddmm-hh': f"{yy}{dd}{mm}-{hh}",
        r'yyyymmdd': f"{yyyy}{mm}{dd}",
        r'ddmmyyyy': f"{dd}{mm}{yyyy}",
        r'mmddyyyy': f"{mm}{dd}{yyyy}",
        r'yyyyddmm': f"{yyyy}{dd}{mm}",
        r'yyyy-mm-dd': f"{yyyy}-{mm}-{dd}",
        r'dd-mm-yyyy': f"{dd}-{mm}-{yyyy}",
        r'mm-dd-yyyy': f"{mm}-{dd}-{yyyy}",
        r'yyyy-mm-dd': f"{yyyy}-{mm}-{dd}",
        r'yyyy_mm_dd': f"{yyyy}_{mm}_{dd}",
        r'dd_mm_yyyy': f"{dd}_{mm}_{yyyy}",
        r'mm_dd_yyyy': f"{mm}_{dd}_{yyyy}",
        r'yyyy_dd_mm': f"{yyyy}_{dd}_{mm}",
        r'(?P<prefix_d>d|D)YYMMDD_(?P<prefix_t>t|T)HH' : f"{prefix_d}{yy}{mm}{dd}_{prefix_t}{hh}",
        r'yymmdd': f"{yy}{mm}{dd}",
        r'ddmmyy': f"{dd}{mm}{yy}",
        r'mmddyy': f"{mm}{dd}{yy}",
        r'yyddmm': f"{yy}{dd}{mm}",
        r'mmyydd': f"{mm}{yy}{dd}",
        r'ddyymm': f"{dd}{yy}{mm}",
        r'yy-mm-dd': f"{yy}-{mm}-{dd}",
        r'dd-mm-yy': f"{dd}-{mm}-{yy}",
        r'mm-dd-yy': f"{mm}-{dd}-{yy}",
        r'yy-mm-dd': f"{yy}-{mm}-{dd}",
        r'dd_mm_yy': f"{dd}_{mm}_{yy}",
        r'mm_dd_yy': f"{mm}_{dd}_{yy}",
        r'yy_dd_mm': f"{yy}_{dd}_{mm}",
        r'ddMMMyyyy': f"{dd}{mmm}{yyyy}",
        r'ddmmmyyyy': f"{dd}{mmm}{yyyy}",
        r'ddMmmyyyy': f"{dd}{mmm}{yyyy}",
        r'yyyymm' : f"{yyyy}{mm}",
        r'yyyyddd' : f"{yyyy}{ddd}",
        r'yyddd' : f"{yy}{ddd}",
        r'yyyy-mm': f"{yyyy}-{mm}",
        r'yyyy_mm': f"{yyyy}_{mm}",
        r'yyyy': f"{yyyy}",
        r'ddmm': f"{dd}{mm}",
        r'mmmdd': f"{mmm}{dd}",
        r'mmdd': f"{mm}{dd}"
    }

    for pattern, replacement in format_patterns.items():
        if re.search(pattern, sourceFile, flags=re.IGNORECASE):
            sourceFile = re.sub(pattern, replacement, sourceFile, flags=re.IGNORECASE)
            try:
                run_date = run_date.strftime('%Y-%m-%d %H:%M:%S')
                dict_obs.update({'run_date_value':run_date})
                print("dict_obs_updated",dict_obs)
                context = get_current_context()
                context['ti'].xcom_push(key='run_date'+sourcefileobj, value=run_date)
            except:
                pass

    return sourceFile


def convertScheduleInterval(schedule_interval,exec_date,tz,days=0):
    try:
        if schedule_interval is None:
            days_interval=0
        elif isinstance(schedule_interval,timedelta):
            days_interval = int(schedule_interval.total_seconds()/3600)
            print("days_interval_as_timedelta",days_interval)
        elif isinstance(schedule_interval, str):
            if 'timedelta' in schedule_interval:
                days_interval = int(eval(schedule_interval).total_seconds()/3600)
            else:
                utc_tz = pytz.utc
                execdateconvert = datetime.strptime(exec_date,'%Y-%m-%dT%H:%M:%S').strftime('%Y-%m-%d %H:%M:%S')
                timeval = utc_tz.localize(datetime.strptime(execdateconvert,'%Y-%m-%d %H:%M:%S')).astimezone(tz)
                iter = croniter(schedule_interval,timeval)
                next_time = iter.get_next(datetime)
                days_interval = ((next_time - timeval).total_seconds() /3600)
                print("days_interval",days_interval)
        return days_interval
    except Exception as e:
        print("Exception occured in schedule conversion")
        return days

def replaceParametersWithRunDate(sourceFile,context,params=None,tz=None,schedule_interval=None):
    dict_obs = context['ti'].xcom_pull(key="dict_obs")
    print("dict_obs : ", dict_obs)
    dag = context["dag"]
    schedule_interval = dag.schedule_interval
    print("schedule_interval",schedule_interval)

    if dict_obs is not None and tz is not None:
        if 'scheduled' in dict_obs['running_instance_id'].lower():
            days_interval=0
            if 'schedule_interval' in dict_obs:
                days_interval = convertScheduleInterval(dict_obs['schedule_interval'],dict_obs['exec_date'],tz)
                current_date = pendulum.parse(dict_obs['exec_date'],tz='UTC').in_timezone(tz) + timedelta(hours=days_interval)
                print("current_date_when_scheduler_run",current_date)
            else:
                current_date = pendulum.now()
        else:
            current_date = pendulum.parse(dict_obs['exec_date'], tz='UTC').in_timezone(tz)
            print("current_date_when_manual_run",current_date)
    else:
        if context is not None:
            if re.search(r'\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}', context['ti'].run_id):
                exec_date = ''.join(
                    re.findall(r'\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}', context['ti'].run_id.split('__', 1)[1]))
            else:
                exec_date = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
            if 'scheduled' in context['ti'].run_id and schedule_interval is not None:
                days_interval = convertScheduleInterval(schedule_interval, exec_date, tz)
                current_date = pendulum.parse(exec_date, tz='UTC').in_timezone(tz) + timedelta(
                    hours=days_interval)
                print("current_date_when_scheduler_run", current_date)
            else:
                current_date = pendulum.parse(exec_date, tz='UTC').in_timezone(tz)
        else:
            current_date = pendulum.now()
        print("current_date",current_date)
    run_date = current_date
    if params is not None:
        if 'run_date' in params['hook']:
            matchdate = params['hook']['run_date'].replace(" ", "")
            match = re.match(r'current_date([-+]\d+)$', matchdate.lower())
            if match:
                run_date = current_date + timedelta(days=int(match.group(1)))
            elif re.match(r'lastdayofmonth',matchdate.lower()):
                run_date = current_date.end_of('month')
            elif re.match(r'firstdayofmonth', matchdate.lower()):
                run_date = current_date.start_of('month')
            elif re.match(r'previousmonth',matchdate.lower()):
                run_date = current_date.subtract(months=1)
            elif re.match(r'lastdayofpreviousmonth',matchdate.lower()):
                run_date = current_date.start_of('month').subtract(days=1)
            elif re.match(r'firstdayofpreviousmonth',matchdate.lower()):
                run_date = current_date.subtract(months=1).start_of('month')
            elif re.match(r'seconddayofpreviousmonth',matchdate.lower()):
                run_date = current_date.subtract(months=1).start_of('month').add(days=1)
    if isinstance(sourceFile, list):
        replaced_sourcefile = []
        for sourceFile in sourceFile:
            sourceFile = str(sourceFile[0])
            sourceFile = file_pattern_check(sourceFile,run_date,dict_obs)
            replaced_sourcefile.append([sourceFile])
        return replaced_sourcefile
    else:
        sourceFile = file_pattern_check(sourceFile, run_date,dict_obs)
        return sourceFile

def createTouchFile(context, params, variables, varMap, dagId, projectDetails, tz, **kwargs):
    project_space = projectDetails[2]
    BASE_DIR = "/home/airflow/gcs/dags/" + project_space+ "/beamx"
    sys.path.append(f"{BASE_DIR}/utils")
    print("touch file creation started...")
    touch_file_name = params["hook"]["touch_file_name"]
    if "_yyyymmdd" in touch_file_name:
        current_date = str(datetime.now().strftime("%Y%m%d"))
        touch_file_name = touch_file_name.replace("_yyyymmdd", "_" + current_date)
    elif "_timestamp" in touch_file_name:
        current_datetime = str(datetime.now().strftime("%Y%m%d%H%M%S"))
        touch_file_name = touch_file_name.replace("_timestamp", "_" + current_datetime)
    else:
        touch_file_name = params["hook"]["touch_file_name"]

    try:
        # create a client to connect to GCS
        gcs_hook = GCSHook(gcp_conn_id=variables[params["hook"]["gcp_conn_id"]])
        credentials = gcs_hook.get_credentials()
        storage_client = storage.Client(credentials=credentials)
        bucket_name = variables['touch_file_bucket']
        bucket = storage_client.bucket(bucket_name)
        destination_blob_name = touch_file_name
        blob = bucket.blob(destination_blob_name)
        blob.upload_from_string('SUCCESS')
        print("touch file created",touch_file_name)
    except Exception as e:
        raise ValueError("Exception occured in creating touch file")
        
def getFileListForMultiFile(sourceObject, dagId, gcp_conn_id, bucketName, catchup_run="no", params=None,
                            tz=None, schedule_interval=None):
    dedupFileList = []
    DagRun_Details = DagRun.find(dag_id=f"{dagId}", state="running")
    dict_obs = {}
    dict_obs['schedule_interval'] = schedule_interval
    if DagRun_Details:
        dict_obs['running_instance_id'] = DagRun_Details[0].run_id
        if re.search(r'\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}', DagRun_Details[0].run_id):
            dict_obs['exec_date'] = ''.join(
                re.findall(r'\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}', DagRun_Details[0].run_id.split('__', 1)[1]))
        else:
            dict_obs['exec_date'] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
    else:
        dict_obs['running_instance_id'] = f"{dagId}_" + str(datetime.now(tz).strftime("%Y%m%d%H%M%S"))
        dict_obs['exec_date'] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))

    if isinstance(dict_obs, dict) and tz is not None:
        if 'exec_date' in dict_obs:
            if 'scheduled' in dict_obs['running_instance_id'].lower():
                days_interval = 0
                if schedule_interval is not None:
                    days_interval = convertScheduleInterval(dict_obs['schedule_interval'], dict_obs['exec_date'],tz)
                    current_date = pendulum.parse(dict_obs['exec_date'], tz='UTC').in_timezone(tz) + timedelta(hours=days_interval)
                else:
                    current_date = pendulum.now()
            else:
                current_date = pendulum.parse(dict_obs['exec_date'], tz='UTC').in_timezone(tz)
    else:
        current_date = pendulum.now()
    run_date = current_date
    if params is not None:
        if 'run_date' in params['hook']:
            matchdate = params['hook']['run_date'].replace(" ", "")
            match = re.match(r'current_date([-+]\d+)$', matchdate.lower())
            if match:
                run_date = current_date + timedelta(days=int(match.group(1)))
            elif re.match(r'lastdayofmonth', matchdate.lower()):
                run_date = current_date.end_of('month')
            elif re.match(r'firstdayofmonth', matchdate.lower()):
                run_date = current_date.start_of('month')
            elif re.match(r'previousmonth', matchdate.lower()):
                run_date = current_date.subtract(months=1)
            elif re.match(r'lastdayofpreviousmonth', matchdate.lower()):
                run_date = current_date.start_of('month').subtract(days=1)
            elif re.match(r'firstdayofpreviousmonth', matchdate.lower()):
                run_date = current_date.subtract(months=1).start_of('month')
            elif re.match(r'seconddayofpreviousmonth', matchdate.lower()):
                run_date = current_date.subtract(months=1).start_of('month').add(days=1)
    # create a connection to gcs using GCSHook
    global source_uri_file
    source_uri_file = sourceObject
    gcs_hook = GCSHook(gcp_conn_id=gcp_conn_id)
    if ("*" in sourceObject):
        prefix = sourceObject.split("*")[0]
        delimiter = sourceObject.split("*")[-1]
        print('prefix is: ', prefix)
        print('match_glob is: ', sourceObject)
        # if catchup is given yes, it sorts the files based on the dates available in filename
        if catchup_run.lower() == "yes" and 'yyyy' in sourceObject.lower():
            date_format = "yyyymmdd" if "yyyymmdd" in sourceObject else "ddmmyyyy" if "ddmmyyyy" in sourceObject else "mmddyyyy" if "mmddyyyy" in sourceObject else "yyyyddmm" if "yyyyddmm" in sourceObject else "YYYYMMDD" if "YYYYMMDD" in sourceObject else "DDMMYYYY" if "DDMMYYYY" in sourceObject else "MMDDYYYY" if "MMDDYYYY" in sourceObject else "YYYYDDMM" if "YYYYDDMM" in sourceObject else ""
            sourceObject = sourceObject.replace(date_format, "")
            print("sourceObject after replacing dateformat", sourceObject)
            prefix = sourceObject.split("*")[0]
            print("updated prefix is ", sourceObject)
            # sort files based on filename
            fileListUnsorted = gcs_hook.list(bucket_name=bucketName, prefix=prefix, match_glob=sourceObject)
            print("File List is: ", fileListUnsorted)
            storage_client = storage.Client(credentials=gcs_hook.get_credentials())
            bucket = storage_client.bucket(bucketName)
            fileListDict = {}
            fileListSorted = []
            if len(fileListUnsorted) > 0:
                files_with_dates = [(file, extract_date(file, date_format.lower())) for file in fileListUnsorted if
                                    extract_date(file, date_format.lower()) is not None]
                sorted_files = sorted(files_with_dates, key=lambda x: x[1])
                fileListSorted = [file_name for file_name, file_date in sorted_files]
                print("sorted_file_names_from_new", fileListSorted)

        else:
            sourceObject = file_pattern_check(sourceObject, run_date, dict_obs)
            removeFileList = []
            prefix = sourceObject.split("*")[0]
            print("prefix when current has to come", prefix)
            fileListUnsorted = gcs_hook.list(bucket_name=bucketName, prefix=prefix, match_glob=sourceObject)
            print("File List is: ", fileListUnsorted)
            storage_client = storage.Client(credentials=gcs_hook.get_credentials())
            bucket = storage_client.bucket(bucketName)
            fileListDict = {}
            fileListSorted = []
            if len(fileListUnsorted) > 0:
                for file in fileListUnsorted:
                    blob = bucket.get_blob(file)
                    fileListDict[file] = blob.updated
                fileListUnsorted = list(fileListDict.keys())
                fileUpdatedTime = list(fileListDict.values())
                sorted_value_index = np.argsort(fileUpdatedTime)
                print("sorted_value_index", sorted_value_index)
                sorted_dict = {fileListUnsorted[i]: fileUpdatedTime[i] for i in sorted_value_index}

                for key in sorted_dict:
                    fileListSorted.append(key)
                    print("job came here and filesorted", fileListSorted)
                    # if the file name belongs to the custom use case 'billcompare'
        if "/billcompare/bco_" in sourceObject or "/nbs_billcompare/" in sourceObject:
            fileListSorted = fileListSorted
            removeFileList = []
        # if two dynamic substrings are present in a file name pattern represented by * in metadata
        # eg: employee_<region>_details_<date>.csv ; here, region and date are dynamic
        elif sourceObject.count('*') == 2:
            midString = sourceObject.split("*")[1]
            regex = re.compile(midString)
            fileListSorted = list(filter(regex.search, fileListSorted))
            regex_0 = re.compile(sourceObject.split("*")[1] + r'[a-zA-Z]+')
            # create a list of files to filter to remove from fileList so that only the file names matching the pattern exactly are considered for load
            removeFileList = list(filter(regex_0.search, fileListSorted))
        # if one dynamic substring is present in a file name pattern represented by * in metadata
        # eg: employee_details_<date>.csv ; here, date is dynamic
        elif sourceObject.count('*') == 1:
            removeFileList = []
        for file in removeFileList:
            if file in fileListSorted:
                fileListSorted.remove(file)
        dedupFileList = []
        [dedupFileList.append(file) for file in fileListSorted if file not in dedupFileList]
    return dedupFileList


"""
This function gets the list of source files in gcs inbound bucket that match the pattern specified by the user in metadata
"""
def getFileList(sourceObject, gcp_conn_id, bucketName):
    # create a connection to gcs using GCSHook
    global source_uri_file
    source_uri_file = sourceObject
    gcs_hook = GCSHook(gcp_conn_id=gcp_conn_id)
    if ("*" in sourceObject):
        prefix = sourceObject.split("*")[0]
        delimiter = sourceObject.split("*")[-1]
        print('prefix is: ', prefix)
        print('match_glob is: ', sourceObject)

        # fileListUnsorted = gcs_hook.list(bucket_name=bucketName, prefix=prefix,  delimiter=delimiter, match_glob=suffix)
        fileListUnsorted = gcs_hook.list(bucket_name=bucketName, prefix=prefix, match_glob=sourceObject)
        print("File List is: ", fileListUnsorted)
        storage_client = storage.Client(credentials=gcs_hook.get_credentials())
        bucket = storage_client.bucket(bucketName)
        fileListDict = {}
        fileListSorted = []
        if len(fileListUnsorted) > 0:
            for file in fileListUnsorted:
                blob = bucket.get_blob(file)
                fileListDict[file] = blob.updated
            fileListUnsorted = list(fileListDict.keys())
            fileUpdatedTime = list(fileListDict.values())
            sorted_value_index = np.argsort(fileUpdatedTime)
            sorted_dict = {fileListUnsorted[i]: fileUpdatedTime[i] for i in sorted_value_index}

            for key in sorted_dict:
                fileListSorted.append(key)

        removeFileList = []
        # if the file name belongs to the custom use case 'billcompare'
        if "/billcompare/bco_" in sourceObject or "/nbs_billcompare/" in sourceObject:
            fileListSorted = fileListSorted
            removeFileList = []
        # if two dynamic substrings are present in a file name pattern represented by * in metadata
        # eg: employee_<region>_details_<date>.csv ; here, region and date are dynamic
        elif sourceObject.count('*') == 2:
            midString = sourceObject.split("*")[1]
            regex = re.compile(midString)
            fileListSorted = list(filter(regex.search, fileListSorted))
            regex_0 = re.compile(sourceObject.split("*")[1] + r'[a-zA-Z]+')
            # create a list of files to filter to remove from fileList so that only the file names matching the pattern exactly are considered for load
            removeFileList = list(filter(regex_0.search, fileListSorted))
        # if one dynamic substring is present in a file name pattern represented by * in metadata
        # eg: employee_details_<date>.csv ; here, date is dynamic
        elif sourceObject.count('*') == 1:
            removeFileList = []
            '''fileListSorted = fileListSorted
            regex_1 = re.compile(prefix+ r'[a-zA-Z]+')
            removeList_1 = list(filter(regex_1.search, fileListSorted))
            #if file name has no extension
            if delimiter == None:
                removeList_2 = []
            else:
                regex_2 = re.compile(r'[a-zA-Z]+' + delimiter)
                removeList_2 = list(filter(regex_2.search, fileListSorted))
            #create a list of files to filter to remove from fileList so that only the file names matching the pattern exactly are considered for load
            removeFileList = removeList_1 + removeList_2'''
        for file in removeFileList:
            if file in fileListSorted:
                fileListSorted.remove(file)
        dedupFileList = []
        [dedupFileList.append(file) for file in fileListSorted if file not in dedupFileList]
    return dedupFileList


"""
This function is used to calculate the size of the source file object
"""


def getFileSize(bucketNameVars, variables, params, sourceFileObject):
    # create a gcs hook using connection id
    gcs_hook = GCSHook(gcp_conn_id=variables[params["hook"]["gcp_conn_id"]])

    # checking the source file size in bytes
    if 'fileTableMap' in params['hook']:
        fileSize = gcs_hook.get_size((bucketNameVars["PROCESS_BUCKET"]).split("/")[-1], sourceFileObject)
    else:
        fileSize = gcs_hook.get_size((bucketNameVars["SOURCE_URI_BUCKET"]).split("/")[-1], sourceFileObject)

    return fileSize


"""
This function extracts the process date and the process time from the source file name
"""


def getProcessDateAndTime(sourceFileName, context, dict_obs, params):
    processDate = None
    processTime = None
    try:
        sourcefile = params["hook"]["sourceUris"]
        if processDate is None:
            try:
                processDateValue = context['ti'].xcom_pull( key='run_date'+sourcefile)
                processDate = processDateValue.split(' ')[0]
                processTime = processDateValue.split(' ')[1]
            except:
                if processDate is None:
                    uptream_task_id = next(iter(context['task'].upstream_task_ids))
                    processDateValue = context['ti'].xcom_pull( key='run_date'+sourcefile)
                    processDate = processDateValue.split(' ')[0]
                    processTime = processDateValue.split(' ')[1]
    except:
        pass
    if processDate is None:
        # Sample datettime pattern : 202304011_04012023_1680555124766
        if re.search(r'\d\d\d\d\d\d\d\d\d_\d\d\d\d\d\d\d\d_\d\d\d\d\d\d\d\d\d\d\d\d\d', sourceFileName):
            matchObj = re.search(r'_\d\d\d\d\d\d\d\d_', sourceFileName)
            processDate = datetime.strptime(matchObj.group(), '_%m%d%Y_').strftime('%Y-%m-%d')
            processTime = None
        # Sample datettime pattern : 202212061531_20221220_96191
        elif re.search(r'\d\d\d\d\d\d\d\d\d\d\d\d_\d\d\d\d\d\d\d\d_\d\d\d\d\d', sourceFileName):
            matchObj = re.search(r'_\d\d\d\d\d\d\d\d_', sourceFileName)
            processDate = datetime.strptime(matchObj.group(), '_%Y%m%d_').strftime('%Y-%m-%d')
            processTime = None
        # Sample datettime pattern : 2022.12.06_02-30-00
        elif re.search(r'\d\d\d\d\.\d\d\.\d\d_\d\d-\d\d-\d\d', sourceFileName):
            matchObj = re.search(r'\d\d\d\d.\d\d.\d\d_\d\d-\d\d-\d\d', sourceFileName)
            processDate = datetime.strptime(matchObj.group(), '%Y.%m.%d_%H-%M-%S').strftime('%Y-%m-%d')
            processTime = datetime.strptime(matchObj.group(), '%Y.%m.%d_%H-%M-%S').strftime('%H:%M:%S')
        # Sample datettime pattern : 2022-12-06
        elif re.search(r'\d\d\d\d-\d\d-\d\d', sourceFileName):
            matchObj = re.search(r'\d\d\d\d-\d\d-\d\d', sourceFileName)
            processDate = matchObj.group()
            processTime = None
        # Sample datettime pattern : 20221206-023000
        elif re.search(r'\d\d\d\d\d\d\d\d-\d\d\d\d\d\d', sourceFileName):
            matchObj = re.search(r'\d\d\d\d\d\d\d\d-\d\d\d\d\d\d', sourceFileName)
            processDate = datetime.strptime(matchObj.group(), '%Y%m%d-%H%M%S').strftime('%Y-%m-%d')
            processTime = datetime.strptime(matchObj.group(), '%Y%m%d-%H%M%S').strftime('%H:%M:%S')
        # Sample datettime pattern : 20221206023000
        elif re.search(r'\d\d\d\d\d\d\d\d\d\d\d\d\d\d', sourceFileName):
            matchObj = re.search(r'\d\d\d\d\d\d\d\d\d\d\d\d\d\d', sourceFileName)
            try:
                processDate = datetime.strptime(matchObj.group(), '%Y%m%d%H%M%S').strftime('%Y-%m-%d')
                processTime = datetime.strptime(matchObj.group(), '%Y%m%d%H%M%S').strftime('%H:%M:%S')
            except ValueError:
                processDate = datetime.strptime(matchObj.group(), '%m%d%Y%H%M%S').strftime('%Y-%m-%d')
                processTime = datetime.strptime(matchObj.group(), '%m%d%Y%H%M%S').strftime('%H:%M:%S')
        # Sample datettime pattern : 2022.12.06.02
        elif re.search(r'\d\d\d\d\.\d\d\.\d\d\.\d\d', sourceFileName):
            matchObj = re.search(r'\d\d\d\d\.\d\d\.\d\d\.\d\d', sourceFileName)
            processDate = datetime.strptime(matchObj.group(), '%Y.%m.%d.%H').strftime('%Y-%m-%d')
            processTime = datetime.strptime(matchObj.group(), '%Y.%m.%d.%H').strftime('%H:%M:%S')
        # Sample datettime pattern : 20221206.023000
        elif re.search(r'\d\d\d\d\d\d\d\d_\d\d\d\d\d\d', sourceFileName):
            matchObj = re.search(r'\d\d\d\d\d\d\d\d_\d\d\d\d\d\d', sourceFileName)
            processDate = datetime.strptime(matchObj.group(), '%Y%m%d_%H%M%S').strftime('%Y-%m-%d')
            processTime = datetime.strptime(matchObj.group(), '%Y%m%d_%H%M%S').strftime('%H:%M:%S')
        # Sample datettime pattern : 20221206_02
        elif re.search(r'\d\d\d\d\d\d\d\d_\d\d', sourceFileName):
            matchObj = re.search(r'\d\d\d\d\d\d\d\d_\d\d', sourceFileName)
            try:
                processDate = datetime.strptime(matchObj.group(), '%Y%m%d_%H').strftime('%Y-%m-%d')
                processTime = datetime.strptime(matchObj.group(), '%Y%m%d_%H').strftime('%H:%M:%S')
            except:
                processDate = datetime.strptime(matchObj.group().split('_')[0], '%Y%m%d').strftime('%Y-%m-%d')
                processTime = None
        # Sample datettime pattern : 20221206 / 12062022
        elif re.search(r'\d\d\d\d\d\d\d\d', sourceFileName):
            matchObj = re.search(r'\d\d\d\d\d\d\d\d', sourceFileName)
            try:
                processDate = datetime.strptime(matchObj.group(), '%Y%m%d').strftime('%Y-%m-%d')
            except ValueError:
                try:
                    processDate = datetime.strptime(matchObj.group(), '%m%d%Y').strftime('%Y-%m-%d')
                except ValueError:
                    processDate = None
            processTime = None
        elif re.search(r'\b[Jj]?(\d{5})\b', sourceFileName):
            try:
                matchObj = re.search(r'\b[Jj]?(\d{5})\b', sourceFileName)
                processDate = datetime.strptime(matchObj.group(1), '%y%j').date().strftime('%Y-%m-%d')
                processTime = None
            except:
                pass
        else:
            processDate = None
            processTime = None
    return [processDate, processTime]


"""
This function gets the value of sourceUris for insert job configuration for BQ Load step
"""


def getSourceUris(params, bucketName, sourceFileObject, filesToLoad, fileCompressionType, bulkLoadFileList, taskType):
    fileName = (sourceFileObject.split('/')[-1]).rsplit('.', 1)[0]
    sourceUris = ""
    if taskType == "bulk load from gcs to bq":
        for index in range(len(bulkLoadFileList)):
            if bulkLoadFileList[index].lower().endswith(".gz") or bulkLoadFileList[index].lower().endswith(".zip") or bulkLoadFileList[index].lower().endswith(".z"):
                bulkLoadFileList[index] = "gs://" + bucketName + "/" + bulkLoadFileList[index] + "/*"
            else:
                bulkLoadFileList[index] = "gs://" + bucketName + "/" + bulkLoadFileList[index]

        print("File objects in processing bucket for bulk load :", bulkLoadFileList)
        sourceUris = bulkLoadFileList
    # if source file is a tar.gz or a .tar file and does not belong to omni ref job
    elif ((params["hook"]["sourceUris"].lower()).endswith('.tar.gz') or (params["hook"]["sourceUris"].lower()).endswith(
            '.tar')) and 'fileTableMap' not in params['hook']:
        if "filesToLoad" in params["hook"]:
            sourceUris = filesToLoad
        else:
            sourceUris = "gs://" + bucketName + "/" + sourceFileObject + "/*"
    # if source file is xml format
    elif (params["hook"]["sourceUris"].lower()).endswith('xml'):
        sourceUris = "gs://" + bucketName + "/" + sourceFileObject.split(".")[0] + "/*.json"
    # if source file belongs to diagnostics use case
    elif "diagnostics" in params["hook"]["sourceUris"].split("/"):
        sourceUris = "gs://" + bucketName + "/" + sourceFileObject + ".json"
    elif "fixedWidth" in params["hook"]:
        # if source file is a uncompressed fixedwidth file
        if(
                (params["hook"]["sourceUris"]).lower().endswith('.z') or (params["hook"]["sourceUris"].lower()).endswith(
                '.gz')):
            sourceUris = "gs://" + bucketName + "/" + sourceFileObject + "/" + fileName
        elif  (params["hook"]["sourceUris"].lower()).endswith(
                '.zip'):
            sourceUris = "gs://" + bucketName + "/" + sourceFileObject + "/*"
        else:
            sourceUris = "gs://" + bucketName + "/" + sourceFileObject
    # if source file is compressed (.gz, .z, .zip)
    elif (fileCompressionType != 'no match' or (params["hook"]["sourceUris"].lower()).endswith('.gz') or (
    params["hook"]["sourceUris"].lower()).endswith('.z') or (params["hook"]["sourceUris"].lower()).endswith(
            '.zip')) and fileCompressionType is not None and 'fileTableMap' not in params['hook']:
        if fileCompressionType == 'gz' or fileCompressionType == 'unix compressed' or (
        params["hook"]["sourceUris"].lower()).endswith('.gz') or (params["hook"]["sourceUris"].lower()).endswith('.z'):
            sourceUris = "gs://" + bucketName + "/" + sourceFileObject + "/" + fileName
        elif fileCompressionType == 'zip' or (params["hook"]["sourceUris"].lower()).endswith('.zip'):
            sourceUris = "gs://" + bucketName + "/" + sourceFileObject + "/*"
    # if source file is csv/newline delimited json
    else:
        sourceUris = "gs://" + bucketName + "/" + sourceFileObject

    print(f"sourceUris ->> {sourceUris}")
    return sourceUris


"""
This function creates the insert job configuration required for BQ load
"""


def getinsertJobConfiguration(params, sourceUris, varMap, tableId, dagId, custom_labels, run_id, task_id,
                              composer_name):
    labels_dict = getLabelsDict(custom_labels, dagId, run_id, task_id, composer_name)

    configuration = {
        "jobType": "LOAD",
        "load": {

            "destinationTable": {
                "projectId": varMap[params["hook"]["projectId"]],
                "datasetId": varMap[params["hook"]["datasetId"]],
                "tableId": tableId
            },
            "sourceUris": [sourceUris]

        },
        "labels": labels_dict
    }
    for key, value in params["hook"].items():
        if key not in (
        'sourceUris', 'projectId', 'datasetId', 'tableId', 'sourceFormat', 'gcp_conn_id', 'archiveLocation',
        'filesToLoad', 'fileTableMap', 'customUdfArgs','exclude_file', 'spark_conf'):
            if value.lower() == 'true':
                configuration["load"][key] = True
            if value.lower() == 'false':
                configuration["load"][key] = False
            elif value.isnumeric():
                configuration["load"][key] = int(value)
            else:
                configuration["load"][key] = value

            if value.lower() == 'cntra' and key.lower() == 'fielddelimiter':
                configuration["load"][key] = ""

    if "diagnostics" in params["hook"]["sourceUris"].split("/"):
        configuration["load"]["sourceFormat"] = 'NEWLINE_DELIMITED_JSON'
    else:
        configuration["load"]["sourceFormat"] = params["hook"]["sourceFormat"]
    return configuration


"""
This function checks if all the prerquisites are met before proceeding to bq load; If any check is not met, the load step is skipped
"""


def checkPrerequisites(context, params, variables, bucketNameVars, sourceFileObject, dict_obs, projectSpace,
                       upstreamTaskId, tz, last_task, taskType):
    # import the necessary modules
    BASE_DIR = "/home/airflow/gcs/dags/" + projectSpace + "/beamx"
    sys.path.append(f"{BASE_DIR}/utils")
    import observability

    # Check the status of preprocessing step; if it failed, skip the load step.
    prevTaskRunState = (TaskInstance(context['dag'].get_task(upstreamTaskId), context['logical_date'])).current_state()
    print("previous task run status is :", prevTaskRunState)
    if prevTaskRunState.lower() != 'success':
        dict_obs["error_message"] = "one or more upstream tasks either failed/skipped"

    # get the source file size and if source file is less than 4 B, skip the process
    if taskType != "bulk load from gcs to bq":
        fileSize = getFileSize(bucketNameVars, variables, params, sourceFileObject)
        if fileSize <= 4:
            sys.path.append(f"{BASE_DIR}/utils")
            print(" Source file is empty, skipping the process...")
            dict_obs["error_message"] = "source file is empty, skipping the process.."
    else:
        fileSize = None

    if (taskType != "bulk load from gcs to bq" and fileSize <= 4) or prevTaskRunState.lower() != 'success':
        # calculate dict_obs params for skipped scenarios
        dict_obs["run_status"] = "SKIPPED"
        # dict_obs["run_date"] = str(datetime.now(tz).strftime('%Y%m%d'))
        # run_hour = context['data_interval_end']
        # dict_obs["run_hour"] = str(run_hour.in_timezone(tz).strftime("%H:%M:%S"))
        data_interval_endtime = context['data_interval_end'].in_timezone(tz)
        dict_obs["run_date"] = str(data_interval_endtime.strftime('%Y%m%d'))
        dict_obs["run_hour"] = str(data_interval_endtime.strftime("%H:%M:%S"))
        dict_obs["run_day"] = str(data_interval_endtime.strftime('%A'))
        dict_obs["inserted_timestamp"] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
        # capturing process end time if the current task is the last task of dag; if not, defaulting it to 'NA'
        dict_obs["process_end_time"] = datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S") if context[
                                                                                             'task'].task_id in last_task else "NA"
        try:
            # call the observability method
            logger_name = params["obs"]["logger_name"]
            observability.ingestion_obs(dict_obs, logger_name)
        except Exception as e:
            error_msg = str(e)
            print("error_msg : ", error_msg)
            logging.error(traceback.format_exc())
            print("Could not send observability log")
        return {'run_status': 'skipped', 'error_message': dict_obs["error_message"], 'dict_obs' : dict_obs}
    return {'run_status': 'success', 'error_message': 'NA'}


"""
Check if a file exists
"""


def checkFilePresence(context, bucketNameVars, variables, sourceFileObject, params, projectDetails, dagId, tz, dict_obs,
                      opsgenie_priority, ingestion_pattern, parallelLoad='false', op_args=None,group_id=None):
    if ("single_file_ingestion" in ingestion_pattern):
        if group_id is not None:
            sourceFileObjectFromXcom = context['ti'].xcom_pull(key=(context['ti'].task_id).replace(f"{group_id}.archival_gcs_to_bq", f"{group_id}")+"_sourceFileObject")
        else:
            sourceFileObjectFromXcom = context['ti'].xcom_pull(key=(context['ti'].task_id).replace("archival_","")+"_sourceFileObject")
        if sourceFileObjectFromXcom != None:
            sourceFileObject = sourceFileObjectFromXcom
    sourceBucket = bucketNameVars["SOURCE_URI_BUCKET"].split("/")[-1]
    gcs_hook = GCSHook(gcp_conn_id=variables[params["hook"]["gcp_conn_id"]])
    storage_client = storage.Client(credentials=gcs_hook.get_credentials())
    bucket = storage_client.bucket(sourceBucket)
    blob = bucket.blob(blob_name=sourceFileObject)
    if not blob.exists():
        processedFileList = None
        try:
            upstreamTaskId = next(iter(context['task'].upstream_task_ids))
            print("upstream task id is :", upstreamTaskId)
            if parallelLoad=='false':
                processedFileList = context['ti'].xcom_pull( key='processed_file_list')
            else:
                processedFileList = context['ti'].xcom_pull(key=group_id.replace("preprocess_", "")+'_processed_file_list')
        except:
            pass
        print("processedFileList: ", processedFileList)
        print("This is just a placeholder task and hence skipping")
        if (processedFileList != None):
            if parallelLoad=='false':
                context['ti'].xcom_push(key='processed_file_list', value=processedFileList)
            else:
                context['ti'].xcom_push(key=group_id.replace("preprocess_", "")+'_processed_file_list', value=processedFileList)
        return {'run_status': 'skipped', 'error_message': "file not present"}
    else:
        return {'run_status': 'success', 'error_message': "NA"}


"""
Send oservability logs to logger
"""


def sendObsLogs(context, params, dict_obs, bq_hook, varMap, projectSpace, tz, processDate, processTime, error_msg,
                run_status, current_task, last_task):
    # import the necessary modules
    BASE_DIR = "/home/airflow/gcs/dags/" + projectSpace + "/beamx"
    sys.path.append(f"{BASE_DIR}/utils")
    import observability

    dict_obs["end_time"] = datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S")
    # get table counts for observability
    project = bq_hook._get_field("project")
    credentials = bq_hook.get_credentials()
    final_count = observability.get_count_file_based(params, varMap, project, credentials)
    dict_obs["source_count"] = "0"
    dict_obs["destination_count"] = final_count
    print(" bqload target count ", final_count)
    dict_obs_static = str(params["obs"])
    dict_obs_static = json.loads(
        (reduce(lambda key, value: key.replace(*value), varMap.items(), dict_obs_static)).replace("'", '"'))
    dict_obs.update(dict_obs_static)
    dict_obs["process_date"] = str(date.today().strftime("%Y-%m-%d"))
    data_interval_endtime = context['data_interval_end'].in_timezone(tz)
    dict_obs["run_date"] = str(data_interval_endtime.strftime('%Y%m%d')) if processDate == None else str(
        datetime.strptime(processDate, '%Y-%m-%d').strftime("%Y%m%d"))
    dict_obs["run_day"] = str(data_interval_endtime.strftime('%A')) if processDate == None else str(
        datetime.strptime(processDate, '%Y-%m-%d').strftime('%A'))
    dict_obs["run_hour"] = str(data_interval_endtime.strftime("%H:%M:%S")) if processTime == None else str(
        datetime.strptime(processTime, '%H:%M:%S').strftime("%H:%M:%S"))
    dict_obs["error_message"] = error_msg
    dict_obs["run_status"] = run_status
    dict_obs["log_file"] = varMap['log_file']

    try:

        ## passing the process end time based on that task sequence in the dag ##
        logger_name = params["obs"]["logger_name"]
        if current_task in last_task:
            dict_obs["process_end_time"] = datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S")
        else:
            print(" current task not in last task ")
            print(" current task is ", current_task)
            print(" last task is ", last_task)
            dict_obs["process_end_time"] = "NA"
        dict_obs["inserted_timestamp"] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
        observability.ingestion_obs(dict_obs, logger_name)
    except Exception as e:
        error_msg = str(e)
        print("error_msg : ", error_msg)
        logging.error(traceback.format_exc())
        print("Could not send observability log")
    return dict_obs


def remove_header(blob, header_pattern, audit_logs, recipient_email, dagId, variables, process_run_id, file,
                  projectDetails):
    project_space = projectDetails[2]
    BASE_DIR = "/home/airflow/gcs/dags/" + project_space+ "/beamx"
    sys.path.append(f"{BASE_DIR}/utils")
    from email_utility import send_email_footer
    file_content1 = blob.download_as_bytes()
    df = pd.read_csv(io.BytesIO(file_content1), dtype=object)
    df_header = pd.read_csv(io.BytesIO(file_content1), dtype=object, skiprows=1)
    df = df.where(df.notnull(), '')
    df_hdr = df_header.where(df_header.notnull(), '')
    header = ""
    for i in df.columns:
        if header != "":
            header = header + "," + str(i)
        else:
            header += str(i)

    if header.startswith(header_pattern) and header_pattern != 'NOT_AVAILABLE':
        print("header pattern matching")
        csv_data = df_hdr.to_csv(index=False)
        blob.upload_from_string(csv_data, content_type='text/csv')
        audit_header_pattern = header
        # print("header moved to audit",header_pattern)
    elif header_pattern == 'NOT_AVAILABLE':
        print("header pattern not available")
        csv_data = df_hdr.to_csv(index=False)
        blob.upload_from_string(csv_data, content_type='text/csv')
        audit_header_pattern = "NULL"
    else:
        audit_header_pattern = None
        print("header pattern not matching,trigger mail and abort")
        if recipient_email != 'na':
            dag = dagId
            subject = f'BeamX|{variables["environment"]}|{process_run_id}'
            msg = f"Footer not present "
            recipient_email = recipient_email
            html_content = f"""Hello Team,<br>
             &emsp;&emsp;&emsp;BeamX | {dagId} - {msg} in {file}."""
            send_email_footer(recipient_email, subject, html_content, dag)
    return audit_header_pattern


def remove_footer(skip_footer_flag, blob, footer_pattern, audit_logs, recipient_email, dagId, variables, process_run_id,
                  file, projectDetails, get_trailor_count, regex_pattern_for_trailor_count, client):
    project_space = projectDetails[2]
    BASE_DIR = "/home/airflow/gcs/dags/" + project_space+ "/beamx"
    sys.path.append(f"{BASE_DIR}/utils")
    from email_utility import send_email_footer
    file_content1 = blob.download_as_bytes()
    df = pd.read_csv(io.BytesIO(file_content1), dtype=object, header=None)
    df = df.where(df.notnull(), '')
    print("footer df", df)
    footer = ""
    for i in df.iloc[-1]:
        footer = footer + str(i)
    print("footer_value", footer)

    footer_record_count = None
    if get_trailor_count:
        sql_query = "select " + str(regex_pattern_for_trailor_count).replace("footer", "\"" + footer.replace("\"",
                                                                                                             "\\\"") + "\"") + "as extract_count;"
        print("query results ", sql_query)
        extract_string = client.query(sql_query).result()
        for i in extract_string:
            print("footer count ", int(i["extract_count"]))
            footer_record_count = int(i["extract_count"])
            break

    audit_footer_record = "NULL"
    if skip_footer_flag:
        if footer.startswith(footer_pattern) and footer_pattern != 'NOT_AVAILABLE':
            print("footer pattern matching")
            df = df.iloc[:-1]
            csv_data = df.to_csv(index=False, header=False)
            blob.upload_from_string(csv_data, content_type='text/csv')
            # print("footer moved to audit")
            audit_footer_record = footer
        elif footer_pattern == 'NOT_AVAILABLE':
            print("footer pattern not available")
            df = df.iloc[:-1]
            csv_data = df.to_csv(index=False, header=False)
            blob.upload_from_string(csv_data, content_type='text/csv')
            audit_footer_record = "NULL"
        else:
            audit_footer_record = None
            print("footer pattern not matching ,trigger mail and abort")
            if recipient_email != 'na':
                dag = dagId
                subject = f'BeamX|{variables["environment"]}|{process_run_id}'
                msg = f"Footer not present "
                recipient_email = recipient_email
                html_content = f"""Hello Team,<br>
                 &emsp;&emsp;&emsp;BeamX | {dagId} - {msg} in {file}."""
                send_email_footer(recipient_email, subject, html_content, dag)

    df_count = len(df)
    print("end result of footer", df)
    return (audit_footer_record, footer_record_count, df_count)


def remove_cntrl_header(blob, audit_logs, dagId, variables, process_run_id, file, projectDetails,
                        cntrl_header_regex_pattern, client, cntrl_header_trailor_count_from_file):
    project_space = projectDetails[2]
    BASE_DIR = "/home/airflow/gcs/dags/" + project_space + "/beamx"
    sys.path.append(f"{BASE_DIR}/utils")
    file_content1 = blob.download_as_bytes()
    df = pd.read_csv(io.BytesIO(file_content1), dtype=object)
    df = df.where(df.notnull(), '')
    print("header df", df)
    header = ""
    for i in df.columns:
        if header != "":
            header = header + "," + str(i)
        else:
            header += str(i)
    print("control file header", header)
    print("regex", cntrl_header_regex_pattern)

    header_record_count = None
    df_count = None
    if cntrl_header_trailor_count_from_file:
        print("Audit_Logs: ", audit_logs)
        if 'file_record_count' in audit_logs:
            df_count = audit_logs['file_record_count']
            print("df_count from audit_logs: ", df_count)
        sql_query = "select " + str(cntrl_header_regex_pattern).replace("header", "\"" + header.replace("\"",
                                                                                                        "\\\"") + "\"") + "as extract_count;"
        print("query results ", sql_query)
        extract_string = client.query(sql_query).result()
        print('extract_string :: ', extract_string)
        for i in extract_string:
            print("header count ", int(i["extract_count"]))
            header_record_count = int(i["extract_count"])
            break

    audit_cntrl_header_pattern = "NULL"
    if header:
        print("Header found:")
        print(header)
        audit_cntrl_header_pattern = header
    else:
        print("No header found")
        audit_cntrl_header_pattern = "null"
    print("audit header pattern", audit_cntrl_header_pattern, " ,header_record_count: ", header_record_count,
          " ,df_count : ", df_count)
    print("end result of footer", df)
    return (audit_cntrl_header_pattern, header_record_count, df_count)

def remove_cntrl_footer(cntrl_footer_flag,src_blob, blob,audit_logs,recipient_email,dagId,variables,process_run_id,file,projectDetails, get_trailor_count,regex_pattern_for_cntrl_count, client, params):
    
    project_space = projectDetails[2]
    BASE_DIR = "/home/airflow/gcs/dags/" + project_space+ "/beamx"
    sys.path.append(f"{BASE_DIR}/utils")
    from email_utility import send_email_footer
    file_content1 = blob.download_as_bytes()
    if "fieldDelimiter" in params['hook']:
        fieldDelimiter = params['hook']["fieldDelimiter"]
        if fieldDelimiter == 'CNTRA':
            fieldDelimiter = ''
    else:
        fieldDelimiter = ','
    if "encoding" in params['hook']:
        encoding = params['hook']["encoding"]
    else:
        encoding = 'utf-8'
    df=pd.read_csv(io.BytesIO(file_content1), dtype=object, header=None)
    df=df.where(df.notnull(), '')
    print("footer df", df)
    footer=""
    for i in df.iloc[-1]:
        footer = footer + str(i)
    print("footer_value",footer)
    print("regex", regex_pattern_for_cntrl_count)
    
    footer_record_count = None
    df_count = None
    if get_trailor_count:
        #file_content2 = src_blob.download_as_bytes()
        #df_src=pd.read_fwf(io.BytesIO(file_content2), dtype=object,delimiter=fieldDelimiter,encoding=encoding)
        #df_count = len(df_src) + 1
        print("Audit_Logs: ", audit_logs)
        if 'file_record_count' in audit_logs:
            df_count = audit_logs['file_record_count'] 
            print("df_count from audit_logs: ", df_count)
        sql_query = "select " + str(regex_pattern_for_cntrl_count).replace("footer", "\""+footer.replace("\"","\\\"")+"\"") + "as extract_count;"
        print( "query results ", sql_query)
        extract_string = client.query(sql_query).result()
        for i in extract_string:
            print("footer count ", int(i["extract_count"]))
            footer_record_count = int(i["extract_count"])
            break

    audit_cntrl_footer_pattern = "NULL"
    if footer:
        print("footer found:")
        print(footer)
        audit_cntrl_footer_pattern = footer
    else:
        print("No footer found")
        audit_cntrl_footer_pattern = "null"
    print("audit footer pattern", audit_cntrl_footer_pattern)
     
    print("end result of footer", df)
    return (audit_cntrl_footer_pattern, footer_record_count, df_count)
"""
Function to check pre-requisites and fetch load job configuration 
"""


def preChecksAndInsertJobConfig(context, bucketNameVars, variables, sourceFileObject, sourceFileName, params,
                                projectDetails, dagId, tz, dict_obs, tableId, last_task, ingestionPattern, taskType,
                                custom_labels,group_id):
    # get the variable map based on the project
    projectTag = projectDetails[0]
    project_space = projectDetails[2]
    varMap = variables[projectTag + "_vars"]

    # import the necessary modules
    BASE_DIR = "/home/airflow/gcs/dags/" + project_space+ "/beamx"
    sys.path.append(f"{BASE_DIR}/utils")
    from email_utility import send_email_footer
    import observability
    from ops_genie import send_alert_to_opsgenie

    # get the necessary details for bq load
    bucketName = (bucketNameVars["PROCESS_BUCKET"]).split("/")[-1]  # process bucket
    upstreamTaskId = next(iter(context['task'].upstream_task_ids))
    print("upstream task id is :", upstreamTaskId)

    bulkLoadFileList = []
    audit_logs = context['ti'].xcom_pull(key="audit_logs")
    audit_logs = {} if audit_logs is None else audit_logs
    process_run_id = context["dag_run"].run_id # get process_run_id
    current_task = context['task'].task_id
    print("current_task is", current_task)
    composer_name = os.getenv('COMPOSER_ENVIRONMENT')

    try:
        if "file_ingestion" in ingestionPattern:
            if "bulk_file_ingestion" in ingestionPattern and taskType == "bulk load from gcs to bq":
                bulkLoadFileList = context['ti'].xcom_pull(key=group_id + '_bulk_load_file_list_final')
                print("bulkLoadFileList : ", bulkLoadFileList)

        # get the static and dynamic observability parameters
        dict_obs = getObsParams(bucketNameVars, variables, params, projectDetails, dagId, tz, dict_obs)

        sourceFile = params["hook"]["sourceUris"]
        filedate = replaceParametersWithRunDate(sourceFile,context,params,tz)

        # check if the prerequisite conditions are satisfied. If no, skip the bq load step
        prerequisitesResult = checkPrerequisites(context, params, variables, bucketNameVars, sourceFileObject, dict_obs,
                                                 project_space, upstreamTaskId, tz, last_task, taskType)
        if prerequisitesResult['run_status'] != 'success':
            return {"sourceFileName": sourceFileName, "error_message": prerequisitesResult['error_message'],
                    "run_status": prerequisitesResult['run_status'], "audit_logs": {},
                    "dict_obs": prerequisitesResult['dict_obs'], "process_run_id": process_run_id,
                    "sourceFileName": sourceFileName, "tableId": tableId}

        if sourceFileObject.endswith('.tar.gz') or sourceFileObject.endswith('.tar'):
            if "filesToLoad" in params["hook"]:
                filesToLoad = params["hook"]["filesToLoad"]
                for index in range(len(filesToLoad)):
                    filesToLoad[index] = "gs://" + bucketName + "/" + sourceFileObject + "/" + filesToLoad[index]
                print("File objects to be loaded after untar:", filesToLoad)
            else:
                filesToLoad = None
        else:
            filesToLoad = None

        fileCompressionType = context['ti'].xcom_pull(key='file_compression_type')
        print("File Compression Type is : ", fileCompressionType)

        # get the sourceUris for bigquery load configuration to run bqhook.insert_job
        sourceUris = getSourceUris(params, bucketName, sourceFileObject, filesToLoad, fileCompressionType,
                                   bulkLoadFileList, taskType)
        dag_file_name = 'dg_' + dagId + '.py'
        global source_uri_file
        print("source_uri_file is ", source_uri_file)
        source_uri = source_uri_file
        source_file_prefix = source_uri_file.split("/")[-1]
        print("source_file_prefix is ", source_file_prefix)
        if ("*" in source_file_prefix):
            file_prefix = source_file_prefix.split("*")[0]
            if file_prefix is None:
                file_prefix = '*'
            print(file_prefix)
        elif ("." in source_file_prefix):
            file_prefix = source_file_prefix.split(".")[0]
            print(file_prefix)

        # get the insert job configuration for bq load step
        configuration = getinsertJobConfiguration(params, sourceUris, varMap, tableId, dagId, custom_labels, process_run_id,current_task,composer_name)
        print("configuration = ", configuration)
        print("load for the source file gs://" + bucketName + "/" + sourceFileObject, " is starting...")

        ##### header/footer code block start #####

        bq_hook = BigQueryHook(gcp_conn_id=variables[params["hook"]["gcp_conn_id"]])
        footer_trailor_count_from_file = False
        footer_regex_pattern = ""
        cntrl_trailor_count_from_file = False
        cntrl_header_trailor_count_from_file = False
        cntrl_regex_pattern = ""
        cntrl_header_regex_pattern = ""
        if "footer_counts_regex" in params["hook"] and str(params["hook"]["footer_counts_regex"]).strip() is not "":
            footer_trailor_count_from_file = True
            footer_regex_pattern = params["hook"]["footer_counts_regex"]
        if "cntrl_regex_pattern" in params["hook"] and str(params["hook"]["cntrl_regex_pattern"]).strip() is not "":
            cntrl_trailor_count_from_file = True
            cntrl_regex_pattern = params["hook"]["cntrl_regex_pattern"]
        if "cntrl_header_regex_pattern" in params["hook"] and str(params["hook"]["cntrl_header_regex_pattern"]).strip() is not "":
            cntrl_header_trailor_count_from_file = True
            cntrl_header_regex_pattern = params["hook"]["cntrl_header_regex_pattern"]
            print('cntrl_header_regex_pattern :',cntrl_header_regex_pattern)
        if "skip_footer" in params["hook"]:
            skip_footer = params["hook"]["skip_footer"]
        else:
            skip_footer = "false"
        if "footer_pattern" in params["hook"]:
            footer_pattern = params["hook"]["footer_pattern"]
        else:
            footer_pattern = "NOT_AVAILABLE"
        if "skip_header" in params["hook"]:
            skip_header = params["hook"]["skip_header"]
        else:
            skip_header = "false"
        if "header_pattern" in params["hook"]:
            header_pattern = params["hook"]["header_pattern"]
        else:
            header_pattern = "NOT_AVAILABLE"
        if "recipient_email" in params["hook"]:
            recipient_email = params["hook"]["recipient_email"]
        else:
            recipient_email = "na"
        if "cntrl_header" in params["hook"]:
            cntrl_header=params["hook"]["cntrl_header"]
        else:
            cntrl_header="false"
        if "cntrl_footer" in params["hook"]:
            cntrl_footer=params["hook"]["cntrl_footer"]
        else:
            cntrl_footer="false"

        gcs_hook = GCSHook(gcp_conn_id=variables[params["hook"]["gcp_conn_id"]])
        storage_client = storage.Client(credentials=gcs_hook.get_credentials())
        print("@@@@@@mysourceuris")
        sourceUris_processing_layer = []
        if isinstance(sourceUris, str):
            sourceUris_processing_layer = [sourceUris]
        else:
            sourceUris_processing_layer = sourceUris
        first_value = sourceUris_processing_layer[0]
        bucket_name_used = first_value.split("/")[2]
        bucket = storage_client.bucket(bucket_name_used)

        # if skip_header.lower() == 'true':
        #     for file in sourceUris_processing_layer:
        #         file = file.split(bucket_name_used + "/")[1]
        #         blob = bucket.blob(blob_name=file)
        #         blob.reload()
        #         if blob.size is None:
        #             raise ValueError("unable to get file size")
        #         size_in_mb = blob.size / (1024 * 1024)
        #         size_formatted = round(size_in_mb, 2)
        #         print("file size in mb formatted", size_formatted)
        #         if size_formatted > 100:
        #             raise ValueError("File size is greater than 100MB")
        #         else:
        #             audit_header_pattern = remove_header(blob, header_pattern, audit_logs, recipient_email, dagId,
        #                                                  variables, process_run_id, file, projectDetails)
        #             print("@@@@@", audit_header_pattern)
        #             if audit_header_pattern == "NULL":
        #                 audit_header_pattern = None
        #             elif audit_header_pattern is None:
        #                 raise ValueError("Header pattern not matching")
        #             audit_logs['header_record'] = audit_header_pattern
        # else:
        #     print("inside else")
        #     audit_logs['header_record'] = None
        #
        # if skip_footer.lower() == 'true' or footer_trailor_count_from_file:
        #     skip_footer_flag = False
        #     if skip_footer.lower() == 'true':
        #         skip_footer_flag = True
        #
        #     for file in sourceUris_processing_layer:
        #         file = file.split(bucket_name_used + "/")[1]
        #         blob = bucket.blob(blob_name=file)
        #         blob.reload()
        #         if blob.size is None:
        #             raise ValueError("unable to get file size")
        #         size_in_mb = blob.size / (1024 * 1024)
        #         size_formatted = round(size_in_mb, 2)
        #         print("file size in mb formatted", size_formatted)
        #         if size_formatted > 100:
        #             raise ValueError("File size is greater than 100MB")
        #         else:
        #             client = bigquery.Client(project=bq_hook._get_field("project"),
        #                                      credentials=bq_hook.get_credentials())
        #             footer_response = remove_footer(skip_footer_flag, blob, footer_pattern, audit_logs, recipient_email,
        #                                             dagId, variables,
        #                                             process_run_id, file, projectDetails,
        #                                             footer_trailor_count_from_file,
        #                                             footer_regex_pattern, client)
        #
        #             audit_footer_record = footer_response[0]
        #             footer_record_count = None
        #             file_record_count = None
        #             if footer_response[1] is not None:
        #                 footer_record_count = int(footer_response[1])
        #             if footer_response[2] is not None:
        #                 file_record_count = int(footer_response[2])
        #
        #             if footer_trailor_count_from_file:
        #                 if not footer_record_count == file_record_count:
        #                     if recipient_email != 'na':
        #                         dag = dagId
        #                         subject = f'BeamX|{variables["environment"]}|{process_run_id}'
        #                         msg = f"Trailor count validation failed "
        #                         recipient_email = recipient_email
        #                         html_content = f"""Hello Team,<br>
        #                                     &emsp;&emsp;&emsp;BeamX | {dagId} - {msg} in {file}."""
        #                         send_email_footer(recipient_email, subject, html_content, dag)
        #                         print("dag failed, email sent")
        #                     raise ValueError("Footer Trailor count not matching")
        #                 else:
        #                     print("trailer count validation successful")
        #             else:
        #                 print("Metadata json doesnt contain the trailor count regex pattern")
        #             print("footer response ", footer_response)
        #             print("@@@@@", audit_footer_record)
        #             if audit_footer_record == "NULL":
        #                 audit_footer_record = None
        #             elif audit_footer_record is None:
        #                 raise ValueError("Footer pattern not matching")
        #
        #             audit_logs['footer_record_count'] = footer_record_count
        #             audit_logs['file_record_count'] = file_record_count
        #             audit_logs['footer_record'] = audit_footer_record
        # else:
        #     print("inside else")
        #     audit_logs['footer_record'] = None

        ##### header/footer code block end #####
        print("audit logs --> ", audit_logs)
        if cntrl_header.lower() == 'true' or cntrl_header_trailor_count_from_file:
            controlFileObject = context['ti'].xcom_pull(key=f'preprocess_{group_id}'+"_controlFileObject")
            controlFileObject = controlFileObject[0]
            print("controlFileObject", controlFileObject)
            sourceBucket = bucketNameVars["SOURCE_URI_BUCKET"].split("/")[-1]
            print("sourceBucket", sourceBucket)
            gcs_hook = GCSHook(gcp_conn_id=variables[params["hook"]["gcp_conn_id"]])
            storage_client = storage.Client(credentials=gcs_hook.get_credentials())
            bucket_src = storage_client.bucket(sourceBucket)
            print("bucket", bucket_src)
            file = controlFileObject
            blob = bucket_src.blob(blob_name=controlFileObject)
            print("blob", blob)
            blob.reload()
            if blob.size is None:
                raise ValueError("unable to get file size")
            size_in_mb = blob.size/(1024*1024)
            size_formatted=round(size_in_mb,2)
            print("file size in mb formatted",size_formatted)
            if size_formatted > 100:
                raise ValueError("File size is greater than 100MB")
            else:
                client = bigquery.Client(project=bq_hook._get_field("project"), credentials=bq_hook.get_credentials())
                audit_cntrl_header = remove_cntrl_header(blob, audit_logs, dagId, variables, process_run_id, file,
                                                         projectDetails, cntrl_header_regex_pattern, client,
                                                         cntrl_header_trailor_count_from_file)
                print('audit_cntrl_header :: ', audit_cntrl_header)
                audit_cntrl_header_pattern = audit_cntrl_header[0]
                header_record_count = None
                file_record_count = None
                if audit_cntrl_header[1] is not None:
                    header_record_count = int(audit_cntrl_header[1])
                if audit_cntrl_header[2] is not None:
                    file_record_count = int(audit_cntrl_header[2])

                if cntrl_header_trailor_count_from_file:
                    if not header_record_count == file_record_count:
                        print("counter value from header and row count from file not matching")
                        if recipient_email != 'na':
                            dag = dagId
                            subject = f'BeamX|{variables["environment"]}|{process_run_id}'
                            msg = f"Control header value and file count validation failed "
                            recipient_email = recipient_email
                            html_content = f"""Hello Team,<br>
                                        &emsp;&emsp;&emsp;BeamX | {dagId} - {msg} in {file}."""
                            send_email_footer(recipient_email, subject, html_content, dag)
                            print("dag failed, email sent")
                        raise ValueError("Control header file count not matching with data file row count")
                    else:
                        print("Control header and file count validation successful")
                else:
                    print("Metadata json doesnt contain the control file count header regex pattern")
                print("@@@@@ audit_cntrl_header_pattern",audit_cntrl_header_pattern)
                if audit_cntrl_header_pattern == "NULL":
                    audit_cntrl_header_pattern = None
                elif audit_cntrl_header_pattern is None:
                    print("Header not present")
                audit_logs['header_cntrl_record']=audit_cntrl_header_pattern
        else:
            print("inside else")
            audit_logs['header_cntrl_record'] = None

        if cntrl_footer.lower() == 'true' or cntrl_trailor_count_from_file:
            cntrl_footer_flag = False
            if cntrl_footer.lower() == 'true':
               cntrl_footer_flag = True
            controlFileObject = context['ti'].xcom_pull(key=f'preprocess_{group_id}'+"_controlFileObject")
            controlFileObject = controlFileObject[0]
            sourceBucket = bucketNameVars["SOURCE_URI_BUCKET"].split("/")[-1]
            gcs_hook = GCSHook(gcp_conn_id=variables[params["hook"]["gcp_conn_id"]])
            storage_client = storage.Client(credentials=gcs_hook.get_credentials())
            bucket_src = storage_client.bucket(sourceBucket)
            file = controlFileObject
            blob = bucket_src.blob(blob_name=controlFileObject)
            blob.reload()
            for file in sourceUris_processing_layer:
                src_file = file.split(bucket_name_used + "/")[1]
                src_blob = bucket.blob(blob_name=src_file)
                src_blob.reload()
            if blob.size is None:
                raise ValueError("unable to get file size")
            size_in_mb = blob.size/(1024*1024)
            size_formatted=round(size_in_mb,2)
            print("file size in mb formatted",size_formatted)
            if size_formatted > 100:
                raise ValueError("File size is greater than 100MB")
            else:
                client = bigquery.Client(project=bq_hook._get_field("project"), credentials=bq_hook.get_credentials())
                audit_cntrl_footer=remove_cntrl_footer(cntrl_footer_flag,src_blob, blob,audit_logs,recipient_email,dagId,variables,process_run_id,file,projectDetails,cntrl_trailor_count_from_file,cntrl_regex_pattern, client,params)
                audit_cntrl_footer_pattern = audit_cntrl_footer[0]
                footer_record_count = None
                file_record_count = None
                if audit_cntrl_footer[1] is not None:
                    footer_record_count = int(audit_cntrl_footer[1])
                if audit_cntrl_footer[2] is not None:
                    file_record_count = int(audit_cntrl_footer[2])

                if cntrl_trailor_count_from_file:
                    if not footer_record_count == file_record_count:
                        if recipient_email != 'na':
                            dag = dagId
                            subject = f'BeamX|{variables["environment"]}|{process_run_id}'
                            msg = f"Control file count validation failed "
                            recipient_email = recipient_email
                            html_content = f"""Hello Team,<br>
                                        &emsp;&emsp;&emsp;BeamX | {dagId} - {msg} in {file}."""
                            send_email_footer(recipient_email, subject, html_content, dag)
                            print("dag failed, email sent")
                        raise ValueError("Control file count not matching with data file row count")
                    else:
                        print("Control file count validation successful")
                else:
                    print("Metadata json doesnt contain the control file count regex pattern")
                print("cntrl footer response ", audit_cntrl_footer_pattern)
                print("@@@@@ audit_cntrl_header_pattern",audit_cntrl_footer_pattern)
                if audit_cntrl_footer_pattern == "NULL":
                    audit_cntrl_footer_pattern = None
                elif audit_cntrl_footer_pattern is None:
                    print("footer not present")
                audit_logs['footer_cntrl_record']=audit_cntrl_footer_pattern
        else:
            print("inside else")
            audit_logs['footer_cntrl_record'] = None

        return {"sourceFileName": sourceFileName, "error_message": "NA", "run_status": "success",
                "bqInsertJobConfig": configuration, "audit_logs": audit_logs, "dict_obs": dict_obs,
                "process_run_id": process_run_id, "sourceFileName": sourceFileName, "tableId": tableId}
    except Exception as e:
        print("error occurred during pre-load activites for bq load: ", str(e))
        logging.error(traceback.format_exc())
        return {"sourceFileName": sourceFileName,
                "error_message": "error occurred during pre-load activites for bq load", "run_status": "failure",
                "audit_logs": audit_logs, "dict_obs": dict_obs, "process_run_id": process_run_id, "tableId": tableId}


"""
This function is for post gcsToBqLoad operations. It gets executed after the gcs to bq load using native operator is run
"""


def postLoad(context, group_id, variables, sourceFileObject, params, projectDetails, dagId, tz, opsgenie_priority, last_task,
             ingestionPattern, superGroupId, last_task_num, preLoadResult,alertTeamName,sub_lob_alert, fileSensorDetails=None):
    # get the variable map based on the project
    projectTag = projectDetails[0]
    project_space = projectDetails[2]
    varMap = variables[projectTag + "_vars"]

    # import the necessary modules
    BASE_DIR = "/home/airflow/gcs/dags/" + project_space+ "/beamx"
    sys.path.append(f"{BASE_DIR}/utils")
    from email_utility import send_email_footer
    import observability
    from ops_genie import send_alert_to_opsgenie

    # do xcom pull for gcs to bq load status
    gcsToBqLoadStatus = context['ti'].xcom_pull(key=f'{group_id}_loadStatus')
    errorDetails = context['ti'].xcom_pull(key=f'{group_id}_errorDetails')


    # required values from xcoms
    job_id = context['ti'].xcom_pull(task_ids=f'{group_id}.gcs_to_bq_load_bigquery_operator', key='job_id_path')
    job_id = job_id.split(":")[2] if job_id is not None else None

    print("job_id : ", job_id)
    process_run_id = preLoadResult['process_run_id']
    audit_logs = preLoadResult['audit_logs']
    print("audit_logs ", audit_logs)
    sourceFileName = preLoadResult['sourceFileName']
    tableId = preLoadResult['tableId']
    dict_obs = preLoadResult['dict_obs']

    if "*" in params['hook']['sourceUris']:
        last_task_name = last_task
        last_task = []
        group_id = superGroupId
        for last in last_task_name:
            last_task = []
            last_task.append(str(group_id + "." + last + '_' + str(last_task_num)))
    print("last_task is ", last_task)
    current_task = context['task'].task_id
    print("current_task is", current_task)

    # Process date, process hour extraction
    processDateAndTime = getProcessDateAndTime(sourceFileName, context, dict_obs,params)
    processDate = processDateAndTime[0]
    processTime = processDateAndTime[1]
    print("process date, process time :", processDate, processTime)

    #xcom push for queryParameters
    context['ti'].xcom_push(key="queryParameters", value = {'processDate':processDate, 'processTime':processTime, 'sourceFileName':sourceFileName})


    bq_hook = BigQueryHook(gcp_conn_id=variables[params["hook"]["gcp_conn_id"]])
    client = bigquery.Client(project=bq_hook._get_field("project"), credentials=bq_hook.get_credentials())

    try:
        query = f'''SELECT column_name FROM {varMap[params["hook"]["projectId"]]}.{varMap[params["hook"]["datasetId"]]}.INFORMATION_SCHEMA.COLUMNS WHERE table_name = '{tableId}';'''
        results = client.query(query).result()
        column_names = [row["column_name"] for row in results]
        if "batchid" in column_names:
            query1 = f'''update `{varMap[params["hook"]["projectId"]]}.{varMap[params["hook"]["datasetId"]]}.{tableId}` SET batchid ='{process_run_id}' where batchid is null; '''
            client.query(query1).result()
        run_status = "SUCCESS"
        error_msg = "None"
    except Exception as e:
        run_status = "FAILURE"
        error_msg = str(e)
        print("error_msg : ", error_msg)
        logging.error(traceback.format_exc())


    # send obs logs
    error_msg = errorDetails['error_msg'] if errorDetails is not None else 'none'
    gcs_to_bq_run_status = gcsToBqLoadStatus.upper() if gcsToBqLoadStatus is not None else "FAILURE"

    dict_obs = sendObsLogs(context, params, dict_obs, bq_hook, varMap, project_space, tz, processDate, processTime,
                           error_msg, gcs_to_bq_run_status, current_task, last_task)
    final_count = dict_obs['destination_count'] if 'destination_count' in dict_obs else '0'
    error_messages = "\"" + "\""
    bad_records = 0
    if job_id is not None:
        if ('storeErrorDetails' in params["hook"] and "TRUE" == params["hook"][
            'storeErrorDetails'].upper()) and run_status == "SUCCESS":
            print("extracting error messages")
            error_messages = store_error_messages(job_id, bq_hook, varMap, params)

        print("Checking for error count/bad records in current job")

        if ('error_count' in params["hook"] and "TRUE" == params["hook"][
            'error_count'].upper()) and run_status == "SUCCESS":

            print("Load Job Run status is success")
            bad_records = get_bad_records_from_api(job_id, bq_hook, variables, projectTag, varMap, params)
            print("number of bad records encountered during load job", bad_records)

        else:
            if run_status != "SUCCESS":
                print("Run status is not success")
            else:
                print("error_count is missing in params or its not set to true, "
                      "check the params if bad records needs to be captured in audit table")
    else:
        error_msg = "error occurred during pre-load activites for bq load"
        run_status = "FAILURE"

    if final_count != '0':
        if fileSensorDetails != None:

            if 'ctrlfile_object' in fileSensorDetails['retryInfo']:
                if fileSensorDetails['retryInfo']['cntrlfile_object'] != 'None':
                    print("inside check query count")
                    tableName = 'file_ingestion_stat_metadata'
                    datasetName = varMap['audit_db_td_bq']
                    base_filename = sourceFileObject + ".STAT"
                    bq_hook = BigQueryHook(gcp_conn_id=variables[params["hook"]["gcp_conn_id"]], use_legacy_sql=False,
                                           location='US')
                    project = bq_hook._get_field("project")
                    credentials = bq_hook.get_credentials()
                    client = bigquery.Client(project=bq_hook._get_field("project"),
                                             credentials=bq_hook.get_credentials())
                    query = f"""select recordcount from {project}.{datasetName}.{tableName} where filename = '{base_filename}'"""
                    print('query', query)
                    query_job = client.query(query, location="US")
                    rows = query_job.result()

                    print(rows)

                    for row in rows:
                        row_count = row["recordcount"]
                        print('count of rows', row_count)
                        if int(row_count) != int(final_count):
                            print("row_count in control", row_count)
                            print("row_count in staging", final_count)
                            run_status = "FAILURE"
                            error_msg = 'control file count mismatch'
                            print("error_msg : ", error_msg)

    # audit entry
    project_id = reduce(lambda key, value: key.replace(*value), varMap.items(), params["hook"]["projectId"])
    audit_db_td_bq = variables["audit_db_td_bq"]
    audit_logs.update(dict_obs)

    audit_logs["td_load_completion_timestamp"] = "None"
    audit_logs['project_id'] = project_id
    audit_logs['bq_dataset'] = audit_db_td_bq
    audit_logs['running_instance_id'] = process_run_id
    audit_logs['target_count'] = dict_obs['destination_count']
    audit_logs['sql_query'] = "None"
    audit_logs['bad_records_count'] = str(bad_records)
    audit_logs['error_messages'] = str(error_messages)
    print("audit logs are: ", audit_logs)

    ingestion_query = None
    try:
        ingestion_query = audit_log(params, variables, audit_logs)
    except Exception as e:
        error_msg = str(e)
        print("error while inserting into audit table: ", error_msg)
        logging.error(traceback.format_exc())
    audit_configuration = {}
    if ingestion_query is not None:
        audit_configuration = {
            "jobType": "QUERY",
            "query": {
                "query": ingestion_query,
                "useLegacySql": False,
            }
        }


    if gcs_to_bq_run_status == 'FAILURE' or run_status == 'FAILURE' :
        print("sending Opsgenie alert as BQ Load failed during insert... exiting")
        task_instance = context['task_instance']
        opsgenie_message = "Beamx|" + variables["environment"] + "|Failure|" + task_instance.task_id + "|" + dict_obs[
            'running_instance_id']
        opsgenie_description = "Failure | BQ Staging Load failed during insert Load run_status == 'FAILURE'|" + \
                               dict_obs['running_instance_id']
        # opsgenie_message = variables["environment"]+" Alert | BQ Staging Load failed during insert"
        # opsgenie_description = "BQ Load run_status == 'FAILURE'"
        opsgenie_details = {"DAG ID": dagId, "Error Step": "BQ Load", "Source Filename": sourceFileName,
                            "Table ID": varMap[params["hook"]["projectId"]] + "." + varMap[
                                params["hook"]["datasetId"]] + "." + params["hook"]["tableId"],
                            "Error Message": error_msg}
        send_alert_to_opsgenie(opsgenie_message, opsgenie_description, opsgenie_details, opsgenie_priority,
                               projectDetails=projectDetails,alertTeamName=alertTeamName,sub_lob_alert=sub_lob_alert)


    return {"audit_configuration":audit_configuration,"processDate": processDate, "processTime": processTime, "sourceFileName": sourceFileName,
            "error_message": 'NA', "run_status": 'success', "final_count": final_count}


"""
This function gets the list of source files in gcs inbound bucket that match the pattern specified by the user in metadata
"""


def getLatestFile(sourceObject, params, variables, bucketNameVars):
    # create a connection to gcs using GCSHook
    latestsourceobject = ""

    if ("*" in sourceObject):
        gcp_conn_id = variables[params["hook"]["gcp_conn_id"]]
        bucketName = bucketNameVars["SOURCE_URI_BUCKET"].split("/")[-1]
        gcs_hook = GCSHook(gcp_conn_id=gcp_conn_id)
        prefix = sourceObject.split("*")[0]
        storage_client = storage.Client(credentials=gcs_hook.get_credentials())
        bucket = storage_client.bucket(bucketName)
        blobs = list(bucket.list_blobs(prefix=prefix))
        latest_blob = max(blobs, key=lambda x: x.time_created)
        latestsourceobject = latest_blob.name
    else:
        latestsourceobject = sourceObject

    return latestsourceobject


def event_table_InsertConfiguration(dag_file_name, dag_name, source_uri, file_prefix, varMap, variables):
    event_table = '`' + varMap['projectId'] + '.' + varMap[
        'db_vzw_cja_env_tbls'] + '.event_based_trigger_metadata' + '`'
    print(event_table)
    bq_hook = BigQueryHook(variables['gcp_conn_id'], use_legacy_sql=False, location='US')
    sql = """
        SELECT *
        FROM {0}
        WHERE dag_name = '{2}'
        AND dag_file_name = '{1}'
        AND source_uri = '{3}'
        AND file_prefix = '{4}'
        """.format(event_table, dag_file_name, dag_name, source_uri, file_prefix)
    result = bq_hook.get_records(sql)
    print(result)
    if len(result) == 0:
        print("0 rows returned")
        insert_query = """
            Insert into {0} 
            SELECT
            '{1}'   AS dag_file_name,
            '{2}'   AS dag_name,
            '{3}'   AS source_uri,
            '{4}'   AS file_prefix

    """.format(event_table, dag_file_name, dag_name, source_uri, file_prefix)
        bq_cursor = bq_hook.get_cursor()
        bq_cursor.execute(insert_query)
        print("Insert into bq event trigger Entry done")
    if len(result) == 1:
        print("1 rows returned")
        print(result)
