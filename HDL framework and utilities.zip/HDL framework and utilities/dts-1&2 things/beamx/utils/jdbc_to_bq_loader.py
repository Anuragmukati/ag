"""
File Name: jdbc_to_bq_loader.py
Desciption: This is a python utility to load data from jdbc table to bigquery
"""

from datetime import datetime
from airflow.models import Variable
from airflow.exceptions import AirflowSkipException
from airflow.models import TaskInstance
from airflow.providers.google.cloud.hooks.bigquery import BigQueryHook
from airflow.providers.google.cloud.hooks.dataproc import DataprocHook
from airflow.providers.google.cloud.hooks.gcs import GCSHook
from google.cloud import storage
from datetime import date
from google.cloud import bigquery
from functools import reduce
import logging
import traceback
import sys
import json
import teradatasql
import oracledb
import base64
import pandas as pd
from datetime import date, timedelta, timezone, tzinfo
import pendulum
from airflow.models import DagRun
from airflow.models import XCom
from airflow.utils.session import  create_session
from google.cloud import secretmanager
import re
import pytz

tz = pendulum.timezone("EST")


def audit_log(params, variables, audit_logs):
    if "error_messages" not in audit_logs:
        audit_logs['error_messages'] = "\"" + "\""

    if "file_record_count" not in audit_logs:
        audit_logs['file_record_count'] = None

    if "footer_record_count" not in audit_logs:
        audit_logs['footer_record_count'] = None

    # application_id = str(datetime.now(tz).strftime("%Y%m%d%H%M%S"))
    application_id = audit_logs['running_instance_id']

    if 'error_msg' in audit_logs:
        error_msg = audit_logs['error_msg']
    elif 'error_message' in audit_logs:
        error_msg = audit_logs['error_message']

    if 'keyvalue' not in audit_logs:
        audit_logs['keyvalue'] = 'NA'
    if 'scheduler' not in audit_logs:
        audit_logs['scheduler'] = 'airflow'
    if 'source_environment' not in audit_logs:
        audit_logs['source_environment'] = 'NA'
    if 'target_environment' not in audit_logs:
        audit_logs['target_environment'] = 'NA'
    if 'source_servername' not in audit_logs:
        audit_logs['source_servername'] = 'NA'
    if 'target_servername' not in audit_logs:
        audit_logs['target_servername'] = 'NA'
    if 'source_type' not in audit_logs:
        audit_logs['source_type'] = 'Table'
    if 'target_type' not in audit_logs:
        audit_logs['target_type'] = 'Table'
    if 'bad_records_count' not in audit_logs:
        audit_logs['bad_records_count'] = 'NA'
    if 'footer_record' not in audit_logs:
        audit_logs['footer_record'] = 'NA'
    if 'header_record' not in audit_logs:
        audit_logs['header_record'] = 'NA'
    if 'footer_cntrl_record' not in audit_logs:
        audit_logs['footer_cntrl_record'] = 'NA'
    if 'header_cntrl_record' not in audit_logs:
        audit_logs['header_cntrl_record'] = 'NA'
    if 'source_count' not in audit_logs:
        audit_logs['source_count'] = 'NA'

    insert_query = """
            Insert into {0}.{1}.audit
            SELECT
            '{2}'   AS application_id,
            '{3}'   AS end_time,
            '{4}'   AS error_msg,
            '{0}'   AS gcp_project,
            '{5}'   AS inserted_timestamp,
            '{6}'   AS keyvalue,
            '{7}'   AS logger_name,
            '{8}'   AS process_date,
            '{9}'   AS process_name,
            '{10}'  AS project_name,
            '{11}'  AS run_date,
            '{12}'  AS run_day,
            '{13}'  AS run_hour,
            '{14}'  AS run_status,
            '{15}'  AS scheduler,
            '{16}'  AS source_environment,
            r'''{17}'''  AS source_name,
            '{18}'  AS source_servername,
            '{19}'  AS source_type,
            '{20}'  AS start_time,
            '{21}'  AS sub_process,
            '{22}'  AS system_name,
            '{23}'  AS target_count,
            '{24}'  AS target_environment,
            r'''{25}'''  AS target_name,
            '{26}'  AS target_servername,
            '{27}'  AS target_type,
            '{28}'  AS td_load_completion_timestamp,
            '{29}'  AS tool_name,
            '''{30}'''  AS sql_query,
            '{31}' as bad_records_count,
            r'''{32}'''  AS footer,
            r'''{33}'''  AS header,
            {34}  AS errors,
            '{35}'  AS file_record_count,
            '{36}'  AS footer_record_count,
            '{37}'  AS footer_cntrl_record,
            '{38}'  AS header_cntrl_record,
            '{39}' as source_count

    """.format(audit_logs['project_id'], audit_logs['bq_dataset'], application_id, audit_logs['end_time'], error_msg,
               audit_logs['inserted_timestamp'], audit_logs['keyvalue'], audit_logs['logger_name'],
               audit_logs['process_date'], audit_logs['process_name'], audit_logs['project_name'],
               audit_logs['run_date'], audit_logs['run_day'], audit_logs['run_hour'], audit_logs['run_status'],
               audit_logs['scheduler'], audit_logs['source_environment'], audit_logs['source_name'],
               audit_logs['source_servername'], audit_logs['source_type'], audit_logs['start_time'],
               audit_logs['sub_process'], audit_logs['system_name'], audit_logs['target_count'],
               audit_logs['target_environment'], audit_logs['target_name'], audit_logs['target_servername'],
               audit_logs['target_type'], audit_logs['td_load_completion_timestamp'], audit_logs['tool_name'],
               audit_logs['sql_query'], audit_logs['bad_records_count'], audit_logs['footer_record'],
               audit_logs['header_record'],
               audit_logs['error_messages'], audit_logs['file_record_count'], audit_logs['footer_record_count'],
               audit_logs['footer_cntrl_record'], audit_logs['header_cntrl_record'], audit_logs['source_count'])
    return insert_query

def get_secret_from_sm(project_id, secret_name,dpHook):
    client = secretmanager.SecretManagerServiceClient(credentials=dpHook.get_credentials())
    secret_name = f"projects/{project_id}/secrets/{secret_name}/versions/latest"
    response = client.access_secret_version(name=secret_name)
    return response.payload.data.decode("UTF-8")

"""
get the labels to be passed to the dataproc job
"""
def getLabelsDict(labelsList, dagId,run_id,task_id,composer_name):
    labels_dict = {
                        "job_id": dagId.lower()[-63:],
                        "task_type": "jdbc_to_bq",
                        "run_id" : re.sub(r'[^A-Za-z0-9 _-]+','',run_id).lower()[-63:],
                        "task_id": task_id.lower().replace('.',""),
                        "instance_name": composer_name.lower()
                    }
    # if labelsList:
    #     if isinstance (labelsList ,list):
    #         for label in labelsList:
    #             key = label.split(':')[0]
    #             value = label.split(':')[1]
    #             labels_dict[key] = value
    #     else:
    #         key = labelsList.split(':')[0]
    #         value = labelsList.split(':')[1]
    #         labels_dict[key] = value
    
    return labels_dict

"""
get the labels to be passed to the dataproc job
"""
def getLabelsDictServerless(labelsList, dagId,run_id,task_id,composer_name):
    labels_dict = {
                 "job_id": dagId.lower()[-63:],
                "task_type": "jdbc_to_bqserverless",
                "run_id" : re.sub(r'[^A-Za-z0-9 _-]+','',run_id).lower()[-63:],
                "task_id": task_id.lower().replace('.', "")[-63:],
                "instance_name": composer_name.lower()
            }
    # if labelsList:
    #     if isinstance (labelsList ,list):
    #         for label in labelsList:
    #             key = label.split(':')[0]
    #             value = label.split(':')[1]
    #             labels_dict[key] = value
    #     else:
    #         key = labelsList.split(':')[0]
    #         value = labelsList.split(':')[1]
    #         labels_dict[key] = value
    
    return labels_dict

"""
This function checks the max load_completion_timestamp of the source teradata table in the lookup table; If the max load_completion_timestamp is less than bq_load_completion_ts, this step returns failed status 
"""
def readLookUpTable(context, params, variables, varMap, dagId, projectDetails, tz, opsgenie_priority, **kwargs):
    dict_obs = context['ti'].xcom_pull(key=dagId,
                                       task_ids="startTask")
    # get the teradata table name details
    td_table = params["hook"]["lookup_table"]
    lookup_td_dbname = variables["lookup_td_dbname"]

    # get the project details
    project_tag = projectDetails[0]
    business_line = projectDetails[1]
    project_space = projectDetails[2]

    # import the necessary modules
    BASE_DIR = "/home/airflow/gcs/dags/"+project_space + "/beamx"
    sys.path.append(f"{BASE_DIR}/utils")
    from ops_genie import send_alert_to_opsgenie
    alertTeamName = kwargs['alertTeamName'] if 'alertTeamName' in kwargs else None
    sub_lob_alert = kwargs['sub_lob_alert'] if 'sub_lob_alert' in kwargs else None    
    task_instance =context['task_instance']
    retries=task_instance.max_tries
    source_dbtype = (params["hook"]["source_dbtype"].lower()).replace("postgresql", "postgres")
    db_instance = params["hook"]["dbinstance"] if "dbinstance" in params["hook"] else "default"
    db_config = variables[project_tag + '_db_config_jdbc_bq'][business_line] if business_line is not None else variables[
        project_tag + '_db_config_jdbc_bq']
    project_id = params["hook"]["projectId"]
    project_id = reduce(lambda key, value: key.replace(*value), varMap.items(), project_id)
    db_config = db_config[source_dbtype][db_instance]
    secret_name = db_config["secret_name"]
    dpHook = DataprocHook(gcp_conn_id=variables[params["hook"]["gcp_conn_id"]])
    payload=get_secret_from_sm(project_id,secret_name,dpHook)
    username,password = payload.strip().split(':')
    username = username.strip()
    password = password.strip()
    #username = Variable.get(db_config["username_key"])
    #password = Variable.get(db_config["password_key"])
    host_name = db_config['host_name']
    target_dbname = params["hook"]["target_dbname"]
    target_dbname = reduce(lambda key, value: key.replace(*value), varMap.items(), target_dbname)
    bq_dbname = project_id+"."+target_dbname
    audit_db_td_bq = variables["audit_db_td_bq"]
    final_target_table = params["hook"]["final_target_table"]
    context['ti'].xcom_push(key="final_target_table", value=final_target_table)

    # create a bigquery hook and establish a bq client
    bq_hook = BigQueryHook(gcp_conn_id=variables[params["hook"]["gcp_conn_id"]])
    client = bigquery.Client(project=bq_hook._get_field("project"), credentials=bq_hook.get_credentials())

    # read the lookup table in teradata to check max(load_completion_timestamp) of source teradata table
    try:
        query = f"SELECT max(load_completion_timestamp) from {lookup_td_dbname}.TABLE_LOAD_STATUS_V where TABLENAME = '{td_table}' "
        with teradatasql.connect(host=host_name, user=username, password=password) as connect:
            df = pd.read_sql(query, connect)
        td_load_completion_ts = str(df.iloc[0][-1])
        print("td_load_completion_ts :", td_load_completion_ts)
        context['ti'].xcom_push(key="td_load_completion_ts", value=td_load_completion_ts)
    except Exception as e:
        error_msg = str(e)
        logging.error(traceback.format_exc())
        task_instance =context['task_instance']
        opsgenie_message = "Beamx|"+variables["environment"]+"|Failure|"+task_instance.task_id+"|"+ dict_obs['running_instance_id']
        opsgenie_description = "Failure |Teradata Check Load Status == 'FAILURE'|" + dict_obs['running_instance_id']
        #opsgenie_message = variables["environment"] + " Alert |Teradata Load Status check failed...problem in connecting to teradata"
        #opsgenie_description = "Teradata Check Load Status == 'FAILURE'"
        opsgenie_details = {"DAG ID": dagId, "Error Step": "Teradata Load Status Check", "Error Message":error_msg}
        if (retries == 0 and task_instance.try_number == 1) or (retries > 0 and task_instance.try_number == retries + 1):
            send_alert_to_opsgenie(opsgenie_message, opsgenie_description, opsgenie_details, opsgenie_priority, projectDetails=projectDetails, alertTeamName=alertTeamName,sub_lob_alert=sub_lob_alert)
        return {'run_status': 'failure', 'error_message': error_msg}

    # get the bq_load_completion_ts using max(inserted_timestamp) of bigquery table
    bq_query = f"select TIMESTAMP(max(inserted_timestamp)) from {project_id}.{audit_db_td_bq}.audit where target_name = '{final_target_table}'  and run_status = 'SUCCESS'"
    df = client.query(bq_query).to_dataframe()
    bq_load_completion_ts = str(df.iloc[0][-1])

    # Condition to handle first load scenario
    if bq_load_completion_ts == "NaT":
        bq_load_completion_ts = "0000-00-00 00:00:00"

    print("bq_load_completion_ts: ", bq_load_completion_ts[0:19])
    print("td_load_completion_ts: ", td_load_completion_ts)

    # Compare source teradata latest load time and target bq latest load time
    if td_load_completion_ts > bq_load_completion_ts[0:19]:
        load_status = "Yes"
        print("load status: ", load_status)
    else:
        return {'run_status': 'failure', 'error_message': 'Bigquery table up to date...exiting'}
    return {'run_status': 'success', 'error_message': 'NA'}


"""
This function creates a touch file when called in the bucket specified
"""
def createTouchFile(context, params, variables, varMap, dagId, projectDetails, tz, opsgenie_priority, **kwargs):
    dict_obs = context['ti'].xcom_pull(key=dagId,
                                       task_ids="startTask")
    project_space = projectDetails[2]
    BASE_DIR = "/home/airflow/gcs/dags/" + project_space+ "/beamx"
    sys.path.append(f"{BASE_DIR}/utils")
    from ops_genie import send_alert_to_opsgenie
    alertTeamName = kwargs['alertTeamName'] if 'alertTeamName' in kwargs else None
    sub_lob_alert = kwargs['sub_lob_alert'] if 'sub_lob_alert' in kwargs else None
    task_instance =context['task_instance']
    retries=task_instance.max_tries
    try:
        # create a client to connect to GCS
        gcs_hook = GCSHook(gcp_conn_id=variables[params["hook"]["gcp_conn_id"]])
        credentials = gcs_hook.get_credentials()
        storage_client = storage.Client(credentials=credentials)
        bucket_name = variables['touch_file_bucket']
        bucket = storage_client.bucket(bucket_name)
        destination_blob_name = variables['touch_file_name']
        touch_file_path = variables['touch_file_path']
        target_table = params["hook"]["final_target_table"].upper()
        process_date = str(date.today().strftime("%Y-%m-%d"))
        blob = bucket.blob(f"{touch_file_path}/{target_table}/{process_date}/" + destination_blob_name)
        blob.upload_from_string('SUCCESS')
        
    except Exception as e:
        error_msg = str(e)
        logging.error(traceback.format_exc())
        sys.tracebacklimit = 0
        task_instance =context['task_instance']
        opsgenie_message = "Beamx|"+variables["environment"]+"|Failure|"+task_instance.task_id+"|"+ dict_obs['running_instance_id']
        opsgenie_description = f"Failure |Touch File {destination_blob_name} Creation Failed.Please create touch file in path {bucket_name}/{touch_file_path}/{target_table}/{process_date}|" + dict_obs['running_instance_id']
        #opsgenie_message = variables["environment"] + " Alert | Touch File Creation Failed"
        #opsgenie_description = f"Touch File {destination_blob_name} Creation Failed.Please create touch file in path {bucket_name}/{touch_file_path}/{target_table}/{process_date}"
        opsgenie_details = {"DAG ID": dagId, "Error Step": "Touch File Creation",
                         "Error Message": error_msg}
        if (retries == 0 and task_instance.try_number == 1) or (retries > 0 and task_instance.try_number == retries + 1):
            send_alert_to_opsgenie(opsgenie_message, opsgenie_description, opsgenie_details, opsgenie_priority, projectDetails=projectDetails, alertTeamName=alertTeamName,sub_lob_alert=sub_lob_alert)

"""
This function gets the static and the dynamic params to send to observability logs. The static params come from metadata and the dynamic params are calculated in this script at run time.
"""
def getObsParams(context, params, varMap, dict_obs, dagId, project_id, tz):

    # capturing obs static values
    dict_obs_static = json.loads(reduce(lambda key, value: key.replace(*value), varMap.items(), (str(params["obs"])).replace("'", '"')))

    # capturing obs dynamic values
    dict_obs["start_time"] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
    dict_obs["process_date"] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))[0:10]
    #dict_obs["run_date"] = str(datetime.now(tz).strftime('%Y%m%d'))
    #dict_obs["run_day"] = str(datetime.now(tz).strftime('%A'))
    #dict_obs["run_hour"] = str(datetime.now(tz).strftime("%H:%M:%S"))
    #run_hour = context['data_interval_end']
    #dict_obs["run_hour"] = str(run_hour.in_timezone(tz).strftime("%H:%M:%S"))
    data_interval_endtime = context['data_interval_end'].in_timezone(tz)
    dict_obs["run_date"] = str(data_interval_endtime.strftime('%Y%m%d'))
    dict_obs["run_day"] = str(data_interval_endtime.strftime('%A'))
    dict_obs["run_hour"] = str(data_interval_endtime.strftime("%H:%M:%S"))
    dict_obs["process_name"] = dagId 
    dict_obs["gcp_project"] = project_id
    dict_obs["target_type"] = "Table"
    dict_obs["log_file"] = varMap['log_file'] 

    # merge static and dynamic ob params
    dict_obs.update(dict_obs_static)
    return dict_obs

"""
Check the result of the previus step ie. readLookUpTable. If not success, send an alert and terminate the job. Else, proceed to bq load step. 
"""
def jdbcCheckLoadStatusResult(context, params, variables, varMap, dagId, projectDetails, tz, opsgenie_priority, dict_obs, **kwargs):

    # import the necessary modules
    project_space = projectDetails[2]
    BASE_DIR = "/home/airflow/gcs/dags/"+project_space + "/beamx"
    sys.path.append(f"{BASE_DIR}/utils")
    from ops_genie import send_alert_to_opsgenie
    alertTeamName = kwargs['alertTeamName'] if 'alertTeamName' in kwargs else None
    sub_lob_alert = kwargs['sub_lob_alert'] if 'sub_lob_alert' in kwargs else None
    task_instance =context['task_instance']
    retries=task_instance.max_tries
    source_table = params["hook"]["lookup_table"]
    upstreamTaskId = next(iter(context['task'].upstream_task_ids))
    print("upstream task id is :", upstreamTaskId)
    prevTaskRunState = (TaskInstance(context['dag'].get_task(upstreamTaskId), context['logical_date'] )). current_state()
    print("previous task run status is :", prevTaskRunState)

    if prevTaskRunState.lower() != 'success':
        sys.tracebacklimit = 0
        task_instance =context['task_instance']
        opsgenie_message = "Beamx|"+variables["environment"]+"|Failure|"+task_instance.task_id+"|"+ dict_obs['running_instance_id']
        opsgenie_description = f"Failure |Load Status Check Failed for {source_table}|" + dict_obs['running_instance_id']
        #opsgenie_message = variables["environment"]+" Alert | Load Status Check Criteria Failed"
        #opsgenie_description = f"Load Status Check Failed for {source_table}"
        opsgenie_details = {"DAG ID": dagId, "Error Step": "Load Status Check", "Source Table": source_table, "Error Message": "Teradata Table load not completed. Please follow up with source"}
        if (retries == 0 and task_instance.try_number == 1) or (retries > 0 and task_instance.try_number == retries + 1):
            send_alert_to_opsgenie(opsgenie_message, opsgenie_description, opsgenie_details, opsgenie_priority, projectDetails=projectDetails,alertTeamName=alertTeamName,sub_lob_alert=sub_lob_alert)
        return {"run_status": "failure", "error_message": "Load Status Check Criteria Failed...exiting"}

    return {"run_status": "success", "error_message": "none"}


"""
Send oservability logs to logger
"""
def sendObsLogs(params,variables, dict_obs, run_status, end_time, target_dbname, error_message, bq_table, project_id, project_space, tz):
    # import the necessary modules
    BASE_DIR = "/home/airflow/gcs/dags/"+project_space + "/beamx"
    sys.path.append(f"{BASE_DIR}/utils")
    from observability import jdbc_to_bq_obs
    
    # add additional run time parameters to send to observability
    dict_obs["process_end_time"] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
    dict_obs["error_message"] = error_message
    dict_obs["run_status"] = run_status
    dict_obs["end_time"] = end_time
    dict_obs["inserted_timestamp"] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
    gcp_conn_id = variables[params["hook"]["gcp_conn_id"]]

    # calling the logger method in observability module
    try:
        logs = jdbc_to_bq_obs(dict_obs, gcp_conn_id, project_id, target_dbname, bq_table)
    except Exception as e:
        logs = {}
        error_msg = str(e)
        print("error_msg : ", error_msg)
        logging.error(traceback.format_exc())
        print("Could not send observability log")

    return logs


"""
This function calls audit_log method which inserts a row with the necessary details in audit table for each run
"""
def auditTableEntry(context, params, variables, logs, project_id, audit_db_td_bq, dagId, jdbc_check_load_status, project_space,opsgenie_priority, projectDetails,tz, alertTeamName,sub_lob_alert):

    # import the necessary modules
    BASE_DIR = "/home/airflow/gcs/dags/" + project_space+ "/beamx"
    sys.path.append(f"{BASE_DIR}/utils")
    from audit import audit_log
    from ops_genie import send_alert_to_opsgenie
    DagRun_Details=DagRun.find(dag_id=f"{dagId}", state="running")
    if DagRun_Details:
        process_run_id= f"{dagId}_"+str(DagRun_Details[0].run_id)
        running_instance_id1= DagRun_Details[0].run_id
    else:
        process_run_id = f"{dagId}_"+str(datetime.now(tz).strftime("%Y%m%d%H%M%S"))
    running_instance_id = process_run_id
    task_instance =context['task_instance']
    retries=task_instance.max_tries
    logs["target_name"] = params["hook"]["target_table"]
    final_target_table = params["hook"]["final_target_table"] if "final_target_table" in params["hook"] else ""
    context['ti'].xcom_push(key="final_target_table", value=final_target_table)
    td_load_completion_timestamp = context['ti'].xcom_pull(key='td_load_completion_ts', task_ids='load_status') if jdbc_check_load_status == "yes" else "None"
    source_dbtype = params["hook"]["source_dbtype"].lower()
    logs["target_name"] = final_target_table
    logs["td_load_completion_timestamp"] = td_load_completion_timestamp
    logs['project_id'] = project_id
    logs['bq_dataset'] = audit_db_td_bq
    logs["running_instance_id"] = running_instance_id
    logs["sql_query"] = "None"
    if source_dbtype == 'teradata':
        try:
            audit_log(params, variables, logs)
        except Exception as e:
            error_msg = str(e)
            logging.error(traceback.format_exc())
            sys.tracebacklimit = 0
            task_instance =context['task_instance']
            opsgenie_message = "Beamx|"+variables["environment"]+"|Failure|"+task_instance.task_id+"|"+ running_instance_id1
            opsgenie_description = f"Failure|Insert into jdbc audit table {audit_db_td_bq}.audit failed. Please refer values in {logs}|" + running_instance_id1
            #opsgenie_message = variables["environment"] + " Alert | Insert into jdbc audit table failed"
            #opsgenie_description = f"Insert into jdbc audit table {audit_db_td_bq}.audit failed. Please refer values in {logs}"
            opsgenie_details = {"DAG ID": dagId, "Error Step": "Insert into jdbc audit table failed", "Error Message": error_msg}
            if (retries == 0 and task_instance.try_number == 1) or (retries > 0 and  task_instance.try_number == retries + 1):
                send_alert_to_opsgenie(opsgenie_message, opsgenie_description, opsgenie_details, opsgenie_priority, projectDetails=projectDetails, alertTeamName=alertTeamName,sub_lob_alert=sub_lob_alert)
            print("error message is: ",error_msg)

"""
This function returns the record count of the input query
"""
def getSourceQueryCount(context, params, host_name, username, password, query, variables, project_space, tz, dict_obs, opsgenie_priority, dagId, varMap, project_id, source_dbtype, port, SID, projectDetails, alertTeamName,sub_lob_alert):

    # import the necessary modules
    BASE_DIR = "/home/airflow/gcs/dags/" + project_space+ "/beamx"
    sys.path.append(f"{BASE_DIR}/utils")
    from ops_genie import send_alert_to_opsgenie
    from observability import ingestion_obs

    sql_keywords = ["join", "group by", "having"]
    task_instance =context['task_instance']
    retries=task_instance.max_tries
    if source_dbtype == "oracle":
        count_check_query = "select count(*) from " + query.lower().split("from")[-1]
        if "where" in count_check_query:
            count_check_query = count_check_query.split("where")[0] + " " + "WHERE ROWNUM <= 1;"
    else:
        count_check_query = "select cast(count(*) as bigint) from " + query.lower().split("from")[-1]

    if query.lower().count("select") > 1 or query.lower().count("from") > 1:
        if source_dbtype == "oracle":
            count_check_query = f"select count(*) from ({query}) a"
        else:
            count_check_query = f"select cast(count(*) as bigint) from ({query}) a"
    else:
        for keyword in sql_keywords:
            if keyword in query.lower():
                if source_dbtype == "oracle":
                    count_check_query = f"select count(*) from ({query}) a"
                else:
                    count_check_query = f"select cast(count(*) as bigint) from ({query}) a"
                break
    print("count_check_query: ", count_check_query)

    # Check the count returned by query
    if source_dbtype == "oracle":
        try:
            with oracledb.connect(host=host_name, port=port, service_name=SID, user=username, password=password) as connect:
                df = pd.read_sql(count_check_query, connect)
                record_count = df.iloc[0][-1]
        except Exception as e:
            print("Error in oracle conn ", str(e))
            record_count = 1
            error_msg = str(e)
            logging.error(traceback.format_exc())
    else:
        try:
            with teradatasql.connect(host=host_name, user=username, password=password) as connect:
                df = pd.read_sql(count_check_query, connect)
                record_count = df.iloc[0][-1]
        except Exception as e:
            record_count = 1
            error_msg = str(e)
            logging.error(traceback.format_exc())
    
    if not record_count > 0:
        message = "count_check_query result is 0, No results returned by query, hence skipping the load step"
        print(message)
        try:
            # get obs static and dynamic parameters
            dict_obs = getObsParams(context, params, varMap, dict_obs, dagId, project_id, tz)
            logger_name = params["obs"]["logger_name"]
            dict_obs["error_message"] = message
            dict_obs["run_status"] = "SKIPPED"
            dict_obs["end_time"] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
            dict_obs["process_end_time"] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
            dict_obs["inserted_timestamp"] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
            ingestion_obs(dict_obs, logger_name)
        except Exception as e:
            print("error_msg : ", str(e))
            logging.error(traceback.format_exc())
            print("Could not send observability log")
        task_instance =context['task_instance']
        opsgenie_message = "Beamx|"+variables["environment"]+"|Skipped|"+task_instance.task_id+"|"+ dict_obs['running_instance_id']
        opsgenie_description = "Skipped|count_check_query result is 0, No results returned by query, hence skipping the load step|" + dict_obs['running_instance_id']
        #opsgenie_message = variables["environment"] + " Alert | No rows returned by input query"
        #opsgenie_description = "count_check_query result is 0, No results returned by query, hence skipping the load step"
        opsgenie_details = {"DAG ID": dagId, "Error Step": "jdbc to BQ Load",
                            "Error Message": message}
        if (retries == 0 and task_instance.try_number == 1) or (retries > 0 and task_instance.try_number == retries + 1):
            if 'skipped_alert' in params['hook']:
                if params['hook']['skipped_alert'].lower() == 'yes':
                    print("Skipped Alert sending")
                    if (retries == 0 and task_instance.try_number == 1) or (retries > 0 and  task_instance.try_number == retries + 1):
                        send_alert_to_opsgenie(opsgenie_message, opsgenie_description, opsgenie_details, opsgenie_priority, projectDetails=projectDetails, alertTeamName=alertTeamName,sub_lob_alert=sub_lob_alert)
        raise AirflowSkipException
    return record_count

def replace_query_xcom(context, query):
    print("Existing query ", query)
    ti = context["ti"]
    dag_id = context["dag"]._dag_id
    print("Dag id", dag_id)
    result = ti.xcom_pull(dag_id=dag_id, key='bq_result',include_prior_dates=False)
    print("Xcom record ...", result)

    if result and len(result[0].items()) > 0:
        print("Xcom record is not empty and length of result is - ", len(result[0].items()))
        record_dict = result[0].items()
        for key, value in record_dict:
            print(f"Key -- {key} , Value -- {value}")

        records_xcom = dict(map(lambda x: ('${xcom_' + x[0] + '}', x[1]), record_dict))
        query = reduce(lambda key, value: key.replace(*value), records_xcom.items(), query)
        print("Query .... ", query)
        return query
    else:
        print("Xcom record is empty or there is no result from BQ")
        return query

def clean_bq_result_xcom(ti):
    print("Deleting the bq_result_xcom")
    with create_session() as session:
        xcom_value = session.query(XCom).filter(
            XCom.key == 'bq_result',
            XCom.dag_id == ti.dag_id
        ).delete()
    session.commit()
    print("bq_result Xcom deleted... - session committed")

