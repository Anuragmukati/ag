from __future__ import annotations

from typing import Any

import google.auth
from google.auth.transport.requests import AuthorizedSession
import requests
from airflow.hooks.base_hook import BaseHook
from google.auth import credentials
from google.oauth2 import service_account
from google.auth import impersonated_credentials
from airflow.providers.google.cloud.hooks.gcs import GCSHook
import time
import json

AUTH_SCOPE = "https://www.googleapis.com/auth/cloud-platform"
CREDENTIALS, _ = google.auth.default(scopes=[AUTH_SCOPE])


def make_composer2_web_server_request(
        url: str, method: str = "GET", credentials: Any = None, **kwargs: Any
) -> google.auth.transport.Response:
    """
    Make a request to Cloud Composer 2 environment's web server.
    Args:
      url: The URL to fetch.
      method: The request method to use ('GET', 'OPTIONS', 'HEAD', 'POST', 'PUT',
        'PATCH', 'DELETE')
      **kwargs: Any of the parameters defined for the request function:
                https://github.com/requests/requests/blob/master/requests/api.py
                  If no timeout is provided, it is set to 90 by default.
    """
    print("new cred ")
    authed_session = AuthorizedSession(credentials)

    # Set the default timeout, if missing
    if "timeout" not in kwargs:
        kwargs["timeout"] = 90

    return authed_session.request(method, url, **kwargs)


def trigger_dag(**kwargs):

    variables = kwargs["variables"]
    params = kwargs["params"]
    dag_id = kwargs["dag_id"]
    endpoint = f"api/v1/dags/{dag_id}/dagRuns"
    gcs_hook = GCSHook(gcp_conn_id=variables["gcp_conn_id"])
    credentials = gcs_hook.get_credentials()
    request = google.auth.transport.requests.Request()
    credentials.refresh(request)
    if "hook" in params and "composer_url" in params["hook"]:
        web_server_url = variables["composer_instance_endpoints"][params["hook"]["composer_url"]]
    else:
        web_server_url = variables["composer_url"]


    request_url = f"{web_server_url}/{endpoint}"
    json_data = {"conf": {}}

    response = make_composer2_web_server_request(
        request_url, method="POST", credentials=credentials, json=json_data
    )

    if response.status_code == 403:
        raise requests.HTTPError(
            "You do not have a permission to perform this operation. "
            "Check Airflow RBAC roles for your account."
            f"{response.headers} / {response.text}"
        )
    elif response.status_code != 200:
        raise requests.HTTPError(
            "error occured while triggering the dag"
            f"{response.headers} / {response.text}"
        )
    else:
        print(f"successfully triggered dag - {dag_id}, response data - {response.text}")
        if "hook" in params and "wait_for_completion" in params["hook"] and str(params["hook"]["wait_for_completion"]).lower() == "true":
            while True:
                dag_run_id = json.loads(response.text)["dag_run_id"]
                request_url = f"{web_server_url}/{endpoint}/{dag_run_id}"
                response_state = make_composer2_web_server_request(
                    request_url, method="GET", credentials=credentials
                )
                state = json.loads(response_state.text)["state"]
                if str(state).lower() == "success":
                    print("triggered dag successfully completed")
                    return response.text
                if str(state).lower() == "failed":
                    print("triggered dag failed")
                    raise requests.HTTPError(
                        "the external triggered dag failed"
                        f"{response_state.headers} / {response_state.text}"
                    )
                    return response.text
                print("waiting for the triggered dag to complete")
                time.sleep(30)

        return response.text
