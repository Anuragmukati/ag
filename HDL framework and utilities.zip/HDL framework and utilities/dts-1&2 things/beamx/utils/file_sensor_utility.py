
from datetime import datetime
from datetime import date, timedelta, timezone, tzinfo
from airflow.providers.google.cloud.hooks.gcs import GCSHook
from ops_genie import send_alert_to_opsgenie
import traceback
import logging
import bq_loader

def touchFileSuccess(context, params, variables, projectDetails, touchFile, tz):
    print("touch file was successfully detected")
    import observability

    projectTag = projectDetails[0]
    varMap = variables[projectTag + "_vars"]
    dict_obs = context['ti'].xcom_pull(key="dict_obs")

    # push file sensor details to xcom
    taskId = context['task_instance'].task_id
    context['ti'].xcom_push(key="touch_file", value = touchFile)

    task_instance = context['task_instance']
    retries = task_instance.max_tries
    # dict_obs_static = str(params["obs"])
    # dict_obs_static = json.loads(
    #     (reduce(lambda key, value: key.replace(*value), varMap.items(), dict_obs_static)).replace("'", '"'))
    # dict_obs.update(dict_obs_static)
    dict_obs["process_date"] = str(date.today().strftime("%Y-%m-%d"))
    data_interval_endtime = context['data_interval_end'].in_timezone(tz)
    dict_obs["run_date"] = str(data_interval_endtime.strftime('%Y%m%d'))
    dict_obs["run_day"] = str(data_interval_endtime.strftime('%A'))
    dict_obs["run_hour"] = str(data_interval_endtime.strftime("%H:%M:%S"))
    dict_obs["error_message"] = "Touch File Detected"
    dict_obs["run_status"] = "Success"
    dict_obs["log_file"] = varMap['log_file']
    try:
        ## passing the process end time based on that task sequence in the dag ##
        logger_name = "dof_gcp_process_log"
        dict_obs["inserted_timestamp"] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
        observability.filecheck_obs(dict_obs, logger_name)
    except Exception as e:
        error_msg = str(e)
        print("error_msg : ", error_msg)
        print("Could not send observability log")
        

def touchFileFailure(context, params, variables, projectDetails, touchFile, dagId,tz, opsgenie_priority=None, alertTeamName=None):
    print("Touch file was not detected")

    # import the necessary modules
    import observability

    projectTag = projectDetails[0]
    varMap = variables[projectTag + "_vars"]
    dict_obs = context['ti'].xcom_pull(key="dict_obs")
    task_instance = context['task_instance']
    retries = task_instance.max_tries

    # push file sensor details to xcom
    taskId = context['task_instance'].task_id
    context['ti'].xcom_push(key="touch_file", value = touchFile)

    # send opsgenie alert
    opsgenie_message = "Beamx|" + variables["environment"] + "|FileWatcher|" + task_instance.task_id + "|" + dict_obs[
        'running_instance_id']
    opsgenie_description = "Filewatcher Failure|Touch File was not detected|" + dict_obs['running_instance_id']
    opsgenie_details = {"DAG ID": dagId, "Error Step": " File Check", "Error Message": "Touch File was not detected"}

    send_alert_to_opsgenie(opsgenie_message, opsgenie_description, opsgenie_details, opsgenie_priority, projectDetails=projectDetails, alertTeamName=alertTeamName)

    # send obs params
    # dict_obs_static = str(params["obs"])
    # dict_obs_static = json.loads(
    #     (reduce(lambda key, value: key.replace(*value), varMap.items(), dict_obs_static)).replace("'", '"'))
    # dict_obs.update(dict_obs_static)
    print("Touch file was not detected")
    dict_obs["process_date"] = str(date.today().strftime("%Y-%m-%d"))
    data_interval_endtime = context['data_interval_end'].in_timezone(tz)
    dict_obs["run_date"] = str(data_interval_endtime.strftime('%Y%m%d'))
    dict_obs["run_day"] = str(data_interval_endtime.strftime('%A'))
    dict_obs["run_hour"] = str(data_interval_endtime.strftime("%H:%M:%S"))
    dict_obs["error_message"] = "File was not detected"
    dict_obs["run_status"] = "Failure"
    dict_obs["log_file"] = varMap['log_file']
    try:
        ## passing the process end time based on that task sequence in the dag ##
        logger_name = "dof_gcp_process_log"
        dict_obs["inserted_timestamp"] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
        observability.filecheck_obs(dict_obs, logger_name)
    except Exception as e:
        error_msg = str(e)
        print("error_msg : ", error_msg)
        logging.error(traceback.format_exc())
        print("Could not send observability log")


def fileSensorSuccess(context, params, variables, projectDetails, fileSensorDetails, tz):
    import observability

    projectTag = projectDetails[0]
    varMap = variables[projectTag + "_vars"]
    dict_obs = context['ti'].xcom_pull(key="dict_obs")

    # push file sensor details to xcom
    taskId = context['task_instance'].task_id
    context['ti'].xcom_push(key="fileSensorDetails", value = fileSensorDetails)

    task_instance = context['task_instance']
    retries = task_instance.max_tries
    # dict_obs_static = str(params["obs"])
    # dict_obs_static = json.loads(
    #     (reduce(lambda key, value: key.replace(*value), varMap.items(), dict_obs_static)).replace("'", '"'))
    # dict_obs.update(dict_obs_static)
    dict_obs["process_date"] = str(date.today().strftime("%Y-%m-%d"))
    data_interval_endtime = context['data_interval_end'].in_timezone(tz)
    dict_obs["run_date"] = str(data_interval_endtime.strftime('%Y%m%d'))
    dict_obs["run_day"] = str(data_interval_endtime.strftime('%A'))
    dict_obs["run_hour"] = str(data_interval_endtime.strftime("%H:%M:%S"))
    dict_obs["error_message"] = "File Detected"
    dict_obs["run_status"] = "Success"
    dict_obs["log_file"] = varMap['log_file']
    try:
        ## passing the process end time based on that task sequence in the dag ##
        dict_obs["inserted_timestamp"] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
        observability.filecheck_obs(dict_obs, logger_name)
    except Exception as e:
        error_msg = str(e)
        print("error_msg : ", error_msg)
        print("Could not send observability log")


def fileSensorFailure(context, params, variables, projectDetails, fileSensorDetails, dagId,tz, opsgenie_priority=None, alertTeamName=None):
    print("file was not detected")

    # import the necessary modules
    import observability

    projectTag = projectDetails[0]
    varMap = variables[projectTag + "_vars"]
    dict_obs = context['ti'].xcom_pull(key="dict_obs")
    task_instance = context['task_instance']
    retries = task_instance.max_tries

    # push file sensor details to xcom
    taskId = context['task_instance'].task_id
    context['ti'].xcom_push(key="fileSensorDetails", value = fileSensorDetails)

    # send opsgenie alert
    opsgenie_message = "Beamx|" + variables["environment"] + "|FileWatcher|" + task_instance.task_id + "|" + dict_obs[
        'running_instance_id']
    opsgenie_description = "Filewatcher Failure|File was not detected|" + dict_obs['running_instance_id']
    opsgenie_details = {"DAG ID": dagId, "Error Step": " File Check", "Error Message": "File was not detected"}

    send_alert_to_opsgenie(opsgenie_message, opsgenie_description, opsgenie_details, opsgenie_priority,
                           projectDetails=projectDetails, alertTeamName=alertTeamName)

    # send obs params
    # dict_obs_static = str(params["obs"])
    # dict_obs_static = json.loads(
    #     (reduce(lambda key, value: key.replace(*value), varMap.items(), dict_obs_static)).replace("'", '"'))
    # dict_obs.update(dict_obs_static)
    print("file was not detected")
    dict_obs["process_date"] = str(date.today().strftime("%Y-%m-%d"))
    data_interval_endtime = context['data_interval_end'].in_timezone(tz)
    dict_obs["run_date"] = str(data_interval_endtime.strftime('%Y%m%d'))
    dict_obs["run_day"] = str(data_interval_endtime.strftime('%A'))
    dict_obs["run_hour"] = str(data_interval_endtime.strftime("%H:%M:%S"))
    dict_obs["error_message"] = "File was not detected"
    dict_obs["run_status"] = "Failure"
    dict_obs["log_file"] = varMap['log_file']
    try:
        ## passing the process end time based on that task sequence in the dag ##
        dict_obs["inserted_timestamp"] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
        observability.filecheck_obs(dict_obs, logger_name)
    except Exception as e:
        error_msg = str(e)
        print("error_msg : ", error_msg)
        logging.error(traceback.format_exc())
        print("Could not send observability log")

def fileCountSensorFailure(context, params, variables, projectDetails, fileSensorDetails, dagId,tz, opsgenie_priority=None, alertTeamName=None):
    print("file count sensor failed")
    task_instance = context['task_instance']
    retries = task_instance.max_tries
    opsgenie_message = "Beamx|" + variables["environment"] + "|FileCountCheck|" + task_instance.task_id + "|" + \
                       dict_obs['running_instance_id']
    opsgenie_description = "File count sensor Failure|Expected file count didnot match|" + dict_obs[
        'running_instance_id']
    opsgenie_details = {"DAG ID": dagId, "Error Step": "FileCountSensor", "Error Message": "File count sensor failed"}

    send_alert_to_opsgenie(opsgenie_message, opsgenie_description, opsgenie_details, opsgenie_priority,
                           projectDetails=projectDetails, alertTeamName=alertTeamName)

def cntrlFileSensorSucess(context, params, variables, projectDetails,fileSensorDetails, tz):
    from control_file_loader import upload_control_file
    import observability

    upload_control_file(context,variables,bucketNameVars,fileSensorDetails,projectDetails)
    projectTag = projectDetails[0]
    varMap = variables[ projectTag+"_vars"]
    dict_obs = context['ti'].xcom_pull(key="dict_obs")
    task_instance =context['task_instance']
    retries=task_instance.max_tries

    # send dict_obs to obs
    # dict_obs_static = str(params["obs"])
    # dict_obs_static = json.loads((reduce(lambda key, value: key.replace(*value), varMap.items(), dict_obs_static)).replace("'", '"'))
    # dict_obs.update(dict_obs_static)
    dict_obs["process_date"] = str(date.today().strftime("%Y-%m-%d"))
    data_interval_endtime = context['data_interval_end'].in_timezone(tz)
    dict_obs["run_date"] = str(data_interval_endtime.strftime('%Y%m%d'))
    dict_obs["run_day"] = str(data_interval_endtime.strftime('%A'))
    dict_obs["run_hour"] = str(data_interval_endtime.strftime("%H:%M:%S"))
    dict_obs["end_time"] = datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S")
    dict_obs["error_message"] = "Control File Detected"
    dict_obs["run_status"] = "Success"
    dict_obs["log_file"] = varMap['log_file']
    try:
        ## passing the process end time based on that task sequence in the dag ##
        dict_obs["inserted_timestamp"] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
        observability.filecheck_obs(dict_obs, logger_name)
    except Exception as e:
        error_msg = str(e)
        print("error_msg : ", error_msg)
        print("Could not send observability log")


def cntrlFileSensorFailure(context, params, variables, projectDetails,dagId,tz , opsgenie_priority=None, alertTeamName=None):
    # import the necessary modules
    import observability

    projectTag = projectDetails[0]
    varMap = variables[ projectTag+"_vars"]
    dict_obs = context['ti'].xcom_pull(key="dict_obs")

    print("file was not detected")
    task_instance =context['task_instance']
    retries=task_instance.max_tries

    # send ops genie alert
    opsgenie_message = "Beamx|"+variables["environment"]+"|FileWatcher|"+task_instance.task_id+"|"+ dict_obs['running_instance_id']
    opsgenie_description = "Filewatcher | File was not detected|" + dict_obs['running_instance_id']
    opsgenie_details = {"DAG ID": dagId, "Error Step": " File Check", "Error Message": "control File was not detected"}
    opsgenie_priority = "{{ opsgeniePriority }}"
    alertTeamName = "{{ alertTeamName }}"

    send_alert_to_opsgenie(opsgenie_message, opsgenie_description, opsgenie_details, opsgenie_priority, projectDetails=projectDetails,alertTeamName=alertTeamName)

    # send obs params
    # dict_obs_static = str(params["obs"])
    # dict_obs_static = json.loads((reduce(lambda key, value: key.replace(*value), varMap.items(), dict_obs_static)).replace("'", '"'))
    # dict_obs.update(dict_obs_static)
    print("file was not detected")
    dict_obs["process_date"] = str(date.today().strftime("%Y-%m-%d"))
    data_interval_endtime = context['data_interval_end'].in_timezone(tz)
    dict_obs["run_date"] = str(data_interval_endtime.strftime('%Y%m%d'))
    dict_obs["run_day"] = str(data_interval_endtime.strftime('%A'))
    dict_obs["run_hour"] = str(data_interval_endtime.strftime("%H:%M:%S"))
    dict_obs["error_message"] = "Control File was not detected"
    dict_obs["run_status"] = "Failure"
    dict_obs["log_file"] = varMap['log_file']
    try:
        ## passing the process end time based on that task sequence in the dag ##
        dict_obs["inserted_timestamp"] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
        observability.filecheck_obs(dict_obs, logger_name)
    except Exception as e:
        error_msg = str(e)
        print("error_msg : ", error_msg)
        logging.error(traceback.format_exc())
        print("Could not send observability log")


def CheckfileCount(context, params, variables, bucket_name, fileSensorDetails, tz):
    sensor_object_values = fileSensorDetails['retryInfo']['object']
    file_sensor_object = bq_loader.replaceParametersWithRunDate(sensor_object_values,context,params,tz)
    file_sensor_object = file_sensor_object[0]
    expected_file_count = int(fileSensorDetails['retryInfo']['number_of_files'] or 0 )
    print(f"expected file count: {expected_file_count}")
    gcs_hook = GCSHook(gcp_conn_id= variables["gcp_conn_id"])
    prefix = file_sensor_object.rsplit('/', 1)[0] if "/" in file_sensor_object else ""
    matching_files = gcs_hook.list(bucket_name=bucket_name, prefix=prefix,match_glob=file_sensor_object)
    actual_file_count = len(set(matching_files))
    print(f"file list : {file_sensor_object}")
    print(f"found files : {matching_files}")
    print(f"expected file count : {expected_file_count}")
    print(f"actual file count : {actual_file_count}")
    if actual_file_count >= expected_file_count or expected_file_count == 0:
        print("File count condition met..")
        return True
    else:
        return False
    
