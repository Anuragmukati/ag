from airflow.models import XCom
from airflow.models import TaskInstance
from airflow.exceptions import AirflowSkipException,AirflowFailException


def pushFailureStatus(context):
    context['ti'].xcom_push(key=f"dag_status", value=False)


def pushLoadStatusResult(context, load_status_prefix, status):
    context['ti'].xcom_push(key=load_status_prefix+"_loadStatus", value=status)

def get_all_upstream_task_ids(task):
    upstream_task_ids = set()
    for upstream_task in task.get_direct_relatives(upstream=True):
        upstream_task_ids.add(upstream_task.task_id)
    return upstream_task_ids


def getPreviousTaskLoadStatus(context):
    task = context["task"]
    upstream_task_ids = get_all_upstream_task_ids(task)
    load_status = context['ti'].xcom_pull(key="load_status", task_ids=upstream_task_ids)
    print("load_status : ", load_status)
    return load_status


def evaluateDagStatus(context):

    dag_status = context['ti'].xcom_pull(key=f"dag_status",task_ids=None)
    print("dag_status",dag_status)
    if (dag_status is False):
        raise AirflowFailException("Failure in one of the tasks...marking dag as failed")
    elif dag_status is None:
        print("All tasks ran successfully...marking dag as success")
        return
    elif(dag_status[0] is False):
        raise AirflowFailException("Failure in one of the tasks..marking dag as failed")
    else:
        print("All tasks ran successfully...marking dag as success")


def multiFileTaskGroupStatus(context,task_id):

    gcsToBqTaskIdRunState = context['ti'].xcom_pull(key='multitaskgroupstatus')
    taskgrpstatus = context['ti'].xcom_pull(key='taskgrpstatus')
    taskgrpsuccess = context['ti'].xcom_pull(key='taskgrpsuccess')
    if taskgrpstatus is not None and taskgrpstatus =='failure':
        raise AirflowFailException("skipping as one of the task group failed")
    elif gcsToBqTaskIdRunState is not None and gcsToBqTaskIdRunState.lower() == 'skipped' and taskgrpsuccess is None:
        raise AirflowSkipException("skipping as the upstream skipped")
    elif gcsToBqTaskIdRunState is not None and gcsToBqTaskIdRunState.lower() == 'skipped' and taskgrpsuccess.lower() == 'success':
        pass
    elif gcsToBqTaskIdRunState is not None and gcsToBqTaskIdRunState.lower() != 'success':
        raise AirflowFailException(" gcs to bq job failed")

