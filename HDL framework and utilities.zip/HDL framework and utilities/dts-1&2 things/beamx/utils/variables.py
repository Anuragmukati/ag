# import yaml
#
# import os
#
#
#
# def getVariables(projectDetails):
#     projectTag = projectDetails[0]
#     businessLine = projectDetails[1]
#     projectSpace = projectDetails[2]
#     BASE_DIR = "/home/airflow/gcs/dags/" + projectSpace + "/beamx"
#
#
#     # read the variables from yaml file
#     yaml_path = '/config/frameworkVariables.yaml'
#     try:
#         with open(f"{BASE_DIR}{yaml_path}", 'r') as file:
#             data = yaml.safe_load(file)
#             gcp_project=os.environ['GCP_PROJECT']
#         if gcp_project in data["project"]:
#             if projectSpace in data["project"][gcp_project]:
#                 variables = data["project"][gcp_project][projectSpace]
#     except:
#         variables = None
#         print("Error while reading yaml config file...please check")
#
#     return variables


import yaml

import os


def mergeVariables(dpfVariables, userVariables, projectTag):
    mergedvariables = dpfVariables.copy()

    varMapKey = projectTag + "_vars"

    mergedvariables[varMapKey].update(userVariables[varMapKey])

    for key in userVariables:
        if key not in mergedvariables:
            mergedvariables[key] = userVariables[key]
    return mergedvariables

def getVariables(projectDetails, instanceName=None):
    projectTag = projectDetails[0]
    businessLine = projectDetails[1]
    projectSpace = projectDetails[2]
    BASE_DIR = "/home/airflow/gcs/dags/" + projectSpace  + "/beamx"


    # read the variables from yaml file
    dpf_yaml_path = '/config/beamxVariables.yaml'
    users_yaml_path = '/config/userVariables.yaml'
    if instanceName == None:
        instanceName = "default"
    try:
        with open(f"{BASE_DIR}{dpf_yaml_path}", 'r') as file:
            data = yaml.safe_load(file)
            gcp_project=os.environ['GCP_PROJECT']
        if gcp_project in data["project"]:
            if projectSpace in data["project"][gcp_project]:
                dpfVariables = data["project"][gcp_project][projectSpace]
    except:
        dpfVariables = None
        print("Error while reading DPF yaml config file...please check")

    try:
        with open(f"{BASE_DIR}{users_yaml_path}", 'r') as file:
            users_data = yaml.safe_load(file)
            gcp_project=os.environ['GCP_PROJECT']
        if gcp_project in data["project"]:
            if projectSpace in data["project"][gcp_project]:
                userVariables = users_data["project"][gcp_project][projectSpace]
    except:
        userVariables = None
        print("Error while reading users yaml config file...please check")

    try:
        variables = mergeVariables(dpfVariables,userVariables, projectTag)
    except:
        variables = None
        print("Error while merging dpf and users yaml config file...please check")

    return variables
