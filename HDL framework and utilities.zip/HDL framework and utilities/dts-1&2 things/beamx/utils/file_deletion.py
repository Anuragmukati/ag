"""
File Name: file_deletion.py
Description: This python script is used to delete the source files in gcs after data is ingested into BQ table.
"""

from airflow.providers.google.cloud.hooks.gcs import GCSHook
from airflow.models import TaskInstance
import re

""""
File Deletion process takes place in this function.
"""
def singleSrcFileDeletion_gcs_td(context, params, variables,ingestionpattern = None):
    array_objects = []
    #get the upstream task id and its run state
    upstreamTaskId = next(iter(context['task'].upstream_task_ids))
    print("upstream task id is :", upstreamTaskId)
    fileCompressionType = context['ti'].xcom_pull(task_ids=upstreamTaskId, key ='file_compression_type')
    logicalDate = context['logical_date']

    print('ingestionpattern',ingestionpattern)
    if ingestionpattern and 'nos_td_to_bq' in ingestionpattern:
        try:
            gcsToBqTaskId = (context['ti'].task_id).replace("file_deletion_nos_", "") + '.gcs_to_bq_load_bigquery_operator'
            prevTaskRunState = (TaskInstance(context['dag'].get_task(gcsToBqTaskId), context['logical_date'])).current_state()
            gcs_to_bq_status = str(prevTaskRunState).lower()
            print('gcs_to_bq_status',gcs_to_bq_status)
            context['ti'].xcom_push(key='gcs_to_bq_status_nos', value=gcs_to_bq_status)
        except Exception as e:
            pass
    prevTaskRunState = (TaskInstance(context['dag'].get_task(upstreamTaskId), logicalDate)).current_state()
    print("previous task run status is :", prevTaskRunState)
    #get the required details for archival
    sourceBucket = params["hook"]["gcs_bucket"]
    sourceFileObject = params["hook"]["gcs_path"]
    object_pattern = '/'.join(params["hook"]["gcs_path"].split('/')[:-1])
    print("object_pattern",object_pattern)
    #connect to gcs
    gcs_hook = GCSHook(gcp_conn_id = variables[params["hook"]["gcp_conn_id"]])
    objects = gcs_hook.list(bucket_name=sourceBucket)
    for obj in objects:
        if re.match(object_pattern,obj):
            array_objects.append(obj)
    print(array_objects)
    for arr in array_objects:
        gcs_hook.delete(bucket_name=sourceBucket, object_name=arr)
        print("file '{}' deleted..".format(arr))


def singleSrcFileDeletion(context, params, variables,ingestionpattern = None):
    array_objects = []
    #get the upstream task id and its run state
    upstreamTaskId = next(iter(context['task'].upstream_task_ids))
    print("upstream task id is :", upstreamTaskId)
    fileCompressionType = context['ti'].xcom_pull(task_ids=upstreamTaskId, key ='file_compression_type')
    logicalDate = context['logical_date']

    print('ingestionpattern',ingestionpattern)
    if ingestionpattern and 'nos_td_to_bq' in ingestionpattern:
        try:
            gcsToBqTaskId = (context['ti'].task_id).replace("file_deletion_nos_", "") + '.gcs_to_bq_load_bigquery_operator'
            prevTaskRunState = (TaskInstance(context['dag'].get_task(gcsToBqTaskId), context['logical_date'])).current_state()
            gcs_to_bq_status = str(prevTaskRunState).lower()
            print('gcs_to_bq_status',gcs_to_bq_status)
            context['ti'].xcom_push(key='gcs_to_bq_status_nos', value=gcs_to_bq_status)
        except Exception as e:
            pass
    prevTaskRunState = (TaskInstance(context['dag'].get_task(upstreamTaskId), logicalDate)).current_state()
    print("previous task run status is :", prevTaskRunState)
    #get the required details for archival
    sourceBucket = params["hook"]["gcs_bucket"]
    sourceFileObject = params["hook"]["gcs_path"]
    object_pattern = '/'.join(params["hook"]["gcs_path"].split('/')[:-1])
    
    object_pattern_temp = params["hook"]["gcs_path"]
    #object_pattern_temp = object_pattern_temp.split("/",1)[1]
        
    print("object_pattern: ", object_pattern)
    print("object_pattern_temp: ", object_pattern_temp)
    if "*" in object_pattern_temp:
        prefix = object_pattern_temp.split("*")[0]
    else:
        prefix = object_pattern_temp[:object_pattern_temp.rfind("/")+1] if "/" in object_pattern_temp else ""
    
    print("Updated prefix in file_deletion: ", prefix)
    #connect to gcs
    gcs_hook = GCSHook(gcp_conn_id = variables[params["hook"]["gcp_conn_id"]])
    # objects = gcs_hook.list(bucket_name=sourceBucket)
    # for obj in objects:
    #     if re.match(object_pattern,obj):
    #         array_objects.append(obj)


    array_objects = gcs_hook.list(bucket_name=sourceBucket, prefix=prefix, match_glob=object_pattern_temp)
    print("array_objects: ", array_objects)
    for arr in array_objects:
        gcs_hook.delete(bucket_name=sourceBucket, object_name=arr)
        print("file '{}' deleted..".format(arr))
