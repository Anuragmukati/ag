"""
File Name: file_preprocessing.py
Description: Tis python utility is used to trigger a cloud function for file preprocessing based on the type and size of the file

"""
import os
import json
import logging
import traceback
import sys
import requests
from datetime import datetime
from datetime import date, timedelta, timezone, tzinfo
import google.oauth2.id_token
import google.auth.transport.requests
from airflow.providers.google.cloud.hooks.gcs import GCSHook
from airflow.providers.google.cloud.hooks.dataproc import DataprocHook
from airflow.providers.google.cloud.hooks.functions import CloudFunctionsHook
import base64
import pendulum
from google.auth import impersonated_credentials
from airflow.exceptions import AirflowSkipException, AirflowFailException
from airflow.providers.google.cloud.operators.dataproc import DataprocSubmitJobOperator
from google.cloud import storage
from google.cloud import dataproc_v1
from google.cloud import bigquery
from datetime import datetime
from datetime import date, timedelta, timezone, tzinfo
import pendulum
import logging
import traceback
import gzip
import unlzw3
import zipfile
import tarfile
import io
import os
import pandas as pd
import numpy as np
import gcsfs
import sys
import tempfile
import re
import fnmatch

"""
This method is used to fetch credentials that are passed to udf in dag
"""


def getCredentials(params, variables):
    credentials = (GCSHook(api_version='v2', gcp_conn_id=variables[params["hook"]["gcp_conn_id"]])).get_credentials()
    return credentials


def checkFileCompression(sourceBucket, variables, sourceFileObject, params, dagId, projectSpace, project):
    #magicDict = {
    #    b'\x1f\x8b\x08': "gz",
    #    b'\x50\x4b\x03\x04': "zip"
    #}
    #maxLen = max(len(x) for x in magicDict)
    #fileCompressionType = "no match"
    #try:
    #    # fs = gcsfs.GCSFileSystem(project=project)
    #    gcp_conn_id = variables[params["hook"]["gcp_conn_id"]]
    #   gcs_hook = GCSHook(gcp_conn_id=gcp_conn_id)
    #    credentials = gcs_hook.get_credentials()
    #    file_content = gcs_hook.download(bucket_name=sourceBucket, object_name=sourceFileObject)
    #    fileStart = file_content[:maxLen]
    #    print("file start bytes :", fileStart)
    #    for magic, compressionType in magicDict.items():
    #        if fileStart.startswith(magic):
    #            fileCompressionType = compressionType
    #            break
    #    if (sourceFileObject.lower()).endswith('.z'):
    #        fileCompressionType = 'unix compressed'
    fileCompressionType = "no match"
    try:
        if (sourceFileObject.lower()).endswith('.gz') and not sourceFileObject.lower().endswith('.tar.gz'):
            fileCompressionType = 'gz'
        elif (sourceFileObject.lower()).endswith('.zip'):
            fileCompressionType = 'zip'
        elif (sourceFileObject.lower()).endswith('.z'):
            fileCompressionType = 'unix compressed'
        else:
            fileCompressionType = "no match"
    except Exception as e:
        error_msg = str(e)
        logging.error(traceback.format_exc())
        opsgenie_params = {
            'opsgenie_message': variables[
                                    "environment"] + " Alert | Failure while checking the source file compression format",
            'opsgenie_description': "Failure while checking the source file compression format",
            'opsgenie_details': {"DAG ID": dagId, "Error Step": "Preprocessing",
                                 "File Location": "gs://" + sourceBucket + "/" + sourceFileObject,
                                 "Error Message": error_msg}
        }
        runtime_error_msg = 'Failure while checking the source file compression format... exiting'
        return {'run_status': 'failure', 'error_msg': error_msg, 'traceback': traceback.format_exc(),
                'runtime_error_msg': runtime_error_msg, 'fileCompressionType': "no match", 'pp_status': 'none',
                'opsgenie_params': opsgenie_params}
    return {'run_status': 'success', 'error_msg': 'none', 'traceback': 'none', 'runtime_error_msg': 'none',
            'pp_status': 'none', 'fileCompressionType': fileCompressionType, 'opsgenie_params': 'none'}


"""
This function untars the source file in inbound bucket and copies the untar file to processing bucket
"""


def untar(sourceBucket, processBucket, variables, sourceFileObject, params, dagId, projectSpace, project):
    '''
    preprocessing for tar.gz : untar and move the file to process bucket
    '''
    gcp_conn_id = variables[params["hook"]["gcp_conn_id"]]
    gcs_hook = GCSHook(gcp_conn_id=gcp_conn_id)
    credentials = gcs_hook.get_credentials()
    input_bucket = storage_client.bucket(sourceBucket)
    output_bucket = storage_client.get_bucket(processBucket)
    try:
        input_blob = input_bucket.get_blob(sourceFileObject).download_as_string()
        tar = tarfile.open(fileobj=io.BytesIO(input_blob), mode='r')
        print("File(s) to be extracted:", tar.getnames())
        for member in tar.getnames():
            print("starting extraction")
            file_object = tar.extractfile(member)
            print("extraction done")
            if file_object:
                print("uploading extracted file to the bucket...")
                output_blob = output_bucket.blob(os.path.join(sourceFileObject, member.replace("./", "")))
                output_blob.upload_from_string(file_object.read())
    except Exception as e:
        error_msg = str(e)
        logging.error(traceback.format_exc())
        opsgenie_params = {
            'opsgenie_message': variables["environment"] + " Alert | Failure while processing the tar file",
            'opsgenie_description': "Failure while extracting file(s) from tar.gz/tar file",
            'opsgenie_details': {"DAG ID": dagId, "Error Step": "Preprocessing",
                                 "File Location": "gs://" + sourceBucket + "/" + sourceFileObject,
                                 "Error Message": error_msg}
        }
        runtime_error_msg = 'Failure while extracting file(s) from tar.gz file... exiting'
        return {'run_status': 'failure', 'error_msg': error_msg, 'traceback': traceback.format_exc(),
                'runtime_error_msg': runtime_error_msg, 'pp_status': 'none', 'opsgenie_params': opsgenie_params}
    return {'run_status': 'success', 'error_msg': 'none', 'traceback': 'none', 'runtime_error_msg': 'none',
            'pp_status': 'done', 'opsgenie_params': 'none'}


def triggerfilesplittingCloudFn(cloudFnParams, target_principal, audience, target_scopes, projectDetails, project_id,
                                region, cloud_fn, context, alertTeamName,sub_lob_alert):
    # import the necessary modules
    BASE_DIR = "/home/airflow/gcs/dags/" + cloudFnParams['projectSpace']
    sys.path.append(f"{BASE_DIR}/utils")
    from ops_genie import send_alert_to_opsgenie
    task_instance = context['task_instance']
    retries = task_instance.max_tries

    gcs_hook = GCSHook(gcp_conn_id=cloudFnParams['variables']['gcp_conn_id'])
    source_credentials = gcs_hook.get_credentials()
    print("function url :", audience)
    target_credentials = impersonated_credentials.Credentials(
        source_credentials=source_credentials,
        target_principal=target_principal,
        target_scopes=target_scopes,
        lifetime=300)
    tokenCredential = impersonated_credentials.IDTokenCredentials(target_credentials, target_audience=audience)
    request = google.auth.transport.requests.Request()
    tokenCredential.refresh(request)
    TOKEN = tokenCredential.token
    try:
        # cloud_function_hook=CloudFunctionsHook(api_version='v1',gcp_conn_id=cloudFnParams['variables']['gcp_conn_id'])
        # response=cloud_function_hook.call_function(function_id=cloud_fn,input_data={"data": json.dumps({"cloudFnParams": cloudFnParams})},location=region,project_id=project_id)

        getenv = os.getenv('no_proxy')
        new_proxy = audience.replace('https://', '')
        getenv += "," + new_proxy
        print("no_proxy is: ", getenv)
        os.environ['no_proxy'] = getenv
        # audience='https://dpf-file-file_splitting-gen2-kafhktey4q-uk.a.run.app'
        response = requests.post(audience,
                                 headers={'Authorization': f"Bearer {TOKEN}", "Content-Type": "application/json"},
                                 data=json.dumps({"cloudFnParams": cloudFnParams}))
    except Exception as e:
        error_msg = str(e)
        logging.error(traceback.format_exc())
        opsgenie_message = "Beamx|" + cloudFnParams['variables']["environment"] + "|FileWatcher|File Splitting|"
        opsgenie_description = "Failure |Failure while invoking the file_splitting cloud function|"
        opsgenie_details = {"DAG ID": cloudFnParams['dagId'], "Error Step": "file_splitting",
                            "File Location": "gs://" + cloudFnParams['sourceBucket'] + "/" + cloudFnParams[
                                'sourceFileObject'], "Error Message": error_msg}
        if (retries == 0 and task_instance.try_number == 1) or (
                retries > 0 and task_instance.try_number == retries + 1):
            send_alert_to_opsgenie(opsgenie_message, opsgenie_description, opsgenie_details,
                                   cloudFnParams['opsgenie_priority'], projectDetails=projectDetails,
                                   alertTeamName=alertTeamName,sub_lob_alert=sub_lob_alert)
        sys.tracebacklimit = 0
        raise AirflowFailException("Failure while invoking the file_splitting cloud function...exiting")
    print("http response status code: ", response.status_code)
    print("Response text is: ", response.text)
    print("Response JSON is: ", response.json())
    # response_text=json.loads(response.json())
    response_text = response.json()
    print("response_text is: ", response_text)
    if response_text['run_status'] != 'success':
        print(response_text)
        # response = json.loads(response.text)
        print('error message :', response_text['error_msg'])
        # logging.error(response['traceback'])
        print("cloud function execution failed.. please check the logs")
        assert str(response_text['opsgenie_params']) != 'none'
        opsgenie_params = response_text['opsgenie_params']
        if (retries == 0 and task_instance.try_number == 1) or (
                retries > 0 and task_instance.try_number == retries + 1):
            send_alert_to_opsgenie(opsgenie_params['opsgenie_message'], opsgenie_params['opsgenie_description'],
                                   opsgenie_params['opsgenie_details'], cloudFnParams['opsgenie_priority'],
                                   projectDetails=projectDetails, alertTeamName=alertTeamName,sub_lob_alert=sub_lob_alert)
        sys.tracebacklimit = 0
        raise AirflowFailException(response_text['runtime_error_msg'])

    # response = json.loads(response.text)
    print("file_splitting cloud function returned value : ", response)
    if response_text['run_status'] == 'failure':
        print('error message :', response_text['error_msg'])
        raise AirflowFailException(response_text['runtime_error_msg'])
    return response_text


def triggerPreprocessingCloudFn(cloudFnParams, target_principal, audience, target_scopes, projectDetails, project_id,
                                region, cloud_fn, context, alertTeamName,sub_lob_alert):
    # import the necessary modules
    BASE_DIR = "/home/airflow/gcs/dags/" + cloudFnParams['projectSpace']
    sys.path.append(f"{BASE_DIR}/utils")
    from ops_genie import send_alert_to_opsgenie
    task_instance = context['task_instance']
    retries = task_instance.max_tries
    gcs_hook = GCSHook(gcp_conn_id=cloudFnParams['variables']['gcp_conn_id'])
    source_credentials = gcs_hook.get_credentials()
    print("function url :", audience)
    target_credentials = impersonated_credentials.Credentials(
        source_credentials=source_credentials,
        target_principal=target_principal,
        target_scopes=target_scopes,
        lifetime=300)
    tokenCredential = impersonated_credentials.IDTokenCredentials(target_credentials, target_audience=audience)
    request = google.auth.transport.requests.Request()
    tokenCredential.refresh(request)
    TOKEN = tokenCredential.token
    try:
        # cloud_function_hook=CloudFunctionsHook(api_version='v1',gcp_conn_id=cloudFnParams['variables']['gcp_conn_id'])
        # response=cloud_function_hook.call_function(function_id=cloud_fn,input_data={"data": json.dumps({"cloudFnParams": cloudFnParams})},location=region,project_id=project_id)

        getenv = os.getenv('no_proxy')
        new_proxy = audience.replace('https://', '')
        getenv += "," + new_proxy
        print("no_proxy is: ", getenv)
        os.environ['no_proxy'] = getenv
        # audience='https://dpf-file-preprocessing-gen2-kafhktey4q-uk.a.run.app'
        response = requests.post(audience,
                                 headers={'Authorization': f"Bearer {TOKEN}", "Content-Type": "application/json"},
                                 data=json.dumps({"cloudFnParams": cloudFnParams}))
    except Exception as e:
        error_msg = str(e)
        logging.error(traceback.format_exc())
        opsgenie_message = "Beamx|" + cloudFnParams['variables'][
            "environment"] + "|Failure|Preprocessing cloud function|"
        opsgenie_description = "Failure |Failure while invoking the preprocessing cloud function|"
        opsgenie_details = {"DAG ID": cloudFnParams['dagId'], "Error Step": "Preprocessing",
                            "File Location": "gs://" + cloudFnParams['sourceBucket'] + "/" + cloudFnParams[
                                'sourceFileObject'], "Error Message": error_msg}
        if (retries == 0 and task_instance.try_number == 1) or (
                retries > 0 and task_instance.try_number == retries + 1):
            send_alert_to_opsgenie(opsgenie_message, opsgenie_description, opsgenie_details,
                                   cloudFnParams['opsgenie_priority'], projectDetails=projectDetails,
                                   alertTeamName=alertTeamName,sub_lob_alert=sub_lob_alert)
        sys.tracebacklimit = 0
        raise AirflowFailException("Failure while invoking the preprocessing cloud function...exiting")
    print("http response status code: ", response.status_code)
    print("Response text is: ", response.text)
    print("Response JSON is: ", response.json())
    # response_text=json.loads(response.json())
    response_text = response.json()
    print("response_text is: ", response_text)
    context['ti'].xcom_push(key = 'audit_logs', value = response_text['audit_logs'])
    if response_text['run_status'] != 'success':
        print(response_text)
        # response = json.loads(response.text)
        print('error message :', response_text['error_msg'])
        # logging.error(response['traceback'])
        print("cloud function execution failed.. please check the logs")
        assert str(response_text['opsgenie_params']) != 'none'
        opsgenie_params = response_text['opsgenie_params']
        if (retries == 0 and task_instance.try_number == 1) or (
                retries > 0 and task_instance.try_number == retries + 1):
            send_alert_to_opsgenie(opsgenie_params['opsgenie_message'], opsgenie_params['opsgenie_description'],
                                   opsgenie_params['opsgenie_details'], cloudFnParams['opsgenie_priority'],
                                   projectDetails=projectDetails, alertTeamName=alertTeamName,sub_lob_alert=sub_lob_alert)
        sys.tracebacklimit = 0
        raise AirflowFailException(response_text['runtime_error_msg'])

    # response = json.loads(response.text)
    print("preprocessing cloud function returned value : ", response)
    if response_text['run_status'] == 'failure':
        print('error message :', response_text['error_msg'])
        raise AirflowFailException(response_text['runtime_error_msg'])
    return response_text


def preProcessingOnDataproc(sourceBucket, processBucket, variables, sourceFileObject, params, dagId, projectSpace,
                            project, tz, fileCompressionType):
    try:
        cluster_label = variables['dataproc_config_file_preprocessing']['cluster_label']
        region = variables['dataproc_config_file_preprocessing']["region"]
        job_id = dagId.lower() + '_' + str(datetime.now(tz).strftime("%Y%m%d%H%M%S"))
        tempFolder = (sourceFileObject.split("/")[-1]).split('.')[0]
        sourceFileName = sourceFileObject.split("/")[-1]
        pyspark_job_config = {"reference": {"project_id": project, "job_id": job_id},
                              "placement": {"cluster_labels": cluster_label},
                              "labels": {
                                  "job_name": dagId.lower(),
                                  "job_type": "file_preprocessing",
                                  "job_mode": "modern"
                              },
                              "pyspark_job": {
                                  "main_python_file_uri": variables['dataproc_config_file_preprocessing']['scriptPath'],
                                  "args": [sourceBucket, sourceFileObject, tempFolder, sourceFileName, processBucket,
                                           fileCompressionType]
                              }
                              }
        return {"run_status": "success", "error_message": "NA",
                "pysparkJobConfig": pyspark_job_config, "sourceFileName": sourceFileName, "region": region,
                "sourceBucket": sourceBucket, "processBucket": processBucket,
                "variables": variables, "sourceFileObject": sourceFileObject, "params": params, "dagId": dagId,
                "projectSpace": projectSpace, "project": project, "tz": tz, "fileCompressionType": fileCompressionType}


    except Exception as e:
        error_msg = str(e)
        logging.error(traceback.format_exc())
        opsgenie_params = {
            'opsgenie_message': variables["environment"] + " Alert | Failure during untar process",
            'opsgenie_description': "Failure while extracting the tar file",
            'opsgenie_details': {"DAG ID": dagId, "Error Step": "Preprocessing",
                                 "File Location": "gs://" + sourceBucket + "/" + sourceFileObject,
                                 "Error Message": error_msg}
        }
        runtime_error_msg = 'Failure while extracting the tar file... exiting'
        return {'run_status': 'failure', 'error_msg': error_msg, 'traceback': traceback.format_exc(),
                'runtime_error_msg': runtime_error_msg, 'pp_status': 'none', 'opsgenie_params': opsgenie_params}


"""
file preprocessing function
"""


def fileUnzip(sourceBucket, processBucket, variables, sourceFileObject, params, dagId, projectSpace,
              fileCompressionType, project):
    """
    Decompression logic to unzip a file based on the compression format
    """
    storage_client = storage.Client(project=project)
    source_bucket = storage_client.get_bucket(sourceBucket)
    output_bucket = storage_client.get_bucket(processBucket)
    blob = source_bucket.blob(sourceFileObject)
    compressedData = io.BytesIO(blob.download_as_string())

    try:
        if fileCompressionType == 'zip':
            with zipfile.ZipFile(compressedData, 'r') as zip_file:
                for fileName in zip_file.namelist():
                    content = zip_file.read(fileName)
                    output_blob = output_bucket.blob(os.path.join(sourceFileObject, fileName))
                    output_blob.upload_from_string(content)
                    print("unzipped file sent to process bucket")

        elif fileCompressionType == 'gz':
            '''
            with gzip.open(compressedData) as gz:
                file = gz.read()
                content = file.decode('utf-8')
                print(type(content))
                print("decompression of data is done")
                fileName = (sourceFileObject.split('/')[-1]).rsplit('.', 1)[0]
                output_blob = output_bucket.blob(os.path.join(sourceFileObject, fileName))
                output_blob.upload_from_string(content)
                print("unzipped file sent to process bucket")
            '''
            fileName = (sourceFileObject.split('/')[-1]).rsplit('.', 1)[0]
            print(f"processing file ->> {fileName}")
            tempFilePath = tempfile.gettempdir()
            tempFile = os.path.join(tempFilePath, fileName)
            inputBlob = source_bucket.blob(sourceFileObject)
            inputBlob.download_to_filename(tempFile)
            outputBlob = output_bucket.blob(os.path.join(sourceFileObject, fileName))
            with gzip.open(tempFile, 'rb') as decompressedFile:
                outputBlob.upload_from_file(decompressedFile)

        elif fileCompressionType == 'unix compressed':
            fs = gcsfs.GCSFileSystem(project=project)
            with fs.open(sourceBucket + '/' + sourceFileObject, 'rb') as fh:
                compressed_data = fh.read()
                uncompressed_data = unlzw3.unlzw(compressed_data)
                fileName = (sourceFileObject.split('/')[-1]).rsplit('.', 1)[0]
                output_blob = output_bucket.blob(os.path.join(sourceFileObject, fileName))
                output_blob.upload_from_string(uncompressed_data)
                print("unzipped file sent to process bucket")

    except Exception as e:
        error_msg = str(e)
        logging.error(traceback.format_exc())
        opsgenie_params = {
            'opsgenie_message': variables[
                                    "environment"] + " Alert | Failure while unzipping the compressed source file",
            'opsgenie_description': "Failure while unzipping the compressed source file",
            'opsgenie_details': {"DAG ID": dagId, "Error Step": "Preprocessing",
                                 "File Location": "gs://" + sourceBucket + "/" + sourceFileObject,
                                 "Error Message": error_msg}
        }
        runtime_error_msg = 'Failure while unzipping the compressed source file... exiting'
        return {'run_status': 'failure', 'error_msg': error_msg, 'traceback': traceback.format_exc(),
                'runtime_error_msg': runtime_error_msg, 'pp_status': 'none', 'opsgenie_params': opsgenie_params}
    return {'run_status': 'success', 'error_msg': 'none', 'traceback': 'none', 'runtime_error_msg': 'none',
            'pp_status': 'done', 'opsgenie_params': 'none'}


def preprocessing(context, bucketNameVars, variables, sourceFileObject, params, dagId, projectDetails,fileCompressionType,opsgenie_priority, **kwargs):
    sourceBucket = bucketNameVars["SOURCE_URI_BUCKET"].split("/")[-1]
    processBucket = bucketNameVars["PROCESS_BUCKET"].split("/")[-1]
    pp_status = 'none'
    alertTeamName = kwargs['alertTeamName'] if 'alertTeamName' in kwargs else None
    sub_lob_alert = kwargs['sub_lob_alert'] if 'sub_lob_alert' in kwargs else None
    # get the variable map based on the project
    projectTag = projectDetails[0]
    projectSpace = projectDetails[2]
    varMap = variables[projectTag + "_vars"]
    fileCompressionType = fileCompressionType

    # create a gcs hook to connect to gcs and get credentials
    gcs_hook = GCSHook(gcp_conn_id=variables[params["hook"]["gcp_conn_id"]])
    credentials = gcs_hook.get_credentials()
    project = gcs_hook._get_field("project")

    tz = kwargs['tz'] if 'tz' in kwargs else pendulum.timezone("UTC")
    taskType = kwargs['taskType'] if 'taskType' in kwargs else 'none'

    if "replacechar" in kwargs:
        replacechar = kwargs['replacechar']
    else:
        replacechar = None
    if "removechar" in kwargs:
        removechar = kwargs['removechar']
    else:
        removechar = ' '

    # checking if preprocessing should be skipped
    if 'skipPreProcessing' in params['hook']:
        if params['hook']['skipPreProcessing'].lower() == 'true':
            print("skipping file pre-processing for this job...")
            fileCompressionType = 'no match'
            context['ti'].xcom_push(key='file_compression_type', value=fileCompressionType)
            return {"pp_status": 'none', "fileCompressionType": 'no match'}

    # Checking if preprocessing udf is executed for this object. If yes, the file inside the preprocessed folder is considered as the source instead.
    if 'preProcessUdf' in params['hook']:
        sourceFileObjectSplit = sourceFileObject.rsplit('/', maxsplit=1)
        sourceFileObject = sourceFileObjectSplit[0] + "/preprocessed/" + sourceFileObjectSplit[1]
        print("preprocessed file object is :", sourceFileObject)

    # defaulting the result dict
    result = {'pp_status': 'none', 'fileCompressionType': 'no match'}

    if "sourceUris" in kwargs:
        sourceUris = kwargs['sourceUris']

    # if the task is for bulk load of files from gcs to bq
    bulkLoadFileListDataproc = None
    if taskType == "bulk load from gcs to bq":
        print("this is a bulk load")
        prefix = sourceFileObject.rsplit('/', 1)[0] if "/" in sourceFileObject else ""
        if "bulkLoadFileListFinal" in kwargs:
            print("bulkLoadFileListFinal in kwargs")
            bulkLoadFileList = kwargs['bulkLoadFileListFinal']
            bulkLoadFileListDataproc =  "true"
        # else:
        #     bulkLoadFileList = gcs_hook.list(bucket_name=sourceBucket, prefix=prefix, match_glob=sourceFileObject)
        # print("bulkLoadFileList : ", bulkLoadFileList)
        # for file in bulkLoadFileList:
        #     print("The file which is being preprocessed: ", file)
        project_id = variables['projectId']
        cloudFnParams = {"sourceBucket": sourceBucket, "processBucket": processBucket, "variables": variables,
                            "sourceFileObject": sourceFileObject, "params": params, "dagId": dagId,
                            "opsgenie_priority": opsgenie_priority, "projectSpace": projectSpace,
                            "fileCompressionType": fileCompressionType, "project": project, "tz": str(tz),
                            "sourceUris": sourceUris, "bulkLoadFileListDataproc": bulkLoadFileListDataproc}
        target_principal = variables[projectTag + '_service_account_id']
        region = variables['preprocessing_cloudfn_region']
        cloud_fn = variables['preprocessing_cloudfn']
        audience = 'https://' + variables['preprocessing_cloudfn_gen2']
        target_scopes = variables['preprocessing_fn_target_scopes']
        result = triggerPreprocessingCloudFn(cloudFnParams, target_principal, audience, target_scopes,
                                                projectDetails, project_id, region, cloud_fn, context, alertTeamName,sub_lob_alert)
        for file in bulkLoadFileList: 
            print("The file which is being preprocessed: ", file)
            if result['pp_status'] != 'done' and "diagnostics" not in params['hook']["sourceUris"].split("/"):
                gcs_hook.copy(sourceBucket, file, processBucket, sourceFileObject)
                print(f"copying all the files to process bucket at gs://{processBucket}/{sourceFileObject.rsplit('/', 1)[0]}/ for bulk load")
    #context['ti'].xcom_push(key='bulk_load_file_list', value=bulkLoadFileList)
    elif 'single_file_pattern' in params['hook'] and taskType == 'load file from gcs':
        #prefix = sourceFileObject.rsplit('/', 1)[0] if "/" in sourceFileObject else ""

        singlefileuri = gcs_hook.list(bucket_name=sourceBucket,  match_glob=sourceFileObject)
        print("singlefileuri : ", singlefileuri)
        for file in singlefileuri:
            print("The file which is being preprocessed: ", file)
            sourceFileObject=file
            print("expanded sourceFileObject", sourceFileObject)
            project_id = variables['projectId']
            cloudFnParams = {"sourceBucket": sourceBucket, "processBucket": processBucket, "variables": variables,
                             "sourceFileObject": file, "params": params, "dagId": dagId,
                             "opsgenie_priority": opsgenie_priority, "projectSpace": projectSpace,
                             "fileCompressionType": fileCompressionType, "project": project, "tz": str(tz),
                             "sourceUris": sourceUris}
            target_principal = variables[projectTag + '_service_account_id']
            region = variables['preprocessing_cloudfn_region']
            cloud_fn = variables['preprocessing_cloudfn']
            audience = 'https://' + variables['preprocessing_cloudfn_gen2']
            target_scopes = variables['preprocessing_fn_target_scopes']
            result = triggerPreprocessingCloudFn(cloudFnParams, target_principal, audience, target_scopes,
                                                 projectDetails, project_id, region, cloud_fn, context, alertTeamName,sub_lob_alert)
            if result['pp_status'] != 'done' and "diagnostics" not in params['hook']["sourceUris"].split("/"):
                gcs_hook.copy(sourceBucket, file, processBucket, file)
                print(
                    f"copying singlefileuri to process bucket at gs://{processBucket}/{sourceFileObject.rsplit('/', 1)[0]}/ for bulk load")
            break
        #context['ti'].xcom_push(key='bulk_load_file_list', value=bulkLoadFileList)

    # if the source file is xml
    elif (sourceFileObject.lower()).endswith('.xml'):
        xml(sourceBucket, processBucket, variables, sourceFileObject, params, dagId, projectDetails, opsgenie_priority,
            projectSpace)
        result = {'pp_status': 'done', 'fileCompressionType': fileCompressionType}
    else:
        project_id = variables['projectId']
        cloudFnParams = {"sourceBucket": sourceBucket, "processBucket": processBucket, "variables": variables,
                         "sourceFileObject": sourceFileObject, "params": params, "dagId": dagId,
                         "opsgenie_priority": opsgenie_priority, "projectSpace": projectSpace,
                         "fileCompressionType": fileCompressionType, "project": project, "tz": str(tz),
                         "sourceUris": sourceUris, "bulkLoadFileListDataproc": bulkLoadFileListDataproc}
        target_principal = variables[projectTag + '_service_account_id']
        region = variables['preprocessing_cloudfn_region']
        cloud_fn = variables['preprocessing_cloudfn']
        # audience = 'https://'+variables['preprocessing_cloudfn_region']+'-'+variables['projectId']+'.cloudfunctions.net/'+ variables['preprocessing_cloudfn_gen2']
        audience = 'https://' + variables['preprocessing_cloudfn_gen2']
        target_scopes = variables['preprocessing_fn_target_scopes']
        result = triggerPreprocessingCloudFn(cloudFnParams, target_principal, audience, target_scopes, projectDetails,
                                             project_id, region, cloud_fn, context, alertTeamName,sub_lob_alert)

    print("pre-processing status: ", result['pp_status'])
    context['ti'].xcom_push(key='file_compression_type', value=result['fileCompressionType'])

    # copy the source file to process bucket if preprocessing is not done/applicable
    if result['pp_status'] != 'done' and "diagnostics" not in params['hook']["sourceUris"].split("/"):
        if taskType != "bulk load from gcs to bq":
            if 'trailerRecord' in params['hook']:

                if params['hook']['trailerRecord'].lower() == 'true':
                    # gcs_hook.copy(sourceBucket, sourceFileObject, processBucket, sourceFileObject)
                    project_id = variables['projectId']
                    cloudFnParams = {"sourceBucket": sourceBucket, "processBucket": processBucket,
                                     "variables": variables, "sourceFileObject": sourceFileObject, "params": params,
                                     "dagId": dagId, "opsgenie_priority": opsgenie_priority,
                                     "projectSpace": projectSpace, "fileCompressionType": fileCompressionType,
                                     "project": project}
                    target_principal = variables[projectTag + '_service_account_id']
                    region = variables['preprocessing_cloudfn_region']
                    cloud_fn = 'file-splitting-gen2'
                    # audience = 'https://'+variables['preprocessing_cloudfn_region']+'-'+variables['projectId']+'.cloudfunctions.net/'+ variables['preprocessing_cloudfn_gen2']
                    audience = 'https://file-splitting-gen2-kafhktey4q-uk.a.run.app'
                    target_scopes = variables['preprocessing_fn_target_scopes']
                    result = triggerfilesplittingCloudFn(cloudFnParams, target_principal, audience, target_scopes,
                                                         projectDetails, project_id, region, cloud_fn, context,
                                                         alertTeamName,sub_lob_alert)
            else:
                gcs_hook.copy(sourceBucket, sourceFileObject, processBucket, sourceFileObject)
        '''else:
            print(f"copying all the files to process bucket at gs://{processBucket}/{sourceFileObject.rsplit('/',1)[0]}/ for bulk load")
            bulkLoadFileList= gcs_hook.list(bucket_name=sourceBucket, prefix=sourceFileObject.rsplit('/',1)[0], match_glob=sourceFileObject)
            for file in bulkLoadFileList:
                gcs_hook.copy(sourceBucket, file, processBucket, file)
            context['ti'].xcom_push(key='bulk_load_file_list', value=bulkLoadFileList)
            print("bulkLoadFileList : ", bulkLoadFileList)'''

    return {"pp_status": result['pp_status'], "fileCompressionType": result['fileCompressionType']}


"""
file preprocessing function
"""


def preprocessing_for_filewithssh(context, bucketNameVars, variables, sourceFileObject, params, dagId, projectDetails,
                                  opsgenie_priority, **kwargs):
    sourceBucket = bucketNameVars["SOURCE_URI_BUCKET"].split("/")[-1]
    processBucket = bucketNameVars["PROCESS_BUCKET"].split("/")[-1]
    pp_status = 'none'

    # get the variable map based on the project
    projectTag = projectDetails[0]
    projectSpace = projectDetails[2]
    varMap = variables[projectTag + "_vars"]
    fileCompressionType = "no match"

    # create a gcs hook to connect to gcs and get credentials
    gcs_hook = GCSHook(gcp_conn_id=variables[params["hook"]["gcp_conn_id"]])
    credentials = gcs_hook.get_credentials()
    project = gcs_hook._get_field("project")

    # checking if preprocessing should be skipped
    if 'skipPreProcessing' in params['hook']:
        if params['hook']['skipPreProcessing'].lower() == 'true':
            print("skipping file pre-processing for this job...")
            fileCompressionType = 'no match'
            gcs_hook.copy(sourceBucket, sourceFileObject, processBucket, sourceFileObject)
            context['ti'].xcom_push(key='file_compression_type', value=fileCompressionType)
            return {"pp_status": 'none', "fileCompressionType": 'no match'}

    # Checking if preprocessing udf is executed for this object. If yes, the file inside the preprocessed folder is considered as the source instead.
    if 'preProcessUdf' in params['hook']:
        sourceFileObjectSplit = sourceFileObject.rsplit('/', maxsplit=1)
        # sourceFileObject = sourceFileObjectSplit[0]+"/preprocessed/"+sourceFileObjectSplit[1]
        print("preprocessed file object is :", sourceFileObject)

    # defaulting the result dict
    result = {'pp_status': 'none', 'fileCompressionType': 'no match'}

    return {"pp_status": 'none', "fileCompressionType": 'no match'}


def preprocessing_control_file(context, bucketNameVars,variables, controlFileObject, params, dagId, projectDetails, opsgenie_priority,group_id, **kwargs):

    sourceBucket = bucketNameVars["SOURCE_URI_BUCKET"].split("/")[-1]
    processBucket = bucketNameVars["PROCESS_BUCKET"].split("/")[-1]
    pp_status = 'none'
    #get the variable map based on the project
    projectTag = projectDetails[0]
    projectSpace = projectDetails[2]
    varMap = variables[projectTag + "_vars"]
    fileCompressionType = "no match"
    processedFileList = []

    # create a gcs hook to connect to gcs and get credentials
    gcs_hook = GCSHook(gcp_conn_id = variables[params["hook"]["gcp_conn_id"]])
    credentials = gcs_hook.get_credentials()
    project=gcs_hook._get_field("project")
    
    tz = kwargs['tz'] if 'tz' in kwargs else pendulum.timezone("UTC")
    taskType = kwargs['taskType'] if 'taskType' in kwargs else 'none'
    sub_lob_alert = kwargs['sub_lob_alert'] if 'sub_lob_alert' in kwargs else None
    project_id=variables['projectId']
    cloudFnParams = { "sourceBucket" : sourceBucket, "processBucket" : processBucket, "variables" : variables, "controlFileObject" : controlFileObject, "params" : params, "dagId" : dagId, "opsgenie_priority" : opsgenie_priority, "projectSpace" : projectSpace, "fileCompressionType" : fileCompressionType, "project" : project, "tz" : str(tz) }
    target_principal = variables[projectTag+'_service_account_id']
    region=variables['preprocessing_cloudfn_region']
    cloud_fn=variables['preprocessing_cloudfn']
    audience = 'https://'+variables['preprocessing_cloudfn_gen2']
    target_scopes = variables['preprocessing_fn_target_scopes']

    if taskType == "bulk load from gcs to bq" or taskType == "load file from gcs":
        print("control file processing")
        all_files = gcs_hook.list(bucket_name=sourceBucket)
        ControlFileList = []
        if isinstance(controlFileObject, str):
            controlFileObject = [controlFileObject]
        for pattern_list in controlFileObject:
            if isinstance(pattern_list, str):
                pattern_list = [pattern_list]
            for pattern in pattern_list:
                for file in all_files:
                    if fnmatch.fnmatch(file, pattern):
                        ControlFileList.append(file)

        print("ControlFileList : ", ControlFileList)

        for file in ControlFileList:
            print("The file which is being preprocessed: ", file)
            gcs_hook.copy(sourceBucket, file, processBucket, file)
            print(f"copying all the files to process bucket at gs://{processBucket}/{controlFileObject}/ for control load")
            context['ti'].xcom_push(key=f'{group_id}_controlFileObject', value=ControlFileList)
    else:
        # copy the source file to process bucket if preprocessing is not done/applicable
        gcs_hook.copy(sourceBucket, controlFileObject, processBucket, controlFileObject)

    # defaulting the result dict
    result = {'pp_status': 'none', 'fileCompressionType' : 'no match'}

def checkfilesize(sourceBucket, blob, variables, sourceFileObject, metadataParams, dagId, projectSpace,project,fileCompressionType,group_id,context):
    blob = blob
    if "encoding" in metadataParams['hook']:
        encoding = metadataParams['hook']["encoding"]
    else:
        encoding = 'utf-8'
    
    if "skip_header" in metadataParams['hook']:
        skip_header = metadataParams['hook']['skip_header']
    else:
        skip_header = "false"

    if "skip_footer" in metadataParams['hook']:
        skip_footer = metadataParams['hook']['skip_footer']
    else:
        skip_footer = "false"

    if "skipLeadingRows" in metadataParams['hook']:
        skipLeadingRows = metadataParams['hook']['skipLeadingRows']
    else:
        skipLeadingRows = "0"

    if fileCompressionType == 'no match':
            file_content = blob.download_as_string().decode(encoding)
            #lines = file_content.splitlines()
            lines = [line.strip() for line in file_content.splitlines() if line.strip()]
            filehdr = "true"
            if skip_header.lower()=="true" and skip_footer.lower()=="true" and len(lines) <= 2:
                context['ti'].xcom_push(key=f'{group_id}_filehdr', value=filehdr)
                raise AirflowSkipException(f"file {sourceFileObject} is having only header and footer, no data.")
            elif (skip_header.lower()=="true" or skip_footer.lower()=="true" or skipLeadingRows!="0") and len(lines) <= 1:
                context['ti'].xcom_push(key=f'{group_id}_filehdr', value=filehdr)
                raise AirflowSkipException(f"file {sourceFileObject} is having only header or footer, no data.")
            else:
                filehdr = "false"
                context['ti'].xcom_push(key=f'{group_id}_filehdr', value=filehdr)
                print(f"file {sourceFileObject} has data records.")
    elif fileCompressionType == 'gz':
        import gzip
        compressed_data = blob.download_as_bytes()
        with gzip.GzipFile(fileobj=io.BytesIO(compressed_data), mode='rb') as f:
            #lines = f.readlines()
            lines = [line.strip() for line in f if line.strip()]
        filehdr = "true"
        if skip_header.lower()=="true" and skip_footer.lower()=="true" and len(lines) <= 2:
            context['ti'].xcom_push(key=f'{group_id}_filehdr', value=filehdr)
            raise AirflowSkipException(f"file {sourceFileObject} is having only header and footer, no data.")
        elif (skip_header.lower()=="true" or skip_footer.lower()=="true" or skipLeadingRows!="0") and len(lines) <= 1:
             context['ti'].xcom_push(key=f'{group_id}_filehdr', value=filehdr)
             raise AirflowSkipException(f"file {sourceFileObject} is having only header or footer, no data.")
        else:
            filehdr = "false"
            context['ti'].xcom_push(key=f'{group_id}_filehdr', value=filehdr)
            print(f"file {sourceFileObject} has data records.")
    elif fileCompressionType == 'zip':
        import zipfile
        zip_data = blob.download_as_bytes()
        with zipfile.ZipFile(io.BytesIO(zip_data), 'r') as z:
            for filename in z.namelist():
                with z.open(filename) as f:
                    lines = f.readlines()
                filehdr = "true"
                if skip_header.lower()=="true" and skip_footer.lower()=="true" and len(lines) <= 2:
                    context['ti'].xcom_push(key=f'{group_id}_filehdr', value=filehdr)
                    raise AirflowSkipException(f"file {filename} is having only header and footer, no data.")
                elif (skip_header.lower()=="true" or skip_footer.lower()=="true" or skipLeadingRows!="0") and len(lines) <= 1:
                    context['ti'].xcom_push(key=f'{group_id}_filehdr', value=filehdr)
                    raise AirflowSkipException(f"file {filename} is having only header or footer, no data.")
                else:
                    filehdr = "false"
                    context['ti'].xcom_push(key=f'{group_id}_filehdr', value=filehdr)
                    print(f"file {filename} has data records.")
    else:
        print("check file size with header not applicable, proceeding..")