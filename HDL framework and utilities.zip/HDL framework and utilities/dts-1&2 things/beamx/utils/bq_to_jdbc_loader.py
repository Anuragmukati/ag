import sqlalchemy
import base64
from datetime import datetime
from airflow.models import Variable
from airflow.models import TaskInstance
from datetime import date
from functools import reduce
from airflow.providers.google.cloud.hooks.bigquery import BigQueryHook
from airflow.providers.google.cloud.hooks.dataproc import DataprocHook
from google.cloud import bigquery
import logging
import traceback
import sys
import json
import re
import uuid
from airflow.providers.google.cloud.operators.dataproc import DataprocCreateBatchOperator
from airflow.exceptions import AirflowSkipException, AirflowFailException
from google.cloud import secretmanager
 
def get_secret_from_sm(project_id, secret_name,dpHook):
    client = secretmanager.SecretManagerServiceClient(credentials=dpHook.get_credentials())
    secret_name = f"projects/{project_id}/secrets/{secret_name}/versions/latest"
    response = client.access_secret_version(name=secret_name)
    return response.payload.data.decode("UTF-8")

"""
get the labels to be passed to the dataproc job
"""
def getLabelsDict(labelsList, dagId,run_id,task_id, composer_name):
    labels_dict = {
                       "dag_id": dagId.lower()[-63:],
                        "task_type": "bq_to_jdbc",
                        "run_id" : re.sub(r'[^A-Za-z0-9 _-]+','',run_id).lower()[-63:],
                        "task_id": task_id.lower().replace('.',"")[-63:],
                        "comp_instance": composer_name.lower()
                        }
    return labels_dict


def read_source_table(context, params, variables, varMap, **kwargs):
    source_table = params["hook"]["parameters"]["source_table"]
    source_table = reduce(lambda key, value: key.replace(*value), varMap.items(), source_table)
    load_check_condition = params["hook"]["parameters"]["load_check_condition"]
    # sub_lob_alert = kwargs['sub_lob_alert'] if 'sub_lob_alert' in kwargs else None
    project_id = params["hook"]["projectId"]
    project_id = reduce(lambda key, value: key.replace(*value), varMap.items(), project_id)
    bq_hook = BigQueryHook(gcp_conn_id=variables[params["hook"]["gcp_conn_id"]])
    client = bigquery.Client(project=bq_hook._get_field("project"), credentials=bq_hook.get_credentials())
    try:
        load_check_query = f"SELECT count(1) from {source_table} {load_check_condition}"
        print("load_check_query:", load_check_query)
        df = client.query(load_check_query).to_dataframe()
        load_check_count = df.iloc[0][-1]
        print("load_check_count:", load_check_count)
    except Exception as e:
        print("exception raised")
        raise AirflowFailException("Error in reading source table")
    if load_check_count > 0:
        print("load status: ", load_check_count)
        run_status= "success"
        context['ti'].xcom_push(key="load_check_count", value=load_check_count)
    else:
        run_status= "failure"
        error_message = "Load Status Check Criteria Failed...exiting"
        print("error",error_message,run_status)
        return {'run_status': 'failure', 'error_message': 'Load Status Check Criteria Failed'}
    return {'run_status': 'success', 'error_message': 'NA'}

"""
Main function for bq to jdbc load where dataproc pyspark job is submitted
"""
def bq_to_jdbc_load(context, params, variables, varMap, dagId, projectDetails, tz, opsgenie_priority,custom_labels,**kwargs):

    #get the project details
    project_tag = projectDetails[0]
    business_line = projectDetails[1]
    project_space = projectDetails[2]

    #import the necessary modules
    BASE_DIR = variables["packages_directory"]
    sys.path.append(f"{BASE_DIR}/utils")
    from ops_genie import send_alert_to_opsgenie
    sub_lob_alert = kwargs['sub_lob_alert'] if 'sub_lob_alert' in kwargs else None
    # get the target db config and connection details using project tag, businessline, target db type, db instance name  Eg: gk1v_db_config['wireline']['teradata_a']
    # gk1v_db_config_bq_teradata['wireline']['teradata]['default']
    target_dbtype = (params["hook"]["parameters"]["target_dbtype"].lower())
    dataprocConfigDict = variables["dataproc_config_bq_to_"+target_dbtype]
    project_id = reduce(lambda key, value: key.replace(*value), varMap.items(), params["hook"]["projectId"])
    target_dbtype = (params["hook"]["parameters"]["target_dbtype"].lower()).replace("teradata_v20", "teradata")
    db_instance = params["hook"]["parameters"]["dbinstance"].lower() if "dbinstance" in params["hook"]["parameters"] else "default"
    db_config = variables[project_tag + '_db_config_bq_jdbc'][business_line] if business_line is not None else variables[
        project_tag + '_db_config_bq_jdbc']
    db_config = db_config[target_dbtype][db_instance]
    jdbc_driver = db_config['jdbc_driver']
    host_name = db_config['host_name']
    jdbc_url_prefix = db_config['jdbc_url_prefix']
    port = db_config['port'] if target_dbtype == "postgres" else ""
    if not port:
        jdbc_url = jdbc_url_prefix + host_name+'/'
    else:
        jdbc_url = f"{jdbc_url_prefix}{host_name}:{port}/"

    #username = Variable.get(db_config["username_key"])
    #password = Variable.get(db_config["password_key"])
    secret_name = db_config["secret_name"]
    dpHook = DataprocHook(gcp_conn_id=variables[params["hook"]["gcp_conn_id"]])
    payload=get_secret_from_sm(project_id,secret_name,dpHook)
    username,password = payload.strip().split(':')
    username = username.strip()
    password = password.strip()

    #password = base64.b64encode(password.encode('utf-8'))
    password_encoded = 'true'
    
    # context['ti'].xcom_push(key="project_id", value=project_id)
    cluster_label = dataprocConfigDict["cluster_label"]
    file_uri = dataprocConfigDict["main_python_file_uri"]
    jar_file_uri = dataprocConfigDict["jar_file_uris"]
    region = dataprocConfigDict["region"]
    target_table = params["hook"]["parameters"]["target_table"]
    target_dbname = reduce(lambda key, value: key.replace(*value), varMap.items(), params["hook"]["parameters"]["target_dbname"])
   
    if 'query' in params["hook"]["parameters"]:
        query = params["hook"]["parameters"]["query"] 
        query = reduce(lambda key, value: key.replace(*value), varMap.items(), query)
        print("load query is: ", query)
        source_table = ""
    elif 'source_table' in params["hook"]["parameters"]:
        source_table = params["hook"]["projectId"]+"."+params["hook"]["parameters"]["source_table"] 
        source_table = reduce(lambda key, value: key.replace(*value), varMap.items(), source_table)
        query = ""
   
    save_mode = params["hook"]["parameters"]["save_mode"] 
    sql_where_clause = params["hook"]["parameters"]["sql_where_clause"] if "sql_where_clause" in params["hook"]["parameters"] else ""
    number_of_partitions = params["hook"]["parameters"]["number_of_partitions"] if "number_of_partitions" in params["hook"]["parameters"] else ""
    batch_size = params["hook"]["parameters"]["batch_size"] if "batch_size" in params["hook"]["parameters"] else ""
    rewrite_batched_inserts = params["hook"]["parameters"]["rewrite_batched_inserts"] if "rewrite_batched_inserts" in params["hook"]["parameters"] else ""
    partition_column = params["hook"]["parameters"]["partition_column"] if "partition_column" in params["hook"]["parameters"] else ""
    dpHook = DataprocHook(gcp_conn_id=variables[params["hook"]["gcp_conn_id"]])
    materialization_bq_dataset = dataprocConfigDict["materialization_dataset"]

    # pyspark job id
    job_id = dagId.lower() +'_' + str(datetime.now(tz).strftime("%Y%m%d%H%M%S"))
    run_id = context['dag_run'].run_id
    task_id = context['task'].task_id
    import os
    composer_name = os.getenv('COMPOSER_ENVIRONMENT')

    labels_dict = getLabelsDict(custom_labels, dagId,run_id,task_id, composer_name)

    # spark application name
    spark_app_name = "bqtoJDBCapp_" + dagId + str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))

    # pyspark job properties
    properties = {
        "spark.master": "yarn",
        "spark.app.name": spark_app_name,
        "spark.submit.deployMode": "cluster",
        "spark.ui.view.acls": "*",
        "spark.redaction.regex": "(?i)secret|password|token|access[.]key",
        "spark.redaction.string.regex":"(?i)secret|password|dbpass|token"
     }

    # update spark properties if custom spark configuration sent from user metadata
    if "spark_conf" in params["hook"]["parameters"]:
        spark_conf = params["hook"]["parameters"]["spark_conf"]
        properties.update(spark_conf)

    # pyspark job configuration
    pyspark_job_config = {
            "reference": {"project_id": project_id, "job_id": job_id},
            "placement": {"cluster_labels": cluster_label},
            "pyspark_job": {
                    "main_python_file_uri": file_uri,
                    "properties": properties,
                    "jar_file_uris": jar_file_uri,
                    "args": [jdbc_driver, host_name, jdbc_url, secret_name, project_id, source_table, target_table, target_dbname, target_dbtype, query, save_mode, materialization_bq_dataset, sql_where_clause, password_encoded, number_of_partitions, batch_size, rewrite_batched_inserts, partition_column]}
    }

    print("********",pyspark_job_config)
    print(type(pyspark_job_config))
    return pyspark_job_config,region

def getObsParams(context, params, varMap, dict_obs, dagId, project_id, tz):

    # capturing obs static values
    dict_obs_static = json.loads(reduce(lambda key, value: key.replace(*value), varMap.items(), (str(params["obs"])).replace("'", '"')))

    # capturing obs dynamic values
    data_interval_endtime = context['data_interval_end'].in_timezone(tz)
    dict_obs["start_time"] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
    dict_obs["process_date"] = str(date.today().strftime("%Y-%m-%d"))
    dict_obs["run_date"] = str(data_interval_endtime.strftime('%Y%m%d'))
    dict_obs["run_day"] = str(data_interval_endtime.strftime('%A'))
    #dict_obs["run_hour"] = str(datetime.now(tz).strftime("%H:%M:%S"))
    #run_hour = context['data_interval_end']
    dict_obs["run_hour"] = str(data_interval_endtime.strftime("%H:%M:%S"))
    dict_obs["log_file"] = varMap['log_file']
    dict_obs["process_name"] = dagId
    dict_obs["gcp_project"] = project_id
    dict_obs["target_type"] = "Table"

    # merge static and dynamic ob params
    dict_obs.update(dict_obs_static)
    return dict_obs

"""
Send oservability logs to logger
"""
def sendObsLogs(params,variables,dict_obs, run_status, end_time, target_dbname, error_message, target_table, host_name, username, password, project_space, tz):

    BASE_DIR = variables["packages_directory"]
    sys.path.append(f"{BASE_DIR}/utils")
    from observability import bq_to_teradata_obs, ingestion_obs
    
    dict_obs["process_end_time"] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
    dict_obs["run_status"] = run_status
    dict_obs["end_time"] = end_time
    dict_obs["error_message"] = error_message
    dict_obs["inserted_timestamp"] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
    logger_name = params["obs"]["logger_name"]
    logs = {}
    try:
        if params["hook"]["parameters"]["target_dbtype"].lower() == "teradata": 
            logs = bq_to_teradata_obs(dict_obs, target_dbname, target_table, host_name, username, password, logger_name)
        elif params["hook"]["parameters"]["target_dbtype"].lower() == "postgres":
            dict_obs["target_type"] = "Table"
            dict_obs['target_count'] = "NA"
            logs = ingestion_obs(dict_obs, logger_name)
    except Exception as e:
        error_message = str(e)
        logging.error(traceback.format_exc())
        print("Could not send observability log")
    return logs

"""
This function inserts a row with the necessary details in audit table for each run
"""
def auditTableEntry(params, variables, varMap, logs, host_name, username, password, target_table, dagId):

    if params["hook"]["parameters"]["target_dbtype"].lower() == "teradata":
    
        audit_db_bq_td = variables["audit_db_bq_td"]
        insert_cnt = logs["target_count"] if logs != "" else 0
        try:
            td_engine = sqlalchemy.create_engine(f'teradatasql://{host_name}/?user={username}&password={password}')
            insert_query = f'''INSERT INTO {audit_db_bq_td}.TABLE_LOAD_STATUS
                            VALUES('{target_table}',NULL,DATE,CAST(CURRENT_TIME AS TIME(0)),CAST(CURRENT_TIME AS TIMESTAMP(0)),DATE
                            ,CAST (CURRENT_TIME AS TIME(0)),CAST (CURRENT_TIME AS TIMESTAMP(0)),{insert_cnt}, 
                            0, 0, 0, 0, 'BTEQ', '{dagId}');'''
            result = td_engine.execute(insert_query)
            print("Audit Entry Done")
        except Exception as e:
            error_message = str(e)
            logging.error(traceback.format_exc())
            sys.tracebacklimit = 0


def debug_print(var_name, var_value):
    print(f"{var_name} (type: {type(var_value)}): {var_value}")

def bq_to_jdbc_load_serverless(context, params, variables, varMap, dagId, projectDetails, tz, opsgenie_priority,custom_labels,**kwargs):

    #get the project details
    project_tag = projectDetails[0]
    business_line = projectDetails[1]
    project_space = projectDetails[2]

    #import the necessary modules
    BASE_DIR = variables["packages_directory"]
    sys.path.append(f"{BASE_DIR}/utils")
    AlertTeamName = kwargs['AlertTeamName'] if 'AlertTeamName' in kwargs else None
    task_instance =context['task_instance']
    retries=task_instance.max_tries
    # get the target db config and connection details using project tag, businessline, target db type, db instance name  Eg: gk1v_db_config['wireline']['teradata_a']
    # gk1v_db_config_bq_teradata['wireline']['teradata]['default']
    target_dbtype = (params["hook"]["parameters"]["target_dbtype"].lower())
    dataprocConfigDict = variables["dataproc_config_bq_to_"+target_dbtype]
    # serverless variables

    SERVICE_ACCOUNT = dataprocConfigDict["service_account"]
    PHS_CLUSTER_PATH = dataprocConfigDict["phs_cluster_path"]
    SUBNETWORK_URI = dataprocConfigDict["subnetwork_uri"]
    serverless_version = str(dataprocConfigDict["serverless_version"])

    #data proc variables
    project_id = reduce(lambda key, value: key.replace(*value), varMap.items(), params["hook"]["projectId"])
    target_dbtype = (params["hook"]["parameters"]["target_dbtype"].lower()).replace("teradata_v20", "teradata")
    db_instance = params["hook"]["parameters"]["dbinstance"].lower() if "dbinstance" in params["hook"]["parameters"] else "default"
    db_config = variables[project_tag + '_db_config_bq_jdbc'][business_line] if business_line is not None else variables[project_tag + '_db_config_bq_jdbc']
    db_config = db_config[target_dbtype][db_instance]
    jdbc_driver = db_config['jdbc_driver']
    jdbc_driver = db_config['jdbc_driver']
    host_name = db_config['host_name']
    jdbc_url_prefix = db_config['jdbc_url_prefix']
    port = db_config['port'] if target_dbtype == "postgres" else ""
    if not port:
        jdbc_url = jdbc_url_prefix + host_name+'/'
    else:
        jdbc_url = f"{jdbc_url_prefix}{host_name}:{port}/"

    #username = Variable.get(db_config["username_key"])
    #password = Variable.get(db_config["password_key"])
    secret_name = db_config["secret_name"]
    dpHook = DataprocHook(gcp_conn_id=variables[params["hook"]["gcp_conn_id"]])
    payload=get_secret_from_sm(project_id,secret_name,dpHook)
    username,password = payload.strip().split(':')
    username = username.strip()
    password = password.strip()

    #password = base64.b64encode(password.encode('utf-8'))
    password_encoded = 'true'
    cluster_label = dataprocConfigDict["cluster_label"]
    file_uri = dataprocConfigDict["main_python_file_uri"]
    staging_bucket = dataprocConfigDict["staging_bucket"]
    temp_bucket = dataprocConfigDict["temp_bucket"]
    jar_file_uri = dataprocConfigDict["jar_file_uris"]
    region = dataprocConfigDict["region"]
    print("serverless region:",region)
    target_table = params["hook"]["parameters"]["target_table"]
    target_dbname = reduce(lambda key, value: key.replace(*value), varMap.items(), params["hook"]["parameters"]["target_dbname"])
    kms_key =   str(dataprocConfigDict["kms_key"])

    if 'query' in params["hook"]["parameters"]:
        query = params["hook"]["parameters"]["query"] 
        query = reduce(lambda key, value: key.replace(*value), varMap.items(), query)
        print("load query is in serverless: ", query)
        source_table = ""
    elif 'source_table' in params["hook"]["parameters"]:
        source_table = params["hook"]["projectId"]+"."+params["hook"]["parameters"]["source_table"] 
        source_table = reduce(lambda key, value: key.replace(*value), varMap.items(), source_table)
        query = ""
   
    save_mode = params["hook"]["parameters"]["save_mode"] 
    sql_where_clause = params["hook"]["parameters"]["sql_where_clause"] if "sql_where_clause" in params["hook"]["parameters"] else ""
    number_of_partitions = params["hook"]["parameters"]["number_of_partitions"] if "number_of_partitions" in params["hook"]["parameters"] else ""
    batch_size = params["hook"]["parameters"]["batch_size"] if "batch_size" in params["hook"]["parameters"] else ""
    rewrite_batched_inserts = params["hook"]["parameters"]["rewrite_batched_inserts"] if "rewrite_batched_inserts" in params["hook"]["parameters"] else ""
    partition_column = params["hook"]["parameters"]["partition_column"] if "partition_column" in params["hook"]["parameters"] else ""
    materialization_bq_dataset = dataprocConfigDict["materialization_dataset"]

    # pyspark job id
    job_id = dagId.lower() +'_' + str(datetime.now(tz).strftime("%Y%m%d%H%M%S"))
    run_id = context['dag_run'].run_id
    task_id = context['task'].task_id
    import os
    composer_name = os.getenv('COMPOSER_ENVIRONMENT')

    labels_dict = getLabelsDict(custom_labels, dagId,run_id,task_id, composer_name)

    # spark application name
    spark_app_name = "bqtoJDBCapp_" + dagId + str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))

    # pyspark job properties
    properties = {
        "spark.master": "yarn",
        "spark.app.name": spark_app_name,
        "spark.submit.deployMode": "cluster",
        "spark.ui.view.acls": "*",
        "spark.redaction.regex": "(?i)secret|password|token|access[.]key",
        "spark.redaction.string.regex":"(?i)secret|password|dbpass|token"
     }

    # update spark properties if custom spark configuration sent from user metadata
    if "spark_conf" in params["hook"]["parameters"]:
        spark_conf = params["hook"]["parameters"]["spark_conf"]
        properties.update(spark_conf)


    # pyspark job configuration
    properties = {
        "spark.sql.parquet.int96RebaseModeInRead": "CORRECTED",
        "spark.sql.parquet.int96RebaseModeInWrite": "CORRECTED",
        "spark.sql.parquet.datetimeRebaseModeInRead": "CORRECTED",
        "spark.sql.parquet.datetimeRebaseModeInWrite": "CORRECTED",
        "spark.dataproc.driverEnv.PYSPARK_PYTHON":"./pyenv/bin/python",
        "spark.executorEnv.PYSPARK_PYTHON":"./pyenv/bin/python",
        "spark.sql.inMemoryColumnarStorage.compressed":"true",
        "spark.redaction.regex": "(?i)secret|password|token|access[.]key",
        "spark.redaction.string.regex":"(?i)secret|password|dbpass|token",
        "spark.hadoop.fs.gs.system.bucket": temp_bucket
    }

    labels_dict['task_type'] = "bq_to_jdbc_serverless"
    project_id = params["hook"]["projectId"]
    batch_id = dagId.lower().replace("gk1v_cwlspr_", "").replace(project_tag + "_", "").replace("_", "-")
    batch_id = (batch_id[:55]) if len(batch_id) > 56 else batch_id
    batch_id = batch_id + "-" + str(datetime.now().strftime("%Y%m%d%H%M%S"))

    project_id = reduce(lambda key, value: key.replace(*value), varMap.items(), params["hook"]["projectId"])
    
    debug_print('Executing serverless code', '')
    debug_print('batch_id', batch_id)
    debug_print('region', region)
    debug_print('project_id', project_id)
    debug_print('properties', properties)
    debug_print('FILE_URI', file_uri)
    debug_print('staging_bucket', staging_bucket)
    debug_print('temp_bucket', temp_bucket)
    debug_print('JAR_FILE_URI', jar_file_uri)
    debug_print('serverless_version', serverless_version)
    debug_print('SERVICE_ACCOUNT', SERVICE_ACCOUNT)
    debug_print('SUBNETWORK_URI', SUBNETWORK_URI)
    debug_print('PHS_CLUSTER_PATH', PHS_CLUSTER_PATH)

    if 'archive_uri' in dataprocConfigDict:
        archive_uri = dataprocConfigDict["archive_uri"]
        print("archive value is: ", archive_uri)
    else:
        if 'np' in project_id:
            archive_uri = ["gs://aid-gk1v-data-ingestion/jars/pyenv_conda.tar.gz#pyenv"]
        else:
            archive_uri = ["gs://aid-gk1v-prod-data-ingestion/jars/pyenv_conda.tar.gz#pyenv"]
    batch={
            "pyspark_batch": {
                "main_python_file_uri": file_uri,
                "archive_uris": archive_uri,
                "jar_file_uris": jar_file_uri,
                "args": [jdbc_driver, host_name, jdbc_url, secret_name, project_id, source_table, target_table, target_dbname, target_dbtype, query, save_mode, materialization_bq_dataset, sql_where_clause, password_encoded, number_of_partitions, batch_size, rewrite_batched_inserts, partition_column]
            },
            "labels": labels_dict,
            "runtime_config":{
                "version": serverless_version,
                "properties": properties
            },
            "environment_config": {
                "execution_config": {
                    "service_account": SERVICE_ACCOUNT,
                    "subnetwork_uri": SUBNETWORK_URI,
                    "kms_key": kms_key,
                    "staging_bucket": staging_bucket
            },
            "peripherals_config": {
                "spark_history_server_config": {
                    "dataproc_cluster": PHS_CLUSTER_PATH,
                },
            },
            },
            }

    print("********",batch)
    print(type(batch))
    return batch_id,batch,region
    
