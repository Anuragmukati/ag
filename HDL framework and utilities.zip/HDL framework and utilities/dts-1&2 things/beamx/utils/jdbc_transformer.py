import sqlalchemy
from datetime import datetime
from airflow.models import Variable
from datetime import date
from functools import reduce
import logging
import traceback
import sys
import json
from datetime import date, timedelta, timezone, tzinfo
from airflow.providers.google.cloud.hooks.dataproc import DataprocHook
import pendulum
from airflow.exceptions import AirflowSkipException
#from airflow.utils.task_group import TaskGroup

from google.cloud import secretmanager
 
def get_secret_from_sm(project_id, secret_name,dpHook):
    client = secretmanager.SecretManagerServiceClient(credentials=dpHook.get_credentials())
    secret_name = f"projects/{project_id}/secrets/{secret_name}/versions/latest"
    response = client.access_secret_version(name=secret_name)
    return response.payload.data.decode("UTF-8")

"""
This function gets the static and the dynamic params to send to observability logs. The static params come from metadata and the dynamic params are calculated in this script at run time.
"""
def getObsParams(context,params, varMap, dict_obs, dagId, project_id, tz):
    
    # capturing static obs values
    dict_obs_static = json.loads(reduce(lambda key, value: key.replace(*value), varMap.items(), (str(params["obs"])).replace("'", '"')))

    # capturing dynamic obs values
    dict_obs["start_time"] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
    dict_obs["process_date"] = str(date.today().strftime("%Y-%m-%d"))
    #dict_obs["run_date"] = str(datetime.now(tz).strftime('%Y%m%d'))
    #dict_obs["run_day"] = str(datetime.now(tz).strftime('%A'))
    #dict_obs["run_hour"] = str(datetime.now(tz).strftime("%H:%M:%S"))
    #run_hour = context['data_interval_end']
    #dict_obs["run_hour"] = str(run_hour.in_timezone(tz).strftime("%H:%M:%S"))
    data_interval_endtime = context['data_interval_end'].in_timezone(tz)
    dict_obs["run_date"] = str(data_interval_endtime.strftime('%Y%m%d'))
    dict_obs["run_day"] = str(data_interval_endtime.strftime('%A'))
    dict_obs["run_hour"] = str(data_interval_endtime.strftime("%H:%M:%S"))
    dict_obs["log_file"] = varMap['log_file']
    dict_obs["process_name"] = dagId
    dict_obs["gcp_project"] = project_id
    dict_obs["target_type"] = "Table"
    dict_obs["target_count"] = "NA"
    dict_obs.update(dict_obs_static)
    return dict_obs

"""
This function runs a sql query to load data from onq teradata table to another.
"""
def tdTransform(params, host_name, query, tz, username, password):


    # run teradata sql query using sqlalchemy lib
    try:
        td_engine = sqlalchemy.create_engine(f'teradatasql://{host_name}/?user={username}&password={password}')
        result = td_engine.execute(query)
        end_time = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
        print("Teradata Query executed successfully")
        run_status = "SUCCESS"
        error_msg = "NA"
    except Exception as e:
        run_status = "FAILURE"
        end_time = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
        error_msg = str(e)
        logging.error(traceback.format_exc()) 
        
    return {'run_status': run_status, 'error_msg': error_msg, 'end_time': end_time}
    
"""
This function runs multiple sql query to load data from onq teradata table to another.
"""
def tdTransform_multiquery(params, host_name, query, tz, username, password):


    # run teradata sql query using sqlalchemy lib
    try:
        td_engine = sqlalchemy.create_engine(f'teradatasql://{host_name}/?user={username}&password={password}')
        query_list=query.split(';')
        counter=1
        for query in query_list:
            if query!='':
                query=query+';'
                result = td_engine.execute(query)
                print("Teradata Query {} executed successfully".format(counter))
                counter+=1
        end_time = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))       
        run_status = "SUCCESS"
        error_msg = "NA"
    except Exception as e:
        run_status = "FAILURE"
        end_time = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
        error_msg = str(e)
        logging.error(traceback.format_exc()) 
        
    return {'run_status': run_status, 'error_msg': error_msg, 'end_time': end_time}


"""
Send oservability logs to logger
"""
def sendObsLogs(params, result, dict_obs, project_space, tz):

    # import the necessary modules
    BASE_DIR = "/home/airflow/gcs/dags/"+project_space + "/beamx"
    sys.path.append(f"{BASE_DIR}/utils")
    from observability import ingestion_obs

    # add additional run time parameters to send to observability
    dict_obs["process_end_time"] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
    dict_obs["run_status"] = result['run_status']
    dict_obs["end_time"] = result['end_time']
    dict_obs["error_message"] = result['error_msg']
    dict_obs["inserted_timestamp"] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
    print("dict_obs : ", dict_obs)
    logger_name = params["obs"]["logger_name"]

    # calling the logger method in observability module
    try:
        ingestion_obs(dict_obs, logger_name)
    except Exception as e:
        error_msg = str(e)
        print("error_msg : ", error_msg)
        logging.error(traceback.format_exc())
        print("Could not send observability log")

"""
Main Function for jdbcTransform. This function submits a job to run jdbc sql query
"""
def jdbcTransform(context, params, variables, varMap, dagId, dict_obs, projectDetails, tz, opsgenie_priority,**kwargs):

    # get the project details
    project_tag = projectDetails[0]
    business_line = projectDetails[1]
    project_space = projectDetails[2]
    task_instance =context['task_instance']
    retries=task_instance.max_tries
    # import the necessary modules
    BASE_DIR = "/home/airflow/gcs/dags/"+project_space + "/beamx"
    sys.path.append(f"{BASE_DIR}/utils")
    from ops_genie import send_alert_to_opsgenie
    alertTeamName = kwargs['alertTeamName'] if 'alertTeamName' in kwargs else None
    sub_lob_alert = kwargs['sub_lob_alert'] if 'sub_lob_alert' in kwargs else None
    try:
        upstreamTaskId = next(iter(context['task'].upstream_task_ids))
        project_id = context['ti'].xcom_pull(key='project_id', task_ids=upstreamTaskId)
    except Exception as e:
        project_id = reduce(lambda key, value: key.replace(*value), varMap.items(), params["hook"]["projectId"])
    
    if "projectId" is params["hook"]:
        project_id = reduce(lambda key, value: key.replace(*value), varMap.items(), params["hook"]["projectId"])
    else:
        project_id = variables["projectId"]

    print("Project_id is: ", project_id)

    # get obs parameters
    dict_obs = getObsParams(context, params, varMap, dict_obs, dagId, project_id, tz)

    if "parameters" not in params['hook']:
        params["hook"]["parameters"] = params["hook"]

    ingestion_pattern = kwargs['ingestion_pattern']
    target_db = (params["hook"]["parameters"]["target_dbtype"].lower()).replace('postgresql', 'postgres')
    db_instance = params["hook"]["parameters"]["dbinstance"] if "dbinstance" in params["hook"]["parameters"] else "default"

    if ingestion_pattern == "bq_to_jdbc":
        db_config = variables[project_tag + '_db_config_bq_jdbc'][business_line] if business_line is not None else \
                        variables[project_tag + '_db_config_bq_jdbc']
    else:
        db_config = variables[project_tag + '_db_config_jdbc_bq'][business_line] if business_line is not None else variables[
                     project_tag + '_db_config_jdbc_bq']

    db_config = db_config[target_db][db_instance]
    host_name = db_config['host_name']
    #username = Variable.get(db_config["username_key"])
    #password = Variable.get(db_config["password_key"])
    secret_name = db_config["secret_name"]
    if "gcp_conn_id" in params["hook"]:
        gcp_conn_id=variables[params["hook"]["gcp_conn_id"]]
    else:
        gcp_conn_id=variables["gcp_conn_id"]
    dpHook = DataprocHook(gcp_conn_id=gcp_conn_id)
    payload=get_secret_from_sm(project_id,secret_name,dpHook)
    username,password = payload.strip().split(':')
    username = username.strip()
    password = password.strip()
    query = params["hook"]["parameters"]["query"]
    query = reduce(lambda key, value: key.replace(*value), varMap.items(), query)

    
    # call the appropriate sql transform method based on target database
    if params["hook"]["parameters"]["target_dbtype"].lower() == "teradata":
        if ';' in query:
            result=tdTransform_multiquery(params, host_name, query, tz, username, password)
        else:
            result = tdTransform(params, host_name, query, tz, username, password)
    
     
    # send Observability Logs to logger
    sendObsLogs(params, result, dict_obs, project_space, tz)
    
    if result['run_status'] == "FAILURE":
        
        task_instance =context['task_instance']
        opsgenie_message = "Beamx|"+variables["environment"]+"|Failure|"+task_instance.task_id+"|"+ dict_obs['running_instance_id']
        opsgenie_description = "Failure |JDBC Transform Step Failed|" + dict_obs['running_instance_id']
        #opsgenie_message = variables["environment"]+" Alert | JDBC Transform Failed"
        #opsgenie_description = "JDBC Transform Step Failed"
        opsgenie_details = {"DAG ID": dagId, "Error Step": "JDBC Transform", "Query": query, "Error Message": result['error_msg']}
        send_alert_to_opsgenie(opsgenie_message, opsgenie_description, opsgenie_details, opsgenie_priority, projectDetails=projectDetails,alertTeamName=alertTeamName,sub_lob_alert=sub_lob_alert)
        return {"run_status": "failure", "error_message": "JDBC Transform failed...exiting"}

    return {"run_status": "success", "error_message": "none"}


"""
Main Function for jdbcTransform. This function submits a job to run jdbc sql delete query
"""
def jdbcTransform_delete(context, params, variables, varMap, dagId, dict_obs, projectDetails, tz, opsgenie_priority,**kwargs):

    # get the project details
    project_tag = projectDetails[0]
    business_line = projectDetails[1]
    project_space = projectDetails[2]
    task_instance =context['task_instance']
    retries=task_instance.max_tries
    # import the necessary modules
    BASE_DIR = "/home/airflow/gcs/dags/"+project_space + "/beamx"
    sys.path.append(f"{BASE_DIR}/utils")
    from ops_genie import send_alert_to_opsgenie
    alertTeamName = kwargs['alertTeamName'] if 'alertTeamName' in kwargs else None
    sub_lob_alert = kwargs['sub_lob_alert'] if 'sub_lob_alert' in kwargs else None

    bq_to_gcs_tpt_status = context['ti'].xcom_pull(key='bq_to_gcs_status')
    print(bq_to_gcs_tpt_status)
    if bq_to_gcs_tpt_status is not None and bq_to_gcs_tpt_status in ["upstream_failed","skipped","failed"]:
        raise AirflowSkipException

    try:
        upstreamTaskId = next(iter(context['task'].upstream_task_ids))
        project_id = context['ti'].xcom_pull(key='project_id', task_ids=upstreamTaskId)
    except Exception as e:
        project_id = reduce(lambda key, value: key.replace(*value), varMap.items(), params["hook"]["projectId"])

    if "projectId" is params["hook"]:
        project_id = reduce(lambda key, value: key.replace(*value), varMap.items(), params["hook"]["projectId"])
    else:
        project_id = variables["projectId"]

    print("Project_id is: ", project_id)

    # get obs parameters
    dict_obs = getObsParams(context, params, varMap, dict_obs, dagId, project_id, tz)

    if "parameters" not in params['hook']:
        params["hook"]["parameters"] = params["hook"]

    ingestion_pattern = kwargs['ingestion_pattern']
    target_db = (params["hook"]["parameters"]["target_dbtype"].lower()).replace('postgresql', 'postgres')
    db_instance = params["hook"]["parameters"]["dbinstance"] if "dbinstance" in params["hook"]["parameters"] else "default"

    if ingestion_pattern == "bq_to_jdbc":
        db_config = variables[project_tag + '_db_config_bq_jdbc'][business_line] if business_line is not None else \
                        variables[project_tag + '_db_config_bq_jdbc']
    else:
        db_config = variables[project_tag + '_db_config_jdbc_bq'][business_line] if business_line is not None else variables[
                     project_tag + '_db_config_jdbc_bq']

    db_config = db_config[target_db][db_instance]
    host_name = db_config['host_name']
    #username = Variable.get(db_config["username_key"])
    #password = Variable.get(db_config["password_key"])
    secret_name = db_config["secret_name"]
    if "gcp_conn_id" in params["hook"]:
        gcp_conn_id=variables[params["hook"]["gcp_conn_id"]]
    else:
        gcp_conn_id=variables["gcp_conn_id"]
    dpHook = DataprocHook(gcp_conn_id=gcp_conn_id)
    payload=get_secret_from_sm(project_id,secret_name,dpHook)
    username,password = payload.strip().split(':')
    username = username.strip()
    password = password.strip()
    query = params["hook"]["parameters"]["query"]
    query = reduce(lambda key, value: key.replace(*value), varMap.items(), query)

    
    # call the appropriate sql transform method based on target database
    if params["hook"]["parameters"]["target_dbtype"].lower() == "teradata":
        if ';' in query:
            result=tdTransform_multiquery(params, host_name, query, tz, username, password)
        else:
            result = tdTransform(params, host_name, query, tz, username, password)
    
     
    # send Observability Logs to logger
    sendObsLogs(params, result, dict_obs, project_space, tz)
    
    if result['run_status'] == "FAILURE":
        task_instance =context['task_instance']
        opsgenie_message = "Beamx|"+variables["environment"]+"|Failure|"+task_instance.task_id+"|"+ dict_obs['running_instance_id']
        opsgenie_description = "Failure |JDBC Transform Step Failed|" + dict_obs['running_instance_id']
        #opsgenie_message = variables["environment"]+" Alert | JDBC Transform Failed"
        #opsgenie_description = "JDBC Transform Step Failed"
        opsgenie_details = {"DAG ID": dagId, "Error Step": "JDBC Transform", "Query": query, "Error Message": result['error_msg']}
        if (retries == 0 and task_instance.try_number == 1) or (retries > 0 and task_instance.try_number == retries + 1):
            send_alert_to_opsgenie(opsgenie_message, opsgenie_description, opsgenie_details, opsgenie_priority, projectDetails=projectDetails, alertTeamName=alertTeamName,sub_lob_alert=sub_lob_alert)
        return {"run_status": "failure", "error_message": "JDBC Transform failed...exiting"}

    return {"run_status": "success", "error_message": "none"}

