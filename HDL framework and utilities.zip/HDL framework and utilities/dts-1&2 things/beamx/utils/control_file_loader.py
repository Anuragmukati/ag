#stdlib imports
from datetime import datetime
from airflow import models
from airflow.models.baseoperator import chain
from airflow.operators.python_operator import PythonOperator
from airflow.decorators import dag, task
from airflow.utils.task_group import TaskGroup
from airflow.models.taskinstance import TaskInstance
from datetime import date, timedelta, timezone, tzinfo
from google.cloud import bigquery
from google.cloud import storage
from functools import reduce
import sys
import os
import io
import pendulum
import traceback
import pandas as pd
from airflow.operators.email_operator import EmailOperator
from airflow.providers.google.cloud.hooks.gcs import GCSHook
from airflow.providers.google.cloud.hooks.dataproc import DataprocHook
from airflow.providers.google.cloud.hooks.functions import CloudFunctionsHook
from airflow.providers.google.cloud.hooks.bigquery import BigQueryHook
import pandas_gbq
import gcsfs


def upload_control_file(context,variables,bucketNameVars,fileSensorDetails,projectDetails):

    print("file was successfully detected")
    ti = context.get('ti')
    print("map index",ti.map_index)
    map_index=ti.map_index
    gcs_hook = GCSHook(gcp_conn_id=variables["gcp_conn_id"])
    bq_hook = BigQueryHook(gcp_conn_id=variables["gcp_conn_id"],use_legacy_sql=False, location ='US')
    project=bq_hook._get_field("project")
    client = bigquery.Client(project=bq_hook._get_field("project"), credentials=bq_hook.get_credentials())
    bkt_name=bucketNameVars[fileSensorDetails['retryInfo']['gcsbucket']].split("/")[-1]
    archive_bkt = bucketNameVars["ARCHIVE_BUCKET"].split("/")[-1]
    control_object=fileSensorDetails['retryInfo']['cntrlfile_object']
    print("object list",control_object[map_index])
    source_glob = control_object[map_index][0]
    print("source_glob",source_glob)
    fileList = gcs_hook.list(bucket_name=bkt_name,  match_glob=source_glob )
    storage_client = storage.Client(credentials = gcs_hook.get_credentials())
    bucket = storage_client.bucket(bkt_name)
    db_name = "audit_db_td_bq"
    cntrlfile_table = "file_ingestion_stat_metadata"
    projectTag = projectDetails[0]
    varMap = variables[ projectTag+"_vars"]
    datasetName =varMap[db_name]
    #cntrlfile_table = varMap[cntrlfile_table]
    colspecs = '44,10,26'
    colSpecification = []
    fixed_width_list = colspecs.split(",")
    start = 0
    for width_pos in fixed_width_list:
        column_position_tup = (start, start + int(width_pos))
        start = start + int(width_pos)
        colSpecification.append(column_position_tup)
    print(colSpecification)
    for file in  fileList:
        print('source uri is',file)
        blob = bucket.blob(file)
        destination_file_name = file.split("/")[-1]
        #blob.download_to_filename(destination_file_name)
        data = blob.download_as_bytes()
        data = data.decode("utf-8")
        print('data is',data)
        #stat=data[0:44]
        #recordcount=data[45:54]
        #updt=data[54:80]
        filename = file
        table_id = project+'.'+datasetName+'.'+cntrlfile_table
        insert_query = """
        delete from {0} 
        where filename='{1}' 
        """.format(table_id, filename)
        print('insert_query',insert_query)
        bq_cursor = bq_hook.get_cursor()
        bq_cursor.execute(insert_query)
        print("Insert into bq event trigger Entry done")
        df = pd.read_fwf(io.StringIO(data),colspecs=colSpecification, header=None, encoding='UTF-8',ignore_index=True,names=['stat', 'recordcount','updt'],dtype=object)
        df['filename']=file
        print(df)
        job_config = bigquery.LoadJobConfig()
        job = client.load_table_from_dataframe(
        df, table_id
        )
        gcs_hook.copy(bkt_name, file, archive_bkt, file)
		
        gcs_hook.delete(bkt_name, file)
