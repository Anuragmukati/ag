import os
import json
import logging
import traceback
import sys
import requests
import google.oauth2.id_token
import google.auth.transport.requests
from airflow.providers.google.cloud.hooks.gcs import GCSHook
from airflow.providers.google.cloud.hooks.dataproc import DataprocHook
import base64
from google.auth import impersonated_credentials
from airflow.providers.google.cloud.hooks.functions import CloudFunctionsHook
from functools import reduce
from datetime import datetime
from datetime import date, timedelta, timezone, tzinfo
import pendulum

tz = pendulum.timezone("America/New_York")


def invoke_udf(context, bucketNameVars, variables, sourceFileObject, params, dagId, projectDetails, opsgenie_priority,
               cloudFnName, dict_obs, **kwargs):
    # get the variable map based on the project
    projectTag = projectDetails[0]
    projectSpace = projectDetails[2]

    # import the necessary modules
    BASE_DIR = "/home/airflow/gcs/dags/" + projectSpace + "/beamx"
    sys.path.append(f"{BASE_DIR}/utils")
    from ops_genie import send_alert_to_opsgenie
    import observability
    varMap = variables[projectTag + "_vars"]
    params = params
    dict_obs = dict_obs
    processDate = None
    processTime = None
    # define the  variables needed to trigger clouf fn
    target_principal = variables[projectTag + '_service_account_id']
    alertTeamName = kwargs['alertTeamName'] if 'alertTeamName' in kwargs else None
    sub_lob_alert = kwargs['sub_lob_alert'] if 'sub_lob_alert' in kwargs else None
    task_instance =context['task_instance']
    retries=task_instance.max_tries
    if 'gen2' in params['hook'] and (params['hook']['gen2']).lower() == 'true':
        print("cloudFnName", cloudFnName)
        env_uri = varMap["udf_source_uri"]
        print("env uri", env_uri)
        if "_" in cloudFnName:
            cloudFnName = cloudFnName.replace("_", "-")
        cloudFnName = cloudFnName + '-' + env_uri
        print("cloudFnName2", cloudFnName)
        print("gen2 is true")
        audience = 'https://' + cloudFnName
    else:
        audience = 'https://' + variables['preprocessing_cloudfn_region'] + '-' + variables[
            'projectId'] + '.cloudfunctions.net/' + cloudFnName
    print("audience is: ", audience)

    getenv = os.getenv('no_proxy')
    new_proxy = audience.replace('https://', '')
    getenv += "," + new_proxy
    print("no_proxy is: ", getenv)
    os.environ['no_proxy'] = getenv

    target_scopes = variables['preprocessing_fn_target_scopes']

    print("target_scopes", target_scopes)

    projectId = variables['projectId']
    clusterLabel = variables['dataproc_config_untar']['cluster_label']
    region = variables['dataproc_config_untar']["region"]

    # defining the args dict for the preprocessing user defined function
    sourceBucket = bucketNameVars["SOURCE_URI_BUCKET"].split("/")[-1]
    processBucket = bucketNameVars["PROCESS_BUCKET"].split("/")[-1]
    if "customArgs" in kwargs:
        customudfargs = kwargs['customArgs']
    else:
        customudfargs = None
    udfArgs = {"sourceBucket": sourceBucket, "processBucket": processBucket, "sourceFileObject": sourceFileObject,
               "projectId": projectId, "clusterLabel": clusterLabel, "region": region, "customUdfArgs": customudfargs}
    print("udf args are: ", udfArgs)

    gcs_hook = GCSHook(gcp_conn_id=variables['gcp_conn_id'])
    source_credentials = gcs_hook.get_credentials()
    print("function url :", audience)
    target_credentials = impersonated_credentials.Credentials(
        source_credentials=source_credentials,
        target_principal=target_principal,
        target_scopes=target_scopes,
        lifetime=300)
    tokenCredential = impersonated_credentials.IDTokenCredentials(target_credentials, target_audience=audience)
    request = google.auth.transport.requests.Request()
    tokenCredential.refresh(request)
    TOKEN = tokenCredential.token
    print(TOKEN)
    dict_obs_static = str(params["obs"])
    dict_obs_static = json.loads(
        (reduce(lambda key, value: key.replace(*value), varMap.items(), dict_obs_static)).replace("'", '"'))
    dict_obs.update(dict_obs_static)
    dict_obs["process_date"] = str(date.today().strftime("%Y-%m-%d"))
    data_interval_endtime = context['data_interval_end'].in_timezone(tz)
    dict_obs["run_date"] = str(data_interval_endtime.strftime('%Y%m%d')) if processDate == None else str(
        datetime.strptime(processDate, '%Y-%m-%d').strftime("%Y%m%d"))
    dict_obs["run_day"] = str(data_interval_endtime.strftime('%A')) if processDate == None else str(
        datetime.strptime(processDate, '%Y-%m-%d').strftime('%A'))
    dict_obs["run_hour"] = str(data_interval_endtime.strftime("%H:%M:%S")) if processTime == None else str(
        datetime.strptime(processTime, '%H:%M:%S').strftime("%H:%M:%S"))
    dict_obs["log_file"] = varMap['log_file']
    dict_obs["process_name"] = dagId
    try:
        if 'gen2' in params['hook']:
            if (params['hook']['gen2']).lower() == 'true':
                response = requests.post(audience,headers={'Authorization': f"Bearer {TOKEN}", "Content-Type": "application/json"},data=json.dumps({"udfArgs": udfArgs}))
                dict_obs["error_message"] = "UDF cloud function"
                dict_obs["run_status"] = "Success"
        else:
            print("gen 1 cloud function is called! Cloud function Hooks are being used.")
            cloud_function_hook=CloudFunctionsHook(api_version='v1',gcp_conn_id=variables['gcp_conn_id'])
            response=cloud_function_hook.call_function(function_id=cloudFnName,input_data={"data": json.dumps({"udfArgs": udfArgs})},location=region,project_id=projectId)
            dict_obs["error_message"] = "UDF cloud function"
            dict_obs["run_status"] = "Success"
    except Exception as e:
        error_msg = str(e)
        dict_obs["run_status"] = "Failure"
        dict_obs["error_message"] = "UDF cloud function"
        logging.error(traceback.format_exc())
        opsgenie_message = variables["environment"] + " Alert | Failure while invoking the UDF cloud function"
        opsgenie_description = "Failure while invoking the UDF cloud function"
        opsgenie_details = {"DAG ID": dagId, "Error Step": "Preprocessing",
                            "File Location": "gs://" + sourceBucket + "/" + sourceFileObject,
                            "Error Message": error_msg}
        if (retries == 0 and task_instance.try_number == 1) or (retries > 0 and  task_instance.try_number == retries + 1):
            send_alert_to_opsgenie(opsgenie_message, opsgenie_description, opsgenie_details, opsgenie_priority,
                               projectDetails=projectDetails,alertTeamName=alertTeamName,sub_lob_alert=sub_lob_alert)
    try:
        ## passing the process end time based on that task sequence in the dag ##
        logger_name = params["obs"]["logger_name"]
        dict_obs["inserted_timestamp"] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
        observability.ingestion_obs(dict_obs, logger_name)
        print("Observablity Inserted Cloud Function")
        # observability.udfcf_obs(dict_obs, logger_name)
    except Exception as e:
        error_msg = str(e)
        print("error_msg : ", error_msg)
        logging.error(traceback.format_exc())
        print("Could not send observability log")
        sys.tracebacklimit = 0
        raise RuntimeError("Failure while sending observability logs")
    # print("http response status code and Reason: ", response.status_code, response.reason)

    if 'gen2' in params['hook']:
        if (params['hook']['gen2']).lower() == 'true':
            if response.status_code != 200:
                #response = json.loads(response.text)
                opsgenie_message = variables["environment"]+" Alert | Failure while executing user defined function " + cloudFnName
                opsgenie_description = "Failure while executing user defined function " + cloudFnName
                opsgenie_details = {"DAG ID":dagId,"Error Step":"Preprocessing","File Location": "gs://"+sourceBucket+"/"+sourceFileObject,"Udf" : cloudFnName}
                if (retries == 0 and task_instance.try_number == 1) or (retries > 0 and  task_instance.try_number == retries + 1):
                    send_alert_to_opsgenie(opsgenie_message, opsgenie_description, opsgenie_details, opsgenie_priority, projectDetails=projectDetails,sub_lob_alert=sub_lob_alert)
                sys.tracebacklimit = 0
                raise RuntimeError("Failure while executing user defined function " + cloudFnName + "... exiting")
    else:
            response_text=response['result']
            if response_text.lower() !='success':
                print(response_text)
                #response = json.loads(response.text)
                #logging.error(response['traceback'])
                print("cloud function execution failed.. please check the logs")
                opsgenie_message = variables["environment"]+" Alert | Failure while executing user defined function " + cloudFnName
                opsgenie_description = "Failure while executing user defined function " + cloudFnName
                opsgenie_details = {"DAG ID":dagId,"Error Step":"Preprocessing","File Location": "gs://"+sourceBucket+"/"+sourceFileObject,"Udf" : cloudFnName}
                send_alert_to_opsgenie(opsgenie_message, opsgenie_description, opsgenie_details, opsgenie_priority, projectDetails=projectDetails,sub_lob_alert=sub_lob_alert)
                sys.tracebacklimit = 0
                raise RuntimeError("Failure while executing user defined function " + cloudFnName + "... exiting")

    # response = json.loads(response.text)
    print("preprocessing cloud function returned value : ", response)
