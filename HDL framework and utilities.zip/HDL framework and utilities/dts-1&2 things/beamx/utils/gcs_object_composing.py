from __future__ import annotations

import itertools
import os
from collections.abc import Iterable
from collections.abc import Iterator
from concurrent.futures import ThreadPoolExecutor
from airflow.providers.google.cloud.hooks.gcs import GCSHook
from google.api_core import client_info as http_client_info
from google.auth import exceptions as auth_exceptions
from google.cloud import storage
from google.cloud.storage import Blob, Bucket
import re
from datetime import datetime
import pendulum
tz = pendulum.timezone("EST")

MAX_BLOB_INSTANCE_TO_COMPOSE: int = 30

USER_AGENT: str = "gcp_test"


class GCSConnectionError(ConnectionError):
    ...


class OverflowSourceBlobObjectsError(Exception):
    ...


def get_http_client_info():
    return http_client_info.ClientInfo(user_agent=USER_AGENT)


def get_client(gcp_conn_id: str):
    try:
        #info = get_http_client_info()
        #client = storage.Client(project=project_id, client_info=info)
        client = GCSHook(gcp_conn_id=gcp_conn_id).get_conn()
        return client
    except auth_exceptions.DefaultCredentialsError as error:
        raise GCSConnectionError from error


def extract_bucket_and_blob_name(gcs_uri: str) -> tuple[str, str]:
    """Returns a tuple of bucket, blob name.

    Args:
        gcs_uri (str): GCS object uri.

    Returns:
        tuple(str, str): Tuple of bucket name and blob name.
    """
    bucket, blob = gcs_uri.replace('gs://', '').split('/', maxsplit=1)
    return bucket, blob

def dynamic_file(sourceFileName :str) -> str :
    
    if re.search(r'YYYYMMDDHHMISS', sourceFileName): 
        matchObj = re.search(r'YYYYMMDDHHMISS', sourceFileName)
        processDate = str(datetime.now(tz).strftime("%Y%m%d%H%M%S"))
        sourceFileName=re.sub(matchObj.group(),processDate,sourceFileName)
        print(sourceFileName)
    # Sample datettime pattern : 202212061531_20221220_96191
    elif re.search(r'YYYYMMDDHHMI', sourceFileName): 
        matchObj = re.search(r'YYYYMMDDHHMI', sourceFileName)
        processDate = str(datetime.now(tz).strftime("%Y%m%d%H%M"))
        sourceFileName=re.sub(matchObj.group(),processDate,sourceFileName)
        print(sourceFileName)
    # Sample datettime pattern : 2022.12.06_02-30-00
    elif re.search(r'YYYYMMDDHH', sourceFileName): 
        matchObj = re.search(r'YYYYMMDDHH', sourceFileName)
        processDate  = str(datetime.now(tz).strftime("%Y%m%d%H"))
        sourceFileName=re.sub(matchObj.group(),processDate,sourceFileName)
        print(sourceFileName)
    # Sample datettime pattern : 2022-12-06
    elif re.search(r'YYYYMMDD', sourceFileName): 
        matchObj = re.search(r'YYYYMMDD', sourceFileName)
        processDate = str(datetime.now(tz).strftime("%Y%m%d"))
        sourceFileName=re.sub(matchObj.group(),processDate,sourceFileName)
        print(sourceFileName)
    # Sample datettime pattern : 202212061531_20221220_96191
    elif re.search(r'YYYYMM', sourceFileName): 
        matchObj = re.search(r'YYYYMM', sourceFileName)
        processDate = str(datetime.now(tz).strftime("%Y%m"))
        sourceFileName=re.sub(matchObj.group(),processDate,sourceFileName)
        print(sourceFileName)
    elif re.search(r'YYYY', sourceFileName): 
        matchObj = re.search(r'YYYY', sourceFileName)
        processDate = str(datetime.now(tz).strftime("%Y"))
        sourceFileName=re.sub(matchObj.group(),processDate,sourceFileName)
        print(sourceFileName)
    
    # Sample datettime pattern : 2022.12.06_02-30-00
    return sourceFileName


def get_file_list(client: storage.Client, bucket_name: str, gcs_uri: str):
    """list of files in GCS bucket.

        Args:
            client: GCS client.
            bucket_name (str): GCS bucket name.
            gcs_uri (str): GCS URI of the file.
        Returns:
            file_list (list): File list in given gcs uri
        """
    # blob_name = gcs_uri.split('gs://{}/'.format(bucket_name))[1]
    _, blob_name = extract_bucket_and_blob_name(gcs_uri)
    blob_list = client.list_blobs(bucket_name, prefix=blob_name)
    file_list = []

    for blob in blob_list:
        if not blob.name.endswith('/'):
            if blob.size > 0:  # Filter empty files
                file_list.append(blob)

    return file_list


def delete_blobs(files_list):
    # for blob_list in files_list:
    #     for blob in enumerate(blob_list):
    #         blob.delete()
    with ThreadPoolExecutor(max_workers=os.cpu_count()) as executor:
        for blobs in files_list:
            results = executor.map(Blob.delete, blobs)
            for _ in results:
                print("Deleting...")


def delete_file(client: storage.Client, bucket_name: str, file_name: str) -> None:
    """Deletes GCS file.

    Args:
        client: GCS Client.
        bucket_name (str): GCS bucket name.
        file_name (str): Complete GCS URI of the object or simply path.
    """

    if file_name.startswith('gs://' + bucket_name + '/'):
        bucket_name, blob_name = extract_bucket_and_blob_name(file_name)
    else:
        blob_name = file_name

    bucket: Bucket = client.get_bucket(bucket_name)
    blob: Blob = bucket.blob(blob_name)
    blob.delete()


def compose_file(client: storage.Client,
                 bucket_name: str,
                 source_blob_list: list,
                 destination_blob_name: str):
    """Concatenate source blobs into destination blob."""

    if not source_blob_list:  # No objects to compose
        return None

    if len(source_blob_list) > MAX_BLOB_INSTANCE_TO_COMPOSE:
        raise OverflowSourceBlobObjectsError(f"source blob object's list should not be "
                                             f"more than {MAX_BLOB_INSTANCE_TO_COMPOSE} objects")

    # SOURCE_CONTENT_TYPE = source_blob_list[0].content_type
    bucket = client.bucket(bucket_name)
    destination: Blob = bucket.blob(destination_blob_name)
    destination.content_type = "text/csv"
    # destination.content_type = SOURCE_CONTENT_TYPE
    print(f"{destination = }")

    # Note: sources is a list of Blob instances, up to the max of 32 instances per request
    destination.compose(source_blob_list)

    return destination


def chunks(iterable: Iterable, chunk_size: int) -> Iterator[tuple]:
    """Splits an iterable into multiple chunks depending on the
    specified chunk size.

    Args:
        iterable (Iterable): A iterable sequence collection.
        chunk_size (int): Chunk size to split an iterable.

    Returns:
         Iterator: An iterator having tuples of an iterable chunk.
    """
    iterator = iter(iterable)
    return iter(lambda: tuple(itertools.islice(iterator, chunk_size)), ())


def main(context,gcp_conn_id, source_path,destination_path,source_object_name,file_extension):
    #PROJECT_ID: str = "vz-it-np-gk1v-dev-cwlspr-0"
    #source_path: str = "gs://verizon_p3_pilot/composer_script_output/export_data/"
    #destination_path: str = "gs://verizon_p3_pilot/composer_script_output/py_final_output/"

    #source_object_name: str = "cja_data"
    #file_extension = "csv"

    source_object_name = dynamic_file(source_object_name)

    _, destination_blob_name = extract_bucket_and_blob_name(destination_path)
    destination_blob_name = destination_blob_name.rstrip('/').lstrip('/')
    # destination_object_name = f"{destination_object_name.rstrip('/')}/{source_object_name}"
    if destination_blob_name != "":
        staged_dest_path = f"{destination_blob_name}/staged_objects/merged_{source_object_name}_{{}}.{file_extension}"
        final_dest_path = f"{destination_blob_name}/mvp_export_soi/{source_object_name}.{file_extension}"
    else:
        staged_dest_path = f"staged_objects/merged_{source_object_name}_{{}}.{file_extension}"
        final_dest_path = f"mvp_export_soi/{source_object_name}.{file_extension}"    

    src_bucket_name, src_blob_name = extract_bucket_and_blob_name(gcs_uri=source_path)

    client: storage.Client = get_client(gcp_conn_id)

    # Get list of all objects
    files_list = get_file_list(client, src_bucket_name, source_path)

    # Split list into multiple batches of 30 (MAX_BLOB_INSTANCE_TO_COMPOSE) objects
    files_list = list(chunks(files_list, MAX_BLOB_INSTANCE_TO_COMPOSE))

    # Composing new objects
    if len(files_list) == 1:  # If there is single batch
        for idx, blob_list in enumerate(files_list, 1):
            composed_object = compose_file(
                client, src_bucket_name, blob_list,
                # f"{destination_object_name}_{idx}.{file_extension}"
                final_dest_path
            )
            print(f"New composed object {idx}: {composed_object.name}")
            print(f"New composed object full object{idx}: {composed_object.bucket},{composed_object} ")
        # delete_blobs(files_list) # Delete source files
    else:
        merged_objects = []
        for idx, blob_list in enumerate(files_list, 1):
            composed_object = compose_file(
                client, src_bucket_name, blob_list,
                # f"{destination_object_name}_{idx}.{file_extension}"
                staged_dest_path.format(idx)
            )
            merged_objects.append(composed_object)
            print(f"Intermediate composed object {idx}: {composed_object.name}")
        print(f"Merged objects -> {merged_objects}")
        composed_object = compose_file(
            client, src_bucket_name, merged_objects,
            # f"{destination_object_name}_{idx}.{file_extension}"
            final_dest_path
        )
        print(f"Final composed object: {composed_object}")
        delete_blobs([merged_objects])


def print_blobs(files_list):
    for idx, blob_list in enumerate(files_list, 1):
        for blob in enumerate(blob_list):
            print("\t" * idx, idx, "==>", blob)


