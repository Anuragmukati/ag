"""
File Name: file_archival.py
Description: This python script is used to archive the source files in gcs after data is ingested into BQ table.
"""

from airflow.providers.google.cloud.hooks.gcs import GCSHook
from airflow.models import TaskInstance
from google.cloud import storage
from datetime import datetime
from datetime import date, timedelta
from airflow.exceptions import AirflowSkipException, AirflowFailException
import re
import bq_loader
import fnmatch
from google.cloud.exceptions import NotFound

"""
This function moves the source file to archive/failed bucket. Since this is for multiple files ingestion, it does not involve deletion in this function. Deletion process is carried out using a separate operator in multiple file ingestion DAGs
"""


def multiSrcFileArchival(params, op_args, context, bucketNameVars, variables, tz, ingestionPattern=None, group_id=None,parallelLoad="false",**kwargs):
    # get the source file object name
    sourceFileObject = op_args[0]
    # get the upstream task id and its run state
    upstreamTaskId = next(iter(context['task'].upstream_task_ids))
    print("upstream task id is :", upstreamTaskId)
    task = context["task"]
    # tis = dag_run.get_task_instances()
    processedFileList = None
    fileCompressionType = None
    logicalDate = context['logical_date']

    if parallelLoad=='false':
        processedFileList = context['ti'].xcom_pull(key='processed_file_list')
    else:
        processedFileList = context['ti'].xcom_pull(key=group_id.replace("preprocess_", "")+'_processed_file_list')
    fileCompressionType = context['ti'].xcom_pull(key=group_id.replace("preprocess_", "")+'file_compression_type')
    print("List of files processed so far :", processedFileList)
    print(" files fileCompressionType  :", fileCompressionType)

    # get the load status of bq load
    if group_id is not None:
        gcsToBqLoadStatus = context['ti'].xcom_pull(
            key=(context['ti'].task_id).replace(".archival_gcs_to_bq", "") + "_loadStatus")
        print("new xcom", (context['ti'].task_id).replace(".archival_gcs_to_bq", "") + "_loadStatus")
    else:
        gcsToBqLoadStatus = context['ti'].xcom_pull(
            key=(context['ti'].task_id).replace("archival_", "") + "_loadStatus")
    gcsToBqLoadStatus = "failure" if gcsToBqLoadStatus == None else gcsToBqLoadStatus
    context['ti'].xcom_push(key='load_status', value=gcsToBqLoadStatus)
    logicalDate = context['logical_date']

    # create a gcs hook to connect to gcs
    gcs_hook = GCSHook(gcp_conn_id=variables[params["hook"]["gcp_conn_id"]])

    if 'preProcessUdf' in params['hook']:
        sourceFileObjectSplit = sourceFileObject.rsplit('/', maxsplit=1)
        getSizeFileObject = sourceFileObjectSplit[0] + "/preprocessed/" + sourceFileObjectSplit[1]
    else:
        getSizeFileObject = sourceFileObject

    # get the size of the source file
    fileSize = gcs_hook.get_size((bucketNameVars["SOURCE_URI_BUCKET"]).split("/")[-1], getSizeFileObject)
    # define destination bucket based on the run status of load and transform steps and the file size
    if str(gcsToBqLoadStatus).lower() == 'success' or fileSize <= 4:
        destinationBucket = (bucketNameVars["ARCHIVE_BUCKET"]).split("/")[-1]
    else:
        destinationBucket = (bucketNameVars["FAILED_BUCKET"]).split("/")[-1]

    # define destination object
    destinationObject = params["hook"]["archiveLocation"] + "/" + sourceFileObject.split("/")[-1]

    # define source bucket
    sourceBucket = (bucketNameVars["SOURCE_URI_BUCKET"]).split("/")[-1]

    '''
    #define  source bucket name based on the file extension and filetype
    if (params["hook"]["sourceUris"].lower()).endswith('.tar.gz') or (params["hook"]["sourceUris"].lower()).endswith('.tar') or (params["hook"]["sourceUris"].lower()).endswith('.xml') or "diagnostics" in params["hook"]["sourceUris"].split("/") or fileCompressionType != 'no match' :
        sourceBucket = (bucketNameVars["SOURCE_URI_BUCKET"]).split("/")[-1]
    elif "fixedWidth" in params["hook"]:
        if params["hook"]["fixedWidth"].lower() == "true":
            sourceBucket = (bucketNameVars["SOURCE_URI_BUCKET"]).split("/")[-1]
    else:
        sourceBucket = (bucketNameVars["PROCESS_BUCKET"]).split("/")[-1]
    '''
    # copy the file
    gcs_hook.copy(sourceBucket, sourceFileObject, destinationBucket, destinationObject)

    if (parallelLoad == "true"):
        multiSrcFileDelete(context, params, bucketNameVars, variables, [], tz, parallelLoad, group_id)


"""
This function is specifically for dags with history enabled. It deletes the source file from inbound and process bucket.
"""
def multiSrcFileDelete(context, params, bucketNameVars, variables, op_args=[], tz=None, parallelLoad='false',group_id=None, **kwargs):
    if parallelLoad=='false':
        processedFileListXcom = context['ti'].xcom_pull(key='processed_file_list')
    else:
        processedFileListXcom = context['ti'].xcom_pull(key=group_id.replace("preprocess_", "")+'_processed_file_list')

    # removing duplicates from processed file list, if any
    processedFileList = []
    [processedFileList.append(file) for file in processedFileListXcom if file not in processedFileList]
    #fileCompressionType = context['ti'].xcom_pull(key=group_id.replace("preprocess_", "")+'file_compression_type')
    print("List of files to be deleted in source and process bucket:", processedFileList)

    # create a gcs hook to connect to gcs
    gcs_hook = GCSHook(gcp_conn_id=variables[params["hook"]["gcp_conn_id"]])

    # get the bucket names
    sourceBucket = (bucketNameVars["SOURCE_URI_BUCKET"]).split("/")[-1]
    processBucket = (bucketNameVars["PROCESS_BUCKET"]).split("/")[-1]

    # get the prefix  from the sourceUris in metadata
    prefix = str(params["hook"]["sourceUris"]).split("*")[0]

    # Checking if preprocessing udf is executed for this object. If yes, the file inside the preprocessed folder is considered as the source instead.
    preProcessedFileList = []
    if 'preProcessUdf' in params['hook']:
        prefixSplit = prefix.rsplit('/', maxsplit=1)
        prefix = prefixSplit[0] + "/preprocessed/" + prefixSplit[1]
        # Get the list of preprocessed files to be deleted
        for filename in processedFileList:
            filenameSplit = filename.rsplit('/', maxsplit=1)
            preProcessedFilename = filenameSplit[0] + "/preprocessed/" + filenameSplit[1]
            preProcessedFileList.append(preProcessedFilename)
        print(" deleting preprocessed files from processing bucket...")
    else:
        print(" deleting processed files from processing bucket...")
    print("prefix:", prefix)

    # Delete source files from process bucket
    if "diagnostics" in params["hook"]["sourceUris"].split("/") or (
            params["hook"]["sourceUris"].lower()).endswith('.tar') or (params["hook"]["sourceUris"].lower()).endswith(
        '.gz') or (params["hook"]["sourceUris"].lower()).endswith('.z') or (
            params["hook"]["sourceUris"].lower()).endswith('.zip') or (params["hook"]["sourceUris"].lower()).endswith(
        '.xml'):
        objects = gcs_hook.list(bucket_name=processBucket, prefix=prefix)
        for object_name in objects:
            try:
                gcs_hook.delete(bucket_name=processBucket, object_name=object_name)
            except NotFound:
                print(f"WARNING ---- {object_name} not found in bucket {processBucket}")


    elif "fixedWidth" in params["hook"]:
        if params["hook"]["fixedWidth"].lower() == "true":
            objects = gcs_hook.list(bucket_name=processBucket, prefix=prefix)
            for object_name in objects:
                try:
                    gcs_hook.delete(bucket_name=processBucket, object_name=object_name)
                except NotFound:
                    print(f"WARNING ---- {object_name} not found in bucket {processBucket}")
    else:
        if 'preProcessUdf' in params['hook']:
            print("preprocessed file list: ", preProcessedFileList)
            for filename in preProcessedFileList:
                try:
                    gcs_hook.delete(bucket_name=processBucket, object_name=filename)
                except NotFound:
                    print(f"WARNING ---- {filename} not found in bucket {processBucket}")
        else:
            for filename in processedFileList:
                try:
                    gcs_hook.delete(bucket_name=processBucket, object_name=filename)
                except NotFound:
                    print(f"WARNING ---- {filename} not found in bucket {processBucket}")

    # Delete source files from source bucket that got processed
    print(" deleting source files from inbound bucket...")
    for filename in processedFileList:
        try:
            gcs_hook.delete(bucket_name=sourceBucket, object_name=filename)
        except NotFound:
            print(f"WARNING ---- {filename} not found in bucket {sourceBucket}")

    # Delete preprocessed source files from source bucket that got processed
    if 'preProcessUdf' in params['hook']:
        print(" deleting preprocessed files from inbound bucket...")
        for filename in preProcessedFileList:
            if gcs_hook.exists(sourceBucket, filename):
                gcs_hook.delete(bucket_name=sourceBucket, object_name=filename)

    if 'cntrl_file' in params['hook']:
        print("control file execution")
        ctrlFile = params["hook"]["cntrl_file"]
        controlFileObject = bq_loader.replaceParametersWithRunDate(ctrlFile, context, params, tz)
        print("control file object", controlFileObject)
        sourceBucket = (bucketNameVars["SOURCE_URI_BUCKET"]).split("/")[-1]
        all_files = gcs_hook.list(bucket_name=sourceBucket)
        matching_files = []
        if isinstance(controlFileObject, str):
            controlFileObject = [controlFileObject]
        for pattern_list in controlFileObject:
            if isinstance(pattern_list, str):
                pattern_list = [pattern_list]
            for pattern in pattern_list:
                for file in all_files:
                    if fnmatch.fnmatch(file, pattern):
                        matching_files.append(file)
        print(f"found files : {matching_files}")

        dag_status = context['ti'].xcom_pull(key=f"dag_status", task_ids=None)
        print("dag_status", dag_status)
        if dag_status is not None and dag_status is False:
            print("Archiving to Failed Bucket")
            ctrlFile_destinationBucket = (bucketNameVars["FAILED_BUCKET"]).split("/")[-1]
        else:
            print("Archiving to Success Bucket")
            ctrlFile_destinationBucket = (bucketNameVars["ARCHIVE_BUCKET"]).split("/")[-1]

        for file_to_archive in matching_files:
            archive_path = params["hook"]["archiveLocation"] + "/" + file_to_archive.split("/")[-1] + "_" + str(
                context['logical_date'])[:19]
            try:
                gcs_hook.copy(sourceBucket, file_to_archive, ctrlFile_destinationBucket, archive_path)
                gcs_hook.delete(sourceBucket, file_to_archive)
            except NotFound:
                print(f"WARNING ---- {file_to_archive} not found in bucket {sourceBucket}")


"""
This function gets the list of source files in gcs inbound bucket that match the pattern specified by the user in metadata
"""


def getLatestFile_forsshtemplate(sourceObject, params, variables, bucketNameVars):
    # create a connection to gcs using GCSHook
    latestsourceobject = ""

    if ("*" in sourceObject):
        gcp_conn_id = variables[params["hook"]["gcp_conn_id"]]
        bucketName = bucketNameVars["PROCESS_BUCKET"].split("/")[-1]
        gcs_hook = GCSHook(gcp_conn_id=gcp_conn_id)
        prefix = sourceObject.split("*")[0]
        storage_client = storage.Client(credentials=gcs_hook.get_credentials())
        bucket = storage_client.bucket(bucketName)
        blobs = list(bucket.list_blobs(prefix=prefix))
        latest_blob = max(blobs, key=lambda x: x.time_created)
        latestsourceobject = latest_blob.name
    else:
        latestsourceobject = sourceObject

    return latestsourceobject


""""
This function moves the source file to archive/failed bucket. Since this is for single file ingestion,file deletion process also takes place in this function.
"""


def singleSrcFileArchival(context, params, bucketNameVars, variables, ingestionPattern=None, taskType=None,
                          fileSensorDetails=None, group_id=None, **kwargs):
    # import the necessary modules
    import bq_loader
    from common_utility_functions import get_all_upstream_task_ids

    # Conditional archival based on file presence and abandon flag
    try:
        preprocessTaskId = (context['ti'].task_id).replace("archival_", "preprocess_") + ".check_file_size"
        preprocessTask = context['dag'].get_task(preprocessTaskId)
    except Exception as e:
        # archival task moved inside task group and checking for right task name
        preprocessTaskId = (context['ti'].task_id).replace(f"{group_id}.archival_gcs_to_bq",
                                                           f"preprocess_{group_id}") + ".check_file_size"
        print("preprocessTaskId", preprocessTaskId)
        preprocessTask = context['dag'].get_task(preprocessTaskId)
    upstreamTaskIds = get_all_upstream_task_ids(preprocessTask)
    fileSensorDetailsFromUpstream = None
    for taskId in upstreamTaskIds:
        fileSensorDetailsFromUpstream = context['ti'].xcom_pull(key="fileSensorDetails", task_ids=taskId)
        if fileSensorDetailsFromUpstream != None:
            break
    print("type of fileSensorDetailsFromUpstream : ", type(fileSensorDetailsFromUpstream))
    print("fileSensorDetailsFromUpstream : ", fileSensorDetailsFromUpstream)
    fileSensorDetails = fileSensorDetailsFromUpstream[0] if fileSensorDetailsFromUpstream != None else fileSensorDetails
    print("type of fileSensorDetails : ", type(fileSensorDetails))
    print("fileSensorDetails : ", fileSensorDetails)

    sourceFileObject = params['hook']['sourceUris']
    # get the load status of bq load
    if group_id is not None:
        gcsToBqLoadStatus = context['ti'].xcom_pull(
            key=(str(context['ti'].task_id)).replace(".archival_gcs_to_bq", "") + "_loadStatus")
    else:
        gcsToBqLoadStatus = context['ti'].xcom_pull(
            key=(str(context['ti'].task_id)).replace("archival_", "") + "_loadStatus")
    gcsToBqLoadStatus = "failure" if gcsToBqLoadStatus == None else gcsToBqLoadStatus
    context['ti'].xcom_push(key='load_status', value=gcsToBqLoadStatus)
    logicalDate = context['logical_date']

    sourceFileObject = params['hook']['sourceUris']

    if taskType != "bulk load from gcs to bq":
        fileCheck = bq_loader.checkFilePresence(context, bucketNameVars, variables, sourceFileObject, params,
                                                None, None, None, None, " ", "single_file_ingestion",'false', "", group_id)

        if fileCheck['run_status'] == 'skipped' and fileSensorDetails is not None and str(
                fileSensorDetails['retryInfo']['abandon_flag']).lower() == 'true':
            print("File not present and abandon_flag is set to true. Skipping archival.")
            raise AirflowSkipException("Skipping archival due to file absence and abandon_flag.")
        elif fileCheck['run_status'] == 'skipped' and (
                'abandon_flag' in params['hook'] and params["hook"]["abandon_flag"].lower() == 'true'):
            raise AirflowSkipException(
                "no files present and abandon flag is set to true in gcs to bq, so hence skipping the task")
        else:
            print("Performing source file archival.")
    else:
        if group_id is not None:
            bulkLoadFileList = context['ti'].xcom_pull(
                key=str((context['ti'].task_id)).replace(".archival_gcs_to_bq", "") + '_bulk_load_file_list')
        else:
            bulkLoadFileList = context['ti'].xcom_pull(
                key=str((context['ti'].task_id)).replace("archival_", "") + '_bulk_load_file_list')
        if ((bulkLoadFileList is not None and len(bulkLoadFileList) == 0) or bulkLoadFileList is None) and (
                fileSensorDetails is not None and str(
            fileSensorDetails['retryInfo']['abandon_flag']).lower() == 'true'):
            raise AirflowSkipException(
                "no files present and abandon flag is set to true so hence skipping the task")
        if ((bulkLoadFileList is not None and len(bulkLoadFileList) == 0) or bulkLoadFileList is None) and \
                ('abandon_flag' in params['hook'] and params["hook"]["abandon_flag"].lower() == 'true'):
            raise AirflowSkipException(
                "no files present and abandon flag is set to true in gcs to bq, so hence skipping the task")
        if ((bulkLoadFileList is not None and len(bulkLoadFileList) == 0) or (bulkLoadFileList is None and \
                                                                              str(gcsToBqLoadStatus).lower() != "success")):
            raise AirflowSkipException("no files present to archive...upstream failed and skipping the task")
        if ((bulkLoadFileList is not None and len(bulkLoadFileList) == 0) or bulkLoadFileList is None):
            raise AirflowFailException("no files present to archive...failing the task")

    # get the file compression type and the taskType
    if group_id is None:
        fileCompressionType = context['ti'].xcom_pull(key=(context['ti'].task_id).replace("archival_", "").replace("preprocess_", "")+'file_compression_type')
    else:
        fileCompressionType = context['ti'].xcom_pull(key=group_id.replace("preprocess_", "")+'file_compression_type')
    print("file compression type : ", fileCompressionType)

    # get the required details for archival
    sourceBucket = (bucketNameVars["SOURCE_URI_BUCKET"]).split("/")[-1]
    processBucket = (bucketNameVars["PROCESS_BUCKET"]).split("/")[-1]
    sourceFile = params["hook"]["sourceUris"]

    if group_id is not None:
        sourceFileObject = context['ti'].xcom_pull(key=(context['ti'].task_id).replace(f"{group_id}.archival_gcs_to_bq",
                                                                                       f"{group_id}") + "_sourceFileObject")
        print("new code sourcefiles")
    else:
        sourceFileObject = context['ti'].xcom_pull(
            key=(context['ti'].task_id).replace("archival_", "") + "_sourceFileObject")
    print("sourceFileObject : ", sourceFileObject)

    # append the logical date to the destination object so that it's not overwritten in the next run
    destinationObject = params["hook"]["archiveLocation"] + "/" + sourceFileObject.split("/")[-1] + "_" + str(
        logicalDate)[:19]
    # connect to gcs
    gcs_hook = GCSHook(gcp_conn_id=variables[params["hook"]["gcp_conn_id"]])

    if group_id is not None:
        fileSize = context['ti'].xcom_pull(key=(context['ti'].task_id).replace(f"{group_id}.archival_gcs_to_bq",
                                                                               f"{group_id}") + "_fileSize") if taskType != "bulk load from gcs to bq" else None
        fileSizeHdr = context['ti'].xcom_pull(key=(context['ti'].task_id).replace(f"{group_id}.archival_gcs_to_bq",
                                                                                  f"preprocess_{group_id}") + "_filehdr") if taskType != "bulk load from gcs to bq" else None
        print("new code", fileSize, fileSizeHdr)
    else:
        # get the source file size
        fileSize = context['ti'].xcom_pull(key=(context['ti'].task_id).replace("archival_",
                                                                               "") + "_fileSize") if taskType != "bulk load from gcs to bq" else None

        fileSizeHdr = context['ti'].xcom_pull(key=(context['ti'].task_id).replace("archival_",
                                                                                  "preprocess_") + "_filehdr") if taskType != "bulk load from gcs to bq" else None

    if str(gcsToBqLoadStatus).lower() == 'success' or (
            taskType != "bulk load from gcs to bq" and (fileSize <= 4 or fileSizeHdr == "true")):
        destinationBucket = (bucketNameVars["ARCHIVE_BUCKET"]).split("/")[-1]
    else:
        destinationBucket = (bucketNameVars["FAILED_BUCKET"]).split("/")[-1]
    # copy the source file from to destination(archive/failed) bucket
    print("taskType : ", taskType)
    if taskType == "bulk load from gcs to bq":
        print("performing bulk load archival for the below file list")
        if group_id is not None:
            bulkLoadFileList = context['ti'].xcom_pull(
                key=str((context['ti'].task_id)).replace(".archival_gcs_to_bq", "") + '_bulk_load_file_list')
            bulkLoadFileListFinal = context['ti'].xcom_pull(
                key=str((context['ti'].task_id)).replace(".archival_gcs_to_bq", "") + '_bulk_load_file_list_final')
        else:
            bulkLoadFileList = context['ti'].xcom_pull(
                key=str((context['ti'].task_id)).replace("archival_", "") + '_bulk_load_file_list')
            bulkLoadFileListFinal = context['ti'].xcom_pull(
                key=str((context['ti'].task_id)).replace("archival_", "") + '_bulk_load_file_list_final')
        print("bulkLoadFileList: ", bulkLoadFileList)
        print("bulkLoadFileListFinal: ", bulkLoadFileListFinal)
        if bulkLoadFileList is not None:
            for file in bulkLoadFileList:
                destinationObject = params['hook']['archiveLocation'] + "/" + file.split("/")[-1] + "_" + str(
                    logicalDate)[:19]
                gcs_hook.copy(sourceBucket, file, destinationBucket, destinationObject)
                gcs_hook.delete(sourceBucket, file)
                '''if str(gcsToBqLoadStatus).lower() == 'success':
                    gcs_hook.delete(processBucket, file)
                    gcs_hook.delete(sourceBucket, file)
                else:
                    gcs_hook.delete(sourceBucket, file)'''
        if bulkLoadFileListFinal is not None and str(gcsToBqLoadStatus).lower() == 'success':
            for file in bulkLoadFileListFinal:
                print("Deleting file: ", file)
                if '.gz' in file.lower() or file.lower().endswith(".z"):
                    sourcefile = (file.split('/')[-1]).rsplit('.',1)[0]
                    gcs_hook.delete(processBucket, file + '/' + sourcefile)
                '''if 'gz' in file:
                    sourcefile = file.rsplit('.',1)[0]
                    gcs_hook.delete(processBucket, file+'/'+sourcefile)
                else:
                    gcs_hook.delete(processBucket, file)'''
                if '.zip' in file.lower():
                    fl_list = gcs_hook.list(processBucket, prefix=file + "/")
                    for file_entry in fl_list:
                        gcs_hook.delete(processBucket, file_entry)

    elif fileSize <= 4:
        gcs_hook.copy(sourceBucket, sourceFileObject, destinationBucket, destinationObject)
    elif fileSizeHdr == "true":
        gcs_hook.copy(sourceBucket, sourceFileObject, destinationBucket, destinationObject)
    elif (params["hook"]["sourceUris"].lower()).endswith('.tar.gz') or (params["hook"]["sourceUris"].lower()).endswith(
            '.tar'):
        gcs_hook.copy(sourceBucket, sourceFileObject, destinationBucket, destinationObject)
        sourceFileList = sorted(gcs_hook.list(bucket_name=processBucket, prefix=sourceFileObject))
        for fileObject in sourceFileList:
            gcs_hook.delete(processBucket, fileObject)
    elif fileCompressionType != 'no match' or (params["hook"]["sourceUris"].lower()).endswith('.gz') or (
            params["hook"]["sourceUris"].lower()).endswith('.z') or (params["hook"]["sourceUris"].lower()).endswith(
        '.zip') or (
            params["hook"]["sourceUris"].lower()).endswith('.xml'):
        gcs_hook.copy(sourceBucket, sourceFileObject, destinationBucket, destinationObject)
        sourceFileList = sorted(gcs_hook.list(bucket_name=processBucket, prefix=sourceFileObject.split(".")[0]))
        for fileObject in sourceFileList:
            gcs_hook.delete(processBucket, fileObject)
    elif "diagnostics" in params["hook"]["sourceUris"].split("/"):
        processObject = sourceFileObject + ".json"
        gcs_hook.copy(sourceBucket, sourceFileObject, destinationBucket, destinationObject)
        gcs_hook.delete(processBucket, processObject)
    elif "fixedWidth" in params["hook"]:
        print("performing fixed width archival")
        gcs_hook.copy(sourceBucket, sourceFileObject, destinationBucket, destinationObject)
        sourceFileList = sorted(gcs_hook.list(bucket_name=processBucket, prefix=sourceFileObject))
        for fileObject in sourceFileList:
            gcs_hook.delete(processBucket, fileObject)
    else:
        gcs_hook.copy(sourceBucket, sourceFileObject, destinationBucket, destinationObject)
        gcs_hook.delete(processBucket, sourceFileObject)

    if 'cntrl_file' in params['hook']:
        print("control file archival starting...")
        if group_id is not None:
            controlFileObject = context['ti'].xcom_pull(
                key=(context['ti'].task_id).replace(f"{group_id}.archival_gcs_to_bq",
                                                    f"preprocess_{group_id}") + "_controlFileObject")
        else:
            controlFileObject = context['ti'].xcom_pull(
                key=(context['ti'].task_id).replace("archival_", "preprocess_") + "_controlFileObject")
        print("control file object", controlFileObject)
        sourceBucket = (bucketNameVars["SOURCE_URI_BUCKET"]).split("/")[-1]
        ctrlFile_destinationBucket = destinationBucket

        for file_to_archive in controlFileObject:
            archive_path = params["hook"]["archiveLocation"] + "/" + file_to_archive.split("/")[-1] + "_" + str(
                logicalDate)[:19]
            gcs_hook.copy(sourceBucket, file_to_archive, ctrlFile_destinationBucket, archive_path)
            gcs_hook.delete(sourceBucket, file_to_archive)

    # Checking if preprocessing udf is executed for this object. If yes, the file inside the preprocessed folder is considered as the source instead.
    if 'preProcessUdf' in params['hook']:
        sourceFileObjectSplit = sourceFileObject.rsplit('/', maxsplit=1)
        preprocessedSourceFileObject = sourceFileObjectSplit[0] + "/preprocessed/" + sourceFileObjectSplit[1]
        # Delete preprocessed source file from source bucket
        if gcs_hook.exists(sourceBucket, preprocessedSourceFileObject):
            print(" deleting preprocessed file from inbound bucket...")
            gcs_hook.delete(sourceBucket, preprocessedSourceFileObject)

    # Delete source file from source bucket for single file ingestion
    if taskType != "bulk load from gcs to bq":
        gcs_hook.delete(sourceBucket, sourceFileObject)

    # Checking if preprocessing udf is executed for this object. If yes, the file inside the preprocessed folder is considered as the source instead.
    if 'preProcessUdf' in params['hook']:
        sourceFileObjectSplit = sourceFileObject.rsplit('/', maxsplit=1)
        preprocessedSourceFileObject = sourceFileObjectSplit[0] + "/preprocessed/" + sourceFileObjectSplit[1]
        # Delete preprocessed source file from source bucket
        if gcs_hook.exists(sourceBucket, preprocessedSourceFileObject):
            print(" deleting preprocessed file from inbound bucket...")
            gcs_hook.delete(sourceBucket, preprocessedSourceFileObject)


""""
This function moves the source file to archive/failed bucket. Since this is for single file ingestion,file deletion process also takes place in this function.
"""


def singleSrcFileArchival_forsshtemplate(context, params, bucketNameVars, variables, **kwargs):
    # get the upstream task id and its run state
    upstreamTaskId = next(iter(context['task'].upstream_task_ids))
    print("upstream task id is :", upstreamTaskId)
    fileCompressionType = context['ti'].xcom_pull(key='file_compression_type')
    logicalDate = context['logical_date']
    prevTaskRunState = (TaskInstance(context['dag'].get_task(upstreamTaskId), logicalDate)).current_state()
    print("previous task run status is :", prevTaskRunState)
    taskType = kwargs['taskType'] if 'taskType' in kwargs else 'none'
    # get the required details for archival
    sourceBucket = (bucketNameVars["SOURCE_URI_BUCKET"]).split("/")[-1]
    processBucket = (bucketNameVars["PROCESS_BUCKET"]).split("/")[-1]
    sourceUri = params["hook"]["sourceUris"]
    sourceFileObject = getLatestFile_forsshtemplate(sourceUri, params, variables, bucketNameVars)
    print("logical date is:", logicalDate)
    # append the logical date to the destination object so that it's not overwritten in the next run
    destinationObject = params["hook"]["archiveLocation"] + "/" + sourceFileObject.split("/")[-1] + "_" + str(
        logicalDate)[:19]

    if 'triggerfileUris' in params['hook']:
        triggerFileUri = params["hook"]["triggerfileUris"]
        triggerFileObject = getLatestFile_forsshtemplate(triggerFileUri, params, variables, bucketNameVars)
        triggerFileDestinationObject = params["hook"]["archiveLocation"] + "/" + triggerFileObject.split("/")[
            -1] + "_" + str(logicalDate)[:19]

        # connect to gcs
    gcs_hook = GCSHook(gcp_conn_id=variables[params["hook"]["gcp_conn_id"]])
    # get the source file size
    fileSize = gcs_hook.get_size(sourceBucket, sourceFileObject) if taskType != "bulk load from gcs to bq" else None
    fileSizeHdr = context['ti'].xcom_pull(key=(context['ti'].task_id).replace("archival_",
                                                                              "preprocess_") + "_filehdr") if taskType != "bulk load from gcs to bq" else None
    if str(prevTaskRunState).lower() == 'success' or (
            taskType != "bulk load from gcs to bq" and (fileSize <= 4 or fileSizeHdr == "true")):
        destinationBucket = (bucketNameVars["ARCHIVE_BUCKET"]).split("/")[-1]
    else:
        destinationBucket = (bucketNameVars["FAILED_BUCKET"]).split("/")[-1]
    # copy the source file from to destination(archive/failed) bucket
    if taskType == "bulk load from gcs to bq":
        bulkLoadFileList = context['ti'].xcom_pull(
            key=str((context['ti'].task_id)).replace("archival_", "") + '_bulk_load_file_list')
        for file in bulkLoadFileList:
            destinationObject = params['hook']['archiveLocation'] + "/" + file.split("/")[-1] + "_" + str(logicalDate)[
                                                                                                      :19]
            gcs_hook.copy(sourceBucket, file, destinationBucket, destinationObject)
            gcs_hook.delete(processBucket, file)
            gcs_hook.delete(sourceBucket, file)
    elif (params["hook"]["sourceUris"].lower()).endswith('.tar.gz') or (params["hook"]["sourceUris"].lower()).endswith(
            '.tar'):
        gcs_hook.copy(sourceBucket, sourceFileObject, destinationBucket, destinationObject)
        sourceFileList = sorted(gcs_hook.list(bucket_name=processBucket, prefix=sourceFileObject))
        for fileObject in sourceFileList:
            gcs_hook.delete(processBucket, fileObject)
    elif fileCompressionType != 'no match' or (params["hook"]["sourceUris"].lower()).endswith('.gz') or (
            params["hook"]["sourceUris"].lower()).endswith('.z') or (params["hook"]["sourceUris"].lower()).endswith(
        '.zip') or (
            params["hook"]["sourceUris"].lower()).endswith('.xml'):
        gcs_hook.copy(sourceBucket, sourceFileObject, destinationBucket, destinationObject)
        if 'triggerfileUris' in params['hook']:
            gcs_hook.copy(sourceBucket, triggerFileObject, destinationBucket, triggerFileDestinationObject)

        sourceFileList = sorted(gcs_hook.list(bucket_name=processBucket, prefix=sourceFileObject.split(".")[0]))
        for fileObject in sourceFileList:
            gcs_hook.delete(processBucket, fileObject)
    elif "diagnostics" in params["hook"]["sourceUris"].split("/"):
        processObject = sourceFileObject + ".json"
        gcs_hook.copy(sourceBucket, sourceFileObject, destinationBucket, destinationObject)
        gcs_hook.delete(processBucket, processObject)
    elif "fixedWidth" in params["hook"]:
        if params["hook"]["fixedWidth"].lower() == "true":
            gcs_hook.copy(sourceBucket, sourceFileObject, destinationBucket, destinationObject)
            sourceFileList = sorted(gcs_hook.list(bucket_name=processBucket, prefix=sourceFileObject))
            for fileObject in sourceFileList:
                gcs_hook.delete(processBucket, fileObject)
    else:
        gcs_hook.copy(sourceBucket, sourceFileObject, destinationBucket, destinationObject)
        gcs_hook.delete(processBucket, sourceFileObject)

        # Delete source file from source bucket for single file ingestion
    if taskType != "bulk load from gcs to bq":
        gcs_hook.delete(sourceBucket, sourceFileObject)
        if 'triggerfileUris' in params['hook']:
            gcs_hook.delete(sourceBucket, triggerFileObject)

            # Checking if preprocessing udf is executed for this object. If yes, the file inside the preprocessed folder is considered as the source instead.
    if 'preProcessUdf' in params['hook']:
        sourceFileObjectSplit = sourceFileObject.rsplit('/', maxsplit=1)
        preprocessedSourceFileObject = sourceFileObjectSplit[0] + "/preprocessed/" + sourceFileObjectSplit[1]
        # Delete preprocessed source file from source bucket
        if gcs_hook.exists(sourceBucket, preprocessedSourceFileObject):
            print(" deleting preprocessed file from inbound bucket...")
            gcs_hook.delete(sourceBucket, preprocessedSourceFileObject)
