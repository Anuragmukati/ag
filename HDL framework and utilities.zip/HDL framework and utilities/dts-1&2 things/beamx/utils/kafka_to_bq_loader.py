from datetime import datetime
from airflow.models import Variable
from datetime import date, timedelta, timezone, tzinfo
from functools import reduce
import logging
import json
import sys
import base64
import traceback
import re
import os
from google.cloud import secretmanager

def get_secret_from_sm(project_id, secret_name, dpHook):
        client = secretmanager.SecretManagerServiceClient(credentials=dpHook.get_credentials())
        secret_name = f"projects/{project_id}/secrets/{secret_name}/versions/latest"
        response = client.access_secret_version(name=secret_name)
        return response.payload.data.decode("UTF-8")

def kafka_to_bq_load(context, metadataParams, dagId, variables, varMap, tz):
    BASE_DIR = variables["packages_directory"]
    sys.path.append(f"{BASE_DIR}/utils")
    """Details for pysprak job creation"""
    dataprocConfigDict = variables["dataproc_config_kafkaToBQ"]
    kafka_type = metadataParams["hook"]["kafka_type"]
    file_uri = dataprocConfigDict["file_uris"][kafka_type]
    project_id = variables["projectId"]
    #job_id = dagId.lower() + '_' + str(datetime.now(tz).strftime("%Y%m%d%H%M%S"))
    job_id = dagId.lower()
    cluster_label_pointer = metadataParams["hook"]["cluster_label_pointer"]
    run_id = context['dag_run'].run_id
    task_id = context['task'].task_id
    composer_name = os.getenv('COMPOSER_ENVIRONMENT')
    dagId = dagId
    # labels_dict = getLabelsDict(run_id,task_id,composer_name)
    labels_dict = {
        "job_id": dagId.lower()[-63:],
        "task_type": "kafka_to_bq",
        "run_id": re.sub(r'[^A-Za-z0-9 _-]+', '', run_id).lower()[-63:],
        "task_id": task_id.lower().replace('.', "")[-63:],
        "instance_name": composer_name.lower()
    }
    cluster_label = dataprocConfigDict["cluster_label"][cluster_label_pointer]
    python_file_uri = "gs://aid-gk1v-data-ingestion/scripts/KafkaToBQStreaming_mytest.py"
    spark_app_name = "KafkatoBQapp_" + dagId + str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
    time_parser_policy = dataprocConfigDict["properties"]["sql.legacy.timeParserPolicy"]
    view_acls = dataprocConfigDict["properties"]["spark.ui.view.acls"]
    permission_unmask_mode = dataprocConfigDict["properties"]["spark.hadoop.fs.permissions.umask-mode"]
    store_assignment_policy = dataprocConfigDict["properties"]["spark.sql.storeAssignmentPolicy"]
    driver_extra_java_options = dataprocConfigDict["properties"]["spark.driver.extraJavaOptions"][kafka_type]
    executor_extra_java_options = dataprocConfigDict["properties"]["spark.executor.extraJavaOptions"][kafka_type]
    resource = metadataParams["hook"]["resource"]
    driver_memory = dataprocConfigDict["properties"][resource]["spark.driver.memory"]
    initial_executors = dataprocConfigDict["properties"][resource]["spark.dynamicAllocation.initialExecutors"]
    min_executors = dataprocConfigDict["properties"][resource]["spark.dynamicAllocation.minExecutors"]
    max_executors = dataprocConfigDict["properties"][resource]["spark.dynamicAllocation.maxExecutors"]
    executor_cores = dataprocConfigDict["properties"][resource]["spark.executor.cores"]
    executor_memory = dataprocConfigDict["properties"][resource]["spark.executor.memory"]
    jar_file_uri = dataprocConfigDict["jar_file_uris"]
    opsgenie_module_file_uri = []
    opsgenie_module_file_uri.append(dataprocConfigDict["ops_genie_module_python_file_uri"])
    kafka_topic_name = metadataParams["hook"]["kafka_topic_name"]
    kafka_topic_name = reduce(lambda key, value: key.replace(*value), varMap.items(), kafka_topic_name)
    kafka_bootstrap_server = dataprocConfigDict["bootstrap_servers"][kafka_type]
    truststore_password = dataprocConfigDict["truststore_password"][kafka_type]
    # truststore_password = base64.b64encode(truststore_password.encode('utf-8'))
    security_protocol = metadataParams["hook"]["security_protocol"]
    sasl_mechanism = metadataParams["hook"]["sasl_mechanism"]
    trustore_location = metadataParams["hook"]["trustore_location"]
    starting_offset = metadataParams["hook"]["starting_offset"]
    temp_view = metadataParams["hook"]["temp_view"]
    json_schema_file = metadataParams["hook"]["json_schema_file"]
    json_schema_file_parent_path = dataprocConfigDict["json_schema_file_parent_path"]
    json_schema_file_path = json_schema_file_parent_path + json_schema_file
    file_format = metadataParams["hook"]["file_format"] if "file_format" in metadataParams["hook"] else ""
    query = metadataParams["hook"]["query"]
    file_format = metadataParams["hook"]["file_format"] if "file_format" in metadataParams["hook"] else ""
    checkpoint_location_sub_path = metadataParams["hook"]["checkpoint_location"]
    checkpoint_location_parent_path = dataprocConfigDict["checkpoint_location_parent_path"]
    checkpoint_location = checkpoint_location_parent_path + checkpoint_location_sub_path
    gcs_tmp_bucket = dataprocConfigDict["gcs_temp_bucket"]
    dataset_name = dataprocConfigDict["bigquery_dataset"][metadataParams["hook"]["dataset_name"]]
    table_name = metadataParams["hook"]["table_name"]
    table_name = project_id + '.' + dataset_name + '.' + table_name
    processing_time = metadataParams["hook"]["processing_time"] if "processing_time" in metadataParams["hook"] else ""
    truncate_table = metadataParams["hook"]["truncate_table"] if "truncate_table" in metadataParams["hook"] else ""
    output_mode = metadataParams["hook"]["output_mode"]
    number_of_partitions = str(metadataParams["hook"]["number_of_partitions"])
    max_offset_per_trigger = str(metadataParams["hook"]["max_offset_per_trigger"])
    fail_on_data_loss = metadataParams["hook"]["fail_on_data_loss"]
    realtime_ingestion_type = metadataParams["hook"]["realtime_ingestion_type"]
    json_columns = metadataParams["hook"]["json_columns"] if "json_columns" in metadataParams["hook"] else ""
    opsgenie_priority = metadataParams["hook"]["opsgeniePriority"]
    env = variables.get("environment")
    airflow_url=variables.get("Airflow_DAG_URL")
    region_pointer = cluster_label_pointer.split('-')[1]
    region = dataprocConfigDict["region"][region_pointer]
    PYSPARK_JOB = {"reference": {"project_id": project_id, "job_id": job_id},
               "placement": {"cluster_labels": cluster_label},
               "labels": labels_dict,
               "pyspark_job": {
                   "main_python_file_uri": python_file_uri,
                   "properties": {
                       "spark.master": "yarn",
                       "spark.app.name": spark_app_name,
                       "spark.submit.deployMode": "cluster",
                       "spark.sql.legacy.timeParserPolicy": time_parser_policy,
                       "spark.ui.view.acls": view_acls,
                       "spark.hadoop.fs.permissions.umask-mode": permission_unmask_mode,
                       "spark.sql.storeAssignmentPolicy": store_assignment_policy,
                       "spark.driver.extraJavaOptions": driver_extra_java_options,
                       "spark.executor.extraJavaOptions": executor_extra_java_options,
                       "spark.driver.memory": driver_memory,
                       "spark.dynamicAllocation.initialExecutors": initial_executors,
                       "spark.dynamicAllocation.maxExecutors": max_executors,
                       "spark.dynamicAllocation.minExecutors": min_executors,
                       "spark.executor.cores": executor_cores,
                       "spark.executor.memory": executor_memory
                   },
                   "file_uris": file_uri,
                   "python_file_uris": opsgenie_module_file_uri,
                   "jar_file_uris": jar_file_uri,
                   "args": [kafka_topic_name, kafka_bootstrap_server, security_protocol, sasl_mechanism,
                            trustore_location, starting_offset, temp_view, query, file_format, checkpoint_location,
                            gcs_tmp_bucket, table_name, truncate_table, processing_time, output_mode,
                            number_of_partitions, json_schema_file_path, max_offset_per_trigger, fail_on_data_loss,
                            realtime_ingestion_type, kafka_type, truststore_password, json_columns,
                            opsgenie_priority, spark_app_name, dagId, env, airflow_url]}}
    print("********",PYSPARK_JOB)
    print(type(PYSPARK_JOB))
    return PYSPARK_JOB,region

def failure_task_alert(error_msg,variables,metadataParams,opsgenie_priority, projectDetails, dagId,task_instance,alertTeamName,sub_lob_alert,dict_obs):
    from ops_genie import send_alert_to_opsgenie
    
    job_id = dagId.lower()
    project_id = variables["projectId"]
    opsgenie_priority = metadataParams["hook"]["opsgeniePriority"]
    dataprocConfigDict = variables["dataproc_config_kafkaToBQ"]
    dataset_name = dataprocConfigDict["bigquery_dataset"][metadataParams["hook"]["dataset_name"]]
    table_name = metadataParams["hook"]["table_name"]
    table_name = project_id + '.' + dataset_name + '.' + table_name
    retries=task_instance.max_tries

    opsgenie_message = "Beamx|"+variables.get("environment")+"|Failure|"+task_instance.task_id+"|"+ dict_obs['running_instance_id']
    opsgenie_description = "Failure |KAFKA to BQ load failed|" + dict_obs['running_instance_id']
    opsgenie_details = {"dataprocJobId": job_id, "DAG ID": dagId, "Error Step": "Kafka to bq pyspark job failed",
                        "Target table": table_name, "Error message": error_msg}
    if (retries == 0 and task_instance.try_number == 1) or (retries > 0 and  task_instance.try_number == retries + 1):
        send_alert_to_opsgenie(opsgenie_message, opsgenie_description, opsgenie_details, opsgenie_priority, projectDetails=projectDetails, alertTeamName=alertTeamName,sub_lob_alert=sub_lob_alert)

"""
This function gets the static and the dynamic params to send to observability logs. The static params come from metadata and the dynamic params are calculated in this script at run time.
"""
def getObsParams(context, dict_obs, tz, varMap, dagId, project_id):
    # capturing obs static values
    dict_obs_static = json.loads(
        reduce(lambda key, value: key.replace(*value), varMap.items(), (str(params["obs"])).replace("'", '"')))

    # capturing obs dynamic values
    dict_obs["start_time"] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
    dict_obs["inserted_timestamp"] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
    dict_obs["process_date"] = str(date.today())
    run_hour = context['data_interval_end']
    dict_obs["run_hour"] = str(run_hour.in_timezone(tz).strftime("%H:%M:%S"))
    dict_obs["run_date"] = str(datetime.now(tz).strftime('%Y%m%d'))
    dict_obs["run_day"] = str(datetime.now(tz).strftime('%A'))
    dict_obs["target_type"] = "Table"
    dict_obs["process_name"] = dagId
    dict_obs["gcp_project"] = project_id

    # merge static and dynamic ob params
    dict_obs.update(dict_obs_static)
    return dict_obs

"""
Send oservability logs to logger
"""
def sendObsLogs(dict_obs, run_status, end_time, error_msg, table_name, dataset_name, variables, project_id):
    BASE_DIR = variables["packages_directory"]
    sys.path.append(f"{BASE_DIR}/utils")
    from observability import kafka_to_bq_obs
    
    # table_name_parts = table_name.split('.')
    bq_table = table_name
    target_db = dataset_name
    dict_obs["error_msg"] = error_msg
    dict_obs["run_status"] = run_status
    dict_obs["process_end_time"] = end_time
    gcp_conn_id = variables["gcp_conn_id"]
    try:
        kafka_to_bq_obs(dict_obs, gcp_conn_id, project_id, target_db, bq_table)
    except Exception as e:
        error_msg = str(e)
        print("error_msg : ", error_msg)
        logging.error(traceback.format_exc())
        print("Could not send observability log")

