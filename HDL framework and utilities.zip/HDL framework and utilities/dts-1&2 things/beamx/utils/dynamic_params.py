"""
File Name: dynamic_params.py
Description: This python utility fetches the dag run config during runtime,if the user opted for "Trigger DAG w/ config"
"""

"""
This functions checks if the user passed any dag run config . If yes, it overwrites and returns the metadata params for a particular step with dynamic params(dag run conf) based on the taskType passed. If no, original params from metadata ate returned
"""
def checkDynamicParams(context, params, taskType):
    dynamic_config = context['dag_run'].conf  
    if dynamic_config != {}:
        dynamic_config = {k.lower(): v for k, v in dynamic_config.items()}
        for task in dynamic_config['steps']:
            task = {k.lower(): v for k, v in task.items()}
            if task['name'].lower() != 'start' and task['name'].lower() != 'end':
                if task['type'].lower() == taskType :
                    params = task['params']
                    print("updated params:", params)
                    break          
            else:
                print("no dynamic config passed for this task while triggering, proceeding with user metadata..")

    else:
        print("no dynamic config passed while triggering, proceeding with user metadata..")

    return params
