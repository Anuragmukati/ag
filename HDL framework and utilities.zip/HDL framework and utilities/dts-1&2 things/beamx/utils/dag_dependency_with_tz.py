from airflow.models.dagrun import DagRun, DagRunState
from airflow import DAG
import pytz
import datetime
from airflow.operators.python import get_current_context
import pendulum
from datetime import date, timedelta, timezone, tzinfo

'''
function:get_dependency_status_interval_end
description:
  The code gets the dependent dag run last run list and checks if it has run successfully for the given data interval end.
  Airflow has a concept called Data interval. Data interval defines a period for which the DAG is running. The Data interval has Start and End and {{ds}} will equal the start of the data interval. {{ds}} is actually one day behind for daily jobs and one week behind for weekly jobs. Because of this delay in {{ds}} the current cross dag dependency is not working as expected. We can solve this by using {{data_interval_end}} variable instead of {{ds}}.  {{data_interval_end}} matches the run date and dependency logic will work as expected. 
  
  op_kwargs :
  Scenarion#1: DAG B wants to check the daily completion status of DAG A before it is initiated - Set delta = 0,for_any_last_exec_flag=0, and threshold =0
  Scenario#2: DAG B want to check the previous day completion status of DAG A before it is initiated: Set delta = n,for_any_last_exec_flag=0 and threshold = 0
  Scenario#3: DAG B want to check the previous weekly/monthly completion status of DAG A before it is initiated: Set delta = 0,for_any_last_exec_flag=1 and threshold = 8 for weekly or 31 for monthly
'''


def get_dependency_status_interval_end(ext_dag, data_interval_end, ts, for_any_last_exec_flag, dag_query_days, tz, delta_hour=0, delta=0, threshold=0 ):
    context = get_current_context()
    date_end = str(context['data_interval_end'].in_timezone(tz)) # 2024-11-14 18:30:00
    ds = (datetime.datetime.strptime(context['ds'], '%Y-%m-%d')).astimezone(tz) # 2024-11-13 18:30:00
    date_end = date_end[:19] # 2024-11-14 18:30:00
    # macro data_interval_end prints in this format '2022-11-22T03:00:00+00:00'. 
    dt = datetime.datetime.strptime(date_end, '%Y-%m-%dT%H:%M:%S') # 2024-11-14T18:30:00
    dt_s = datetime.datetime.strftime(dt, '%Y-%m-%d') # 2024-11-14
    dt_hr = datetime.datetime.strftime(dt, '%Y-%m-%d %H') # 2024-11-14 18:00:00
    print('Upstream Dag Name: ', ext_dag)
    print('dag interval end date: ', date_end, 'for dag execution date: ', str(ds)[:10])
    print('for any last execution date flag :', for_any_last_exec_flag)
    print('Dag Query Number of Days :', dag_query_days)
    print('previous run delta days: ', delta)
    print('for any previous run threshold # of Days: ', threshold)
    print("dt_hr is", dt_hr)
    t = datetime.datetime.now(tz=tz) # 2024-11-14 18:00:00
    delta_date = (datetime.datetime.strptime(dt_s, "%Y-%m-%d") - datetime.timedelta(days=delta)).strftime("%Y-%m-%d") #2024-11-14 - 1 = 2024-11-13
    delta_hr = (datetime.datetime.strptime(dt_hr, "%Y-%m-%d %H") - datetime.timedelta(hours=delta_hour)).strftime("%Y-%m-%d %H") #2024-11-14 18:00:00 - 3 = 2024-11-14 15:00:00
    print('delta date', delta_date)
    print('delta hour', delta_hr)
    # date range query filter for dag run instances:
    dag_run_start_date = (datetime.datetime.strptime(dt_s, "%Y-%m-%d") - datetime.timedelta(days=dag_query_days)).astimezone(tz)
    dag_run_end_date = datetime.datetime.strptime(t.strftime('%Y-%m-%d %H:%M:%S'), "%Y-%m-%d %H:%M:%S").astimezone(tz)
    print('Dag Query Start Date is :', dag_run_start_date)
    print('Dag Query End Date is: ', dag_run_end_date)
    # Hour
    dependency_delta_hourly = delta_hour
    # Queries only for date range
    dag_runs = DagRun.find(dag_id=ext_dag, state=DagRunState.SUCCESS, execution_start_date=dag_run_start_date, execution_end_date=dag_run_end_date)
    print("printing the dag runs...")
    print(dag_runs)
    dags = []
    ld_dt = None
    ld_hr = None
    # for previous dag runs delta is <> 0 and ld_dt is the delta date = child dag's  interval end date - # days of delta
    if delta != 0 and for_any_last_exec_flag == 0:
        ld_dt = delta_date
        print('Previous Run Load Date is: ', ld_dt)
    if delta_hour != 0 and for_any_last_exec_flag == 0:
       ld_hr = delta_hr
       print('Previous Run Load Hour is:', ld_hr)
    # for current loads: ld_dt is child dag current interval end date
    if delta == 0 and for_any_last_exec_flag == 0:
        ld_dt = dt_s
        print('Current Load Dt is: ', ld_dt)
    if delta_hour == 0 and for_any_last_exec_flag == 0:
        ld_hr = dt_hr
        print('Current Load Hr is :', ld_hr)
    print("ld_hr is", ld_hr)
    print("ld_dt is", ld_dt)
    for d in dag_runs:
        ####
        print("data interval end hr of dag run ", d.data_interval_end.strftime("%Y-%m-%d %H"))
        print("data interval end date of dag run", d.data_interval_end.strftime("%Y-%m-%d"))
        #### 
        threshold_days = datetime.datetime.strptime(dt_s,"%Y-%m-%d") - datetime.datetime.strptime(str(d.data_interval_end.strftime("%Y-%m-%d")), "%Y-%m-%d")
        threshold_hours = datetime.datetime.strptime(dt_hr, "%Y-%m-%d %H") - datetime.datetime.strptime(str(d.data_interval_end.strftime("%Y-%m-%d %H")), "%Y-%m-%d %H")
        #print("threshold_days is " , threshold_days)
        #print("threshold_hours is ", threshold_hours)
        #print("threshold_days.days is ", threshold_days.days)
        #print("threshold is ", threshold)
        if for_any_last_exec_flag == 1 and int(threshold_days.days) <= threshold and  int(threshold_days.days) >= 0:
            print('dag instance condition met within the threshold days for execution date:', d.execution_date.strftime("%Y-%m-%d"), ' and threshold days# ', threshold_days, 'and interval end date is : ',str(d.data_interval_end.strftime("%Y-%m-%d")))
            dags.append(d)
        elif for_any_last_exec_flag == 0 and d.data_interval_end.strftime("%Y-%m-%d %H") == ld_hr and d.data_interval_end.strftime("%Y-%m-%d") == ld_dt:
            print('dag instance condition met for execution hour : ', d.data_interval_end.strftime("%Y-%m-%d %H"))
            print('dag instance condition met for execution date: ', d.data_interval_end.strftime("%Y-%m-%d"))
            dags.append(d)        
        #elif for_any_last_exec_flag == 0 and d.data_interval_end.strftime("%Y-%m-%d") == ld_dt:
        #    print('dag instance condition met for execution date: ', d.data_interval_end.strftime("%Y-%m-%d"))
        #    dags.append(d)        
        else:
            print('dag instance condition not met for execution hour:', d.data_interval_end.strftime("%Y-%m-%d %H"))
            print('dag instance condition not met for execution date: ', d.data_interval_end.strftime("%Y-%m-%d"))
            print('dag instance condition not satisfied')
    return len(dags) >= 1

