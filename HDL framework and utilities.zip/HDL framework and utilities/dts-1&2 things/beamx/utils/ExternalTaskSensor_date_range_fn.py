from airflow.sensors.external_task import ExternalTaskSensor
from airflow.models import DagRun
from airflow.utils.state import State
from airflow.utils.session import provide_session
from datetime import datetime, date, timedelta, timezone, tzinfo
import pytz
from airflow.models.dag import DAG
from airflow.operators.python import get_current_context
import pendulum

def date_range_fn(context, for_any_last_exec_flag, delta_hour, delta, dag_query_days, threshold, op_kwargs):
    """Returns a 24-hour interval(start_date, end_date). """
    #start_date = execution_date - timedelta(days = 2)
    #end_date = execution_date
    
    print("Inside date_range_fn")
    print("context is: ", context)
    tz = op_kwargs.get("tz")
    print("Timezone is: ", tz)
    date_end = str(context['data_interval_end']) 
    ds = (datetime.strptime(context['ds'], '%Y-%m-%d'))
    date_end = date_end[:19] 
    date_end =date_end.replace(' ','T')
    # macro data_interval_end prints in this format '2022-11-22T03:00:00+00:00'. 
    dt = datetime.strptime(date_end, '%Y-%m-%dT%H:%M:%S') 
    dt_s = datetime.strftime(dt, '%Y-%m-%d')
    dt_hr = datetime.strftime(dt, '%Y-%m-%d %H') 
    print('dag interval end date: ', date_end, 'for dag execution date: ', str(ds)[:10])
    print('for any last execution date flag :',for_any_last_exec_flag )
    print('Dag Query Number of Days :', dag_query_days)
    print('previous run delta days: ', delta)
    print('for any previous run threshold # of Days: ', threshold)
    print("dt_hr is", dt_hr)
    t = datetime.now()
    delta_date = (datetime.strptime(dt_s, "%Y-%m-%d") - timedelta(days=delta)).strftime("%Y-%m-%d") # 2024-11-21
    delta_hr = (datetime.strptime(dt_hr, "%Y-%m-%d %H") - timedelta(hours=delta_hour)).strftime("%Y-%m-%d %H") # 2024-11-21 13
    print('delta date', delta_date)
    print('delta hour', delta_hr)
    # date range query filter for dag run instances:
    dag_run_start_date = (datetime.strptime(dt_s, "%Y-%m-%d") - timedelta(days=dag_query_days)).astimezone(tz) # 2024-11-21
    if 'start_time' in op_kwargs.keys():
        start_time = op_kwargs.get("start_time")
        print("provided start time in metadata json is",start_time)
        if start_time != 'None':
            start_time = op_kwargs.get("start_time")
            print("Start time found under op_kwargs start time changes to:",start_time)
            combined_dt_s=f"{dt_s} {start_time}"
            print("combined_dt_s is:",combined_dt_s)  
            dag_run_start_date = (datetime.strptime(combined_dt_s, "%Y-%m-%d %H:%M:%S") - timedelta(days=dag_query_days)).astimezone(tz) # 2024-11-21
            print("combined_dt_s is:",dag_run_start_date)
    dag_run_end_date = datetime.strptime(t.strftime('%Y-%m-%d %H:%M:%S'), "%Y-%m-%d %H:%M:%S").astimezone(tz)
    print('Dag Query Start Date is :', dag_run_start_date)
    print('Dag Query End Date is: ', dag_run_end_date)
    # Hour
    dependency_delta_hourly = delta_hour
    ld_dt = None
    ld_hr = None
    # for previous dag runs delta is <> 0 and ld_dt is the delta date = child dag's  interval end date - # days of delta
    if delta != 0 and for_any_last_exec_flag == 0:
        ld_dt = delta_date
        print('Previous Run Load Date is: ', ld_dt)
    if delta_hour != 0 and for_any_last_exec_flag == 0:
       ld_hr = delta_hr
       print('Previous Run Load Hour is:', ld_hr)
    # for current loads: ld_dt is child dag current interval end date
    if delta == 0 and for_any_last_exec_flag == 0:
        ld_dt = dt_s
        print('Current Load Dt is: ', ld_dt)
    if delta_hour == 0 and for_any_last_exec_flag == 0:
        ld_hr = dt_hr
        print('Current Load Hr is :', ld_hr)
    print("ld_hr is", ld_hr)
    print("ld_dt is", ld_dt)
    
    print(f"start_date: {dag_run_start_date}, end_date: {dag_run_end_date}")
    return dag_run_start_date, dag_run_end_date, ld_dt, ld_hr, dt_s