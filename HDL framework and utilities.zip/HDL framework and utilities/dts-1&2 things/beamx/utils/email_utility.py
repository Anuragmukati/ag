import requests
import json
import sys
import pytz

from airflow.models import Variable
from datetime import datetime

from datetime import date, timedelta, timezone, tzinfo
from functools import reduce
from airflow.utils.email import send_email

      
def send_email_footer(recipient_email,subject,html_content,dag):
    to_email=recipient_email
    subject=subject
    body=html_content
    dag=dag
    send_email(to_email, subject, body)
