"""
File Name: custom_spark_job.py
Description: This python script is used to execute a custom pyspark script given by the users in the metadata.
"""
from datetime import datetime
from airflow.providers.google.cloud.hooks.bigquery import BigQueryHook
from airflow.providers.google.cloud.hooks.gcs import GCSHook
from airflow.providers.google.cloud.hooks.dataproc import DataprocHook
from datetime import date, timedelta, timezone, tzinfo
from google.cloud import bigquery
from google.cloud import storage
from airflow.models import TaskInstance
from functools import reduce
from airflow.operators.python import task, get_current_context
import logging
import pandas as pd
import io
import os
import traceback
import json
import sys
import re
import pytz
from datetime import date, timedelta, timezone, tzinfo
import pendulum
from collections import OrderedDict
import numpy as np
from airflow.models import DagRun
from croniter import croniter
import google.auth.transport.requests
from airflow.operators.email_operator import EmailOperator


tz = pendulum.timezone("EST")


"""
get the labels to be passed to the dataproc job
"""
def getLabelsDict(labelsList, dagId,run_id,task_id, composer_name):
    labels_dict = {
        "job_id": dagId.lower()[-63:],
        "task_type": "custom_spark_job",
        "run_id": re.sub(r'[^A-Za-z0-9 _-]+', '', run_id).lower()[-63:],
        "task_id": task_id.lower().replace('.', "")[-63:],
        "instance_name": composer_name.lower()
    }

    return labels_dict

"""
get the parameters to send to observability logs
"""
def getObsParams(bucketNameVars, variables, params, projectDetails, dagId, tz, dict_obs):

    #get the variable map based on the project
    projectTag = projectDetails[0]
    varMap = variables[ projectTag+"_vars"]

    dict_obs["process_date"] = str(date.today().strftime("%Y-%m-%d"))
    dict_obs["start_time"] = str(datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"))
    dict_obs["process_name"] = dagId
    dict_obs["gcp_project"] = varMap[ params["hook"]["projectId"] ]

    return dict_obs


"""
Send oservability logs to logger
"""
def sendObsLogs(context, params, dict_obs, varMap, projectSpace, tz, error_msg,
                run_status, current_task, last_task):
    # import the necessary modules
    BASE_DIR = "/home/airflow/gcs/dags/" + projectSpace + "/beamx"
    sys.path.append(f"{BASE_DIR}/utils")
    import observability

    dict_obs["end_time"] = datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S")
    dict_obs_static = str(params["obs"])
    dict_obs_static = json.loads(
        (reduce(lambda key, value: key.replace(*value), varMap.items(), dict_obs_static)).replace("'", '"'))
    dict_obs.update(dict_obs_static)
    dict_obs["process_date"] = str(date.today().strftime("%Y-%m-%d"))
    data_interval_endtime = context['data_interval_end'].in_timezone(tz)
    dict_obs["run_date"] = str(data_interval_endtime.strftime('%Y%m%d'))
    dict_obs["run_day"] = str(data_interval_endtime.strftime('%A'))
    dict_obs["run_hour"] = str(data_interval_endtime.strftime("%H:%M:%S"))
    dict_obs["error_message"] = error_msg
    dict_obs["run_status"] = run_status
    dict_obs["log_file"] = varMap['log_file']

    try:

        ## passing the process end time based on that task sequence in the dag ##
        logger_name = params["obs"]["logger_name"]
        if last_task is not None and current_task in last_task:
            dict_obs["process_end_time"] = datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S")
        else:
            print(" current task not in last task ")
            print(" current task is ", current_task)
            print(" last task is ", last_task)
            dict_obs["process_end_time"] = "NA"
        print ("dict_obs : ", dict_obs)
        observability.ingestion_obs(dict_obs, logger_name)
    except Exception as e:
        error_msg = str(e)
        print("error_msg : ", error_msg)
        logging.error(traceback.format_exc())
        print("Could not send observability log")
    return dict_obs


"""
Function to check pre-requisites and fetch load job configuration 
"""

def createSparkJobConfig(params, dagId, projectDetails, tz, context, bucketNameVars, variables, ingestionPattern, opsgenie_priority, superGroupId, custom_labels, alertTeamName,sub_lob_alert, taskType, serverless, taskId):
    
    # get the variable map based on the project
    projectTag = projectDetails[0]
    project_space = projectDetails[2]
    varMap = variables[projectTag + "_vars"]

    # import the necessary modules
    BASE_DIR = "/home/airflow/gcs/dags/" + project_space+ "/beamx"
    sys.path.append(f"{BASE_DIR}/utils")
    import observability
    from ops_genie import send_alert_to_opsgenie

    try:
        #get dict_obs
        dict_obs = context['ti'].xcom_pull(key='dict_obs')

        dataprocConfigDict = variables["dataproc_config_custom_spark_job"]
        project_id = variables["projectId"] if "project_id" not in params['hook'] else params['hook']['project_id']
        cluster_label = dataprocConfigDict["cluster_label"]
        region = dataprocConfigDict['region']
        file_uri = dataprocConfigDict['bucket_name']+params["hook"]["file_uri"]
        staging_bucket = dataprocConfigDict["staging_bucket"]
        temp_bucket = dataprocConfigDict["temp_bucket"]
        service_account = dataprocConfigDict["service_account"]
        subnetwork_uri = dataprocConfigDict["subnetwork_uri"]
        phs_cluster_path = dataprocConfigDict["phs_cluster_path"]
        serverless_version = str(dataprocConfigDict["serverless_version"])
        kms_key = dataprocConfigDict["kms_key"]

        # get the labels
        run_id = context['dag_run'].run_id
        task_id = context['task'].task_id
        import os
        composer_name = os.getenv('COMPOSER_ENVIRONMENT')
        labels_dict = getLabelsDict(custom_labels, dagId, run_id, task_id, composer_name)

        # get obs static and dynamic parameters
        dict_obs =getObsParams(bucketNameVars, variables, params, projectDetails, dagId, tz, dict_obs)
        context['ti'].xcom_push(key='dict_obs_dataproc_prep', value=dict_obs)

        # spark application name
        spark_app_name = taskId.lower() + dict_obs["start_time"]
        spark_args = params["hook"]["custom_args"] if "custom_args" in params["hook"] else ""
        spark_jars = params["hook"]["extra_jars"] if "extra_jars" in params["hook"] else ""

        args = []
        #defaultArgs = f"{{\"projectId\": {project_id}, \"region\": {region}, \"varMap\" : {varMap}, \"params\": {params}, \"bucketNameVars\" : {bucketNameVars} }}"
        defaultArgs = {"projectId" : project_id, "region" : region, "yamlVariables" : varMap, "params" : params, "bucketNameVars" : bucketNameVars}
        defaultArgsStr = json.dumps(defaultArgs)
        args.append(defaultArgsStr)

        if spark_args != '':
            for element in spark_args:
                args.append(element)

        jar_file_uri = []
        if spark_jars != '':
            for element in spark_jars:
                jar_file_uri.append(bucketNameVars['SQL_BUCKET']+'/'+element)


        # create pyspark job config
        if serverless:

            # pyspark job properties
            properties = {
                "spark.app.name": spark_app_name,
                "spark.sql.legacy.parquet.int96RebaseModeInRead": "CORRECTED",
                "spark.sql.legacy.parquet.int96RebaseModeInWrite": "CORRECTED",
                "spark.sql.legacy.parquet.datetimeRebaseModeInRead": "CORRECTED",
                "spark.sql.legacy.parquet.datetimeRebaseModeInWrite": "CORRECTED",
                "spark.dynamicAllocation.enabled": "true",
                "spark.dynamicAllocation.initialExecutors": "15",  # // Assuming 4 cores per executor
                "spark.dynamicAllocation.minExecutors": "5",
                "spark.dynamicAllocation.maxExecutors": "400",
                "spark.dynamicAllocation.executorAllocationRatio": "1.0",
                "spark.dynamicAllocation.executorIdleTimeout": "5m",
                "spark.dynamicAllocation.cachedExecutorIdleTimeout": "5m",
                "spark.redaction.regex": "(?i)secret|password|token|access[.]key",
                "spark.redaction.string.regex":"(?i)secret|password|dbpass|token",
                "spark.hadoop.fs.gs.system.bucket": temp_bucket
            }

            # update spark properties if custom spark configuration sent from user metadata
            if "spark_conf" in params["hook"]:
                spark_conf = params["hook"]["spark_conf"]
                if "overwrite_default_properties" in params["hook"] and params["hook"][
                    "overwrite_default_properties"] == 'yes':
                    properties = {"spark.app.name": spark_app_name,
                                  "spark.redaction.regex": "(?i)secret|password|token|access[.]key",
                                  "spark.redaction.string.regex":"(?i)secret|password|dbpass|token"}
                    properties.update(spark_conf)
                else:
                    properties.update(spark_conf)

            batch_id = taskId.lower().replace("_", "-").replace(".","-")
            batch_id = (batch_id[:55]) if len(batch_id) > 56 else batch_id

            run_id_dag = str(context["dag_run"].run_id)[0: str(context["dag_run"].run_id).index("+")] \
                             .replace(".", "-").replace(":", "-").replace("__", "-").lower()[:61]
            batch_id = batch_id + "-" + run_id_dag
            batch_id = batch_id[:61]
            if batch_id.endswith("-"):
                batch_id = batch_id[:-1]

            pyspark_job_config = {
                "pyspark_batch": {
                    "main_python_file_uri": file_uri,
                    "jar_file_uris": jar_file_uri,
                    "args": args
                },
                "labels": labels_dict,
                "runtime_config": {
                    "version": serverless_version,
                    "properties": properties
                },
                "environment_config": {
                    "execution_config": {
                        "service_account": service_account,
                        "subnetwork_uri": subnetwork_uri,
                        "kms_key": kms_key,
                        "staging_bucket": staging_bucket
                    },

                },
            }
            if "phs_cluster" in params["hook"]:
                if params["hook"]["phs_cluster"].lower() == "yes":
                    phs_config = {"peripherals_config": {
                        "spark_history_server_config": {
                            "dataproc_cluster": phs_cluster_path,
                        },
                    },
                    }
                    pyspark_job_config["environment_config"].update(phs_config)

            return {'pyspark_job_config': pyspark_job_config, 'region': region, 'project_id': project_id,
                    'gcp_conn_id': params["hook"]["gcp_conn_id"], 'batch_id' : batch_id, 'run_status' : 'success', 'dict_obs' : dict_obs}

        else:

            # pyspark job properties
            properties = {
                "spark.master": "yarn",
                "spark.app.name": spark_app_name,
                "spark.submit.deployMode": "cluster",
                "spark.ui.view.acls": "*",
                "spark.sql.legacy.parquet.int96RebaseModeInRead": "CORRECTED",
                "spark.sql.legacy.parquet.int96RebaseModeInWrite": "CORRECTED",
                "spark.sql.legacy.parquet.datetimeRebaseModeInRead": "CORRECTED",
                "spark.sql.legacy.parquet.datetimeRebaseModeInWrite": "CORRECTED",
                "spark.redaction.regex": "(?i)secret|password|token|access[.]key",
                "spark.redaction.string.regex":"(?i)secret|password|dbpass|token"
            }

            # update spark properties if custom spark configuration sent from user metadata
            if "spark_conf" in params["hook"]:
                spark_conf = params["hook"]["spark_conf"]
                if "overwrite_default_properties" in params["hook"] and params["hook"][
                    "overwrite_default_properties"] == 'yes':
                    properties = {"spark.app.name": spark_app_name,
                                  "spark.redaction.regex": "(?i)secret|password|token|access[.]key",
                                  "spark.redaction.string.regex":"(?i)secret|password|dbpass|token"}
                    properties.update(spark_conf)
                else:
                    properties.update(spark_conf)


            job_id = taskId.lower().replace("_", "-").replace(".","-")
            job_id = (job_id[:55]) if len(job_id) > 56 else job_id

            run_id_dag = str(context["dag_run"].run_id)[0: str(context["dag_run"].run_id).index("+")] \
                             .replace(".", "-").replace(":", "-").replace("__", "-").lower()[:61]
            job_id = job_id + "-" + run_id_dag
            job_id = job_id[:61]
            if job_id.endswith("-"):
                job_id = job_id[:-1]

            # pyspark job configuration
            pyspark_job_config = {"reference": {"project_id": project_id, "job_id": job_id},
                                  "placement": {"cluster_labels": cluster_label},
                                  "labels": labels_dict,
                                  "pyspark_job": {
                                      "main_python_file_uri": file_uri,
                                      "properties": properties,
                                      "jar_file_uris": jar_file_uri,
                                      "args": args
                                  }
                                  }

            return {'pyspark_job_config' : pyspark_job_config, 'region' : region, 'project_id' : project_id, 'gcp_conn_id' : params["hook"]["gcp_conn_id"], 'run_status' : 'success', 'dict_obs': dict_obs}

    except Exception as e:
        print("error while creating the custom spark job config: ", str(e))
        logging.error(traceback.format_exc())
        return{'run_status' : 'failure', 'error_message' : 'error while creating the custom spark job config', 'dict_obs': dict_obs}

   
"""
This function is to send observability logs
"""


def sendObservabilityLogs(context, variables, params, projectDetails, dagId, tz, opsgenie_priority,
                 ingestionPattern,alertTeamName,sub_lob_alert, last_task, getSparkJobConfigResult):
    # get the variable map based on the project
    projectTag = projectDetails[0]
    project_space = projectDetails[2]
    varMap = variables[projectTag + "_vars"]

    # import the necessary modules
    BASE_DIR = "/home/airflow/gcs/dags/" + project_space+ "/beamx"
    sys.path.append(f"{BASE_DIR}/utils")
    from email_utility import send_email_footer
    import observability
    from ops_genie import send_alert_to_opsgenie



    # get the error message if the upstream task failed
    error_message = context['ti'].xcom_pull(task_ids = next(iter(context['task'].upstream_task_ids)), key='error_message')
    sparkJobRunStatus = "failure" if error_message is not None else "success"

    # observability logging
    dict_obs = getSparkJobConfigResult['dict_obs']
    dict_obs = sendObsLogs(context, params, dict_obs, varMap, project_space, tz,
                           error_message, sparkJobRunStatus , context['task'].task_id, last_task)
    if getSparkJobConfigResult['run_status'] == 'failure':
        error_message = "Error occurred while creating the config for custom spark job"

    #opsgenie alerting
    if getSparkJobConfigResult['run_status'] == 'failure' or sparkJobRunStatus == 'failure':
        print("sending Opsgenie alert as custom spark job failed...")
        task_instance = context['task_instance']
        opsgenie_message = "Beamx|" + variables["environment"] + "|Failure|" + task_instance.task_id + "|" + dict_obs[
            'running_instance_id']
        opsgenie_description = "Failure | Custom Spark Job Failed with run_status == 'FAILURE'|" + \
                               dict_obs['running_instance_id']
        opsgenie_details = {"DAG ID": dagId, "Error Step": "custom spark job",
                            "Error Message": error_message}
        send_alert_to_opsgenie(opsgenie_message, opsgenie_description, opsgenie_details, opsgenie_priority,
                               projectDetails=projectDetails,alertTeamName=alertTeamName,sub_lob_alert=sub_lob_alert)



